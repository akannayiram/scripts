#!/bin/bash
# *****************
#  N O N - P R O D
#
#   S T A R T   W E B   D O M A I N S
# *****************
#set -x
LOGSDIR=$HOME/logsdir/web
[[ ! -d "$LOGSDIR" ]] && mkdir -p $LOGSDIR

actn=start

# For NP MX
pillar=cs
limit_hosts=np${pillar}web

##limit_hosts=npihweb
##limit_hosts=npfsweb
##limit_hosts=nphcweb
##limit_hosts=npcsweb

teelog=${LOGSDIR}/${HOSTNAME}.$(logname).${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

sttm="BEGIN: Playbook: [play.yml] Action: [$actn]: $(date)"
echo $sttm
ansible-playbook play.yml --limit "$limit_hosts" -e actn="$actn" | tee -a $teelog
echo "CHECKING THE LOG"
grep "PID at end " $teelog|sort|nl
echo $sttm
echo "END:   Playbook: [play.yml] Action: [$actn]: $(date)"
echo "Log: $teelog"
