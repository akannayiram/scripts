#!/bin/bash
#echo "Running on [$HOSTNAME] as [$LOGNAME]"

# np - actual count: 1
np_min_pid_count=1
# prod - actual count: 1
prod_min_pid_count=1
# perf - actual count: 1
perf_min_pid_count=1

hst=$(echo "$HOSTNAME"|cut -d"." -f1)
[[ "$hst" =~ np ]] && min_pid_count=$np_min_pid_count
[[ "$hst" =~ pf ]] && min_pid_count=$perf_min_pid_count
[[ "$hst" =~ pr ]] && min_pid_count=$prod_min_pid_count

#pidcnt=$(ps -eo "pid,command,user"|grep cnyrb|grep java|grep -v grep|wc -l)
pidcnt=$(ps -aef|grep java|grep Elasticsearch|grep -v grep|wc -l)
[[ "$pidcnt" -ge $min_pid_count ]] && { echo "UP - Elasticsearch has [$pidcnt] processes running on [$hst] [Expected Min count: $min_pid_count]"; exit; } || { echo "DOWN - Elasticsearch has [$pidcnt] processes running on [$hst] [Expected Min count: $min_pid_count]"; exit; }
