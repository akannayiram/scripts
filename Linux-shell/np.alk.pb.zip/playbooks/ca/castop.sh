#!/bin/bash
echo "Running on [$HOSTNAME] as [$LOGNAME]"
cd bin
pwd
./stop_clnaddrd.sh
