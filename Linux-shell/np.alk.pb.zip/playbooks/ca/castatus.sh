#!/bin/bash
#echo "Running on [$HOSTNAME] as [$LOGNAME]"

# np - actual count: 19
np_min_pid_count=15
# prod - actual count: 24
prod_min_pid_count=20
# perf - actual count: 8
perf_min_pid_count=5

hst=$(echo "$HOSTNAME"|cut -d"." -f1)
[[ "$hst" =~ np ]] && min_pid_count=$np_min_pid_count
[[ "$hst" =~ pf ]] && min_pid_count=$perf_min_pid_count
[[ "$hst" =~ pr ]] && min_pid_count=$prod_min_pid_count

#pidcnt=$(ps -eo "pid,comm,user" |grep cnyclnaddr|wc -l)
pidcnt=$(ps -aef|grep clnaddrd|grep -v grep|wc -l)
[[ "$pidcnt" -ge $min_pid_count ]] && { echo "UP - CleanAddress has [$pidcnt] processes running on [$hst] [Expected Min count: $min_pid_count]"; exit; } || { echo "DOWN - CleanAddress has [$pidcnt] processes running on [$hst] [Expected Min count: $min_pid_count]"; exit; }
