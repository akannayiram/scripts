#!/bin/bash
#echo "Running on [$HOSTNAME] as [$LOGNAME]"

# np - actual count: 5 to 12
np_min_pid_count=5
# prod - actual count: 6 on 2 hots, 7 on 2 hosts
prod_min_pid_count=6
# perf - actual count: 6
perf_min_pid_count=6

hst=$(echo "$HOSTNAME"|cut -d"." -f1)
[[ "$hst" =~ dev ]] && min_pid_count=$np_min_pid_count
[[ "$hst" =~ prf ]] && min_pid_count=$perf_min_pid_count
[[ "$hst" =~ prd ]] && min_pid_count=$prod_min_pid_count
pidcnt=$(ps -aef|grep ohs|grep httpd.conf|grep -v grep|wc -l)
[[ "$pidcnt" -ge $min_pid_count ]] && { echo "UP - OHS has [$pidcnt] processes running on [$hst] [Expected Min count: $min_pid_count]"; exit; } || { echo "DOWN - OHS has [$pidcnt] processes running on [$hst] [Expected Min count: $min_pid_count]"; exit; }
