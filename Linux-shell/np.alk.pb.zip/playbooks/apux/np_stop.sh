#!/bin/bash
# *****************
#  N O N - P R O D
#
#   S T O P    D O M A I N S
# *****************
#set -x
LOGSDIR=$HOME/logsdir/apux
[[ ! -d "$LOGSDIR" ]] && mkdir -p $LOGSDIR

actn=stop

# For NP MX
pillar=cs
limit_hosts=np${pillar}appprcs

##limit_hosts=npihappprcs
##limit_hosts=npfsappprcs
##limit_hosts=nphcappprcs
##limit_hosts=npcsappprcs

starttime="BEGIN: Playbook: [play.yml] Action: [$actn]: $(date)"
teelog=${LOGSDIR}/${HOSTNAME}.$(logname).${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log
echo "$starttime" > $teelog

./np_exec_play.sh $actn $limit_hosts | tee -a $teelog

# Parse the log file
./apux_parse_logs.sh "$teelog"
echo "CHECKING THE LOG"
grep -B 2 BBL "$teelog"|grep "STDOUT"|sort|nl
echo "Log: $teelog"
echo "$starttime"
echo "END:   Playbook: [play.yml] Action: [$actn]: $(date)"
