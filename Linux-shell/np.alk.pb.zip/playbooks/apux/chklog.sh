#!/bin/bash
# Check the log
logfile=$1

#grep STDOUT $logfile|sed -e "s/^.* on //"|awk '{print $1}'|sort -u
#grep STDERR $logfile|sort

stdoutcnt=$(grep STDOUT $logfile|wc -l)
echo "STDOUT Count: [$stdoutcnt]"
stderrcnt=$(grep STDERR $logfile|wc -l)
echo "STDERR Count: [$stderrcnt]"
