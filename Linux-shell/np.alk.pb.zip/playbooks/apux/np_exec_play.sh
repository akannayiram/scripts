#!/bin/bash
# *****************
#  N O N - P R O D
#
#    Usage: Pass two input parameters
#       1) Action (start, stop, purge or sstatus)
#       2) Host or Host group (limit_hosts)
# *****************
#set -x
#
# C O N S T A N T S
#
#ENV

[[ $# -ne 2 ]] && { echo "ERROR! Two input parameters are required for [$0]. Aborting...."; exit; }

actn=$1
[[ "$actn" == "status" ]] && actn=sstatus
[[ "$actn" != "sstatus" && "$actn" != "start" && "$actn" != "stop" && "$actn" != "purge" ]] && { echo "ERROR! [$actn] is invalid input parameter"; exit; }

# Limit the number of hosts
#limit_hosts=npfsprcs
#limit_hosts=fs92npux051
limit_hosts=$2
[[ ! "$limit_hosts" =~ np ]] && { echo "ERROR! [$limit_hosts] is invalid host or host group. Please check and try again. Aborting...."; exit; }

# Set COMMON_DIR
#export COMMON_DIR=$HOME/playbooks/appprcs/common

#cd $COMMON_DIR

# Set the environment
#. $COMMON_DIR/setenv.sh

sttm="BEGIN: Playbook: [play.yml] Action: [$actn]: $(date)"
echo $sttm
ansible-playbook play.yml --limit "$limit_hosts" -e actn="$actn"
echo $sttm
echo "END:   Playbook: [play.yml] Action: [$actn]: $(date)"
