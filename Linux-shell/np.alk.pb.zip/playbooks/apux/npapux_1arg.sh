#!/bin/bash
# *****************
#  APUX
#
# *****************
set -x

[[ $# -ne 1 ]] && { echo "ERROR! Action input parameter is required for [$0]. Aborting...."; exit; }

actn=$1
[[ "$actn" == "status" ]] && actn=sstatus
[[ "$actn" != "sstatus" && "$actn" != "start" && "$actn" != "stop" && "$actn" != "purge" ]] && { echo "ERROR! [$actn] is invalid input parameter"; exit; }

LOGSDIR=$HOME/logsdir/apux
[[ ! -d "$LOGSDIR" ]] && mkdir -p $LOGSDIR

sttm="BEGIN: Playbook: [play.yml] Action: [$actn]: $(date)"
teelog=${LOGSDIR}/${HOSTNAME}.$(logname).${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log
echo "$sttm" > $teelog

# Limit the number of hosts
#limit_hosts=npihappprcs
#limit_hosts=npfsappprcs
#limit_hosts=nphcappprcs
#limit_hosts=npcsappprcs
limit_hosts=ih92npux052

echo $sttm
ansible-playbook play.yml --limit "$limit_hosts" -e actn="$actn" >> $teelog 2>&1
# Parse the log file
./apux_parse_logs.sh "$teelog"
echo "CHECKING THE LOG"
grep -B 2 BBL "$teelog"|grep "STDOUT"|sort|nl
echo "Log: $teelog"
echo $sttm
echo "END:   Playbook: [play.yml] Action: [$actn]: $(date)"

