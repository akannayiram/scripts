#!/bin/bash
# *****************
#  APUX
#    Usage: Pass two input parameters
#       1) Action (start, stop, purge or sstatus)
#       2) Host or Host group (limit_hosts)
# *****************

#set -x

[[ $# -ne 2 ]] && { echo "ERROR! Two input parameters are required for [$0]. Aborting...."; exit; }

actn=$1
[[ "$actn" == "status" ]] && actn=sstatus
[[ "$actn" != "sstatus" && "$actn" != "start" && "$actn" != "stop" && "$actn" != "purge" ]] && { echo "ERROR! [$actn] is invalid input parameter"; exit; }

limit_hosts=$2
[[ ! "$limit_hosts" =~ np ]] && { echo "ERROR! [$limit_hosts] is invalid host or host group. Please check and try again. Aborting...."; exit; }


LOGSDIR=$HOME/logsdir/apux
[[ ! -d "$LOGSDIR" ]] && mkdir -p $LOGSDIR

sttm="BEGIN: APUX Host Group: [$limit_hosts] Action: [$actn]: $(date)"
echo $sttm
teelog=${LOGSDIR}/${HOSTNAME}.$(logname).${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log
echo "$sttm" > $teelog

#ansible-playbook play.yml --limit "$limit_hosts" -e actn="$actn" >> $teelog 2>&1
ansible-playbook play.yml --limit "$limit_hosts" -e actn="$actn"  2>&1 | tee -a $teelog

endtm="END:   APUX Host Group: [$limit_hosts] Action: [$actn]: $(date)"
echo "$endtm" >> $teelog

# Parse the log file
./apux_parse_logs.sh "$teelog"
echo "CHECKING THE LOG"
#[[ "$actn" == "stop" ]] && grep "STDOUT - " "$teelog"|sort|nl || grep -B 2 BBL "$teelog"|grep "STDOUT - "|sort|nl
grep "STDOUT - " "$teelog"|sort|nl

echo "Log: $teelog"
echo $sttm
echo $endtm

