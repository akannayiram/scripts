#!/bin/bash
#echo "Running on [$HOSTNAME] as [$LOGNAME]"

# np - actual count: 2
np_min_pid_count=2
# prod - actual count: 4
prod_min_pid_count=4
# perf - actual count: ?
perf_min_pid_count=1

hst=$(echo "$HOSTNAME"|cut -d"." -f1)
[[ "$hst" =~ np ]] && min_pid_count=$np_min_pid_count
[[ "$hst" =~ pf ]] && min_pid_count=$perf_min_pid_count
[[ "$hst" =~ pr ]] && min_pid_count=$prod_min_pid_count

#pidcnt=$(ps -eo "pid,command,user"|grep cnyrb|grep java|grep -v grep|wc -l)
pidcnt=$(ps -aef|grep cnyrb|grep RoboRegistrar|grep java|grep -v grep|wc -l)
[[ "$pidcnt" -ge $min_pid_count ]] && { echo "UP - RoboReg has [$pidcnt] processes running on [$hst] [Expected Min count: $min_pid_count]"; exit; } || { echo "DOWN - RoboReg has [$pidcnt] processes running on [$hst] [Expected Min count: $min_pid_count]"; exit; }
