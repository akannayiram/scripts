#!/bin/bash
# ######################################
#   Al Kannayiram 
#      June 2024 
# 
#     Parse ansible log from APUX start/stop/status
#
# ######################################
#

[[ -z "$1" ]] && { echo "ERROR! Log file input paramter is required. Aborting..."; exit 1; }
[[ ! -f "$1" ]] && { echo "ERROR! Input Log file [$1] is missing. Aborting..."; exit 1; }
[[ ! -r "$1" ]] && { echo "ERROR! Input Log file [$1] is not readable. Aborting..."; exit 1; }

INPLOG="$1"

# Temporary file to save the App/Prcs Domain names from Ansible log
APUXDOM=/tmp/apux_doms_from_ansible_log.$$.tmp;rm -f $APUXDOM
echo -e "Hostname \t User \t Domain \t DomType" > $APUXDOM
#ERRCNT=$(grep ERROR $INPLOG|wc -l)

# Get the 'fatal' lines count
FATALCNT=$(grep "^fatal" $INPLOG|wc -l)

# Get the total count from PLAY RECAP
#TOTALPLAY=$(grep "ok=" $INPLOG|grep "failed="|wc -l)
#TOTALPLAY=$(grep "Execute psadmin command for App/Prcs domains" "$INPLOG"|wc -l)
TOTALPLAY=$(grep "^ok:.*=>" "$INPLOG"|wc -l)
# Get the 'failed' count from PLAY RECAP
FAILPLAYCNT=$(grep "ok=" $INPLOG|grep -v "failed=0 "|wc -l)

# Get the App/Prcs count breakup
APPCNT=0; CSAPPCNT=0; IHAPPCNT=0; HCAPPCNT=0; FSAPPCNT=0 
PRCSCNT=0; CSPRCSCNT=0; IHPRCSCNT=0; HCPRCSCNT=0; FSPRCSCNT=0 
#for i in $(grep "STDOUT - Executed" $INPLOG)
TMPFILE=/tmp/apux_log_stdout.$$.tmp;rm -f $TMPFILE
grep "STDOUT - Executed" "$INPLOG" > $TMPFILE
while read -r i
do
  hst=$(echo "$i"|awk '{print $5}')
  usr=$(echo "$i"|awk '{print $7}')
  dom=$(echo "$i"|awk '{print $14}')
  if [[ "$hst" =~ [cfhi].*ap ]] ; then 

  APPCNT=$(( APPCNT + 1 ))
  [[ "$hst" =~ cs.*ap ]] && CSAPPCNT=$(( CSAPPCNT + 1 ))
  [[ "$hst" =~ ih.*ap ]] && IHAPPCNT=$(( IHAPPCNT + 1 ))
  [[ "$hst" =~ hc.*ap ]] && HCAPPCNT=$(( HCAPPCNT + 1 ))
  [[ "$hst" =~ f[is].*ap ]] && FSAPPCNT=$(( FSAPPCNT + 1 ))

  echo -e "$hst \t $usr \t $dom \t App" >> $APUXDOM

  fi

  if [[ "$hst" =~ [cfhi].*ux ]] ; then


  PRCSCNT=$(( PRCSCNT + 1 ))
  [[ "$hst" =~ cs.*ux ]] && CSPRCSCNT=$(( CSPRCSCNT + 1 ))
  [[ "$hst" =~ ih.*ux ]] && IHPRCSCNT=$(( IHPRCSCNT + 1 ))
  [[ "$hst" =~ hc.*ux ]] && HCPRCSCNT=$(( HCPRCSCNT + 1 ))
  [[ "$hst" =~ f[is].*ux ]] && FSPRCSCNT=$(( FSPRCSCNT + 1 ))

  echo -e "$hst \t $usr \t $dom \t Prcs" >> $APUXDOM
  fi

done < $TMPFILE

# delete the temp file
rm -f $TMPFILE

[[ "$FATALCNT" -eq 0 && "$FAILPLAYCNT" -eq 0 ]] && MSG="SUCCESS" || MSG="ERRORS FOUND"

# Echo display the results
echo "###########################"
echo "ANSIBLE PLAY RESULTS: $MSG"
date
echo " "
echo "Total domain count:  $TOTALPLAY"
#echo "   App domains: $APPCNT  CS App:  $CSAPPCNT  IH App:  $IHAPPCNT  HC App:  $HCAPPCNT  FS App:   $FSAPPCNT"
#echo "  Prcs domains: $PRCSCNT  CS Prcs: $CSPRCSCNT  IH Prcs: $IHPRCSCNT  HC Prcs: $HCPRCSCNT  FS Prcs:  $FSPRCSCNT"
echo -e "   App domains:  $APPCNT \t CS: \t $CSAPPCNT \t IH: \t $IHAPPCNT \t HC: \t $HCAPPCNT \t FS: \t $FSAPPCNT"
echo -e "  Prcs domains:  $PRCSCNT \t CS: \t $CSPRCSCNT \t IH: \t $IHPRCSCNT \t HC: \t $HCPRCSCNT \t FS: \t $FSPRCSCNT"
echo " "
echo "Fatal message count: $FATALCNT"
echo "Failed Play count:   $FAILPLAYCNT"
#echo "###########################"
echo "***************************"
echo "F A T A L    M E S S A G E S"
#echo " "
[[ "$FATALCNT" -eq 0 ]] && echo "   N O N E " || grep -n "^fatal" $INPLOG
#echo "###########################"
echo "***************************"
echo "ANSIBLE PLAY RESULTS: $MSG"
date
echo "###########################"
echo "Detailed domains, Hosts: $APUXDOM"
