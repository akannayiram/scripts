#!/bin/bash
# ##############################
# Al Kannayirm 4/30/2025
#   - Update NP start/stop/status scripts
#     with 2-char pillar
#   - Useful during NP MX to work on pillar
# ##############################

[[ $# -ne 1 ]] && { echo "ERROR! please provide pillar parameter!"; exit 1; }
[[ "$1" != "ih" && "$1" != "fs" && "$1" != "hc" && "$1" != "cs" ]] && { echo "ERROR! please provide correct pillar parameter!"; exit 1; }


# 2-char 'pillar' input
inp=$1

# List the current pillar value
grep "^pillar" *st*sh

# select start, top, status scripts in the current dir only
for f in $(find . -maxdepth 1 -type f -name "*start*sh" -o -type f -name "*stop*sh"  -o -type f -name "*status*sh")
do
sed -i -e "s/^pillar=.*$/pillar=${inp}/" "$f"
done

# List the updated pillar value
grep "^pillar" *st*sh

