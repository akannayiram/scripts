#!/bin/bash
# ######################################
#   Al Kannayiram 
#      June 2024 
#   A N S I B L E    W E B    P A R S E    L O G S 
#     Parse ansible log from WEB start/stop/status
#
# ######################################
#
[[ -z "$1" ]] && { echo "ERROR! Log file input paramter is required. Aborting..."; exit 1; }
[[ ! -f "$1" ]] && { echo "ERROR! Input Log file [$1] is missing. Aborting..."; exit 1; }
[[ ! -r "$1" ]] && { echo "ERROR! Input Log file [$1] is not readable. Aborting..."; exit 1; }

INPLOG="$1"

ERRCNT=$(grep "ERROR -" $INPLOG|wc -l)


# Temporary file to save the App/Prcs Domain names from Ansible log
WEBDOM=/tmp/web_doms_from_ansible_log.$$.tmp;rm -f $WEBDOM
echo -e "Hostname \t User \t Domain \t DomType" > $WEBDOM

# Get the 'fatal' lines count
#FATALCNT=$(grep "^fatal" $INPLOG|wc -l)

# Get the total count from PLAY RECAP
#TOTALPLAY=$(grep "ok=" $INPLOG|grep "failed="|wc -l)
TOTALPLAY=$(grep "^ok:.*=>" $INPLOG|wc -l)
TOTALPLAYINCL=$(grep "^included" $INPLOG|wc -l)
# Get the 'failed' count from PLAY RECAP
FAILPLAYCNT=$(grep "ok=" $INPLOG|grep -v "failed=0 "|wc -l)

# Get the web domain breakup by Pillar
WEBCNT=0;CSWEBCNT=0; IHWEBCNT=0;HCWEBCNT=0;FSWEBCNT=0

TMPFILE=/tmp/web_log_stdout.$$.tmp;rm -f $TMPFILE
grep "STDOUT - Executed" "$INPLOG" > $TMPFILE
while read -r i
do
  hst=$(echo "$i"|awk '{print $5}')
  usr=$(echo "$i"|awk '{print $7}')
  cmd=$(echo "$i"|awk '{print $10}')
  if [[ "$hst" =~ [cfhi].*wl ]] ; then 

  WEBCNT=$(( WEBCNT + 1 ))
  [[ "$hst" =~ cs.*wl ]] && CSWEBCNT=$(( CSWEBCNT + 1 ))
  [[ "$hst" =~ ih.*wl ]] && IHWEBCNT=$(( IHWEBCNT + 1 ))
  [[ "$hst" =~ hc.*wl ]] && HCWEBCNT=$(( HCWEBCNT + 1 ))
  [[ "$hst" =~ f[is].*wl ]] && FSWEBCNT=$(( FSWEBCNT + 1 ))

  echo -e "$hst \t $usr \t $cmd" >> $WEBDOM

  fi

done < $TMPFILE

# delete the temp file
#rm -f $TMPFILE


[[ "$ERRCNT" -eq 0 && "$FAILPLAYCNT" -eq 0 ]] && MSG="SUCCESS" || MSG="ERRORS FOUND"

# Echo display the results
echo "###########################"
echo "WEB - ANSIBLE PLAY RESULTS: $MSG"
date
echo " "
echo "Total domain count:  $TOTALPLAY     Total included task count:  $TOTALPLAYINCL"
echo -e "   Web domains:  $WEBCNT \t CS: \t $CSWEBCNT \t IH: \t $IHWEBCNT \t HC: \t $HCWEBCNT \t FS: \t $FSWEBCNT"
echo " "
echo "Failed Play count:   $FAILPLAYCNT"
echo "ERROR message count: $ERRCNT"
#echo "###########################"
echo "***************************"
echo "E R R O R    M E S S A G E S"
#echo " "
[[ "$ERRCNT" -eq 0 ]] && echo "   N O N E " || grep -n "ERROR -" $INPLOG
#echo "###########################"
echo "***************************"
echo "ANSIBLE PLAY RESULTS: $MSG"
date
echo "###########################"
