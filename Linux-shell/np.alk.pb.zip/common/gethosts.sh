#!/bin/bash

# To get hosts for a group
grp=$1

# To list the hosts
ansible-inventory --graph $grp|grep -v "@"|sed -e "s/^.*--//"|sort

# Remove the group names(@) from the output 
cnt=$(ansible-inventory --graph $grp|grep -v "@"|wc -l)
echo " "
echo "Number of hosts: [$cnt]"
