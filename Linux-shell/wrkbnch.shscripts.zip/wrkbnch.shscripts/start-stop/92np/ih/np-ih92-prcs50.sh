#!/bin/bash
#set -x
# Commands genersted on the fly using the script grep_BBL.v2.sh
# IH NP PRCS servers ih92npux050 and ih92npux051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
actn=$1
[[ "$actn" == "status" ]] && actn="sstatus"
echo "Input param is [$actn]"
else
echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
exit
fi

#akannayiram@ih92npux050 $ /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
date
echo "sudo su - cnyihdm2 -c \"psadmin -p $actn -d CNYIHDM2\"" -t ih92npux050 
bolt command run "sudo su - cnyihdm2 -c \"psadmin -p $actn -d CNYIHDM2\"" -t ih92npux050 --tty
date
echo "sudo su - cnyihug2 -c \"psadmin -p $actn -d CNYIHUG2\"" -t ih92npux050 
bolt command run "sudo su - cnyihug2 -c \"psadmin -p $actn -d CNYIHUG2\"" -t ih92npux050 --tty
date
echo "sudo su - cnyihug1 -c \"psadmin -p $actn -d CNYIHUG1\"" -t ih92npux050 
bolt command run "sudo su - cnyihug1 -c \"psadmin -p $actn -d CNYIHUG1\"" -t ih92npux050 --tty
date
echo "sudo su - cnyihdm3 -c \"psadmin -p $actn -d CNYIHDM3\"" -t ih92npux050 
bolt command run "sudo su - cnyihdm3 -c \"psadmin -p $actn -d CNYIHDM3\"" -t ih92npux050 --tty

date
