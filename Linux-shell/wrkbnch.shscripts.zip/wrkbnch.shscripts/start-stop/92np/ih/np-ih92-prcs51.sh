#!/bin/bash
#set -x
# Commands genersted on the fly using the script grep_BBL.v2.sh
# IH NP PRCS servers ih92npux050 and ih92npux051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
actn=$1
[[ "$actn" == "status" ]] && actn="sstatus"
echo "Input param is [$actn]"
else
echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
exit
fi

#akannayiram@ih92npux051 $ /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
date
echo "sudo su - cnyihde2 -c \"psadmin -p $actn -d CNYIHDE2\"" -t ih92npux051 
bolt command run "sudo su - cnyihde2 -c \"psadmin -p $actn -d CNYIHDE2\"" -t ih92npux051 --tty
date
echo "sudo su - cnyihpst -c \"psadmin -p $actn -d CNYIHPST\"" -t ih92npux051 
bolt command run "sudo su - cnyihpst -c \"psadmin -p $actn -d CNYIHPST\"" -t ih92npux051 --tty
date
#echo "sudo su - cnyihpdv -c \"psadmin -p $actn -d CNYIHPDV\"" -t ih92npux051 
#bolt command run "sudo su - cnyihpdv -c \"psadmin -p $actn -d CNYIHPDV\"" -t ih92npux051 --tty
date
echo "sudo su - cnyihdev -c \"psadmin -p $actn -d CNYIHDEV\"" -t ih92npux051 
bolt command run "sudo su - cnyihdev -c \"psadmin -p $actn -d CNYIHDEV\"" -t ih92npux051 --tty
date
echo "sudo su - cnyihdem -c \"psadmin -p $actn -d CNYIHDEM\"" -t ih92npux051 
bolt command run "sudo su - cnyihdem -c \"psadmin -p $actn -d CNYIHDEM\"" -t ih92npux051 --tty
date
echo "sudo su - cnyihdmo -c \"psadmin -p $actn -d CNYIHDMO\"" -t ih92npux051 
bolt command run "sudo su - cnyihdmo -c \"psadmin -p $actn -d CNYIHDMO\"" -t ih92npux051 --tty

date
