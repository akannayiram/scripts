#!/bin/bash
#set -x
# Commands genersted on the fly using the script grep_BBL.v2.sh
# IH NP App servers ih92npap050 and ih92npap051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi

#akannayiram@ih92npap050 $ /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
bolt command run "sudo su - cnyihdm2 -c \"psadmin -c $actn -d CNYIHDM2\"" -t ih92npap050 --tty
bolt command run "sudo su - cnyihug1 -c \"psadmin -c $actn -d CNYIHUG1\"" -t ih92npap050 --tty
bolt command run "sudo su - cnyihug2 -c \"psadmin -c $actn -d CNYIHUG2\"" -t ih92npap050 --tty

#akannayiram@ih92npap051 $ /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
bolt command run "sudo su - cnyihpst -c \"psadmin -c $actn -d CNYIHPST\"" -t ih92npap051 --tty
bolt command run "sudo su - cnyihde2 -c \"psadmin -c $actn -d CNYIHDE2\"" -t ih92npap051 --tty
bolt command run "sudo su - cnyihdev -c \"psadmin -c $actn -d CNYIHDEV\"" -t ih92npap051 --tty
bolt command run "sudo su - cnyihpdv -c \"psadmin -c $actn -d CNYIHPDV\"" -t ih92npap051 --tty
bolt command run "sudo su - cnyihdmo -c \"psadmin -c $actn -d CNYIHDMO\"" -t ih92npap051 --tty

