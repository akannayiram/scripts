./np-ih92-prcs51.sh $1|tee -a tee_np-ih92-prcs51_${1}_$(date '+%Y%m%d').log
