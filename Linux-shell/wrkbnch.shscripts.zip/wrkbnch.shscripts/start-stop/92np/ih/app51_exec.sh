./np-ih92-app51.sh $1|tee -a tee_np-ih92-app51_${1}_$(date '+%Y%m%d').log
