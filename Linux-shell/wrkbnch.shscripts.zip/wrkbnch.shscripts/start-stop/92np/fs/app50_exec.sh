./np-fs92-app50.sh $1|tee -a tee_np-fs92-app50_${1}_$(date '+%Y%m%d').log
