#!/bin/bash
#set -x
# Commands genersted on the fly using the script grep_BBL.v2.sh
# FS NP App servers fs92npap050 and fs92npap051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi
#akannayiram@fs92npap050 $ /software/akannayiram/bin/grep_BBL.v2.sh|grep "^bolt"
bolt command run "sudo su - cnyfsug2 -c \"psadmin -c $actn -d CNYFSUG2\"" -t fs92npap050 --tty
bolt command run "sudo su - cnyfsrpu -c \"psadmin -c $actn -d CNYFSRPU\"" -t fs92npap050 --tty
bolt command run "sudo su - cnyfsdm2 -c \"psadmin -c $actn -d CNYFSDM2\"" -t fs92npap050 --tty
bolt command run "sudo su - cnyfsug1 -c \"psadmin -c $actn -d CNYFSUG1\"" -t fs92npap050 --tty

#akannayiram@fs92npap051 $ /software/akannayiram/bin/grep_BBL.v2.sh|grep "^bolt"
bolt command run "sudo su - cnyfsdev -c \"psadmin -c $actn -d CNYFSDEV\"" -t fs92npap051 --tty
bolt command run "sudo su - cnyfsde2 -c \"psadmin -c $actn -d CNYFSDE2\"" -t fs92npap051 --tty
bolt command run "sudo su - cnyfspst -c \"psadmin -c $actn -d CNYFSPST\"" -t fs92npap051 --tty
bolt command run "sudo su - cnyfspdv -c \"psadmin -c $actn -d CNYFSPDV\"" -t fs92npap051 --tty

