#!/bin/bash
#set -x
# Commands genersted on the fly using the script grep_BBL.v2.sh
# FS NP PRCS servers fs92npux050 and fs92npux051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi
#akannayiram@fs92npux050 $ /software/akannayiram/bin/grep_BBL.v2.sh|grep "^bolt"
bolt command run "sudo su - cnyfsrpu -c \"psadmin -p $actn -d CNYFSRPU\"" -t fs92npux050 --tty
bolt command run "sudo su - cnyfsug1 -c \"psadmin -p $actn -d CNYFSUG1\"" -t fs92npux050 --tty
bolt command run "sudo su - cnyfsdm2 -c \"psadmin -p $actn -d CNYFSDM2\"" -t fs92npux050 --tty
bolt command run "sudo su - cnyfsug2 -c \"psadmin -p $actn -d CNYFSUG2\"" -t fs92npux050 --tty

#akannayiram@fs92npux051 $ /software/akannayiram/bin/grep_BBL.v2.sh|grep "^bolt"
bolt command run "sudo su - cnyfsdev -c \"psadmin -p $actn -d CNYFSDEV\"" -t fs92npux051 --tty
bolt command run "sudo su - cnyfsde2 -c \"psadmin -p $actn -d CNYFSDE2\"" -t fs92npux051 --tty
bolt command run "sudo su - cnyfspdv -c \"psadmin -p $actn -d CNYFSPDV\"" -t fs92npux051 --tty
bolt command run "sudo su - cnyfspst -c \"psadmin -p $actn -d CNYFSPST\"" -t fs92npux051 --tty

