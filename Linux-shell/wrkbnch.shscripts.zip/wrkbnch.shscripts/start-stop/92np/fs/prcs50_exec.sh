./np-fs92-prcs50.sh $1|tee -a tee_np-fs92-prcs50_${1}_$(date '+%Y%m%d').log
