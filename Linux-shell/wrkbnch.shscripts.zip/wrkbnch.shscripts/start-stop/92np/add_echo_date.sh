#!/bin/bash
#
while read -r line
do
  if [[ $line =~ ^bolt ]] ; then
     echo "date"
     line2=$(echo $line|sed -e "s/bolt command run //"|sed -e "s/--tty.*$//")
     echo "echo $line2"
     echo -e "$line"
  else
     echo -e "$line"
  fi
done < $1
echo "date"
