#!/bin/bash
# ======================================
#    H C   9.2   P R C S   S E R V E R S
# ======================================
set -x
# Commands generated on the fly using the script grep_BBL.v3.sh
# e.g.  /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi

akannayiram@hc92npux050 $ /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
bolt command run "sudo su - cnyhcrpu -c \"psadmin -p $actn -d CNYHCRPU\"" -t hc92npux050 --tty
bolt command run "sudo su - cnyhcdm2 -c \"psadmin -p $actn -d CNYHCDM2\"" -t hc92npux050 --tty
bolt command run "sudo su - cnyhcad1 -c \"psadmin -p $actn -d CNYHCAD1\"" -t hc92npux050 --tty
bolt command run "sudo su - cnyhcad2 -c \"psadmin -p $actn -d CNYHCAD2\"" -t hc92npux050 --tty
#bolt command run "sudo su - cnyhcug1 -c \"psadmin -p $actn -d CNYHCUG1\"" -t hc92npux050 --tty
bolt command run "sudo su - cnyhcug2 -c \"psadmin -p $actn -d CNYHCUG2\"" -t hc92npux050 --tty

akannayiram@hc92npux051 $ /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
bolt command run "sudo su - cnyhcde2 -c \"psadmin -p $actn -d CNYHCDE2\"" -t hc92npux051 --tty
bolt command run "sudo su - cnyhcpst -c \"psadmin -p $actn -d CNYHCPST\"" -t hc92npux051 --tty
bolt command run "sudo su - cnyhcpdv -c \"psadmin -p $actn -d CNYHCPDV\"" -t hc92npux051 --tty
bolt command run "sudo su - cnyhcdev -c \"psadmin -p $actn -d CNYHCDEV\"" -t hc92npux051 --tty

