./np_hc92_app50.sh $1|tee -a tee_np_hc92_app50_${1}_$(date '+%Y%m%d').log
