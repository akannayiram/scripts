./np_hc92_app51.sh $1|tee -a tee_np_hc92_app51_${1}_$(date '+%Y%m%d').log
