#!/bin/bash  -x
# #################################
# crawl_app_prcs_dom: Call with two parameters 
#   param#1: File containing host names
#   Param#2: Tier (app or prcs: Used only for naming o/p file)
#
#   Call the above script for each pillar/tier combination
#      - Al Kannayiram (12/29/2021)
# ##################################
#

# =======================================
#     F U N C T I O N S
# =======================================

#
# To build a script file to be executed by a bolt command
# The script file will be copied to target server 
# just before executing the bolt
#

function build_grep_ps_BBL_script
{
srcscript=/tmp/alk.scr$$.tmp
cat > $srcscript <<!EOF
#!/bin/bash
# ---------------------------------------
# Al Kannayiram - Jan 2022
#     - Gather User Login, Domain name
#       from 'BBL' unix process
# ---------------------------------------
hostnm=\`echo \$HOSTNAME|cut -d"." -f1\`
echo ""
echo "=========================================================="
echo "BEGIN Hostname: \$hostnm    User: \$USER "
echo "=========================================================="
BBLFILE=/tmp/alk\$\$.txt
rm -f \$BBLFILE
echo ""
#echo "ps -aef|grep BBL|grep -v grep"
ps -aef|grep BBL|grep -v grep > \$BBLFILE
while read -r line
do
  usr=\`echo \$line|cut -d" " -f1\`
  # if the 'ps' line contains "/prcs/" then it is a process scheduler
  if [[ \$line =~ prcs ]] ; then
     dom=\`echo \$line|cut -d"-" -f6|cut -d" " -f2|sed -e "s#^.*prcs/##"|sed -e"s%/LOGS.*$%%"\`
     echo "\$hostnm \$usr \$dom prcs"
     echo "submit_bolt_run \$hostnm \$usr \$dom prcs \\\$ACTN"
  else
     dom=\`echo \$line|cut -d"-" -f6|cut -d" " -f2|sed -e "s#^.*appserv/##"|sed -e "s%/LOGS.*$%%"\`
     echo "\$hostnm \$usr \$dom app"
     echo "submit_bolt_run \$hostnm \$usr \$dom app \\\$ACTN"
  fi
done < \$BBLFILE
echo ""
echo "=========================================================="
echo "END Hostname: \$hostnm    User: \$USER "
echo "=========================================================="
echo ""
!EOF

chmod 755 $srcscript

}

# ===================
#    M A I N
# ===================

date
# Check Input parameters 
[[ $# -lt 1 ]] && { echo "ERROR! ERROR!! Input file param is required. Aborting..."; exit; }

servers=$1
[[ ! -f $servers ]] && { echo "ERROR! ERROR!! Input file [$servers] is missing. Aborting..."; exit; }


# Build script that would extarct details from BBL process 
build_grep_ps_BBL_script
  
# Source script must exist and be executable
if [[ ! -x $srcscript ]] ; then
   echo "ERROR! ERROR!! Script [$srcscript] is missing. Aborting..."
   exit
fi

# Define the script template locations
# Script template has two portions.
#    Part1 is top of the scrip that has the functions for star/stop/status commands
#    Part2 contains the logic for anaylyzing the output of actions
part1=/home/akannayiram/start-stop/startstop_template_part1.sh
part2=/home/akannayiram/start-stop/startstop_template_part2.sh
[[ ! -f $part1 && ! -f $part2 ]] && { echo "ERROR! ERROR!! Templates [$part1] and [$part2] are missing. Aborting..."; exit; }
[[ ! -f $part1 ]] && { echo "ERROR! ERROR!! Template [$part1] is missing. Aborting..."; exit; }
[[ ! -f $part2 ]] && { echo "ERROR! ERROR!! Template [$part2] is missing. Aborting..."; exit; }

# Define variables
dttm=`date '+%Y%m%d_%H%M%S'`
dt=`date '+%Y%m%d'`
#logdir=${dttm}_logs
logdir=${dt}_logs

# Create log directory if not exists already
[[ ! -d $logdir ]] && mkdir $logdir

# Build log filename
extractfile=$(basename $servers)
logfile=${logdir}/${dttm}.${extractfile}.bolt.output.log

# Target script location: The script will be scp'd to this location
tgtscript=$srcscript

while read -r line
do
  echo "Checking [$line]"
  echo "Copy [$srcscript] to target [${line}:${tgtscript}]"
  scp -p $srcscript ${line}:${tgtscript}
  bolt command run $tgtscript -t $line --no-host-key-check --connect-timeout 60 --tty
done < $servers  > $logfile 2>&1
echo " "

# Anylyze the [$logfile] to build two files
# Extract submit_bolt_run commmands from the log to build a shell script 
# There will be one submit_bolt_run per app/prcs domain on a server    
# There will be one host, user, domain combo per app/prcs domain on a server    
logtmpfile=/tmp/alklog$$.tmp
tmpfile=/tmp/alk$$.tmp
rm -f $logtmpfile $tmpfile
col -b < $logfile > $logtmpfile

grep submit $logtmpfile|sed -e "s/\r//" > $tmpfile
cnt=`cat $tmpfile|wc -l`
if [[ $cnt -eq 0 ]] ; then
 echo "Skipping [$logfile]. No submit_bolt_run commands in this file"
 #echo "Skipping [$logfile]. No app/prcs domains in this file"
else
  filepart=`echo $logfile|cut -d"." -f2`
  outfile="${logdir}/${filepart}_psa.sh"
  cat $part1 $tmpfile $part2 > $outfile

  # Extract host, user, domain from the log  
  hostdomfile="${logdir}/${extractfile}_host_user_domain.txt"
  cat $logtmpfile|egrep "app|prcs"|grep -v submit|sed -e "s/^    //" > $hostdomfile
fi
rm -f $tmpfile
rm -f $logtmpfile

date

