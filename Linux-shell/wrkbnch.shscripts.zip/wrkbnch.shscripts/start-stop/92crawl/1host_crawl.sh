#!/bin/bash
# ---------------------------------------
# Al Kannayiram - Jan 2022
#     - Gather User Login, Domain name
#       from 'BBL' unix process
# ---------------------------------------
hostnm=`echo $HOSTNAME|cut -d"." -f1`
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $hostnm    User: $USER "
echo "=========================================================="
BBLFILE=/tmp/alk$$.txt
rm -f $BBLFILE
echo ""
#echo "ps -aef|grep BBL|grep -v grep"
ps -aef|grep BBL|grep -v grep > $BBLFILE
while read -r line
do
  usr=`echo $line|cut -d" " -f1`
  # if the 'ps' line contains "/prcs/" then it is a process scheduler
  if [[ $line =~ prcs ]] ; then
     dom=`echo $line|cut -d"-" -f6|cut -d" " -f2|sed -e "s#^.*prcs/##"|sed -e"s%/LOGS.*$%%"`
     echo "$hostnm $usr $dom prcs"
     echo "submit_bolt_run $hostnm $usr $dom prcs \$ACTN"
  else
     dom=`echo $line|cut -d"-" -f6|cut -d" " -f2|sed -e "s#^.*appserv/##"|sed -e "s%/LOGS.*$%%"`
     echo "$hostnm $usr $dom app"
     echo "submit_bolt_run $hostnm $usr $dom app \$ACTN"
  fi
done < $BBLFILE
echo ""
echo "=========================================================="
echo "END Hostname: $hostnm    User: $USER "
echo "=========================================================="
echo ""
