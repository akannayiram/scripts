#!/bin/bash
# ###################################################
#  PERF CS PRCS DOMAINS ONLY
#  - al kannayiram
#
#
#
# ###################################################

# --------------
# check_actn_args  function
#   - use when the input should be one of start, stop, sstatus
# --------------

function check_actn_args
{
# Check if input parameter (actn) is passed
if [[ $# -eq 0 ]] ; then
   echo "$(echo_color "$0: Missing input parameter" "lred")"
   echo "$(echo_color "ERROR ERROR...Aborting" "lred")"
   exit
fi

if [[ ! "$1" == "sstatus" && ! "$1" == "start" && ! "$1" == "stop" && ! "$1" == "qstatus" ]] ; then
   echo "$(echo_color "Invalid parameter $1. Must be start, stop, or sstatus" "lred")"
   exit
fi

}


# -------------
# echo_color function
# -------------

function echo_color
{
    text=$1
    color=$2

    case $color in
        red) code="0;31m" ;;
        green) code="0;32m" ;;
        brown) code="0;33m" ;;
        blue) code="0;34m" ;;
        purple) code="0;35m" ;;
        cyan) code="0;36m" ;;
        gray) code="1;30m" ;;
        lred) code="1;31m" ;;
        lgreen) code="1;32m" ;;
        yellow) code="1;33m" ;;
        lblue) code="1;34m" ;;
        lpurple) code="1;35m" ;;
        lcyan) code="1;36m" ;;
        lgray) code="0;37m" ;;
        *) code="0m" ;;
    esac

    echo -e "\e[$code$text\e[0m"

}


# "$@" holds the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# CS Prcs domains: Two domains on each of the three hosts 
# Two bolt commands are executed: one for each domain
HOSTGRP1=/tmp/csprcshstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
csspfux301
csspfux302
!EOF
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR1\"" -t @$HOSTGRP1 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR2\"" -t @$HOSTGRP1 --tty

