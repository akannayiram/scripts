actn=start
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap329 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap330 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap331 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap332 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSIM1\"" -t csspfap333 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSAM1\"" -t csspfap334 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSSL1\"" -t csspfap335 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSSL2\"" -t csspfap336 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSSL3\"" -t csspfap337 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSCM1\"" -t csspfap338 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSRR1\"" -t csspfap338 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSCM1\"" -t csspfap339 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSRR1\"" -t csspfap339 --tty
