actn=start
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap315 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap316 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap317 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap318 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap319 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap320 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap321 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap322 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap323 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap324 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap325 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap326 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap327 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap328 --tty
