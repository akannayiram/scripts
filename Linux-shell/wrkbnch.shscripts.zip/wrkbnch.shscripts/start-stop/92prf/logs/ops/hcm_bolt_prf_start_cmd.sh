actn=start
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCPF1\"" -t hcmpfap301 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCPF1\"" -t hcmpfap302 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCPF1\"" -t hcmpfap303 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCPF1\"" -t hcmpfap304 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCAM1\"" -t hcmpfap305 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCIM1\"" -t hcmpfap306 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCCM1\"" -t hcmpfap307 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -p $actn -d CNYHCPF1\"" -t hcmpfux301 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -p $actn -d CNYHCPF1\"" -t hcmpfux302 --tty
