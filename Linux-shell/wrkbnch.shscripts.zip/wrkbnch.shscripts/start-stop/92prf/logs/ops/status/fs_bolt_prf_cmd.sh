actn=stop
bolt command run "sudo su - cnyfsprf -c \"psadmin -c $actn -d CNYFSPF1\"" -t finpfap301 --tty
bolt command run "sudo su - cnyfsprf -c \"psadmin -c $actn -d CNYFSPF1\"" -t finpfap302 --tty
bolt command run "sudo su - cnyfsprf -c \"psadmin -c $actn -d CNYFSAM1\"" -t finpfap303 --tty
bolt command run "sudo su - cnyfsprf -c \"psadmin -c $actn -d CNYFSIM1\"" -t finpfap304 --tty
bolt command run "sudo su - cnyfsprf -c \"psadmin -p $actn -d CNYFSPF1\"" -t finpfux301 --tty
bolt command run "sudo su - cnyfsprf -c \"psadmin -p $actn -d CNYFSPF1\"" -t finpfux302 --tty
