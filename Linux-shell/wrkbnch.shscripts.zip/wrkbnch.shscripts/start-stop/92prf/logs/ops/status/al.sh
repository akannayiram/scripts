while read line
do
#bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap301 --tty
hst=$(echo $line|awk '{print $15}')
dom=$(echo $line|awk '{print $13}'|cut -F"\" -f1)
echo "nohup $line > $hst.\$actn.\$dttm.nohup.out 2>&1 &"
done < cs_bolt_prf_cmd2.sh
