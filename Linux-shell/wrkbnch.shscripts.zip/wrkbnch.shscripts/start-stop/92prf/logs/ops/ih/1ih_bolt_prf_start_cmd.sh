actn=start
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap301 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap302 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap303 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap304 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap305 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap306 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap307 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap308 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap309 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap310 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap311 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap312 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap313 --tty
