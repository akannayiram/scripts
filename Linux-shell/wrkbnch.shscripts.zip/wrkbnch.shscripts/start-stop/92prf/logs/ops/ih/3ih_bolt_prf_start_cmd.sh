actn=start
bolt command run "sudo su - cnyihprf -c \"psadmin -p $actn -d CNYIHPR1\"" -t ihpfux301 --tty
