actn=start
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap314 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap315 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap316 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap317 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap318 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap319 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap320 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap321 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap322 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap323 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap324 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHAM1\"" -t ihpfap325 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHIM1\"" -t ihpfap326 --tty
