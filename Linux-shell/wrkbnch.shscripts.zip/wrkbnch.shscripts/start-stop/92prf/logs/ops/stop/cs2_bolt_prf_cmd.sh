actn=stop
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap326 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap327 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap328 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap329 --tty
