actn=stop
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR1\"" -t csspfux301 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR2\"" -t csspfux301 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR1\"" -t csspfux302 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR2\"" -t csspfux302 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR2\"" -t csspfux303 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR1\"" -t csspfux303 --tty
