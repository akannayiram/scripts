actn=start
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap310 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap311 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap312 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap313 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap314 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap315 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap316 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap317 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t ihpfap318 --tty
