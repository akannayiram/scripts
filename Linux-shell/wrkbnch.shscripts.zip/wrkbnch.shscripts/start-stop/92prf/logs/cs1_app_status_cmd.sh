actn=sstatus
TMPHOSTFILE=/tmp/hstfile$$.txt
rm -f $TMPHOSTFILE
cat > $TMPHOSTFILE << !EOF
csspfap301
csspfap302
csspfap303
csspfap304
csspfap305
csspfap306
csspfap307
csspfap308
csspfap309
csspfap310
csspfap311
csspfap312
csspfap313
csspfap314
csspfap315
csspfap316
csspfap317
csspfap318
csspfap319
csspfap320
csspfap321
csspfap322
csspfap323
csspfap324
csspfap325
csspfap326
csspfap327
csspfap328
csspfap329
csspfap330
csspfap331
csspfap332
!EOF
bolt command run "sudo su - cnycsprf -c \"echo $(hostname);psadmin -c $actn -d CNYCSPR1\"" -t @$TMPHOSTFILE --tty
