#!/bin/bash -x

getbbl ()
{

while read -r inphost
do
if [[ $inphost =~ pfap || $inphost =~ pfux ]] ; then
#   continue;
   echo "Checking $inphost"
   bolt command run $grepbblscript -t $inphost --no-host-key-check --connect-timeout 60 --tty
#else
#   echo "Skipping $inphost"
fi
done < $inphostsfile > $outfile 2>&1

}
#inphostsfile=$1
hostsfile=/home/akannayiram/start-stop/92prf/all_prf_servers.txt
grepbblscript=/software/akannayiram/bin/grep_BBL.v3.sh
date
inphostsfile=/tmp/alk.hosts$$.txt

for pillar in cs fs hc ih
do
  echo "Processing $pillar"
  rm -f $inphostsfile
  grep "^$pillar" $hostsfile > $inphostsfile
  outfile=${pillar}.bolt.output.txt
  getbbl
done
# =========================
# process cs
#echo "process cs"
#rm -f $inphostsfile
#grep "^cs" $hostsfile > $inphostsfile
#outfile=cs.bolt.output.txt
#getbbl
# =========================

# while read -r inphost
# do
# if [[ $inphost =~ pfap || $inphost =~ pfux ]] ; then
# #   continue;
#    echo "Checking $inphost"
#    bolt command run $grepbblscript -t $inphost --no-host-key-check --connect-timeout 60 --tty
# #else
# #   echo "Skipping $inphost"
# fi
# done < $inphostsfile
echo " "
date
