#!/bin/bash

#inphostsfile=$1
inphostsfile=/home/akannayiram/start-stop/92prf/all_prf_servers.txt
grepbblscript=/software/akannayiram/bin/grep_BBL.v3.sh
date
while read -r inphost
do
if [[ $inphost =~ pfap || $inphost =~ pfux ]] ; then
#   continue;
   echo "Checking $inphost"
   bolt command run $grepbblscript -t $inphost --no-host-key-check --connect-timeout 60 --tty
#else
#   echo "Skipping $inphost"
fi
done < $inphostsfile
echo " "
date
