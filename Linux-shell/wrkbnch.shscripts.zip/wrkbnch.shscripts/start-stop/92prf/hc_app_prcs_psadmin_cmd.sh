#!/bin/bash
# ###################################################
#  PERF HC APP AND PRCS DOMAINS
#  - al kannayiram
#
#
#
# ###################################################

# --------------
# check_actn_args  function
#   - use when the input should be one of start, stop, sstatus
# --------------

function check_actn_args
{
# Check if input parameter (actn) is passed
if [[ $# -eq 0 ]] ; then
   echo "$(echo_color "$0: Missing input parameter" "lred")"
   echo "$(echo_color "ERROR ERROR...Aborting" "lred")"
   exit
fi

if [[ ! "$1" == "sstatus" && ! "$1" == "start" && ! "$1" == "stop" && ! "$1" == "qstatus" ]] ; then
   echo "$(echo_color "Invalid parameter $1. Must be start, stop, or sstatus" "lred")"
   exit
fi

}


# -------------
# echo_color function
# -------------

function echo_color
{
    text=$1
    color=$2

    case $color in
        red) code="0;31m" ;;
        green) code="0;32m" ;;
        brown) code="0;33m" ;;
        blue) code="0;34m" ;;
        purple) code="0;35m" ;;
        cyan) code="0;36m" ;;
        gray) code="1;30m" ;;
        lred) code="1;31m" ;;
        lgreen) code="1;32m" ;;
        yellow) code="1;33m" ;;
        lblue) code="1;34m" ;;
        lpurple) code="1;35m" ;;
        lcyan) code="1;36m" ;;
        lgray) code="0;37m" ;;
        *) code="0m" ;;
    esac

    echo -e "\e[$code$text\e[0m"

}


# "$@" holds the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# HC App domains are same on the first 4 servers
# They are grouped together so that the same command 
# can be passed to all 4 servers
HOSTGRP1=/tmp/hcapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
hcmpfap301
hcmpfap302
hcmpfap303
hcmpfap304
!EOF
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCPR1\"" -t @$HOSTGRP1 --tty

# Remaining three servers have different domain names
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCAM1\"" -t hcmpfap305 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCIM1\"" -t hcmpfap306 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCSL1\"" -t hcmpfap306 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCCM1\"" -t hcmpfap307 --tty

# Including PRCS domains also
# HC Prcs domains on 2 servers
# They are grouped together so that the same command can be passed
HOSTGRP2=/tmp/hcprcshstgrp1$$.txt
rm -f $HOSTGRP2
cat > $HOSTGRP2 << !EOF
hcmpfux301
hcmpfux302
!EOF
bolt command run "sudo su - cnyhcprf -c \"psadmin -p $actn -d CNYHRPRF\"" -t @$HOSTGRP2 --tty
