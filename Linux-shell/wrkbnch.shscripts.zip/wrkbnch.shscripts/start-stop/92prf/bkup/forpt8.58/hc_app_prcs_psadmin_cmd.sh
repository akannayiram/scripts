#!/bin/bash
# ###################################################
#  PERF HC APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# HC App domains are same on the first 4 servers
# They are grouped together so that the same command 
# can be passed to all 4 servers
HOSTGRP1=/tmp/hcapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
hcmpfap301
hcmpfap302
hcmpfap303
hcmpfap304
!EOF
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCPF1\"" -t @$HOSTGRP1 --tty

# Remaining three servers have different domain names
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCAM1\"" -t hcmpfap305 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCIM1\"" -t hcmpfap306 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCCM1\"" -t hcmpfap307 --tty

# Including PRCS domains also
# HC Prcs domains on 2 servers
# They are grouped together so that the same command can be passed
HOSTGRP2=/tmp/hcprcshstgrp1$$.txt
rm -f $HOSTGRP2
cat > $HOSTGRP2 << !EOF
hcmpfux301
hcmpfux302
!EOF
bolt command run "sudo su - cnyhcprf -c \"psadmin -p $actn -d CNYHCPF1\"" -t @$HOSTGRP2 --tty
