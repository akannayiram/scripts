#!/bin/bash
# ###################################################
#  PERF CS PRCS DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# CS Prcs domains: Two domains on each of the three hosts 
# Two bolt commands are executed: one for each domain
HOSTGRP1=/tmp/csprcshstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
csspfux301
csspfux302
csspfux303
!EOF
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR1\"" -t @$HOSTGRP1 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -p $actn -d CNYCSPR2\"" -t @$HOSTGRP1 --tty

