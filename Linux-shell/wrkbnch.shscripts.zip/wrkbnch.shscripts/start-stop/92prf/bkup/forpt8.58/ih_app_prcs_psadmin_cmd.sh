#!/bin/bash
# ###################################################
#  PERF IH APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# IH App domains are same on the first 24 servers
# They are grouped together so that the same command 
# can be passed to all 24 servers
HOSTGRP1=/tmp/ihapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
ihpfap301
ihpfap302
ihpfap303
ihpfap304
ihpfap305
ihpfap306
ihpfap307
ihpfap308
ihpfap309
ihpfap310
ihpfap311
ihpfap312
ihpfap313
ihpfap314
ihpfap315
ihpfap316
ihpfap317
ihpfap318
ihpfap319
ihpfap320
ihpfap321
ihpfap322
ihpfap323
ihpfap324
!EOF
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t @$HOSTGRP1 --tty

# Remaining servers 325 & 326 have different domain names
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHAM1\"" -t ihpfap325 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHIM1\"" -t ihpfap326 --tty

# Including PRCS domains also
bolt command run "sudo su - cnyihprf -c \"psadmin -p $actn -d CNYIHPR1\"" -t ihpfux301 --tty

