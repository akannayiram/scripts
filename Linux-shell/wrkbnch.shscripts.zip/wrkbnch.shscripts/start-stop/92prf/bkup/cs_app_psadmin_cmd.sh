#!/bin/bash
# ###################################################
#  PERF CS APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft_prod/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft_prod/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# CS App domains are same on the first 32 servers
# They are grouped together so that the same command 
# can be passed to all 32 servers
HOSTGRP1=/tmp/csapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
csspfap301
csspfap302
csspfap303
csspfap304
csspfap305
csspfap306
csspfap307
csspfap308
csspfap309
csspfap310
csspfap311
csspfap312
csspfap313
csspfap314
csspfap315
csspfap316
csspfap317
csspfap318
csspfap319
csspfap320
csspfap321
csspfap322
csspfap323
csspfap324
csspfap325
csspfap326
csspfap327
csspfap328
csspfap329
csspfap330
csspfap331
csspfap332
!EOF
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t @$HOSTGRP1 --tty

# Remaining servers 333 to 337 have different domain names
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSIM1\"" -t csspfap333 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSAM1\"" -t csspfap334 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSSL1\"" -t csspfap335 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSSL2\"" -t csspfap336 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSSL3\"" -t csspfap337 --tty

# These two servers 338 & 339 have the same two domains
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSCM1\"" -t csspfap338 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSRR1\"" -t csspfap338 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSCM1\"" -t csspfap339 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSRR1\"" -t csspfap339 --tty
