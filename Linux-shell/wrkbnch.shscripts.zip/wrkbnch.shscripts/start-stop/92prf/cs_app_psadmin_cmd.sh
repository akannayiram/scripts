#!/bin/bash
# ###################################################
#  PERF CS APP DOMAINS ONLY
#  - al kannayiram
#
#
#
# ###################################################

# --------------
# check_actn_args  function
#   - use when the input should be one of start, stop, sstatus
# --------------

function check_actn_args
{
# Check if input parameter (actn) is passed
if [[ $# -eq 0 ]] ; then
   echo "$(echo_color "$0: Missing input parameter" "lred")"
   echo "$(echo_color "ERROR ERROR...Aborting" "lred")"
   exit
fi

if [[ ! "$1" == "sstatus" && ! "$1" == "start" && ! "$1" == "stop" && ! "$1" == "qstatus" ]] ; then
   echo "$(echo_color "Invalid parameter $1. Must be start, stop, or sstatus" "lred")"
   exit
fi

}


# -------------
# echo_color function
# -------------

function echo_color
{
    text=$1
    color=$2

    case $color in
        red) code="0;31m" ;;
        green) code="0;32m" ;;
        brown) code="0;33m" ;;
        blue) code="0;34m" ;;
        purple) code="0;35m" ;;
        cyan) code="0;36m" ;;
        gray) code="1;30m" ;;
        lred) code="1;31m" ;;
        lgreen) code="1;32m" ;;
        yellow) code="1;33m" ;;
        lblue) code="1;34m" ;;
        lpurple) code="1;35m" ;;
        lcyan) code="1;36m" ;;
        lgray) code="0;37m" ;;
        *) code="0m" ;;
    esac

    echo -e "\e[$code$text\e[0m"

}

# "$@" holds the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# CS App domains are same on the first 32 servers
# They are grouped together so that the same command 
# can be passed to all 32 servers
HOSTGRP1=/tmp/csapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
csspfap301
csspfap302
csspfap303
csspfap304
csspfap305
csspfap306
csspfap307
csspfap308
csspfap309
csspfap310
csspfap311
csspfap312
csspfap313
csspfap314
csspfap315
csspfap316
csspfap317
csspfap318
csspfap319
csspfap320
csspfap321
csspfap322
csspfap323
csspfap324
csspfap325
csspfap326
csspfap327
csspfap328
csspfap329
csspfap330
csspfap331
csspfap332
!EOF
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t @$HOSTGRP1 --tty

# Remaining servers 333 to 337 have different domain names
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSIM1\"" -t csspfap333 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSAM1\"" -t csspfap334 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSSL1\"" -t csspfap335 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSSL2\"" -t csspfap336 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSSL3\"" -t csspfap337 --tty

# These two servers 338 & 339 have the same two domains
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSCM1\"" -t csspfap338 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSRR1\"" -t csspfap338 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSCM1\"" -t csspfap339 --tty
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSRR1\"" -t csspfap339 --tty
