#!/bin/bash
#bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t csspfap330 --tty
actn=preload
inp=./cs_prf_app
bolt command run "sudo su - cnycsprf -c \"psadmin -c $actn -d CNYCSPR1\"" -t "@$inp" --no-host-key-check --tty

