#!/bin/bash
# ###################################################
#  PERF IH APP AND PRCS DOMAINS
#  - al kannayiram
#
#
#
# ###################################################

# --------------
# check_actn_args  function
#   - use when the input should be one of start, stop, sstatus
# --------------

function check_actn_args
{
# Check if input parameter (actn) is passed
if [[ $# -eq 0 ]] ; then
   echo "$(echo_color "$0: Missing input parameter" "lred")"
   echo "$(echo_color "ERROR ERROR...Aborting" "lred")"
   exit
fi

if [[ ! "$1" == "sstatus" && ! "$1" == "start" && ! "$1" == "stop" && ! "$1" == "qstatus" ]] ; then
   echo "$(echo_color "Invalid parameter $1. Must be start, stop, or sstatus" "lred")"
   exit
fi

}


# -------------
# echo_color function
# -------------

function echo_color
{
    text=$1
    color=$2

    case $color in
        red) code="0;31m" ;;
        green) code="0;32m" ;;
        brown) code="0;33m" ;;
        blue) code="0;34m" ;;
        purple) code="0;35m" ;;
        cyan) code="0;36m" ;;
        gray) code="1;30m" ;;
        lred) code="1;31m" ;;
        lgreen) code="1;32m" ;;
        yellow) code="1;33m" ;;
        lblue) code="1;34m" ;;
        lpurple) code="1;35m" ;;
        lcyan) code="1;36m" ;;
        lgray) code="0;37m" ;;
        *) code="0m" ;;
    esac

    echo -e "\e[$code$text\e[0m"

}


# "$@" holds the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# IH App domains are same on the first 24 servers
# They are grouped together so that the same command 
# can be passed to all 24 servers
HOSTGRP1=/tmp/ihapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
ihpfap301
ihpfap302
ihpfap303
ihpfap304
ihpfap305
ihpfap306
ihpfap307
ihpfap308
ihpfap309
ihpfap310
ihpfap311
ihpfap312
ihpfap313
ihpfap314
ihpfap315
ihpfap316
ihpfap317
ihpfap318
ihpfap319
ihpfap320
ihpfap321
ihpfap322
ihpfap323
ihpfap324
!EOF
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHPR1\"" -t @$HOSTGRP1 --tty

# Remaining servers 325 & 326 have different domain names
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHAM1\"" -t ihpfap325 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHIM1\"" -t ihpfap326 --tty
bolt command run "sudo su - cnyihprf -c \"psadmin -c $actn -d CNYIHSL1\"" -t ihpfap326 --tty

# Including PRCS domains also
bolt command run "sudo su - cnyihprf -c \"psadmin -p $actn -d CNYIHPR1\"" -t ihpfux301 --tty

