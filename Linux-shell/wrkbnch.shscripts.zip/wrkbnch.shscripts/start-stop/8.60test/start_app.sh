sudo su - $1 -c 'for i in $(find $PS_CFG_HOME/appserv -type d -name CNY* -exec basename {} \;);do echo "Domain $i on $HOSTNAME"; date;psadmin -c start -d $i;date;done'
