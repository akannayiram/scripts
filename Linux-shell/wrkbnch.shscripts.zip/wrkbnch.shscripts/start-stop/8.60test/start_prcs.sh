sudo su - $1 -c 'for i in $(find $PS_CFG_HOME/appserv/prcs -type d -name CNY* -exec basename {} \;);do echo "Domain $i on $HOSTNAME"; date;psadmin -p start -d $i;date;done'
