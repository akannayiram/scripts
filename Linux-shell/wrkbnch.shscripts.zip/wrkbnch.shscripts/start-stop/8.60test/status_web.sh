date
for usr in $(grep cnyp /etc/hosts|grep -v "#"|grep 860|awk '{print $2}')
do
sudo su - $usr -c 'echo "Web: $LOGNAME on $HOSTNAME";$PS_CFG_HOME/webserv/peoplesoft/bin/singleserverStatus.sh;echo'
done
date
