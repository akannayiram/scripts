#!/bin/bash
# ======================================
#    C S   9.2   P R C S   S E R V E R S
# ======================================
set -x
# Commands generated on the fly using the script grep_BBL.v3.sh
# e.g.  /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi

#akannayiram@cs92npux050 $ /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
date
bolt command run "sudo su - cnycsug2 -c \"psadmin -p $actn -d CNYCSUG2\"" -t cs92npux050 --tty
date
bolt command run "sudo su - cnycsrpu -c \"psadmin -p $actn -d CNYCSRPU\"" -t cs92npux050 --tty
date
bolt command run "sudo su - cnycsdm2 -c \"psadmin -p $actn -d CNYCSDM2\"" -t cs92npux050 --tty
date
bolt command run "sudo su - cnycsdm3 -c \"psadmin -p $actn -d CNYCSDM3\"" -t cs92npux050 --tty
date
bolt command run "sudo su - cnycsug1 -c \"psadmin -p $actn -d CNYCSUG1\"" -t cs92npux050 --tty
date
bolt command run "sudo su - cnycsad2 -c \"psadmin -p $actn -d CNYCSAD2\"" -t cs92npux050 --tty
date
bolt command run "sudo su - cnycsad1 -c \"psadmin -p $actn -d CNYCSAD1\"" -t cs92npux050 --tty
date

