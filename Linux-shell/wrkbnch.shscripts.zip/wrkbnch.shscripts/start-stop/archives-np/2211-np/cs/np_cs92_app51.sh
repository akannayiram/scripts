#!/bin/bash
# ======================================
#    C S   9.2   A P P   S E R V E R S
# ======================================
#set -x
# Commands generated on the fly using the script grep_BBL.v3.sh
# e.g.  /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi

#akannayiram@cs92npap051 $ /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
date
echo "sudo su - cnycsdev -c \"psadmin -c $actn -d CNYCSDEV\""
bolt command run "sudo su - cnycsdev -c \"psadmin -c $actn -d CNYCSDEV\"" -t cs92npap051 --tty
date
echo "sudo su - cnycspst -c \"psadmin -c $actn -d CNYCSPST\"" 
bolt command run "sudo su - cnycspst -c \"psadmin -c $actn -d CNYCSPST\"" -t cs92npap051 --tty
date
echo "sudo su - cnycsdmo -c \"psadmin -c $actn -d CNYCSDMO\"" 
bolt command run "sudo su - cnycsdmo -c \"psadmin -c $actn -d CNYCSDMO\"" -t cs92npap051 --tty
date
echo "sudo su - cnycspdv -c \"psadmin -c $actn -d CNYCSPDV\""
bolt command run "sudo su - cnycspdv -c \"psadmin -c $actn -d CNYCSPDV\"" -t cs92npap051 --tty
date
echo "sudo su - cnycs005 -c \"psadmin -c $actn -d CNYCS005\"" 
bolt command run "sudo su - cnycs005 -c \"psadmin -c $actn -d CNYCS005\"" -t cs92npap051 --tty
date
echo "sudo su - cnycscu5 -c \"psadmin -c $actn -d CNYCSCU5\""
bolt command run "sudo su - cnycscu5 -c \"psadmin -c $actn -d CNYCSCU5\"" -t cs92npap051 --tty
date
echo "sudo su - cnycsde2 -c \"psadmin -c $actn -d CNYCSDE2\""
bolt command run "sudo su - cnycsde2 -c \"psadmin -c $actn -d CNYCSDE2\"" -t cs92npap051 --tty
date
#echo "sudo su - cnycsdem -c \"psadmin -c $actn -d CNYCSDEM\"" 
#bolt command run "sudo su - cnycsdem -c \"psadmin -c $actn -d CNYCSDEM\"" -t cs92npap051 --tty
date

