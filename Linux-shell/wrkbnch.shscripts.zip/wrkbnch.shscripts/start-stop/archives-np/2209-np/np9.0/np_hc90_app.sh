#!/bin/bash
# ======================================
#    H C   9.0   A P P   S E R V E R S
# ======================================
#set -x
# Commands generated on the fly using the script grep_BBL.v3.sh
# e.g.  /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi
#akannayiram@hcmnpap001 $ /psft/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
bolt command run "sudo su - cnyhcdm2 -c \"psadmin -c $actn -d CNYHCDM2\"" -t hcmnpap001 --tty

#akannayiram@hcmnpap002 $ /psft/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
bolt command run "sudo su - cnycssnd -c \"psadmin -c $actn -d CNYCSSND\"" -t hcmnpap002 --tty

