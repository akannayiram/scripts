#!/bin/bash
# ======================================
#    H C   9.0   P R C S   S E R V E R S
# ======================================
#set -x
# Commands generated on the fly using the script grep_BBL.v3.sh
# e.g.  /software/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi
#akannayiram@hcmnpux001 $ /psft/akannayiram/bin/grep_BBL.v3.sh|grep "^bolt"
bolt command run "sudo su - cnyhcdm2 -c \"psadmin -p $actn -d CNYHCDM2\"" -t hcmnpux001 --tty
bolt command run "sudo su - cnycssnd -c \"psadmin -p $actn -d CNYCSSND\"" -t hcmnpux001 --tty

