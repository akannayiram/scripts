#!/bin/bash
# ###################################################
#  DR HC APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft_prod/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft_prod/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# HC App domains are same on the first 4 servers
# They are grouped together so that the same command 
# can be passed to all 4 servers
HOSTGRP1=/tmp/hcdrapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
hc92drap201
hc92drap202
hc92drap203
hc92drap204
!EOF
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCPR1\"" -t @$HOSTGRP1 --tty

# Remaining three servers have different domain names
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCAM1\"" -t hc92drap205 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCIM1\"" -t hc92drap206 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCCM1\"" -t hc92drap207 --tty

# Including PRCS domains also
# HC Prcs domains on 2 servers
# They are grouped together so that the same command can be passed
HOSTGRP2=/tmp/hcprcshstgrp1$$.txt
rm -f $HOSTGRP2
cat > $HOSTGRP2 << !EOF
hc92drux201
hc92drux202
!EOF
bolt command run "sudo su - cnyhcprf -c \"psadmin -p $actn -d CNYHCPR1\"" -t @$HOSTGRP2 --tty
