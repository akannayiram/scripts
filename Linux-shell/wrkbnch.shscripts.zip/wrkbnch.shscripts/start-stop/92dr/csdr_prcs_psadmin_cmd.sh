#!/bin/bash
# ###################################################
#  DR CS PRCS DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft_prod/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft_prod/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# CS Prcs domains: Two domains on each of the three hosts 
# Two bolt commands are executed: one for each domain
HOSTGRP1=/tmp/csdrprcshstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
cs92drux201
cs92drux202
!EOF
bolt command run "sudo su - cnycsprd -c \"psadmin -p $actn -d CNYCSPR1\"" -t @$HOSTGRP1 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -p $actn -d CNYCSPR2\"" -t @$HOSTGRP1 --tty

