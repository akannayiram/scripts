#!/bin/bash
# ###################################################
#  DR CS APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft_prod/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft_prod/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# CS App domains are same on the first 32 servers
# They are grouped together so that the same command 
# can be passed to all 32 servers
HOSTGRP1=/tmp/csdrapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
cs92drap201
cs92drap202
cs92drap203
cs92drap204
cs92drap205
cs92drap206
cs92drap207
cs92drap208
cs92drap209
cs92drap210
cs92drap211
cs92drap212
cs92drap213
cs92drap214
cs92drap215
cs92drap216
cs92drap217
cs92drap218
cs92drap219
cs92drap220
cs92drap221
cs92drap222
cs92drap223
cs92drap224
cs92drap225
cs92drap226
cs92drap227
cs92drap228
cs92drap229
cs92drap230
cs92drap231
cs92drap232
!EOF
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSPR1\"" -t @$HOSTGRP1 --tty

# Remaining servers 333 to 337 have different domain names
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSIM1\"" -t cs92drap233 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSAM1\"" -t cs92drap234 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSSL1\"" -t cs92drap235 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSSL2\"" -t cs92drap236 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSSL3\"" -t cs92drap237 --tty

# These two servers 338 & 339 have the same two domains
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSCM1\"" -t cs92drap238 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSRR1\"" -t cs92drap238 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSCM1\"" -t cs92drap239 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSRR1\"" -t cs92drap239 --tty
