#!/bin/bash
# ###################################################
#  DR IH APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft_prod/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft_prod/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# IH App domains are same on the first 24 servers
# They are grouped together so that the same command 
# can be passed to all 24 servers
HOSTGRP1=/tmp/ihdrapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
ihdrap201
ihdrap202
ihdrap203
ihdrap204
ihdrap205
ihdrap206
ihdrap207
ihdrap208
ihdrap209
ihdrap210
ihdrap211
ihdrap212
ihdrap213
ihdrap214
ihdrap215
ihdrap216
ihdrap217
ihdrap218
ihdrap219
ihdrap220
ihdrap221
ihdrap222
ihdrap223
ihdrap224
!EOF
bolt command run "sudo su - cnyihprd -c \"psadmin -c $actn -d CNYIHPR1\"" -t @$HOSTGRP1 --tty

# Remaining servers 325 & 326 have different domain names
bolt command run "sudo su - cnyihprd -c \"psadmin -c $actn -d CNYIHAM1\"" -t ihdrap225 --tty
bolt command run "sudo su - cnyihprd -c \"psadmin -c $actn -d CNYIHIM1\"" -t ihdrap226 --tty

# Including PRCS domains also
bolt command run "sudo su - cnyihprd -c \"psadmin -p $actn -d CNYIHPR1\"" -t ihdrux201 --tty
bolt command run "sudo su - cnyihprd -c \"psadmin -p $actn -d CNYIHPR1\"" -t ihdrux202 --tty

