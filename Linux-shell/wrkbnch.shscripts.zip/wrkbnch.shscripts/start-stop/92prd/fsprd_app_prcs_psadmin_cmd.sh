#!/bin/bash
# ###################################################
#  PRD FS APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# FS App domains are same on the first 2 servers
# They are grouped together so that the same command 
# can be passed to all 2 servers
HOSTGRP1=/tmp/fsprdapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
fs92prap101
fs92prap102
!EOF
bolt command run "sudo su - cnyfsprd -c \"psadmin -c $actn -d CNYFSPR1\"" -t @$HOSTGRP1 --tty

# Remaining servers have different domain names
bolt command run "sudo su - cnyfsprd -c \"psadmin -c $actn -d CNYFSAM1\"" -t fs92prap103 --tty
bolt command run "sudo su - cnyfsprd -c \"psadmin -c $actn -d CNYFSIM1\"" -t fs92prap104 --tty

# Including PRCS domains also
# FS Prcs domains on 2 servers
# They are grouped together so that the same command can be passed
HOSTGRP2=/tmp/fsprcshstgrp1$$.txt
rm -f $HOSTGRP2
cat > $HOSTGRP2 << !EOF
fs92prux101
fs92prux102
!EOF
bolt command run "sudo su - cnyfsprd -c \"psadmin -p $actn -d CNYFSPR1\"" -t @$HOSTGRP2 --tty
