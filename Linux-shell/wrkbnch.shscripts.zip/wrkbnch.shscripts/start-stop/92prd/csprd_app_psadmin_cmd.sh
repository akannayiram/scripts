#!/bin/bash
# ###################################################
#  PRD CS APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# CS App domains are same on the first 32 servers
# They are grouped together so that the same command 
# can be passed to all 32 servers
HOSTGRP1=/tmp/csprdapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
cs92prap101
cs92prap102
cs92prap103
cs92prap104
cs92prap105
cs92prap106
cs92prap107
cs92prap108
cs92prap109
cs92prap110
cs92prap111
cs92prap112
cs92prap113
cs92prap114
cs92prap115
cs92prap116
cs92prap117
cs92prap118
cs92prap119
cs92prap120
cs92prap121
cs92prap122
cs92prap123
cs92prap124
cs92prap125
cs92prap126
cs92prap127
cs92prap128
cs92prap129
cs92prap130
cs92prap131
cs92prap132
!EOF
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSPR1\"" -t @$HOSTGRP1 --tty

# Remaining servers 333 to 337 have different domain names
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSIM1\"" -t cs92prap133 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSAM1\"" -t cs92prap134 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSSL1\"" -t cs92prap135 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSSL2\"" -t cs92prap136 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSSL3\"" -t cs92prap137 --tty

# These two servers 338 & 339 have the same two domains
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSCM1\"" -t cs92prap138 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSRR1\"" -t cs92prap138 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSCM1\"" -t cs92prap139 --tty
bolt command run "sudo su - cnycsprd -c \"psadmin -c $actn -d CNYCSRR1\"" -t cs92prap139 --tty
