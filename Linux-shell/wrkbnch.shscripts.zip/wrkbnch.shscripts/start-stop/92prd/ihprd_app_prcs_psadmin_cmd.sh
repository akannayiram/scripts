#!/bin/bash
# ###################################################
#  PRD IH APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# IH App domains are same on the first 24 servers
# They are grouped together so that the same command 
# can be passed to all 24 servers
HOSTGRP1=/tmp/ihprdapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
ihprap101
ihprap102
ihprap103
ihprap104
ihprap105
ihprap106
ihprap107
ihprap108
ihprap109
ihprap110
ihprap111
ihprap112
ihprap113
ihprap114
ihprap115
ihprap116
ihprap117
ihprap118
ihprap119
ihprap120
ihprap121
ihprap122
ihprap123
ihprap124
!EOF
bolt command run "sudo su - cnyihprd -c \"psadmin -c $actn -d CNYIHPR1\"" -t @$HOSTGRP1 --tty

# Remaining servers 325 & 326 have different domain names
bolt command run "sudo su - cnyihprd -c \"psadmin -c $actn -d CNYIHAM1\"" -t ihprap125 --tty
bolt command run "sudo su - cnyihprd -c \"psadmin -c $actn -d CNYIHIM1\"" -t ihprap126 --tty

# Including PRCS domains also
bolt command run "sudo su - cnyihprd -c \"psadmin -p $actn -d CNYIHPR1\"" -t ihprux101 --tty
bolt command run "sudo su - cnyihprd -c \"psadmin -p $actn -d CNYIHPR1\"" -t ihprux102 --tty

