#!/bin/bash
# ###################################################
#  PRD HC APP DOMAINS
#
#
#
# ###################################################

# Source functions
# echo_color_func is to display messages in red/blue/green etc.
. /psft/akannayiram/bin/echo_color_func.sh
# check_actn_args_func is to validate input arguments (start, stop, sstatus)
. /psft/akannayiram/bin/check_actn_args_func.sh

# "$@" hols the input args in an array
# Pass them to the function
check_actn_args "$@"
actn=$1

# HC App domains are same on the first 4 servers
# They are grouped together so that the same command 
# can be passed to all 4 servers
HOSTGRP1=/tmp/hcprdapphstgrp1$$.txt
rm -f $HOSTGRP1
cat > $HOSTGRP1 << !EOF
hc92prap101
hc92prap102
hc92prap103
hc92prap104
!EOF
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCPR1\"" -t @$HOSTGRP1 --tty

# Remaining three servers have different domain names
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCAM1\"" -t hc92prap105 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCIM1\"" -t hc92prap106 --tty
bolt command run "sudo su - cnyhcprf -c \"psadmin -c $actn -d CNYHCCM1\"" -t hc92prap107 --tty

# Including PRCS domains also
# HC Prcs domains on 2 servers
# They are grouped together so that the same command can be passed
HOSTGRP2=/tmp/hcprcshstgrp1$$.txt
rm -f $HOSTGRP2
cat > $HOSTGRP2 << !EOF
hc92prux101
hc92prux102
!EOF
bolt command run "sudo su - cnyhcprf -c \"psadmin -p $actn -d CNYHCPR1\"" -t @$HOSTGRP2 --tty
