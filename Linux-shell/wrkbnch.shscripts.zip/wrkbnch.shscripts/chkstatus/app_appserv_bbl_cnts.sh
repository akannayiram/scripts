#!/bin/bash
# #####################################
#   Al Kannayiram October 2023
#     To get BBL & PSAPPSRV Service counts
# ####################################

# Build a temporary file containing prod app hosts on the fly,
# so that the script does not depend on any external file
TMPFILE=/tmp/appsrvcnt$$.tmp
rm -f $TMPFILE
cat > $TMPFILE << !EOF
cs92prap101
cs92prap102
cs92prap103
cs92prap104
cs92prap105
cs92prap106
cs92prap107
cs92prap108
cs92prap109
cs92prap110
cs92prap111
cs92prap112
cs92prap113
cs92prap114
cs92prap115
cs92prap116
cs92prap117
cs92prap118
cs92prap119
cs92prap120
cs92prap121
cs92prap122
cs92prap123
cs92prap124
cs92prap125
cs92prap126
cs92prap127
cs92prap128
cs92prap129
cs92prap130
cs92prap131
cs92prap132
cs92prap133
cs92prap134
cs92prap135
cs92prap136
cs92prap137
cs92prap138
cs92prap139
fs92prap101
fs92prap102
fs92prap103
fs92prap104
hc92prap101
hc92prap102
hc92prap103
hc92prap104
hc92prap105
hc92prap106
hc92prap107
fs92prap101
fs92prap102
fs92prap103
fs92prap104
ihprap101
ihprap102
ihprap103
ihprap104
ihprap105
ihprap106
ihprap107
ihprap108
ihprap109
ihprap110
ihprap111
ihprap112
ihprap113
ihprap114
ihprap115
ihprap116
ihprap117
ihprap118
ihprap119
ihprap120
ihprap121
ihprap122
ihprap123
ihprap124
ihprap125
ihprap126
!EOF


bolt command run 'bblcnt=$(ps -aef|grep BBL|grep -v grep|wc -l);appsrvcnt=$(ps -aef|grep PSAPPSRV|grep -v grep|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST :BBL:$bblcnt  :PSAPPSRV:$appsrvcnt' -t "@${TMPFILE}" --tty

# delete the temp file
rm -f $TMPFILE
