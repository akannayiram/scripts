#!/bin/bash
# ####################################################
#   Al Kannayiram October 2023
#     1) To get BBL & PSAPPSRV Service counts by pillar
#        and compare against the expected counts
#     2) To get WebLogic Domain counts by pillar
#        and compare against the expected counts
#     Version 3 December 2023
# ####################################################

# ========================
#    F U N C T I O N S
# ========================
# ******************
#  prod_app_hosts
# ******************
prod_app_hosts () {

# Prod host names rarely change, but for major upgrades.
# Build a temporary file containing prod app hosts on the fly,
# so that the script does not depend on any external files
cat > $APPHOSTS << !EOF
cs92prap101
cs92prap102
cs92prap103
cs92prap104
cs92prap105
cs92prap106
cs92prap107
cs92prap108
cs92prap109
cs92prap110
cs92prap111
cs92prap112
cs92prap113
cs92prap114
cs92prap115
cs92prap116
cs92prap117
cs92prap118
cs92prap119
cs92prap120
cs92prap121
cs92prap122
cs92prap123
cs92prap124
cs92prap125
cs92prap126
cs92prap127
cs92prap128
cs92prap129
cs92prap130
cs92prap131
cs92prap132
cs92prap133
cs92prap134
cs92prap135
cs92prap136
cs92prap137
cs92prap138
cs92prap139
fs92prap101
fs92prap102
fs92prap103
fs92prap104
hc92prap101
hc92prap102
hc92prap103
hc92prap104
hc92prap105
hc92prap106
hc92prap107
fs92prap101
fs92prap102
fs92prap103
fs92prap104
ihprap101
ihprap102
ihprap103
ihprap104
ihprap105
ihprap106
ihprap107
ihprap108
ihprap109
ihprap110
ihprap111
ihprap112
ihprap113
ihprap114
ihprap115
ihprap116
ihprap117
ihprap118
ihprap119
ihprap120
ihprap121
ihprap122
ihprap123
ihprap124
ihprap125
ihprap126
!EOF
}

# ******************
#  prod_web_hosts
# ******************
prod_web_hosts () {

# Prod host names rarely change, but for major upgrades.
# Build a temporary file containing prod web hosts on the fly,
# so that the script does not depend on any external files
cat > $WEBHOSTS << !EOF
cs92prwl101
cs92prwl102
cs92prwl103
cs92prwl104
cs92prwl105
cs92prwl106
cs92prwl107
cs92prwl108
fs92prwl101
fs92prwl102
fs92prwl103
fs92prwl104
fs92prwl105
fs92prwl106
hc92prwl101
hc92prwl102
hc92prwl103
hc92prwl104
hc92prwl105
hc92prwl106
ihprwl101
ihprwl102
ihprwl103
ihprwl104
ihprwl105
ihprwl106
!EOF

}

# ******************
#  app_execute_bolt
# ******************
app_execute_bolt () {

#echo "$(date): Submitting bolt command" $infocolor
# bolt command to collect the counts from prod app hosts at once
bolt command run 'bblcnt=$(ps -aef|grep BBL|grep -v grep|wc -l);appsrvcnt=$(ps -aef|grep PSAPPSRV|grep -v grep|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST :BBL:$bblcnt  :PSAPPSRV:$appsrvcnt' -t "@${APPHOSTS}" --tty --connect-timeout 10 > $APPBOLTLOG 2>&1

# delete the temp hosts file
rm -f $APPHOSTS

}

# ******************
#  web_execute_bolt
# ******************
web_execute_bolt () {

#echo "$(date): Submitting bolt command" $infocolor
# bolt command to collect the counts from prod web hosts at once
bolt command run 'domcnt=$(ps -ef|grep java|grep "^cny"|grep "Dps_home="|grep weblogic.Server|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST:WEBDOM:$domcnt' -t "@${WEBHOSTS}" --tty --connect-timeout 10 > $WEBBOLTLOG 2>&1

# delete the temp hosts file
rm -f $WEBHOSTS

}


# ******************
#  app_parse_logs
# ******************
app_parse_logs () {

#echo "$(date): Parsing log output" $infocolor
# ######################################
# Parse the bolt log output
# The input format is:
#   hostname :BBL:cnt1 :PSAPPSRV:cnt2
# Third and fifth fields have the counts
# ######################################

grep BBL $APPBOLTLOG | sort > $APPSTATSLOG


# ###################################
# Expected Total counts:
# CS:      BBL: 41         PSAPPSRV: 492
# HC:      BBL: 8          PSAPPSRV: 128
# FS:      BBL: 5          PSAPPSRV: 68
# IH:      BBL: 27         PSAPPSRV: 434
# ###################################

# Initliaze target counts
#CS
csbbltarget=41; csappsrvtarget=492
#HC
hcbbltarget=8; hcappsrvtarget=128
#FS
fsbbltarget=5; fsappsrvtarget=68
#IH
ihbbltarget=27; ihappsrvtarget=434


# Initialize counters to zero
#CS
csbbltotal=0; csappsrvtotal=0
#HC
hcbbltotal=0; hcappsrvtotal=0
#FS
fsbbltotal=0; fsappsrvtotal=0
#IH
ihbbltotal=0; ihappsrvtotal=0


while read line
do
  # Strip carriage-return
  editline=$(echo $line|sed 's/\r$//')
  # Strip any leading spaces and then get the first two chars
  pillar=$(echo $editline|sed -e "s/^[ ]*//"|cut -c1,2)
  # BBL count is in third field
  bblcnt=$(echo $editline|awk -F":" '{print $3}')
  # APPSRV count is in fifth field
  appsrvcnt=$(echo $editline|sed 's/\r$//'|awk -F":" '{print $5}')

  # Keep running total of BBL and PSAPPSRV services
  # Once a pillar is found, "continue" skips the remaining commands in the loop
  # (Note: "break" terminates the loop)
  [[ "$pillar" == "cs" ]] && csbbltotal=$(( csbbltotal+bblcnt )) && csappsrvtotal=$(( csappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "hc" ]] && hcbbltotal=$(( hcbbltotal+bblcnt )) && hcappsrvtotal=$(( hcappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "fs" ]] && fsbbltotal=$(( fsbbltotal+bblcnt )) && fsappsrvtotal=$(( fsappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "ih" ]] && ihbbltotal=$(( ihbbltotal+bblcnt )) && ihappsrvtotal=$(( ihappsrvtotal+appsrvcnt )) && continue

  echo "$(date): ERROR! ERROR!! Incorrect host/pillar [$(echo $editline|awk '{print $1}')/${pillar}]"

done < $APPSTATSLOG


# Define constants
ok="OK"
mismatch="MISMATCH"

# Compare agaist the expected total
#CS
[[ "$csbbltotal" == "$csbbltarget" ]] && csbbl=$ok || csbbl=$mismatch
[[ "$csappsrvtotal" == "$csappsrvtarget" ]] && csappsrv=$ok || csappsrv=$mismatch

#HC
[[ "$hcbbltotal" == "$hcbbltarget" ]] && hcbbl=$ok || hcbbl=$mismatch
[[ "$hcappsrvtotal" == "$hcappsrvtarget" ]] && hcappsrv=$ok || hcappsrv=$mismatch

#FS
[[ "$fsbbltotal" == "$fsbbltarget" ]] && fsbbl=$ok || fsbbl=$mismatch
[[ "$fsappsrvtotal" == "$fsappsrvtarget" ]] && fsappsrv=$ok || fsappsrv=$mismatch

#IH
[[ "$ihbbltotal" == "$ihbbltarget" ]] && ihbbl=$ok || ihbbl=$mismatch
[[ "$ihappsrvtotal" == "$ihappsrvtarget" ]] && ihappsrv=$ok || ihappsrv=$mismatch


# Initialize
bblmismatch=N;appsrvmismatch=N

# Check if there are any mismatches
[[ "$csbbl" == "$mismatch" ]] || [[ "$hcbbl" == "$mismatch" ]] || [[ "$fsbbl" == "$mismatch" ]] || [[ "$ihbbl" == "$mismatch" ]] && bblmismatch=Y
[[ "$csappsrv" == "$mismatch" ]] || [[ "$hcappsrv" == "$mismatch" ]] || [[ "$fsappsrv" == "$mismatch" ]] || [[ "$ihappsrv" == "$mismatch" ]] && appsrvmismatch=Y


if [[ "$bblmismatch" == "Y" ]] || [[ "$appsrvmismatch" == "Y" ]] ; then
   #
   # Please review the logs. 
   # Log files are not deleted, when there is a mismatch.
   #
   #echo " ";echo " ";date;echo "**************************************" $alertcolor
   echo " "
   echo " ";date;
   echo "**************************************" >> $EMAILBODY
   #echo "PRODUCTION"
   #echo "ERROR! Actual counts did not match the expected counts. Please check"
   echo "APP SERVICES: ERROR! Actual counts did not match the expected counts. Please check"  >> $EMAILBODY
   echo "**************************************" >> $EMAILBODY
   #echo "  1) Trimmed log: \t $APPSTATSLOG" $alertcolor
   #echo "  2) Full log: \t $APPBOLTLOG" $alertcolor
   #echo "**************************************" $alertcolor
   appdomstatus="App Services: F A I L E D  "
else
   appdomstatus="App Services: S U C C E S S"
   # Clean up log, temp files
   rm -f $APPBOLTLOG $APPSTATSLOG
fi
   #echo " ";echo " ";date;echo "**********************************" $successcolor
   AppLine02="**********************************"
   #echo "PRODUCTION"
   #echo "No Issues. BBL and PSAPPSRV counts matched"
   AppLine03="$appdomstatus"
   #msg_color "PRODUCTION: BBL and PSAPPSRV counts matched" $statuscolor
   AppLine04="**********************************"


AppLine05="COUNTS (Actual/Expected/Result)"

AppLine06="PILLAR   BBL            PSAPPSRV"
AppLine07="------------------------------------"
AppLine08="CS:      $csbbltotal/$csbbltarget/$csbbl  $csappsrvtotal/$csappsrvtarget/$csappsrv"
AppLine09="HC:      $hcbbltotal/$hcbbltarget/$hcbbl  $hcappsrvtotal/$hcappsrvtarget/$hcappsrv"
AppLine10="FS:      $fsbbltotal/$fsbbltarget/$fsbbl  $fsappsrvtotal/$fsappsrvtarget/$fsappsrv"
AppLine11="IH:      $ihbbltotal/$ihbbltarget/$ihbbl  $ihappsrvtotal/$ihappsrvtarget/$ihappsrv"

}


# ******************
#  web_parse_logs
# ******************
web_parse_logs () {

#echo "$(date): Parsing log output" $infocolor
# ######################################
# Parse the bolt log output
# The input format is:
#   hostname:WEBDOM:count
# Third field has the counts
# ######################################

grep WEBDOM $WEBBOLTLOG | sort > $WEBSTATSLOG


# ###################################
# Expected Total WebLogic Domain counts:
# CS:      WEBDOM: 22
# HC:      WEBDOM: 10
# FS:      WEBDOM: 8
# IH:      WEBDOM: 18
# ###################################

# Initliaze target counts
#CS #HC #FS #IH
cswebdomtarget=22; hcwebdomtarget=10; fswebdomtarget=8; ihwebdomtarget=18


# Initialize counters to zero
#CS #HC #FS #IH
cswebdomtotal=0; hcwebdomtotal=0; fswebdomtotal=0; ihwebdomtotal=0


while read line
do
  # Strip carriage-return
  editline=$(echo $line|sed 's/\r$//')
  # Strip any leading spaces and then get the first two chars
  pillar=$(echo $editline|sed -e "s/^[ ]*//"|cut -c1,2)
  # WEBDOM count is in third field
  webdomcnt=$(echo $editline|awk -F":" '{print $3}')

  # Keep running total of WEBDOM services
  # Once a pillar is found, "continue" skips the remaining commands in the loop
  # (Note: "break" terminates the loop)
  [[ "$pillar" == "cs" ]] && cswebdomtotal=$(( cswebdomtotal+webdomcnt )) && continue
  [[ "$pillar" == "hc" ]] && hcwebdomtotal=$(( hcwebdomtotal+webdomcnt )) && continue
  [[ "$pillar" == "fs" ]] && fswebdomtotal=$(( fswebdomtotal+webdomcnt )) && continue
  [[ "$pillar" == "ih" ]] && ihwebdomtotal=$(( ihwebdomtotal+webdomcnt )) && continue

  echo "$(date): ERROR! ERROR!! Incorrect host/pillar [$(echo $editline|awk '{print $1}')/${pillar}]"

done < $WEBSTATSLOG


# Define constants
ok="OK"
mismatch="MISMATCH"

# Compare agaist the expected total
#CS
[[ "$cswebdomtotal" == "$cswebdomtarget" ]] && cswebdom=$ok || cswebdom=$mismatch

#HC
[[ "$hcwebdomtotal" == "$hcwebdomtarget" ]] && hcwebdom=$ok || hcwebdom=$mismatch

#FS
[[ "$fswebdomtotal" == "$fswebdomtarget" ]] && fswebdom=$ok || fswebdom=$mismatch

#IH
[[ "$ihwebdomtotal" == "$ihwebdomtarget" ]] && ihwebdom=$ok || ihwebdom=$mismatch


# Initialize
webdommismatch=N

# Check if there are any mismatches
[[ "$cswebdom" == "$mismatch" ]] || [[ "$hcwebdom" == "$mismatch" ]] || [[ "$fswebdom" == "$mismatch" ]] || [[ "$ihwebdom" == "$mismatch" ]] && webdommismatch=Y


if [[ "$webdommismatch" == "Y" ]] ; then
   #
   # Please review the logs. 
   # Log files are not deleted, when there is a mismatch.
   #
   #echo " ";echo " ";date;echo "**************************************" $alertcolor
   echo " "
   echo " ";date;
   echo "**************************************"  >> $EMAILBODY
   #echo "PRODUCTION"
   #echo "ERROR! Actual counts did not match the expected counts. Please check"
   echo "WEB SERVICES: ERROR! ERROR!! Actual counts did not match the expected counts. Please check"  >> $EMAILBODY
   echo "**************************************"  >> $EMAILBODY
   #echo "  1) Trimmed log: \t $WEBSTATSLOG" $alertcolor
   #echo "  2) Full log: \t $WEBBOLTLOG" $alertcolor
   #echo "**************************************" $alertcolor
   webdomstatus="Web Services: F A I L E D  "
else
   webdomstatus="Web Services: S U C C E S S"
   # Clean up log, temp files
   rm -f $WEBBOLTLOG $WEBSTATSLOG
fi
   #echo " ";echo " ";date;echo "**********************************" $successcolor
   WebLine02="*******************************"
   #echo "PRODUCTION"
   #echo "No Issues. BBL and PSAPPSRV counts matched"
   WebLine03="$webdomstatus"
   #echo "PRODUCTION: WebLogic Domain counts matched" $successcolor
   WebLine04="*******************************" 


WebLine05="COUNTS (Actual/Expected/Result)"

WebLine06="PILLAR   WEBDOMAIN "
WebLine07="-------------------------------"
WebLine08="CS:      $cswebdomtotal/$cswebdomtarget/$cswebdom "
WebLine09="HC:      $hcwebdomtotal/$hcwebdomtarget/$hcwebdom "
WebLine10="FS:      $fswebdomtotal/$fswebdomtarget/$fswebdom "
WebLine11="IH:      $ihwebdomtotal/$ihwebdomtarget/$ihwebdom "

}


buildemail ()
{

# tmp file for email body
EMAILBODY=/tmp/email$$.alk.tmp
rm -f $EMAILBODY
cat > $EMAILBODY <<!EOF
PSA - App and Web Services Status

!EOF

}

progressbar ()
{

while true
do
echo -n ".........."
#echo -n "/\\/\\/\\/\\"
sleep 1
done

}

# **************************************
#    E N D    O F    F U N C T I O N S
# **************************************

# **********************
# Main program
# *********************

#progressbar &
#displpid=$! 

# To suppress 'killed' message, execute disown. 
# The disown will remove the most recently spawned process 
# from the list of watched "jobs" so that no debug message 
# will be generated when it is killed, even with SIGKILL (-9).
#disown

# Constants
successcolor=green
alertcolor=red
#infocolor=lpurple
infocolor="white"
statuscolor=""
msg_return=""


FROMEMAIL="akannayiram@workbench.cf.cuny.edu"
TOEMAIL="al.kannayiram@sierra-cedar.com"
buildemail

# Initialize 

# Host files
APPHOSTS=/tmp/apphosts$$.tmp; rm -f $APPHOSTS
WEBHOSTS=/tmp/webhosts$$.tmp; rm -f $WEBHOSTS

# Log files
APPBOLTLOG=/tmp/stats_${HOSTNAME}.${LOGNAME}.appsrv.$(date '+%Y%m%d_%H%M%S').log; rm -f $APPBOLTLOG
APPSTATSLOG=/tmp/trimmedlog$$.tmp; rm -f $APPSTATSLOG

WEBBOLTLOG=/tmp/stats_${HOSTNAME}.${LOGNAME}.weblogic.$(date '+%Y%m%d_%H%M%S').log; rm -f $WEBBOLTLOG
WEBSTATSLOG=/tmp/webtrimmedlog$$.tmp; rm -f $WEBSTATSLOG

# Output lines
AppLine01=""; AppLine02=""; AppLine03=""; AppLine04=""; AppLine05=""; AppLine06=""; AppLine07=""; AppLine08=""; AppLine09=""; AppLine10=""; AppLine11=""
WebLine01=""; WebLine02=""; WebLine03=""; WebLine04=""; WebLine05=""; WebLine06=""; WebLine07=""; WebLine08=""; WebLine09=""; WebLine10=""; WebLine11=""


prod_app_hosts

app_execute_bolt

app_parse_logs

prod_web_hosts

web_execute_bolt

web_parse_logs

#kill -9 $displpid > /dev/null 2>&1
#echo "PID: $displpid"
#kill -9 -INT $displpid > /dev/null 2>&1
#kill -9 $displpid > /dev/null 2>&1

echo " " >> $EMAILBODY

echo "$(date)" >> $EMAILBODY

echo " " >> $EMAILBODY

echo "App Services Status" >> $EMAILBODY


  echo "$AppLine02" >> $EMAILBODY
  echo "$AppLine03" >> $EMAILBODY
  echo "$AppLine04" >> $EMAILBODY
  echo "$AppLine05" >> $EMAILBODY
  echo "$AppLine06" >> $EMAILBODY
  echo "$AppLine07" >> $EMAILBODY
  echo "$AppLine08" >> $EMAILBODY
  echo "$AppLine09" >> $EMAILBODY
  echo "$AppLine10" >> $EMAILBODY
  echo "$AppLine11" >> $EMAILBODY


echo " " >> $EMAILBODY
echo " " >> $EMAILBODY

echo "Web Services Status" >> $EMAILBODY

  echo "$WebLine02" >> $EMAILBODY
  echo "$WebLine03" >> $EMAILBODY
  echo "$WebLine04" >> $EMAILBODY
  echo "$WebLine05" >> $EMAILBODY
  echo "$WebLine06" >> $EMAILBODY
  echo "$WebLine07" >> $EMAILBODY
  echo "$WebLine08" >> $EMAILBODY
  echo "$WebLine09" >> $EMAILBODY
  echo "$WebLine10" >> $EMAILBODY
  echo "$WebLine11" >> $EMAILBODY


mail -s "PSA App and Web Services Status" $TOEMAIL < $EMAILBODY
echo "Email sent"

# ######## END ###########
