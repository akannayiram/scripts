#!/bin/bash
# ####################################################
#   Al Kannayiram October 2023
#     To get BBL & PSAPPSRV Service counts by pillar
#        and compare against the expected counts
# ####################################################

# ========================
#    F U N C T I O N S
# ========================
function echo_color
{
    text=$1
    color=$2

    case $color in
        red) code="0;31m" ;;
        green) code="0;32m" ;;
        brown) code="0;33m" ;;
        blue) code="0;34m" ;;
        purple) code="0;35m" ;;
        cyan) code="0;36m" ;;
        gray) code="1;30m" ;;
        lred) code="1;31m" ;;
        lgreen) code="1;32m" ;;
        yellow) code="1;33m" ;;
        lblue) code="1;34m" ;;
        lpurple) code="1;35m" ;;
        lcyan) code="1;36m" ;;
        lgray) code="0;37m" ;;
        *) code="0m" ;;
    esac

    echo -e "\e[$code$text\e[0m"

}

# Constants
successcolor=green
alertcolor=red
infocolor=lpurple
statuscolor=""

# Prod host names rarely change, but for major upgrades.
# Build a temporary file containing prod app hosts on the fly,
# so that the script does not depend on any external file
APPHOSTS=/tmp/apphosts$$.tmp; rm -f $APPHOSTS
cat > $APPHOSTS << !EOF
cs92prap101
cs92prap102
cs92prap103
cs92prap104
cs92prap105
cs92prap106
cs92prap107
cs92prap108
cs92prap109
cs92prap110
cs92prap111
cs92prap112
cs92prap113
cs92prap114
cs92prap115
cs92prap116
cs92prap117
cs92prap118
cs92prap119
cs92prap120
cs92prap121
cs92prap122
cs92prap123
cs92prap124
cs92prap125
cs92prap126
cs92prap127
cs92prap128
cs92prap129
cs92prap130
cs92prap131
cs92prap132
cs92prap133
cs92prap134
cs92prap135
cs92prap136
cs92prap137
cs92prap138
cs92prap139
fs92prap101
fs92prap102
fs92prap103
fs92prap104
hc92prap101
hc92prap102
hc92prap103
hc92prap104
hc92prap105
hc92prap106
hc92prap107
fs92prap101
fs92prap102
fs92prap103
fs92prap104
ihprap101
ihprap102
ihprap103
ihprap104
ihprap105
ihprap106
ihprap107
ihprap108
ihprap109
ihprap110
ihprap111
ihprap112
ihprap113
ihprap114
ihprap115
ihprap116
ihprap117
ihprap118
ihprap119
ihprap120
ihprap121
ihprap122
ihprap123
ihprap124
ihprap125
ihprap126
es92npwl050
!EOF


WEBHOSTS=/tmp/webhosts$$.tmp; rm -f $WEBHOSTS
cat > $WEBHOSTS << !EOF
cs92prwl101
cs92prwl102
cs92prwl103
cs92prwl104
cs92prwl105
cs92prwl106
cs92prwl107
cs92prwl108
fs92prwl101
fs92prwl102
fs92prwl103
fs92prwl104
fs92prwl105
fs92prwl106
hc92prwl101
hc92prwl102
hc92prwl103
hc92prwl104
hc92prwl105
hc92prwl106
ihprwl101
ihprwl102
ihprwl103
ihprwl104
ihprwl105
ihprwl106
!EOF

APPLOGFILE=/tmp/appstats_${HOSTNAME}.${LOGNAME}.appsrv.$(date '+%Y%m%d_%H%M%S').log; rm -f $APPLOGFILE

echo_color "$(date): Submitting bolt command" $infocolor
# bolt command to collect the counts from prod app hosts at once
bolt command run 'bblcnt=$(ps -aef|grep BBL|grep -v grep|wc -l);appsrvcnt=$(ps -aef|grep PSAPPSRV|grep -v grep|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST :BBL:$bblcnt  :PSAPPSRV:$appsrvcnt' -t "@${APPHOSTS}" --tty --connect-timeout 30 > $APPLOGFILE 2>&1

# delete the temp hosts file
rm -f $APPHOSTS


echo_color "$(date): Parsing log output" $infocolor
# ######################################
# Parse the bolt log output
# The input format is:
#   hostname :BBL:cnt1 :PSAPPSRV:cnt2
# Third and fifth fields have the counts
# ######################################

APPTRIMMEDLOG=/tmp/apptrimmedlog$$.tmp; rm -f $APPTRIMMEDLOG
grep BBL $APPLOGFILE | sort > $APPTRIMMEDLOG


# ###################################
# Expected Total counts:
# CS:      BBL: 41         PSAPPSRV: 492
# HC:      BBL: 8          PSAPPSRV: 128
# FS:      BBL: 5          PSAPPSRV: 68
# IH:      BBL: 27         PSAPPSRV: 434
# ###################################

# Initliaze target counts
#CS
csbbltarget=41; csappsrvtarget=492
#HC
hcbbltarget=8; hcappsrvtarget=128
#FS
fsbbltarget=5; fsappsrvtarget=68
#IH
ihbbltarget=27; ihappsrvtarget=434


# Initialize counters to zero
#CS
csbbltotal=0; csappsrvtotal=0
#HC
hcbbltotal=0; hcappsrvtotal=0
#FS
fsbbltotal=0; fsappsrvtotal=0
#IH
ihbbltotal=0; ihappsrvtotal=0


while read line
do
  # Strip carriage-return
  editline=$(echo $line|sed 's/\r$//')
  # Strip any leading spaces and then get the first two chars
  pillar=$(echo $editline|sed -e "s/^[ ]*//"|cut -c1,2)
  # BBL count is in third field
  bblcnt=$(echo $editline|awk -F":" '{print $3}')
  # APPSRV count is in fifth field
  appsrvcnt=$(echo $editline|sed 's/\r$//'|awk -F":" '{print $5}')

  # Keep running total of BBL and PSAPPSRV services
  [[ "$pillar" == "cs" ]] && csbbltotal=$(( csbbltotal+bblcnt )) && csappsrvtotal=$(( csappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "hc" ]] && hcbbltotal=$(( hcbbltotal+bblcnt )) && hcappsrvtotal=$(( hcappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "fs" ]] && fsbbltotal=$(( fsbbltotal+bblcnt )) && fsappsrvtotal=$(( fsappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "ih" ]] && ihbbltotal=$(( ihbbltotal+bblcnt )) && ihappsrvtotal=$(( ihappsrvtotal+appsrvcnt )) && continue

  echo_color "$(date): ERROR! ERROR!! Incorrect host/pillar [$(echo $editline|awk '{print $1}')/${pillar}]" $alertcolor

done < $TRIMMEDLOG


# Define constants
ok="OK"
mismatch="MISMATCH"

# Compare agaist the expected total
#CS
[[ "$csbbltotal" == "$csbbltarget" ]] && csbbl=$ok || csbbl=$mismatch
[[ "$csappsrvtotal" == "$csappsrvtarget" ]] && csappsrv=$ok || csappsrv=$mismatch

#HC
[[ "$hcbbltotal" == "$hcbbltarget" ]] && hcbbl=$ok || hcbbl=$mismatch
[[ "$hcappsrvtotal" == "$hcappsrvtarget" ]] && hcappsrv=$ok || hcappsrv=$mismatch

#FS
[[ "$fsbbltotal" == "$fsbbltarget" ]] && fsbbl=$ok || fsbbl=$mismatch
[[ "$fsappsrvtotal" == "$fsappsrvtarget" ]] && fsappsrv=$ok || fsappsrv=$mismatch

#IH
[[ "$ihbbltotal" == "$ihbbltarget" ]] && ihbbl=$ok || ihbbl=$mismatch
[[ "$ihappsrvtotal" == "$ihappsrvtarget" ]] && ihappsrv=$ok || ihappsrv=$mismatch


# Initialize
bblmismatch=N;appsrvmismatch=N

# Check if there are any mismatches
[[ "$csbbl" == "$mismatch" ]] || [[ "$hcbbl" == "$mismatch" ]] || [[ "$fsbbl" == "$mismatch" ]] || [[ "$ihbbl" == "$mismatch" ]] && bblmismatch=Y
[[ "$csappsrv" == "$mismatch" ]] || [[ "$hcappsrv" == "$mismatch" ]] || [[ "$fsappsrv" == "$mismatch" ]] || [[ "$ihappsrv" == "$mismatch" ]] && appsrvmismatch=Y


if [[ "$bblmismatch" == "Y" ]] || [[ "$appsrvmismatch" == "Y" ]] ; then
   #
   # Please review the logs. 
   # Log files are not deleted, when there is a mismatch.
   #
   echo " ";echo " ";date;echo_color "**************************************" $alertcolor
   #echo "PRODUCTION"
   #echo "ERROR! Total counts did not match the expected counts. Please check"
   echo_color "PRODUCTION: ERROR! ERROR!! Total counts did not match the expected counts. Please check" $alertcolor
   echo_color "  1) Trimmed log: \t $APPTRIMMEDLOG" $alertcolor
   echo_color "  2) Full log: \t $APPLOGFILE" $alertcolor
   echo_color "**************************************" $alertcolor
   statuscolor=$alertcolor
else
   echo " ";echo " ";date;echo_color "**********************************" $successcolor
   #echo "PRODUCTION"
   #echo "No Issues. BBL and PSAPPSRV counts matched"
   echo_color "S U C C E S S    S U C C E S S" $successcolor
   echo_color "PRODUCTION: BBL and PSAPPSRV counts matched" $successcolor
   echo_color "**********************************" $successcolor
   statuscolor=$successcolor
   # Clean up log, temp files
   rm -f $APPLOGFILE $APPTRIMMEDLOG
fi


echo_color "BBL AND PSAPPSRV COUNTS (Total/Expected/Result)" $statuscolor

echo_color "PILLAR \t BBL \t\t PSAPPSRV" $statuscolor
echo_color "--------------------------------------" $statuscolor
echo_color "CS: \t $csbbltotal/$csbbltarget/$csbbl \t $csappsrvtotal/$csappsrvtarget/$csappsrv" $statuscolor
echo_color "HC: \t $hcbbltotal/$hcbbltarget/$hcbbl \t $hcappsrvtotal/$hcappsrvtarget/$hcappsrv" $statuscolor
echo_color "FS: \t $fsbbltotal/$fsbbltarget/$fsbbl \t $fsappsrvtotal/$fsappsrvtarget/$fsappsrv" $statuscolor
echo_color "IH: \t $ihbbltotal/$ihbbltarget/$ihbbl \t $ihappsrvtotal/$ihappsrvtarget/$ihappsrv" $statuscolor

