# ###################################################
#  Global Functions for scripts (logs, date/time etc.)
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 09/10/2021 Al Kannayiram    Initial develoment
#
# ###################################################

# ======================================
#    G L O B A L    C O N S T A N T S
# ======================================

# Set common environment variables

#DTTM=`date '+%Y-%m-%d_%H.%M.%S'`
DTTM=`date '+%Y-%m-%d_%H%M%S'`
DTYYYY=`date '+%Y'`

# ========================
#    F U N C T I O N S
# ========================


function echo_color
{
    text=$1
    color=$2

    case $color in
        red) code="0;31m" ;;
        green) code="0;32m" ;;
        brown) code="0;33m" ;;
        blue) code="0;34m" ;;
        purple) code="0;35m" ;;
        cyan) code="0;36m" ;;
        gray) code="1;30m" ;;
        lred) code="1;31m" ;;
        lgreen) code="1;32m" ;;
        yellow) code="1;33m" ;;
        lblue) code="1;34m" ;;
        lpurple) code="1;35m" ;;
        lcyan) code="1;36m" ;;
        lgray) code="0;37m" ;;
        *) code="0m" ;;
    esac

    echo -e "\e[$code$text\e[0m"

}


function check_arguments
{
# Check if input parameter is passed
[[ $# -eq 0 ]] && { echo "$(echo_color "$0: Missing input parameter" "lred")"; echo "$(echo_color "ERROR ERROR...Aborting" "lred")"; exit; }

[[ ! "$1" == "status" && ! "$1" == "start" && ! "$1" == "stop" ]] && { echo "$(echo_color "Invalid parameter $1. Must be start, stop, or status" "lred")"; exit; }

}


function validate_if_file_exists
{

# check if file exists
[[ ! -f $1 ]] && { echo "$(echo_color "ERROR ERROR!! Input file [$1] is missing. Aborting....." "lred")" ; exit; }

}


function validate_if_script_exists
{

# check if script exists
[[ -f $1 && ! -x $1 ]] && { echo "$(echo_color "ERROR ERROR!! Input script [$1] is not executable. Aborting....." "lred")" ; exit; }
[[ ! -f $1 ]] && { echo "$(echo_color "ERROR ERROR!! Input script [$1] is missing. Aborting....." "lred")" ; exit; }

}


function validate_if_dir_exists
{

# check if directory exists
[[ -d $1 && ! -w $1 ]] && { echo "$(echo_color "ERROR ERROR!! Input dir [$1] is not writable. Aborting....." "lred")"; exit; }
[[ ! -d $1 ]] && { echo "$(echo_color "ERROR ERROR!! Input dir [$1] is missing. Aborting....." "lred")"; exit; }

}

