#!/bin/bash
# ####################################################
#   Al Kannayiram October 2023
#     1) To get BBL & PSAPPSRV Service counts by pillar
#        and compare against the expected counts
#     2) To get WebLogic Domain counts by pillar
#        and compare against the expected counts
#     Version 3 December 2023
# ####################################################

# ========================
#    F U N C T I O N S
# ========================
# ******************
#  prod_app_hosts
# ******************
prod_app_hosts () {

# Prod host names rarely change, but for major upgrades.
# Build a temporary file containing prod app hosts on the fly,
# so that the script does not depend on any external files
for ((a=101; a<=139; a++)) do echo "cs92prap$a" >> $APPHOSTS; done
for ((a=101; a<=104; a++)) do echo "fs92prap$a" >> $APPHOSTS; done
for ((a=101; a<=107; a++)) do echo "hc92prap$a" >> $APPHOSTS; done
for ((a=101; a<=126; a++)) do echo "ihprap$a" >> $APPHOSTS; done
}

# ******************
#  prod_web_hosts
# ******************
prod_web_hosts () {

# Prod host names rarely change, but for major upgrades.
# Build a temporary file containing prod web hosts on the fly,
# so that the script does not depend on any external files
for ((a=101; a<=108; a++)) do echo "cs92prwl$a" >> $WEBHOSTS; done
for ((a=101; a<=106; a++)) do echo "fs92prwl$a" >> $WEBHOSTS; done
for ((a=101; a<=106; a++)) do echo "hc92prwl$a" >> $WEBHOSTS; done
for ((a=101; a<=106; a++)) do echo "ihprwl$a" >> $WEBHOSTS; done
}

# ******************
#  msg_color
# ******************
function msg_color
{
    text="$1"
    color=$2

    case $color in
        red) code="0;31m" ;;
        green) code="0;32m" ;;
        brown) code="0;33m" ;;
        blue) code="0;34m" ;;
        purple) code="0;35m" ;;
        cyan) code="0;36m" ;;
        gray) code="1;30m" ;;
        lred) code="1;31m" ;;
        lgreen) code="1;32m" ;;
        yellow) code="1;33m" ;;
        lblue) code="1;34m" ;;
        lpurple) code="1;35m" ;;
        lcyan) code="1;36m" ;;
        lgray) code="0;37m" ;;
        *) code="0m" ;;
    esac

    msg_return="\e[$code$text\e[0m"

}

# ******************
#  echo_color
# ******************
function echo_color
{
    text="$1"
    color=$2

    case $color in
        red) code="0;31m" ;;
        green) code="0;32m" ;;
        brown) code="0;33m" ;;
        blue) code="0;34m" ;;
        purple) code="0;35m" ;;
        cyan) code="0;36m" ;;
        gray) code="1;30m" ;;
        lred) code="1;31m" ;;
        lgreen) code="1;32m" ;;
        yellow) code="1;33m" ;;
        lblue) code="1;34m" ;;
        lpurple) code="1;35m" ;;
        lcyan) code="1;36m" ;;
        lgray) code="0;37m" ;;
        *) code="0m" ;;
    esac

    echo -e "\e[$code$text\e[0m"

}

# ******************
#  app_execute_bolt
# ******************
app_execute_bolt () {

#echo_color "$(date): Submitting bolt command" $infocolor
# bolt command to collect the counts from prod app hosts at once
bolt command run 'bblcnt=$(ps -aef|grep BBL|grep -v grep|wc -l);appsrvcnt=$(ps -aef|grep PSAPPSRV|grep -v grep|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST :BBL:$bblcnt  :PSAPPSRV:$appsrvcnt' -t "@${APPHOSTS}" --tty --connect-timeout 10 > $APPBOLTLOG 2>&1

# delete the temp hosts file
rm -f $APPHOSTS

}

# ******************
#  web_execute_bolt
# ******************
web_execute_bolt () {

#echo_color "$(date): Submitting bolt command" $infocolor
# bolt command to collect the counts from prod web hosts at once
bolt command run 'domcnt=$(ps -ef|grep java|grep "^cny"|grep "Dps_home="|grep weblogic.Server|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST:WEBDOM:$domcnt' -t "@${WEBHOSTS}" --tty --connect-timeout 10 > $WEBBOLTLOG 2>&1

# delete the temp hosts file
rm -f $WEBHOSTS

}


# ******************
#  app_parse_logs
# ******************
app_parse_logs () {

#echo_color "$(date): Parsing log output" $infocolor
# ######################################
# Parse the bolt log output
# The input format is:
#   hostname :BBL:cnt1 :PSAPPSRV:cnt2
# Third and fifth fields have the counts
# ######################################

grep BBL $APPBOLTLOG | sort > $APPSTATSLOG


# ###################################
# Expected Total counts:
# CS:      BBL: 41         PSAPPSRV: 428 (used to be 492)
# HC:      BBL: 8          PSAPPSRV: 128
# FS:      BBL: 5          PSAPPSRV: 60  (Used to be 68)
# IH:      BBL: 27         PSAPPSRV: 434
# ###################################

# Initliaze target counts
#CS
csbbltarget=41; csappsrvtarget=428
#HC
hcbbltarget=8; hcappsrvtarget=128
#FS
fsbbltarget=5; fsappsrvtarget=60
#IH
ihbbltarget=27; ihappsrvtarget=434


# Initialize counters to zero
#CS
csbbltotal=0; csappsrvtotal=0
#HC
hcbbltotal=0; hcappsrvtotal=0
#FS
fsbbltotal=0; fsappsrvtotal=0
#IH
ihbbltotal=0; ihappsrvtotal=0


while read line
do
  # Strip carriage-return
  editline=$(echo $line|sed 's/\r$//')
  # Strip any leading spaces and then get the first two chars
  pillar=$(echo $editline|sed -e "s/^[ ]*//"|cut -c1,2)
  # BBL count is in third field
  bblcnt=$(echo $editline|awk -F":" '{print $3}')
  # APPSRV count is in fifth field
  appsrvcnt=$(echo $editline|sed 's/\r$//'|awk -F":" '{print $5}')

  # Keep running total of BBL and PSAPPSRV services
  # Once a pillar is found, "continue" skips the remaining commands in the loop
  # (Note: "break" terminates the loop)
  [[ "$pillar" == "cs" ]] && csbbltotal=$(( csbbltotal+bblcnt )) && csappsrvtotal=$(( csappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "hc" ]] && hcbbltotal=$(( hcbbltotal+bblcnt )) && hcappsrvtotal=$(( hcappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "fs" ]] && fsbbltotal=$(( fsbbltotal+bblcnt )) && fsappsrvtotal=$(( fsappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "ih" ]] && ihbbltotal=$(( ihbbltotal+bblcnt )) && ihappsrvtotal=$(( ihappsrvtotal+appsrvcnt )) && continue

  echo_color "$(date): ERROR! ERROR!! Incorrect host/pillar [$(echo $editline|awk '{print $1}')/${pillar}]" $alertcolor

done < $APPSTATSLOG


# Define constants
ok="OK"
mismatch="MISMATCH"

# Compare agaist the expected total
#CS
[[ "$csbbltotal" == "$csbbltarget" ]] && csbbl=$ok || csbbl=$mismatch
[[ "$csappsrvtotal" == "$csappsrvtarget" ]] && csappsrv=$ok || csappsrv=$mismatch

#HC
[[ "$hcbbltotal" == "$hcbbltarget" ]] && hcbbl=$ok || hcbbl=$mismatch
[[ "$hcappsrvtotal" == "$hcappsrvtarget" ]] && hcappsrv=$ok || hcappsrv=$mismatch

#FS
[[ "$fsbbltotal" == "$fsbbltarget" ]] && fsbbl=$ok || fsbbl=$mismatch
[[ "$fsappsrvtotal" == "$fsappsrvtarget" ]] && fsappsrv=$ok || fsappsrv=$mismatch

#IH
[[ "$ihbbltotal" == "$ihbbltarget" ]] && ihbbl=$ok || ihbbl=$mismatch
[[ "$ihappsrvtotal" == "$ihappsrvtarget" ]] && ihappsrv=$ok || ihappsrv=$mismatch


# Initialize
bblmismatch=N;appsrvmismatch=N

# Check if there are any mismatches
[[ "$csbbl" == "$mismatch" ]] || [[ "$hcbbl" == "$mismatch" ]] || [[ "$fsbbl" == "$mismatch" ]] || [[ "$ihbbl" == "$mismatch" ]] && bblmismatch=Y
[[ "$csappsrv" == "$mismatch" ]] || [[ "$hcappsrv" == "$mismatch" ]] || [[ "$fsappsrv" == "$mismatch" ]] || [[ "$ihappsrv" == "$mismatch" ]] && appsrvmismatch=Y


if [[ "$bblmismatch" == "Y" ]] || [[ "$appsrvmismatch" == "Y" ]] ; then
   #
   # Please review the logs. 
   # Log files are not deleted, when there is a mismatch.
   #
   #echo " ";echo " ";date;echo_color "**************************************" $alertcolor
   echo " "
   echo " ";date;echo_color "**************************************" $alertcolor
   #echo "PRODUCTION"
   #echo "ERROR! Actual counts did not match the expected counts. Please check"
   echo_color "PRODUCTION: ERROR! ERROR!! Actual counts did not match the expected counts. Please check" $alertcolor
   echo_color "  1) Trimmed log: \t $APPSTATSLOG" $alertcolor
   echo_color "  2) Full log: \t $APPBOLTLOG" $alertcolor
   echo_color "**************************************" $alertcolor
   statuscolor=$alertcolor
   appdomstatus="App Services: F A I L E D  "
else
   statuscolor=$successcolor
   appdomstatus="App Services: S U C C E S S"
   # Clean up log, temp files
   rm -f $APPBOLTLOG $APPSTATSLOG
fi
   #echo " ";echo " ";date;echo_color "**********************************" $successcolor
   msg_color "**********************************" $statuscolor ; AppLine02=$msg_return
   #echo "PRODUCTION"
   #echo "No Issues. BBL and PSAPPSRV counts matched"
   msg_color "$appdomstatus" $statuscolor ; AppLine03=$msg_return
   #msg_color "PRODUCTION: BBL and PSAPPSRV counts matched" $statuscolor
   msg_color "**********************************" $statuscolor ; AppLine04=$msg_return


msg_color "COUNTS (Actual/Expected/Result)" $statuscolor ; AppLine05=$msg_return

msg_color "PILLAR \t BBL \t\t PSAPPSRV" $statuscolor ; AppLine06=$msg_return
msg_color "------------------------------------" $statuscolor ; AppLine07=$msg_return
msg_color "CS: \t $csbbltotal/$csbbltarget/$csbbl \t $csappsrvtotal/$csappsrvtarget/$csappsrv" $statuscolor ; AppLine08=$msg_return
msg_color "HC: \t $hcbbltotal/$hcbbltarget/$hcbbl \t $hcappsrvtotal/$hcappsrvtarget/$hcappsrv" $statuscolor ; AppLine09=$msg_return
msg_color "FS: \t $fsbbltotal/$fsbbltarget/$fsbbl \t $fsappsrvtotal/$fsappsrvtarget/$fsappsrv" $statuscolor ; AppLine10=$msg_return
msg_color "IH: \t $ihbbltotal/$ihbbltarget/$ihbbl \t $ihappsrvtotal/$ihappsrvtarget/$ihappsrv" $statuscolor ; AppLine11=$msg_return

}


# ******************
#  web_parse_logs
# ******************
web_parse_logs () {

#echo_color "$(date): Parsing log output" $infocolor
# ######################################
# Parse the bolt log output
# The input format is:
#   hostname:WEBDOM:count
# Third field has the counts
# ######################################

grep WEBDOM $WEBBOLTLOG | sort > $WEBSTATSLOG


# ###################################
# Expected Total WebLogic Domain counts:
# CS:      WEBDOM: 22
# HC:      WEBDOM: 10
# FS:      WEBDOM: 8
# IH:      WEBDOM: 18
# ###################################

# Initliaze target counts
#CS #HC #FS #IH
cswebdomtarget=22; hcwebdomtarget=10; fswebdomtarget=8; ihwebdomtarget=18


# Initialize counters to zero
#CS #HC #FS #IH
cswebdomtotal=0; hcwebdomtotal=0; fswebdomtotal=0; ihwebdomtotal=0


while read line
do
  # Strip carriage-return
  editline=$(echo $line|sed 's/\r$//')
  # Strip any leading spaces and then get the first two chars
  pillar=$(echo $editline|sed -e "s/^[ ]*//"|cut -c1,2)
  # WEBDOM count is in third field
  webdomcnt=$(echo $editline|awk -F":" '{print $3}')

  # Keep running total of WEBDOM services
  # Once a pillar is found, "continue" skips the remaining commands in the loop
  # (Note: "break" terminates the loop)
  [[ "$pillar" == "cs" ]] && cswebdomtotal=$(( cswebdomtotal+webdomcnt )) && continue
  [[ "$pillar" == "hc" ]] && hcwebdomtotal=$(( hcwebdomtotal+webdomcnt )) && continue
  [[ "$pillar" == "fs" ]] && fswebdomtotal=$(( fswebdomtotal+webdomcnt )) && continue
  [[ "$pillar" == "ih" ]] && ihwebdomtotal=$(( ihwebdomtotal+webdomcnt )) && continue

  echo_color "$(date): ERROR! ERROR!! Incorrect host/pillar [$(echo $editline|awk '{print $1}')/${pillar}]" $alertcolor

done < $WEBSTATSLOG


# Define constants
ok="OK"
mismatch="MISMATCH"

# Compare agaist the expected total
#CS
[[ "$cswebdomtotal" == "$cswebdomtarget" ]] && cswebdom=$ok || cswebdom=$mismatch

#HC
[[ "$hcwebdomtotal" == "$hcwebdomtarget" ]] && hcwebdom=$ok || hcwebdom=$mismatch

#FS
[[ "$fswebdomtotal" == "$fswebdomtarget" ]] && fswebdom=$ok || fswebdom=$mismatch

#IH
[[ "$ihwebdomtotal" == "$ihwebdomtarget" ]] && ihwebdom=$ok || ihwebdom=$mismatch


# Initialize
webdommismatch=N

# Check if there are any mismatches
[[ "$cswebdom" == "$mismatch" ]] || [[ "$hcwebdom" == "$mismatch" ]] || [[ "$fswebdom" == "$mismatch" ]] || [[ "$ihwebdom" == "$mismatch" ]] && webdommismatch=Y


if [[ "$webdommismatch" == "Y" ]] ; then
   #
   # Please review the logs. 
   # Log files are not deleted, when there is a mismatch.
   #
   #echo " ";echo " ";date;echo_color "**************************************" $alertcolor
   echo " "
   echo " ";date;echo_color "**************************************" $alertcolor
   #echo "PRODUCTION"
   #echo "ERROR! Actual counts did not match the expected counts. Please check"
   echo_color "PRODUCTION: ERROR! ERROR!! Actual counts did not match the expected counts. Please check" $alertcolor
   echo_color "  1) Trimmed log: \t $WEBSTATSLOG" $alertcolor
   echo_color "  2) Full log: \t $WEBBOLTLOG" $alertcolor
   echo_color "**************************************" $alertcolor
   statuscolor=$alertcolor
   webdomstatus="Web Services: F A I L E D  "
else
   statuscolor=$successcolor
   webdomstatus="Web Services: S U C C E S S"
   # Clean up log, temp files
   rm -f $WEBBOLTLOG $WEBSTATSLOG
fi
   #echo " ";echo " ";date;echo_color "**********************************" $successcolor
   msg_color "*******************************" $statuscolor ; WebLine02=$msg_return
   #echo "PRODUCTION"
   #echo "No Issues. BBL and PSAPPSRV counts matched"
   msg_color "$webdomstatus" $statuscolor ; WebLine03=$msg_return
   #echo_color "PRODUCTION: WebLogic Domain counts matched" $successcolor
   msg_color "*******************************" $statuscolor ; WebLine04=$msg_return


msg_color "COUNTS (Actual/Expected/Result)" $statuscolor ; WebLine05=$msg_return

msg_color "PILLAR\t   WEBDOMAIN " $statuscolor ; WebLine06=$msg_return
msg_color "-------------------------------" $statuscolor ; WebLine07=$msg_return
msg_color "CS: \t   $cswebdomtotal/$cswebdomtarget/$cswebdom " $statuscolor ; WebLine08=$msg_return
msg_color "HC: \t   $hcwebdomtotal/$hcwebdomtarget/$hcwebdom " $statuscolor ; WebLine09=$msg_return
msg_color "FS: \t   $fswebdomtotal/$fswebdomtarget/$fswebdom " $statuscolor ; WebLine10=$msg_return
msg_color "IH: \t   $ihwebdomtotal/$ihwebdomtarget/$ihwebdom " $statuscolor ; WebLine11=$msg_return

}

progressbar ()
{

while true
do
echo -n ".........."
#echo -n "/\\/\\/\\/\\"
sleep 1
done

}

# **************************************
#    E N D    O F    F U N C T I O N S
# **************************************

# **********************
# Main program
# *********************

progressbar &
displpid=$! 

# To suppress 'killed' message, execute disown. 
# The disown will remove the most recently spawned process 
# from the list of watched "jobs" so that no debug message 
# will be generated when it is killed, even with SIGKILL (-9).
disown

# Constants
successcolor=green
alertcolor=red
#infocolor=lpurple
infocolor="white"
statuscolor=""
msg_return=""

# Initialize 

# Host files
APPHOSTS=/tmp/apphosts$$.tmp; rm -f $APPHOSTS
WEBHOSTS=/tmp/webhosts$$.tmp; rm -f $WEBHOSTS

# Log files
APPBOLTLOG=/tmp/stats_${HOSTNAME}.${LOGNAME}.appsrv.$(date '+%Y%m%d_%H%M%S').log; rm -f $APPBOLTLOG
APPSTATSLOG=/tmp/trimmedlog$$.tmp; rm -f $APPSTATSLOG

WEBBOLTLOG=/tmp/stats_${HOSTNAME}.${LOGNAME}.weblogic.$(date '+%Y%m%d_%H%M%S').log; rm -f $WEBBOLTLOG
WEBSTATSLOG=/tmp/webtrimmedlog$$.tmp; rm -f $WEBSTATSLOG

# Output lines
AppLine01=""; AppLine02=""; AppLine03=""; AppLine04=""; AppLine05=""; AppLine06=""; AppLine07=""; AppLine08=""; AppLine09=""; AppLine10=""; AppLine11=""
WebLine01=""; WebLine02=""; WebLine03=""; WebLine04=""; WebLine05=""; WebLine06=""; WebLine07=""; WebLine08=""; WebLine09=""; WebLine10=""; WebLine11=""


prod_app_hosts

app_execute_bolt

app_parse_logs

prod_web_hosts

web_execute_bolt

web_parse_logs

#kill -9 $displpid > /dev/null 2>&1
#echo "PID: $displpid"
#kill -9 -INT $displpid > /dev/null 2>&1
kill -9 $displpid > /dev/null 2>&1

echo " ";echo " "
echo_color "$(date)" lpurple
echo -e "$AppLine02 \t \t $WebLine02"
echo -e "$AppLine03 \t \t \t $WebLine03"
echo -e "$AppLine04 \t \t $WebLine04"
echo -e "$AppLine05 \t \t $WebLine05"
echo -e "$AppLine06 \t \t $WebLine06"
echo -e "$AppLine07 \t \t $WebLine07"
echo -e "$AppLine08 \t \t $WebLine08"
echo -e "$AppLine09 \t \t $WebLine09"
echo -e "$AppLine10 \t \t $WebLine10"
echo -e "$AppLine11 \t \t $WebLine11"

# ######## END ###########
