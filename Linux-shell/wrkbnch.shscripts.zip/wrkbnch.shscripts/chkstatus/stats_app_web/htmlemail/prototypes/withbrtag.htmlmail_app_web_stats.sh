#!/bin/bash
# ####################################################
#   Al Kannayiram October 2023
#     1) To get BBL & PSAPPSRV Service counts by pillar
#        and compare against the expected counts
#     2) To get WebLogic Domain counts by pillar
#        and compare against the expected counts
#     Version 3 December 2023
# ####################################################

# ========================
#    F U N C T I O N S
# ========================
# ******************
#  prod_app_hosts
# ******************
prod_app_hosts () {

# Prod host names rarely change, but for major upgrades.
# Build a temporary file containing prod app hosts on the fly,
# so that the script does not depend on any external files
cat > $APPHOSTS << !EOF
cs92prap101
cs92prap102
cs92prap103
cs92prap104
cs92prap105
cs92prap106
cs92prap107
cs92prap108
cs92prap109
cs92prap110
cs92prap111
cs92prap112
cs92prap113
cs92prap114
cs92prap115
cs92prap116
cs92prap117
cs92prap118
cs92prap119
cs92prap120
cs92prap121
cs92prap122
cs92prap123
cs92prap124
cs92prap125
cs92prap126
cs92prap127
cs92prap128
cs92prap129
cs92prap130
cs92prap131
cs92prap132
cs92prap133
cs92prap134
cs92prap135
cs92prap136
cs92prap137
cs92prap138
cs92prap139
fs92prap101
fs92prap102
fs92prap103
fs92prap104
hc92prap101
hc92prap102
hc92prap103
hc92prap104
hc92prap105
hc92prap106
hc92prap107
fs92prap101
fs92prap102
fs92prap103
fs92prap104
ihprap101
ihprap102
ihprap103
ihprap104
ihprap105
ihprap106
ihprap107
ihprap108
ihprap109
ihprap110
ihprap111
ihprap112
ihprap113
ihprap114
ihprap115
ihprap116
ihprap117
ihprap118
ihprap119
ihprap120
ihprap121
ihprap122
ihprap123
ihprap124
ihprap125
ihprap126
!EOF
}

# ******************
#  prod_web_hosts
# ******************
prod_web_hosts () {

# Prod host names rarely change, but for major upgrades.
# Build a temporary file containing prod web hosts on the fly,
# so that the script does not depend on any external files
cat > $WEBHOSTS << !EOF
cs92prwl101
cs92prwl102
cs92prwl103
cs92prwl104
cs92prwl105
cs92prwl106
cs92prwl107
cs92prwl108
fs92prwl101
fs92prwl102
fs92prwl103
fs92prwl104
fs92prwl105
fs92prwl106
hc92prwl101
hc92prwl102
hc92prwl103
hc92prwl104
hc92prwl105
hc92prwl106
ihprwl101
ihprwl102
ihprwl103
ihprwl104
ihprwl105
ihprwl106
!EOF

}

# ******************
#  app_execute_bolt
# ******************
app_execute_bolt () {

#echo "$(date): Submitting bolt command" $infocolor
# bolt command to collect the counts from prod app hosts at once
bolt command run 'bblcnt=$(ps -aef|grep BBL|grep -v grep|wc -l);appsrvcnt=$(ps -aef|grep PSAPPSRV|grep -v grep|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST :BBL:$bblcnt  :PSAPPSRV:$appsrvcnt' -t "@${APPHOSTS}" --tty --connect-timeout 10 > $APPBOLTLOG 2>&1

# delete the temp hosts file
rm -f $APPHOSTS

}

# ******************
#  web_execute_bolt
# ******************
web_execute_bolt () {

#echo "$(date): Submitting bolt command" $infocolor
# bolt command to collect the counts from prod web hosts at once
bolt command run 'domcnt=$(ps -ef|grep java|grep "^cny"|grep "Dps_home="|grep weblogic.Server|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST:WEBDOM:$domcnt' -t "@${WEBHOSTS}" --tty --connect-timeout 10 > $WEBBOLTLOG 2>&1

# delete the temp hosts file
rm -f $WEBHOSTS

}


# ******************
#  app_parse_logs
# ******************
app_parse_logs () {

#echo "$(date): Parsing log output" $infocolor
# ######################################
# Parse the bolt log output
# The input format is:
#   hostname :BBL:cnt1 :PSAPPSRV:cnt2
# Third and fifth fields have the counts
# ######################################

grep BBL $APPBOLTLOG | sort > $APPSTATSLOG


# ###################################
# Expected Total counts:
# CS:      BBL: 41         PSAPPSRV: 492
# HC:      BBL: 8          PSAPPSRV: 128
# FS:      BBL: 5          PSAPPSRV: 68
# IH:      BBL: 27         PSAPPSRV: 434
# ###################################

# Initliaze target counts
#CS
csbbltarget=41; csappsrvtarget=492
#HC
hcbbltarget=8; hcappsrvtarget=128
#FS
fsbbltarget=5; fsappsrvtarget=68
#IH
ihbbltarget=27; ihappsrvtarget=434


# Initialize counters to zero
#CS
csbbltotal=0; csappsrvtotal=0
#HC
hcbbltotal=0; hcappsrvtotal=0
#FS
fsbbltotal=0; fsappsrvtotal=0
#IH
ihbbltotal=0; ihappsrvtotal=0


while read line
do
  # Strip carriage-return
  editline=$(echo $line|sed 's/\r$//')
  # Strip any leading spaces and then get the first two chars
  pillar=$(echo $editline|sed -e "s/^[ ]*//"|cut -c1,2)
  # BBL count is in third field
  bblcnt=$(echo $editline|awk -F":" '{print $3}')
  # APPSRV count is in fifth field
  appsrvcnt=$(echo $editline|sed 's/\r$//'|awk -F":" '{print $5}')

  # Keep running total of BBL and PSAPPSRV services
  # Once a pillar is found, "continue" skips the remaining commands in the loop
  # (Note: "break" terminates the loop)
  [[ "$pillar" == "cs" ]] && csbbltotal=$(( csbbltotal+bblcnt )) && csappsrvtotal=$(( csappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "hc" ]] && hcbbltotal=$(( hcbbltotal+bblcnt )) && hcappsrvtotal=$(( hcappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "fs" ]] && fsbbltotal=$(( fsbbltotal+bblcnt )) && fsappsrvtotal=$(( fsappsrvtotal+appsrvcnt )) && continue
  [[ "$pillar" == "ih" ]] && ihbbltotal=$(( ihbbltotal+bblcnt )) && ihappsrvtotal=$(( ihappsrvtotal+appsrvcnt )) && continue

  echo "$(date): ERROR! ERROR!! Incorrect host/pillar [$(echo $editline|awk '{print $1}')/${pillar}]"

done < $APPSTATSLOG


# Define constants
ok="OK"
mismatch="MISMATCH"

# Compare agaist the expected total
#CS
[[ "$csbbltotal" == "$csbbltarget" ]] && csbbl=$ok || csbbl=$mismatch
[[ "$csappsrvtotal" == "$csappsrvtarget" ]] && csappsrv=$ok || csappsrv=$mismatch

#HC
[[ "$hcbbltotal" == "$hcbbltarget" ]] && hcbbl=$ok || hcbbl=$mismatch
[[ "$hcappsrvtotal" == "$hcappsrvtarget" ]] && hcappsrv=$ok || hcappsrv=$mismatch

#FS
[[ "$fsbbltotal" == "$fsbbltarget" ]] && fsbbl=$ok || fsbbl=$mismatch
[[ "$fsappsrvtotal" == "$fsappsrvtarget" ]] && fsappsrv=$ok || fsappsrv=$mismatch

#IH
[[ "$ihbbltotal" == "$ihbbltarget" ]] && ihbbl=$ok || ihbbl=$mismatch
[[ "$ihappsrvtotal" == "$ihappsrvtarget" ]] && ihappsrv=$ok || ihappsrv=$mismatch


# Initialize
bblmismatch=N;appsrvmismatch=N

# Check if there are any mismatches
[[ "$csbbl" == "$mismatch" ]] || [[ "$hcbbl" == "$mismatch" ]] || [[ "$fsbbl" == "$mismatch" ]] || [[ "$ihbbl" == "$mismatch" ]] && bblmismatch=Y
[[ "$csappsrv" == "$mismatch" ]] || [[ "$hcappsrv" == "$mismatch" ]] || [[ "$fsappsrv" == "$mismatch" ]] || [[ "$ihappsrv" == "$mismatch" ]] && appsrvmismatch=Y


if [[ "$bblmismatch" == "Y" ]] || [[ "$appsrvmismatch" == "Y" ]] ; then
   #
   # Please review the logs. 
   # Log files are not deleted, when there is a mismatch.
   #
   echo " ";echo " ";date;echo "**************************************"
   #echo "PRODUCTION"
   echo "APP SERVICES: ERROR! ERROR!! Actual counts did not match the expected counts. Please check"
   echo "**************************************" 
   echo "  1) Trimmed log:  $APPSTATSLOG" 
   echo "  2) Full log:     $APPBOLTLOG" 
   echo "**************************************" 
   appstatuscolor=$alerthtmlcolor
   appdomstatus="F A I L E D  "
else
   appstatuscolor=$successhtmlcolor
   appdomstatus="S U C C E S S"
   # Clean up log, temp files
   rm -f $APPBOLTLOG $APPSTATSLOG
fi


#AppLine05="COUNTS (Actual/Expected/Result)"

#AppLine06="PILLAR   BBL            PSAPPSRV"
cspillar="CS";  #   $csbbltotal/$csbbltarget/$csbbl  $csappsrvtotal/$csappsrvtarget/$csappsrv"
hcpillar="HC";  #   $hcbbltotal/$hcbbltarget/$hcbbl  $hcappsrvtotal/$hcappsrvtarget/$hcappsrv"
fspillar="FS";  #   $fsbbltotal/$fsbbltarget/$fsbbl  $fsappsrvtotal/$fsappsrvtarget/$fsappsrv"
ihpillar="IH";  #   $ihbbltotal/$ihbbltarget/$ihbbl  $ihappsrvtotal/$ihappsrvtarget/$ihappsrv"

}


# ******************
#  web_parse_logs
# ******************
web_parse_logs () {

#echo "$(date): Parsing log output" $infocolor
# ######################################
# Parse the bolt log output
# The input format is:
#   hostname:WEBDOM:count
# Third field has the counts
# ######################################

grep WEBDOM $WEBBOLTLOG | sort > $WEBSTATSLOG


# ###################################
# Expected Total WebLogic Domain counts:
# CS:      WEBDOM: 22
# HC:      WEBDOM: 10
# FS:      WEBDOM: 8
# IH:      WEBDOM: 18
# ###################################

# Initliaze target counts
#CS #HC #FS #IH
cswebdomtarget=22; hcwebdomtarget=10; fswebdomtarget=8; ihwebdomtarget=18


# Initialize counters to zero
#CS #HC #FS #IH
cswebdomtotal=0; hcwebdomtotal=0; fswebdomtotal=0; ihwebdomtotal=0


while read line
do
  # Strip carriage-return
  editline=$(echo $line|sed 's/\r$//')
  # Strip any leading spaces and then get the first two chars
  pillar=$(echo $editline|sed -e "s/^[ ]*//"|cut -c1,2)
  # WEBDOM count is in third field
  webdomcnt=$(echo $editline|awk -F":" '{print $3}')

  # Keep running total of WEBDOM services
  # Once a pillar is found, "continue" skips the remaining commands in the loop
  # (Note: "break" terminates the loop)
  [[ "$pillar" == "cs" ]] && cswebdomtotal=$(( cswebdomtotal+webdomcnt )) && continue
  [[ "$pillar" == "hc" ]] && hcwebdomtotal=$(( hcwebdomtotal+webdomcnt )) && continue
  [[ "$pillar" == "fs" ]] && fswebdomtotal=$(( fswebdomtotal+webdomcnt )) && continue
  [[ "$pillar" == "ih" ]] && ihwebdomtotal=$(( ihwebdomtotal+webdomcnt )) && continue

  echo "$(date): ERROR! ERROR!! Incorrect host/pillar [$(echo $editline|awk '{print $1}')/${pillar}]"

done < $WEBSTATSLOG


# Define constants
ok="OK"
mismatch="MISMATCH"

# Compare agaist the expected total
#CS
[[ "$cswebdomtotal" == "$cswebdomtarget" ]] && cswebdom=$ok || cswebdom=$mismatch

#HC
[[ "$hcwebdomtotal" == "$hcwebdomtarget" ]] && hcwebdom=$ok || hcwebdom=$mismatch

#FS
[[ "$fswebdomtotal" == "$fswebdomtarget" ]] && fswebdom=$ok || fswebdom=$mismatch

#IH
[[ "$ihwebdomtotal" == "$ihwebdomtarget" ]] && ihwebdom=$ok || ihwebdom=$mismatch


# Initialize
webdommismatch=N

# Check if there are any mismatches
[[ "$cswebdom" == "$mismatch" ]] || [[ "$hcwebdom" == "$mismatch" ]] || [[ "$fswebdom" == "$mismatch" ]] || [[ "$ihwebdom" == "$mismatch" ]] && webdommismatch=Y


if [[ "$webdommismatch" == "Y" ]] ; then
   #
   # Please review the logs. 
   # Log files are not deleted, when there is a mismatch.
   #
   #echo " ";echo " ";date;echo "**************************************" $alerthtmlcolor
   #echo " "
   echo " ";date;
   echo "**************************************" 
   #echo "PRODUCTION"
   #echo "ERROR! Actual counts did not match the expected counts. Please check"
   echo "WEB SERVICES: ERROR! ERROR!! Actual counts did not match the expected counts. Please check"
   echo "**************************************"  >> $EMAILBODY
   #echo "  1) Trimmed log: \t $WEBSTATSLOG" $alerthtmlcolor
   #echo "  2) Full log: \t $WEBBOLTLOG" $alerthtmlcolor
   #echo "**************************************" $alerthtmlcolor
   webstatuscolor=$alerthtmlcolor
   webdomstatus="F A I L E D  "
else
   webstatuscolor=$successhtmlcolor
   webdomstatus="S U C C E S S"
   # Clean up log, temp files
   rm -f $WEBBOLTLOG $WEBSTATSLOG
fi

#WebLine05="COUNTS (Actual/Expected/Result)"

#WebLine06="PILLAR   WEBDOMAIN "
cspillar="CS" ; #   $cswebdomtotal/$cswebdomtarget/$cswebdom "
hcpillar="HC" ; #   $hcwebdomtotal/$hcwebdomtarget/$hcwebdom "
fspillar="FS" ; #   $fswebdomtotal/$fswebdomtarget/$fswebdom "
ihpillar="IH" ; #   $ihwebdomtotal/$ihwebdomtarget/$ihwebdom "

}


# Build the email functions


buildemailbody ()
{

cat > $EMAILTMPFILE <<!EOF
<html> <head> <meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title></title> </head> <body> <h4>PSA - App and Web Services Status</h4>
$(date)
<table width="50%" cellspacing="2" cellpadding="4" border="1"> <tbody> <tr> <td valign="top">App Service Status</td>
<!-- RED: bgcolor="#cc0000"   GREEN: bgcolor="#009900" -->

<td valign="top" bgcolor="$appstatuscolor"><font color="#ffffff"><b>$appdomstatus</b></font></td>

</tr></tbody></table>
<table width="100%" cellspacing="2" cellpadding="4" border="1">
<tbody><tr align="center"><td rowspan="1" colspan="3" valign="top">COUNTS 
(<font size="+1">&nbsp; Actual&nbsp; / Expected&nbsp; / Result </font>)<br>
</td></tr><tr><td width="25%" valign="top"><b>PILLAR</b><br></td><td width="35%" valign="top"><b>BBL</b><br>
</td><td width="45%" valign="top"><b>PSAPPSRV</b><br></td></tr><tr><td width="25%" valign="top">

CS <br></td><td width="35%" valign="top"> $csbbltotal / $csbbltarget / $csbbl <br></td><td valign="top"> $csappsrvtotal / $csappsrvtarget / $csappsrv <br></td></tr><tr><td width="25%" valign="top">
HC <br></td><td width="35%" valign="top"> $hcbbltotal / $hcbbltarget / $hcbbl </td><td valign="top"> $hcappsrvtotal / $hcappsrvtarget / $hcappsrv </td></tr><tr><td width="25%" valign="top">
FS <br></td><td width="35%" valign="top"> $fsbbltotal / $fsbbltarget / $fsbbl </td><td valign="top"> $fsappsrvtotal / $fsappsrvtarget / $fsappsrv </td></tr><tr><td width="25%" valign="top">
IH <br></td><td width="35%" valign="top"> $ihbbltotal / $ihbbltarget / $ihbbl </td><td valign="top"> $ihappsrvtotal / $ihappsrvtarget / $ihappsrv </td></tr></tbody></table><br><br>

$(date)
<table width="50%" cellspacing="2" cellpadding="4" border="1"><tbody><tr> <td valign="top">Web Service Status</td>
<!-- RED: bgcolor="#cc0000"   GREEN: bgcolor="#009900" -->

<td valign="top" bgcolor="$webstatuscolor"><font color="#ffffff"><b>$appdomstatus</b></font></td>

</tr></tbody></table>
<table width="70%" cellspacing="2" cellpadding="4" border="1">
<tbody><tr align="center"><td rowspan="1" colspan="2" valign="top">COUNTS 
(<font size="+1">&nbsp; Actual&nbsp; / Expected&nbsp; / Result </font>)<br>
</td></tr><tr><td width="40%" valign="top"><b>PILLAR</b><br></td><td width="60%" valign="top"><b>BBL</b><br>
</td></tr><tr><td width="25%" valign="top">

CS <br></td><td width="35%" valign="top"> $cswebdomtotal / $cswebdomtarget / $cswebdom <br></td></tr><tr><td width="25%" valign="top"> 
HC <br></td><td width="35%" valign="top"> $hcwebdomtotal / $hcwebdomtarget / $hcwebdom </td></tr><tr><td width="25%" valign="top"> 
FS <br></td><td width="35%" valign="top"> $fswebdomtotal / $fswebdomtarget / $fswebdom </td></tr><tr><td width="25%" valign="top">
IH <br></td><td width="35%" valign="top"> $ihwebdomtotal / $ihwebdomtarget / $ihwebdom </td></tr></tbody></table><br></body></html>
!EOF

# From app services with height parameter
# <table width="100%" cellspacing="2" cellpadding="6" border="1" height="178">

# From web services with height parameter
# <table width="70%" cellspacing="2" cellpadding="6" border="1" height="178">

}


sendstatusmail ()
{

(
#echo "From: akannayiram@workbench.cf.cuny.edu"
#echo "To: al.kannayiram@sierra-cedar.com"
echo "From: $FROMEMAIL"
echo "To: $TOEMAIL"
echo "MIME-Version: 1.0"
echo "Content-Type: multipart/alternative; " 
echo ' boundary="chkstatus.notification/workbench.cf.cuny.edu"'
echo "Subject: Test HTML e-mail." 
echo "" 
echo "This is a MIME-encapsulated message" 
echo "" 
echo "--chkstatus.notification/workbench.cf.cuny.edu"
echo "Content-Type: text/html" 
echo "" 
#cat $TMPFILE
cat $EMAILTMPFILE
#echo "------chkstatus.notification/workbench.cf.cuny.edu--"
) | sendmail -t

}


# **************************************
#    E N D    O F    F U N C T I O N S
# **************************************

# **********************
# Main program
# *********************

# Constants
#<!-- RED: bgcolor="#cc0000"   GREEN: bgcolor="#009900" -->
successhtmlcolor="#009900"
alerthtmlcolor="#cc0000"
appstatuscolor=""; webstatuscolor=""


FROMEMAIL="akannayiram@workbench.cf.cuny.edu"
TOEMAIL="al.kannayiram@sierra-cedar.com, al.kannayiram@sierra-cedar.com"

# Initialize 

# Host files
APPHOSTS=/tmp/apphosts$$.tmp; rm -f $APPHOSTS
WEBHOSTS=/tmp/webhosts$$.tmp; rm -f $WEBHOSTS

# Log files
APPBOLTLOG=/tmp/stats_${HOSTNAME}.${LOGNAME}.appsrv.$(date '+%Y%m%d_%H%M%S').log; rm -f $APPBOLTLOG
APPSTATSLOG=/tmp/trimmedlog$$.tmp; rm -f $APPSTATSLOG

WEBBOLTLOG=/tmp/stats_${HOSTNAME}.${LOGNAME}.weblogic.$(date '+%Y%m%d_%H%M%S').log; rm -f $WEBBOLTLOG
WEBSTATSLOG=/tmp/webtrimmedlog$$.tmp; rm -f $WEBSTATSLOG

# Email tmp file
EMAILTMPFILE=/tmp/statusemail_${HOSTNAME}.${LOGNAME}.html.$(date '+%Y%m%d_%H%M%S').html; rm -f $EMAILTMPFILE

# Output lines
AppLine01=""; AppLine02=""; AppLine03=""; AppLine04=""; AppLine05=""; AppLine06=""; AppLine07=""; AppLine08=""; AppLine09=""; AppLine10=""; AppLine11=""
WebLine01=""; WebLine02=""; WebLine03=""; WebLine04=""; WebLine05=""; WebLine06=""; WebLine07=""; WebLine08=""; WebLine09=""; WebLine10=""; WebLine11=""


prod_app_hosts

app_execute_bolt

app_parse_logs

prod_web_hosts

web_execute_bolt

web_parse_logs

buildemailbody 

sendstatusmail

#mail -s "PSA App and Web Services Status" $TOEMAIL < $EMAILBODY
echo "Email sent"

# ######## END ###########

