#!/bin/bash

buildemailbody ()
{

ALKTMP=alk.email.tmp
rm -f $ALKTMP
cat > $ALKTMP <<!EOF
<html> <head> <meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title></title> </head> <body> <h4>PSA - App and Web Services Status</h4>
$(date)
<table width="50%" cellspacing="2" cellpadding="6" border="1"> <tbody> <tr> <td valign="top">App Service Status</td>
<!-- RED: bgcolor="#cc0000"   GREEN: bgcolor="#009900" -->

<td valign="top" bgcolor="#009900"><font color="$alerthtmlcolor"><b>$appstatus</b></font></td>

</tr></tbody></table>
<table width="100%" cellspacing="2" cellpadding="6" border="1" height="178">
<tbody><tr align="center"><td rowspan="1" colspan="3" valign="top">COUNTS 
(<font size="+1">&nbsp; Actual&nbsp; / Expected&nbsp; / Result </font>)<br>
</td></tr><tr><td width="25%" valign="top">PILLAR<br></td><td width="35%" valign="top">BBL<br>
</td><td width="45%" valign="top">PSAPPSRV<br></td></tr><tr><td width="25%" valign="top">


CS <br></td><td width="35%" valign="top"> 41 / 41 / OK <br></td><td valign="top"> 492 /492 / MISMATCH <br></td></tr><tr><td width="25%" valign="top">
HC <br></td><td width="35%" valign="top"> 8 / 8 / OK </td><td valign="top"> 128 / 128 / OK </td></tr><tr><td width="25%" valign="top">
FS <br></td><td width="35%" valign="top"> 5 / 5 / OK </td><td valign="top"> 68 / 68 / OK </td></tr><tr><td width="25%" valign="top">
IH <br></td><td width="35%" valign="top"> 27 / 27 / OK </td><td valign="top"> 434 / 434 / OK </td></tr></tbody></table><br><br>



Date




<table width="50%" cellspacing="2" cellpadding="6" border="1"><tbody><tr>
<td valign="top">Web Service Status</td>
<!-- RED: bgcolor="#cc0000"   GREEN: bgcolor="#009900" -->



<td valign="top" bgcolor="#009900"><font color="#ffffff"><b>S U C C E S S</b></font></td>


</tr></tbody></table><table width="70%" cellspacing="2" cellpadding="6" border="1" height="178">
<tbody><tr align="center"><td rowspan="1" colspan="2" valign="top">COUNTS 
(<font size="+1">&nbsp; Actual&nbsp; / Expected&nbsp; / Result </font>)<br>
</td></tr><tr><td width="40%" valign="top">PILLAR<br></td><td width="60%" valign="top">BBL<br>
</td></tr><tr><td width="25%" valign="top">



CS <br></td><td width="35%" valign="top"> 41 /41 /OK <br></td></tr><tr><td width="25%" valign="top"> 
HC <br></td><td width="35%" valign="top"> 10 / 10 / OK</td></tr><tr><td width="25%" valign="top"> 
FS <br></td><td width="35%" valign="top"> 8 / 8 / MISMATCH </td></tr><tr><td width="25%" valign="top">
IH <br></td><td width="35%" valign="top"> 18 / 18 / OK </td></tr></tbody></table><br></body></html>





}



FRM="akannayiram@workbench.cf.cuny.edu"
#FRM="al.kannayiram@sierra-cedar.com"
TOLIST="al.kannayiram@sierra-cedar.com"
TMPFILE=alk.body.tmp
rm -f $TMPFILE
cat > $TMPFILE <<!EOF
<html> 
<head>
<title>HTML E-mail</title>
</head>
<body>
<b>Al K Test 12/5/2023 using test file</b><br/>
<a href='http://www.google.com'>Click Here</a>
</body>
</html>
!EOF

TESTEMAILFILE=/home/akannayiram/chkstatus/stats_app_web/htmlemail/emailbody.txt
(
#echo "From: akannayiram@workbench.cf.cuny.edu"
#echo "To: al.kannayiram@sierra-cedar.com"
echo "From: $FRM"
echo "To: $TOLIST"
echo "MIME-Version: 1.0"
echo "Content-Type: multipart/alternative; " 
echo ' boundary="chkstatus.notification/workbench.cf.cuny.edu"'
echo "Subject: Test HTML e-mail." 
echo "" 
echo "This is a MIME-encapsulated message" 
echo "" 
echo "--chkstatus.notification/workbench.cf.cuny.edu"
echo "Content-Type: text/html" 
echo "" 
#cat $TMPFILE
cat $TESTEMAILFILE
#echo "------chkstatus.notification/workbench.cf.cuny.edu--"
) | sendmail -t






