#!/bin/bash

# to test weblogic domain counts
# bolt command run 'domcnt=$(ps -ef|grep java|grep "^cny"|grep "Dps_home="|grep weblogic.Server|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST:$domcnt' -t "ih92npwl051" --tty --connect-timeout 10


# to test user/login names from /etc/hosts
# fist test the command using ssh
# 
ssh ih92npwl052 'HST=$(echo $HOSTNAME|cut -d"." -f1);for usr in $(grep -v "^[ ]*#" /etc/hosts|grep cny|cut -f2); do echo "$HST:WEBDOM:$usr";done; '

# Now use bolt commnd to get users from /etc/hosts
bolt command run 'HST=$(echo $HOSTNAME|cut -d"." -f1);for usr in $(grep -v "^[ ]*#" /etc/hosts|grep cny|cut -f2); do echo "$HST:WEBDOM:$usr";done; ' -t "ih92npwl052" --tty --connect-timeout 10
