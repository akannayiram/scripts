#!/bin/bash
#bolt command run 'domcnt=$(ps -ef|grep java|grep "^cny"|grep "Dps_home="|grep weblogic.Server|wc -l);HST=$(echo $HOSTNAME|cut -d"." -f1);echo $HST:$domcnt' -t "ih92npwl051" --tty --connect-timeout 10


webhosts=/home/akannayiram/chkstatus/prod_web_servers.txt

logfile=webdom_get_etc_hosts_users.${HOSTNAME}.${LOGNAME}.$(date '+%Y%m%d_%H%MS').log.txt

# Now use bolt commnd to get users from /etc/hosts
bolt command run 'HST=$(echo $HOSTNAME|cut -d"." -f1);for usr in $(grep -v "^[ ]*#" /etc/hosts|grep cny|sed -e "s/\r$//"|awk '\''{print $2}'\''); do echo "$HST:WEBDOM:$usr";done; ' -t "@${webhosts}" --tty --connect-timeout 10 > $logfile 2>&1

webdomfile=webdomfile$$.txt
grep WEBDOM $logfile > $webdomfile
