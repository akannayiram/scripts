#bolt command run 'echo [$HOSTNAME] [$(date '+%Y%m%d_%H%M%S')];cnt=$(ps -aef|grep BBL|grep -v grep|wc -l);echo [$HOSTNAME] [$cnt] [$(date '+%Y%m%d_%H%M%S')]' -t '@prod_app_servers.txt' --tty
bolt command run 'cnt=$(ps -aef|grep BBL|grep -v grep|wc -l);echo [$HOSTNAME] [$cnt] [$(date '+%Y%m%d_%H%M%S')]' -t '@prod_app_servers.txt' --tty

