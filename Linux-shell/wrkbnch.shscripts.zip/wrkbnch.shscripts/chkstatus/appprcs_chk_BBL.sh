#!/bin/bash
inp=$1
#inp="./prf_app_prcs.202304.txt"
#bolt command run 'echo [$HOSTNAME] [$(date '+%Y%m%d_%H%M%S')];cnt=$(ps -aef|grep BBL|grep -v grep|wc -l);echo [$HOSTNAME] [$cnt] [$(date '+%Y%m%d_%H%M%S')]' -t '@prod_app_servers.txt' --tty
#bolt command run 'cnt=$(ps -aef|grep BBL|grep -v grep|wc -l);echo [$HOSTNAME] [$cnt] [$(date '+%Y%m%d_%H%M%S')]' -t '@prod_app_servers.txt' --tty
bolt command run 'echo BEGIN: [$HOSTNAME] [$(date '+%Y%m%d_%H%M%S')];cnt=$(ps -aef|grep BBL|grep -v grep|wc -l);echo END: [$HOSTNAME] [$cnt] [$(date '+%Y%m%d_%H%M%S')]' -t "@${inp}" --tty --no-host-key-check

