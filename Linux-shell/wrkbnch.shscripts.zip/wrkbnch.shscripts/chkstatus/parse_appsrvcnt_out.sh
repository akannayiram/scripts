#!/bin/bash
# #####################
#  Al Kannayiram 10/24/2023 
#    Get an grant total count by pillar
# ####################
#set -x
# The input file format is:
#   hostname :BBL:cnt1 :PSAPPSRV:cnt2
# Third and fifth fields have the counts

# Input is the log from bolt execution. 
# The script is:
# (/home/akannayiram/chkstatus/app_appserv_bbl_cnts.sh)

TMPFILE=/tmp/appsrvtotalcnt$$.tmp
rm -f $TMPFILE
grep BBL $1 | sort > $TMPFILE


# ###################################
# Expected Total counts:
# CS:      BBL: 41         PSAPPSRV: 492
# HC:      BBL: 8          PSAPPSRV: 128
# FS:      BBL: 5          PSAPPSRV: 68
# IH:      BBL: 27         PSAPPSRV: 434
# ###################################

# Initliaze target counts
#CS
csbbltarget=41; csappsrvtarget=492
#HC
hcbbltarget=8; hcappsrvtarget=128
#FS
fsbbltarget=5; fsappsrvtarget=68
#IH
ihbbltarget=27; ihappsrvtarget=434


# Initialize counters to zero
#CS
csbbltotal=0; csappsrvtotal=0
#HC
hcbbltotal=0; hcappsrvtotal=0
#FS
fsbbltotal=0; fsappsrvtotal=0
#IH
ihbbltotal=0; ihappsrvtotal=0


while read line
do
#  echo "Line: $line"
  # Strip carriage-return
  editline=$(echo $line|sed 's/\r$//')
  pillar=$(echo $editline|sed -e "s/^[ ]*//"|cut -c1,2)
  bblcnt=$(echo $editline|awk -F":" '{print $3}')
  appsrvcnt=$(echo $editline|sed 's/\r$//'|awk -F":" '{print $5}')

  # Count BBL and PSAPPSRV services
  [[ "$pillar" == "cs" ]] && csbbltotal=$(( csbbltotal+bblcnt )) && csappsrvtotal=$(( csappsrvtotal+appsrvcnt ))
  [[ "$pillar" == "hc" ]] && hcbbltotal=$(( hcbbltotal+bblcnt )) && hcappsrvtotal=$(( hcappsrvtotal+appsrvcnt ))
  [[ "$pillar" == "fs" ]] && fsbbltotal=$(( fsbbltotal+bblcnt )) && fsappsrvtotal=$(( fsappsrvtotal+appsrvcnt ))
  [[ "$pillar" == "ih" ]] && ihbbltotal=$(( ihbbltotal+bblcnt )) && ihappsrvtotal=$(( ihappsrvtotal+appsrvcnt ))

done < $TMPFILE


# Compare agaist the expected total
#CS
[[ "$csbbltotal" == "$csbbltarget" ]] && csbbl=OK || csbbl=MISMATCH
[[ "$csappsrvtotal" == "$csappsrvtarget" ]] && csappsrv=OK || csappsrv=MISMATCH

#HC
[[ "$hcbbltotal" == "$hcbbltarget" ]] && hcbbl=OK || hcbbl=MISMATCH
[[ "$hcappsrvtotal" == "$hcappsrvtarget" ]] && hcappsrv=OK || hcappsrv=MISMATCH

#FS
[[ "$fsbbltotal" == "$fsbbltarget" ]] && fsbbl=OK || fsbbl=MISMATCH
[[ "$fsappsrvtotal" == "$fsappsrvtarget" ]] && fsappsrv=OK || fsappsrv=MISMATCH

#IH
[[ "$ihbbltotal" == "$ihbbltarget" ]] && ihbbl=OK || ihbbl=MISMATCH
[[ "$ihappsrvtotal" == "$ihappsrvtarget" ]] && ihappsrv=OK || ihappsrv=MISMATCH


ok="OK"
mismatch="MISMATCH"
bblmismatch=N;appsrvmismatch=N


# Check if there are any mismatches
[[ "$csbbl" == "$mismatch" ]] || [[ "$hcbbl" == "$mismatch" ]] || [[ "$fsbbl" == "$mismatch" ]] || [[ "$ihbbl" == "$mismatch" ]] && bblmismatch=Y
[[ "$csappsrv" == "$mismatch" ]] || [[ "$hcappsrv" == "$mismatch" ]] || [[ "$fsappsrv" == "$mismatch" ]] || [[ "$ihappsrv" == "$mismatch" ]] && appsrvmismatch=Y


if [[ "$bblmismatch" == "Y" ]] || [[ "$appsrvmismatch" == "Y" ]] ; then
   echo " ";echo " ";echo "**********************************"
   #echo "PRODUCTION"
   #echo "ERROR! Total counts did not match the expected counts. Please check"
   echo "PRODUCTION: ERROR! ERROR!! Total counts did not match the expected counts. Please check"
   echo "**********************************"
else
   echo " ";echo " ";echo "**********************************"
   #echo "PRODUCTION"
   #echo "No Issues. BBL and PSAPPSRV counts matched"
   echo "S U C C E S S    S U C C E S S"
   echo "PRODUCTION: BBL and PSAPPSRV counts matched"
   echo "**********************************"
fi


echo "BBL AND PSAPPSRV COUNTS (Total/Expected/Result)"

echo -e "PILLAR \t BBL \t\t PSAPPSRV"
echo "--------------------------------------"
echo -e "CS: \t $csbbltotal/$csbbltarget/$csbbl \t $csappsrvtotal/$csappsrvtarget/$csappsrv"
echo -e "HC: \t $hcbbltotal/$hcbbltarget/$hcbbl \t $hcappsrvtotal/$hcappsrvtarget/$hcappsrv"
echo -e "FS: \t $fsbbltotal/$fsbbltarget/$fsbbl \t $fsappsrvtotal/$fsappsrvtarget/$fsappsrv"
echo -e "IH: \t $ihbbltotal/$ihbbltarget/$ihbbl \t $ihappsrvtotal/$ihappsrvtarget/$ihappsrv"


