inp=$1
#bolt command run 'ps -eo user:16,pid,rss,cmd|grep java|grep PIA|grep -v grep' -t '@prod_web_servers.txt' --tty
#bolt command run 'echo [$HOSTNAME] [$(date '+%Y%m%d_%H%M%S')];ps -eo user:16,pid,rss,cmd|grep java|grep PIA|grep -v grep;echo [$HOSTNAME] [$(date '+%Y%m%d_%H%M%S')]' -t "@${inp}" --tty
bolt command run 'cnt=$(ps -eo user:16,pid,rss,cmd|grep java|grep PIA|grep -v grep|wc -l);echo [$HOSTNAME] [$cnt] [$(date '+%Y%m%d_%H%M%S')]' -t "@${inp}" --tty
