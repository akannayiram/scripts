#bolt command run 'ps -aef|grep BBL|grep -v grep' -t '@prod_psunx_servers.txt' --tty
#bolt command run 'echo [$HOSTNAME] [$(date '+%Y%m%d_%H%M%S')];ps -aef|grep BBL|grep -v grep;echo [$HOSTNAME] [$(date '+%Y%m%d_%H%M%S')]' -t '@prod_prcs_servers.txt' --tty
bolt command run 'cnt=$(ps -aef|grep BBL|grep -v grep|wc -l);echo [$HOSTNAME] [$cnt] [$(date '+%Y%m%d_%H%M%S')]' -t '@prod_prcs_servers.txt' --tty

