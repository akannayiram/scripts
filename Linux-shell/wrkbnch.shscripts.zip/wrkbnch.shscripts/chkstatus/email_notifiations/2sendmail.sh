#!/bin/bash

# (
# echo "From: me@xyz.com "
# echo "To: them@xyz.com "
# echo "MIME-Version: 1.0"
# echo "Content-Type: multipart/alternative; " 
# echo ' boundary="some.unique.value.ABC123/server.xyz.com"' 
# echo "Subject: Test HTML e-mail." 
# echo "" 
# echo "This is a MIME-encapsulated message" 
# echo "" 
# echo "--some.unique.value.ABC123/server.xyz.com" 
# echo "Content-Type: text/html" 
# echo "" 
# echo "<html> 
# <head>
# <title>HTML E-mail</title>
# </head>
# <body>
# <a href='http://www.google.com'>Click Here</a>
# </body>
# </html>"
# echo "------some.unique.value.ABC123/server.xyz.com--"
# ) | sendmail -t








(
echo "From: akannayiram@workbench.cf.cuny.edu"
echo "To: al.kannayiram@sierra-cedar.com"
echo "MIME-Version: 1.0"
echo "Content-Type: multipart/alternative; " 
echo ' boundary="chkstatus.notification/workbench.cf.cuny.edu"'
echo "Subject: Test HTML e-mail." 
echo "" 
echo "This is a MIME-encapsulated message" 
echo "" 
echo "--chkstatus.notification/workbench.cf.cuny.edu"
echo "Content-Type: text/html" 
echo "" 
echo "<html> 
<head>
<title>HTML E-mail</title>
</head>
<body>
<b>Al K Test 12/5/2023</b>
<a href='http://www.google.com'>Click Here</a>
</body>
</html>"
#echo "------chkstatus.notification/workbench.cf.cuny.edu--"
) | sendmail -t
