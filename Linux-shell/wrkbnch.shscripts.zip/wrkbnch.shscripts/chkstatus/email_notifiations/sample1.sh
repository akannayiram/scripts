#!/bin/bash

# body = '...'
# 
# echo $body | mail \
# -a "From: me@example.com" \
# -a "MIME-Version: 1.0" \
# -a "Content-Type: text/html" \
# -s "This is the subject" \
# you@example.com




body = 'Al K Test'

echo $body | mail \
-a "From: akannayiram@workbench.cf.cuny.edu" \
-a "MIME-Version: 1.0" \
-a "Content-Type: text/html" \
-s "Al K Test-12/5/2023" \
al.kannayiram@sierra-cedar.com
