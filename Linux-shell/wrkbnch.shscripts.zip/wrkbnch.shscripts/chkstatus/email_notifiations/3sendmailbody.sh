#!/bin/bash

TMPFILE=alk.body.tmp
rm -f $TMPFILE
cat > $TMPFILE <<!EOF
<html> 
<head>
<title>HTML E-mail</title>
</head>
<body>
<b>Al K Test 12/5/2023 using test file</b><br/>
<a href='http://www.google.com'>Click Here</a>
</body>
</html>
!EOF
(
echo "From: akannayiram@workbench.cf.cuny.edu"
echo "To: al.kannayiram@sierra-cedar.com"
echo "MIME-Version: 1.0"
echo "Content-Type: multipart/alternative; " 
echo ' boundary="chkstatus.notification/workbench.cf.cuny.edu"'
echo "Subject: Test HTML e-mail." 
echo "" 
echo "This is a MIME-encapsulated message" 
echo "" 
echo "--chkstatus.notification/workbench.cf.cuny.edu"
echo "Content-Type: text/html" 
echo "" 
cat $TMPFILE
#echo "------chkstatus.notification/workbench.cf.cuny.edu--"
) | sendmail -t






