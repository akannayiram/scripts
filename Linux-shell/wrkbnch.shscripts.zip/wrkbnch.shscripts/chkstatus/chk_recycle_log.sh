#bolt command run 'echo [$HOSTNAME] [$(date '+%Y%m%d_%H%M%S')];cnt=$(ps -aef|grep BBL|grep -v grep|wc -l);echo [$HOSTNAME] [$cnt] [$(date '+%Y%m%d_%H%M%S')]' -t '@prod_app_servers.txt' --tty

# get only CS servers 101 to 132 only
tmpfile=/tmp/alk.cs92$$.txt
grep cs92prap1 prod_app_servers.txt > $tmpfile 
#bolt command run 'cnt=$(ls -l /tmp/$HOSTNAME.*recycle*log|wc -l);echo [$HOSTNAME] [$cnt] [$(date '+%Y%m%d_%H%M%S')]' -t '@prod_app_servers.txt' --tty
bolt command run 'fname=$(ls -l /tmp/$HOSTNAME.*recycle*log);echo [$HOSTNAME] [$fname] [$(date '+%Y%m%d_%H%M%S')]' -t "@$tmpfile" --tty

