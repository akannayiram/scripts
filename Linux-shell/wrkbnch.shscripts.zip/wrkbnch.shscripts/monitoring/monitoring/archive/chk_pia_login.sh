#!/bin/bash
# ======================================================
# Check PIA Online Login Status
#  Usage:
#    ./chk_pia_login.sh <Environment>
#  Returns exit status of 0 (Success) or 1 (Failure)
# History:  
# Who                When      Why and What
# -----------------  --------- ------------------------
# Al Kannayiram      6/11/2021 Initial creation
#
# ======================================================

#
SCRIPTLOC=/psft/amsscripts/monitoring
CONFIGFILE=$SCRIPTLOC/chk_pia_login.conf
CURLSCRIPT=$SCRIPTLOC/call_curl.sh
#
# Return Code for non-login related errors. e.g. missing config file

#MISCERR=5
MISCERR=1

# functions
myecho()
{
 dttm=`date '+%Y-%m-%d %H:%M:%S'`
 echo "[$dttm]:: $1"
}

# Check if Environment parameter is passed or not
if [[ $# -eq 0 ]] ; then
    myecho 'ERROR!! PIA Environment argument is required! Aborting...'
    exit $MISCERR
fi
PIAENV=$1

# Check if second parameter debug is passed
if [[ ! -z $2 ]] ; then
   UPPER2=`echo $2|tr [a-z] [A-Z]`
   if [[ $UPPER2 = "DEBUG" || $UPPER2 = "VERBOSE" ]] ; then
      VERBOSE=Y
   fi
fi

# check if chk_pia_login.conf file exists 
if [[ ! -f $CONFIGFILE ]] ; then
   myecho "ERROR! PIA Environment config file missing [$CONFIGFILE]"
   exit $MISCERR
fi
if [[ ! -r $CONFIGFILE ]] ; then
   myecho "ERROR! PIA Environment config file not readable [$CONFIGFILE]"
   exit $MISCERR
fi

# Check the config if the PIA URL is defined for the input param
# Grep "-m1": stop after first match (-m num matches) 
CFG_ENTRY=`grep -v "#" $CONFIGFILE|grep -i -m1 "^${PIAENV};"`
CNT=`echo $CFG_ENTRY|wc -l`
# if URL entry is not found, exit 
if [[ $CNT -eq 0 ]] ; then
    myecho "ERROR!! URL entry not found for environment [$PIAENV]! Aborting..."
    exit $MISCERR
fi

PIAURL=`echo $CFG_ENTRY|cut -d ";" -f 2`
if [[ $VERBOSE = "Y" ]] ; then
   myecho "Found PIA URL: $PIAURL"
fi

# check if call_curl.sh script exists
if [[ ! -f $CURLSCRIPT ]] ; then
   myecho "ERROR! Curl call script missing [$CURLSCRIPT]"
   exit $MISCERR
fi
if [[ ! -x $CURLSCRIPT ]] ; then
   myecho "ERROR! Curl call script not set as executable [$CURLSCRIPT]"
   exit $MISCERR
fi
# define constants
PIAUSR=OEMUSER
PIAPW=oemT15#R
CURLOUTPUT=/tmp/curloutput$$
COOKIEFILE=/tmp/cookiefile$$
TIMEOUT=60
KILLTIME=5

# Curl
timeout -k $KILLTIME $TIMEOUT $CURLSCRIPT $PIAURL $PIAUSR $PIAPW $CURLOUTPUT $COOKIEFILE
RET=$?

if [[ $VERBOSE = "Y" ]] ; then
   myecho "Retun code from Curl call $RET"
fi

rm -f $COOKIEFILE
if [[ $RET -eq 124 || $RET -eq 137 ]] ; then
   myecho "ERROR! PIA is unresponsive ($PIAURL)"
   exit 1
fi

mainfound=`cat $CURLOUTPUT|grep ">Worklist<"|wc -l`
if [[ $mainfound -eq 0 ]] ; then
    myecho "ERROR!! Could not log into $PIAURL"
    rm -f $CURLOUTPUT
    exit 1
else
    myecho "Logged successfully into $PIAURL"
    rm -f $CURLOUTPUT
    exit 0
fi

