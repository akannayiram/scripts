#!/bin/bash 
# ######################################################
# test_sftp_put_get.sh
#    - To validate sftp connectivity, access permissions
# Usage:
#   test_sftp_put_get.sh
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 6/21/2021  Al Kannayiram    Initial develoment
#
# ######################################################

# functions
myecho()
{
 dttm=`date '+%Y-%m-%d %H:%M:%S'`
 echo "[$dttm]:: $1"
}

#
# Set constants
#
SFTPSERVER=cnysftpxdev.cunyfirst.cuny.edu
SFTPUSR=cnynonprdintsftp
SFTPPW=Cuny2020
# ------------PUT A TEST FILE-------------
FILENAME=oemsftptest$$.`date '+%Y-%m-%d_%H-%M-%S'`
TESTDIR=/tmp/OEMTEST$$
mkdir -p $TESTDIR
TESTFILE=/tmp/${FILENAME}
date > $TESTFILE
lftp sftp://${SFTPUSR}:${SFTPPW}@${SFTPSERVER} <<!EOF
cd OEMSFTPTEST
ls
put ${TESTFILE} 
ls
lcd $TESTDIR
get ${FILENAME}
rm -f ${FILENAME}
ls
bye
!EOF
LFTPRET=$?
myecho "lftp return code: $LFTPRET"
if [[ $LFTPRET -eq 0 ]] ; then
   myecho "SFTP ($SFTPSERVER) test file put successful"
   rm -f $TESTFILE
   rm -rf $TESTDIR
   exit 0
else
   myecho "ERROR! SFTP ($SFTPSERVER) test file put failed"
   rm -f $TESTFILE
   rm -rf $TESTDIR
   exit 1
fi
