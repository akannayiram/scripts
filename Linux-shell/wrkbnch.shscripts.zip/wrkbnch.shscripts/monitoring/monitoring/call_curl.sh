#!/bin/bash
# ======================================================
# Call curl to check PIA Online Login Status
# Call this script with 5 parameters
#  Usage:
#    ./call_curl.sh <PIAURL> <PIAUSR> <PIAPW> <CURLOUTPUT> <COOKIEFILE>
# History:  
# Who                When       Why and What
# -----------------  ---------- ------------------------
# Al Kannayiram      06/11/2021 Initial creation
# Al Kannayiram      07/02/2021 Added logout logic
#
# ======================================================

# Check if URL parameter is passed or not
if [[ $# -eq 0 ]] ; then
    echo 'ERROR!! PIA URL argument is required! Aborting...'
    exit 1
fi
PIAURL=$1
PIAUSR=$2
PIAPW=$3
CURLOUTPUT=$4
COOKIEFILE=$5
INOUT=$6
PIAURL=${PIAURL}${INOUT}

if [[ $INOUT = "login" ]] ; then
   # Curl
   curl -u ${PIAUSR}:${PIAPW} -iL --cookie-jar ${COOKIEFILE} "$PIAURL" >> ${CURLOUTPUT} 2>&1
elif [[ $INOUT = "logout" ]] ; then
     # Curl
     curl -u ${PIAUSR}:${PIAPW} -iL -b ${COOKIEFILE} "$PIAURL" >> ${CURLOUTPUT} 2>&1
else
   exit 1
fi

