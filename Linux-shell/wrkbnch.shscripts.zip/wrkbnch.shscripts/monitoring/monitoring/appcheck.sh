#!/bin/ksh

USER1=$1
DOMAIN=$2
USER=`echo $USER1 | tr '[:upper:]' '[:lower:]'`
USER_HOME=`cat /etc/passwd | grep -w $USER |awk -F: '{print $6}'`

CHECK_BBL=`ps -ef|grep -i ${USER:?"Please enter a valid username."}|grep BBL| \
           grep -v grep|grep ${DOMAIN:?"Please enter a valid APP Server DOMAIN."}`


CHECK_WSL=`ps -ef|grep -i ${USER:?"Please enter a valid username."}|grep WSL| \
           grep -v grep|grep ${DOMAIN:?"Please enter a valid APP Server DOMAIN."}`
NOBBL="NOBBL"
NOWSL="NOWSL"

CHECK_BBL=${CHECK_BBL:=NOBBL}
CHECK_WSL=${CHECK_WSL:=NOWSL}

if [ "$CHECK_BBL" = "$NOBBL" ];then
        echo "BBL in ${DOMAIN} - error!"
        exit 1
fi

#if [ "$CHECK_WSL" = "$NOWSL" ];then
#        print "WSL in ${DOMAIN} - error!"
#        exit 1
#fi

CHECK_JSL=`ps -ef|grep -i ${USER:?"Please enter a valid username."}|grep JSL| \
           grep -v grep|grep ${DOMAIN:?"Please enter a valid APP Server DOMAIN."}`

CHECK_PSAPPSRV=`ps -ef|grep -i ${USER:?"Please enter a valid username."}|grep PSAPPSRV| \
                grep -v grep|grep ${DOMAIN:?"Please enter a valid APP Server DOMAIN."}` 

CHECK_PSQRYSRV=`ps -ef|grep -i ${USER:?"Please enter a valid username."}|grep PSQRYSRV| \
                grep -v grep|grep ${DOMAIN:?"Please enter a valid APP Server DOMAIN."}`

NOJSL="NOJSL"
NOPSAPPSRV="NOPSAPPSRV"
NOPSQRYSRV="NOPSQRYSRV"

CHECK_JSL=${CHECK_JSL:=NOJSL}
CHECK_APPSRV=${CHECK_APPSRV:=NOPSAPPSRV}
CHECK_PSQRYSRV=${CHECK_PSQRYSRV:=NOPSQRYSRV}


if [ "$CHECK_JSL" = "$NOJSL" ];then
        print "JSL in ${DOMAIN} - error!"
        exit 1
fi


PSAPPSRV_CONFIG_FILE_MIN=`awk '/Settings for PSAPPSRV/{x=NR+10}(NR<=x){print}' $USER_HOME/appserv/${DOMAIN:?"Please enter a valid APP Server DOMAIN."}/psappsrv.cfg | grep 'Min Instances' | cut -c15-17`

PSAPPSRV_MIN=`expr $PSAPPSRV_CONFIG_FILE_MIN - 1`

PSAPPSRV_RUNNING=`ps -ef|grep -i ${USER:?"Please enter a valid username."}|grep PSAPPSRV| \grep -v grep|grep ${DOMAIN:?"Please enter a valid APP Server DOMAIN."} | wc -l`

if [ "$PSAPPSRV_RUNNING" -lt  "$PSAPPSRV_MIN" ];then
       print "MIN_PSAPPSRV_NOT_RUNNING in ${DOMAIN} - error!"
       exit 1
fi


if [ -f ${USER_HOME}/${DOMAIN}_DEAD_PSAPPSRV.LOG ];then
         DEAD_PSAPPSRV=`cat ${USER_HOME}/${DOMAIN}_DEAD_PSAPPSRV.LOG`
     else
         print "Check_${USER}_crontab_${DOMAIN}_DEAD_PSAPPSRV_LOG_File_Not_Found in ${DOMAIN} - error!"
         exit 1
     fi

     if [ "$DEAD_PSAPPSRV" != 0 ];then
         print "DEAD_PSAPPSRV in ${DOMAIN} - error!"
         exit 1
     fi


if [ "$CHECK_PSAPPSRV" = "$NOPSAPPSRV" ];then
        print "PSAPPSRV in ${DOMAIN} - error!"
        exit 1
else
        print "ALLAPPSUP in ${DOMAIN} - success!"
        exit 0;
fi
