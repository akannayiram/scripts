#!/bin/bash
# #######################################################
# oem_db_alert_teams.sh 
#     To send an alert to Teams Channel
# Usage:
#   oem_db_alert_teams.sh <oem_message>
#
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 6/22/2021  Al Kannayiram    Initial develoment
#
# ######################################################
#

# Constants
# Teams Channel Webhook URL
NPDB_TEAMURL="https://sierracedarinc.webhook.office.com/webhookb2/160f06c8-5b3d-4a48-8a72-d22971af897c@0f1fa860-6a95-4198-b969-fe5e480b6a85/IncomingWebhook/69cd868cfd6245198c41f3fcf7214561/82833435-a7fa-4aac-aabd-450dead019bf"

# functions
myecho()
{
 dttm=`date '+%Y-%m-%d %H:%M:%S'`
 echo "[$dttm]:: $1"
}

send_alert ()
{

  echo "curl -X POST -H 'Content-type: application/json' --data '{\"text\":\"$BODY\"}'" $TEAMURL > sendalert.sh
 sh sendalert.sh
 rm sendalert.sh
}

# Main
# Input message
MSGIN=$MESSAGE
STATUS="UNVAILABLE"
if [[ $MSGIN =~ UNKNOWN ]] ; then
      STATUS="DOWN"
elif [[ $MSGIN =~ OPEN ]] ; then
     STATUS="AVAILABLE"
fi
#DB_ALERT="$TARGET_NAME is ${STATUS}!!. PLEASE CHECK [$MESSAGE]"
DB_ALERT="$TARGET_NAME Database is ${STATUS}!!. PLEASE CHECK."

TEAMURL=$NPDB_TEAMURL
BODY=$DB_ALERT

send_alert
if [[ $? -eq 0 ]] ; then
      exit 0
else
      myecho "ERROR!! Problem sending alert to Teams"
      exit 1
fi

