#!/bin/bash
# #######################################################
# oem_hosts_alert_teams.sh 
#     To send an alert to Teams Channel
# Usage:
#   oem_hosts_alert_teams.sh <oem_message>
#
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 6/22/2021  Al Kannayiram    Initial develoment
#
# ######################################################
#

# Constants
# Teams Channel Webhook URL
NPHOSTS_TEAMURL="https://sierracedarinc.webhook.office.com/webhookb2/160f06c8-5b3d-4a48-8a72-d22971af897c@0f1fa860-6a95-4198-b969-fe5e480b6a85/IncomingWebhook/ce7344da822e4556992d3f2e039a8ceb/82833435-a7fa-4aac-aabd-450dead019bf"


# functions
myecho()
{
 dttm=`date '+%Y-%m-%d %H:%M:%S'`
 echo "[$dttm]:: $1"
}

send_alert ()
{

  echo "curl -X POST -H 'Content-type: application/json' --data '{\"text\":\"$BODY\"}'" $TEAMURL > sendalert.sh
 sh sendalert.sh
 rm sendalert.sh
}


# Input message
#MSGIN=$MESSAGE
#MSGIN2=`echo $MSGIN | awk -F: '{print $2}'`
#CRITICAL_ALERT="$MSGIN2 is in CRITICAL STATUS!!. PLEASE CHECK"
#DOWN_ALERT="$MSGIN2 is DOWN!!. PLEASE CHECK"
#CRITICAL_ALERT="$MSGIN2 is in CRITICAL STATUS!!. PLEASE CHECK [$MESSAGE]"
#DOWN_ALERT="$MSGIN2 is DOWN!!. PLEASE CHECK [$MESSAGE]"

# Intialize variable
FOUND=N
TEAMURL=""

      TEAMURL=$NPHOSTS_TEAMURL
      BODY=$TARGET_NAME" : "$MESSAGE

   send_alert
   if [[ $? -eq 0 ]] ; then
      exit 0
   else
      myecho "ERROR!! Problem sending alert to Teams"
      exit 1
   fi

