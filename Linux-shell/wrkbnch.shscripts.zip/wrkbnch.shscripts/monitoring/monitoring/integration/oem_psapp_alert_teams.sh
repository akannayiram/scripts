#!/bin/ksh
# #######################################################
# oem_psapp_alert_teams.sh 
#     To send an alert to Teams Channel
# Usage:
#   oem_psapp_alert_teams.sh <oem_message>
#
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 6/22/2021  Al Kannayiram    Initial develoment
#
# ######################################################
#

# Constants
# Teams Channel Webhook URL
NPAPPMSG_TEAMURL="https://sierracedarinc.webhook.office.com/webhookb2/160f06c8-5b3d-4a48-8a72-d22971af897c@0f1fa860-6a95-4198-b969-fe5e480b6a85/IncomingWebhook/8486b899de424fb7b837db93837efbc7/82833435-a7fa-4aac-aabd-450dead019bf"

NPAPPSRV_TEAMURL="https://sierracedarinc.webhook.office.com/webhookb2/160f06c8-5b3d-4a48-8a72-d22971af897c@0f1fa860-6a95-4198-b969-fe5e480b6a85/IncomingWebhook/f93915b7e03447c2b64f19757a673a32/82833435-a7fa-4aac-aabd-450dead019bf"

NPPRCS_TEAMURL="https://sierracedarinc.webhook.office.com/webhookb2/160f06c8-5b3d-4a48-8a72-d22971af897c@0f1fa860-6a95-4198-b969-fe5e480b6a85/IncomingWebhook/da554c21285b43ae94a9203ab02408d8/82833435-a7fa-4aac-aabd-450dead019bf"

NPWEB_TEAMURL="https://sierracedarinc.webhook.office.com/webhookb2/160f06c8-5b3d-4a48-8a72-d22971af897c@0f1fa860-6a95-4198-b969-fe5e480b6a85/IncomingWebhook/12da09555d364068b9b5c253d62d59d6/82833435-a7fa-4aac-aabd-450dead019bf"

NPSFTP_TEAMURL="https://sierracedarinc.webhook.office.com/webhookb2/160f06c8-5b3d-4a48-8a72-d22971af897c@0f1fa860-6a95-4198-b969-fe5e480b6a85/IncomingWebhook/46d4618f345b4b698f6e80c10515162e/82833435-a7fa-4aac-aabd-450dead019bf"

NPOHS_TEAMURL="https://sierracedarinc.webhook.office.com/webhookb2/160f06c8-5b3d-4a48-8a72-d22971af897c@0f1fa860-6a95-4198-b969-fe5e480b6a85/IncomingWebhook/d17653057d394ce9bd1c9207b087a7d9/82833435-a7fa-4aac-aabd-450dead019bf"

# Search Strings
APPMSG_SRCH_STR="APP MESSAGE CHECK"
APPSRV_SRCH_STR="Application Server"
PSUNXSRV_SRCH_STR="Process Scheduler Server PSUNX"
PSNTSRV_SRCH_STR="Process Scheduler Server PSNT"
LOGFAIL_SRCH_STR="Login"
WEBSRV_SRCH_STR="webserver|GATEWAY URL|REPORT URL"
SFTP_SRCH_STR="SFTP"
OHS_SRCH_STR="OHS"


# functions
myecho()
{
 dttm=`date '+%Y-%m-%d %H:%M:%S'`
 echo "[$dttm]:: $1"
}

send_alert ()
{

  echo "curl -X POST -H 'Content-type: application/json' --data '{\"text\":\"$BODY\"}'" $TEAMURL > sendalert.sh
 sh sendalert.sh
 rm sendalert.sh
}

checkstr()
{
  srch_str=$1
  CNT=`echo $MSGIN|grep -i "$srch_str"|wc -l`
  if [[ $CNT > 0 ]] ; then
      FOUND=Y
   fi

}

# Main

# Input message
MSGIN=$MESSAGE
MSGIN2=`echo $MSGIN | awk -F: '{print $2}'`
CRITICAL_ALERT="$MSGIN2 is in CRITICAL STATUS!!. PLEASE CHECK"
DOWN_ALERT="$MSGIN2 is DOWN!!. PLEASE CHECK"

# Intialize variable
FOUND=N
TEAMURL=""

# APPMSG
if [[ $FOUND = "N" ]] ; then
   CNT=`echo $MSGIN|grep -i "$APPMSG_SRCH_STR"|wc -l`
   if [[ $CNT > 0 ]] ; then
      FOUND=Y
      TEAMURL=$NPAPPMSG_TEAMURL
      BODY=$CRITICAL_ALERT
   fi
fi


# APPSRV
if [[ $FOUND = "N" ]] ; then
   CNT=`echo $MSGIN|grep -i "$APPSRV_SRCH_STR"|wc -l`
   if [[ $CNT > 0 ]] ; then
      FOUND=Y
      TEAMURL=$NPAPPSRV_TEAMURL
      BODY=$DOWN_ALERT
   fi
fi

# PSUNXSRV
if [[ $FOUND = "N" ]] ; then
   CNT=`echo $MSGIN|grep -i "$PSUNXSRV_SRCH_STR"|wc -l`
   if [[ $CNT > 0 ]] ; then
      FOUND=Y
      TEAMURL=$NPPRCS_TEAMURL
      BODY=$DOWN_ALERT
   fi
fi

# PSNTSRV
if [[ $FOUND = "N" ]] ; then
   CNT=`echo $MSGIN|grep -i "$PSNTSRV_SRCH_STR"|wc -l`
   if [[ $CNT > 0 ]] ; then
      FOUND=Y
      TEAMURL=$NPPRCS_TEAMURL
      BODY=$DOWN_ALERT
   fi
fi

# LOGFAIL
if [[ $FOUND = "N" ]] ; then
   CNT=`echo $MSGIN|grep -i "$LOGFAIL_SRCH_STR"|wc -l`
   if [[ $CNT > 0 ]] ; then
      FOUND=Y
      TEAMURL=$NPAPPMSG_TEAMURL
      BODY=$CRITICAL_ALERT
   fi
fi

# WEBSRV_SRCH_STR
if [[ $FOUND = "N" ]] ; then
   CNT=`echo $MSGIN|egrep "$WEBSRV_SRCH_STR"|wc -l`
   if [[ $CNT > 0 ]] ; then
      FOUND=Y
      TEAMURL=$NPWEB_TEAMURL
      BODY=$DOWN_ALERT
   fi
fi

# OHS_SRCH_STR
if [[ $FOUND = "N" ]] ; then
   CNT=`echo $MSGIN|grep "$OHS_SRCH_STR"|wc -l`
   if [[ $CNT > 0 ]] ; then
      FOUND=Y
      TEAMURL=$NPOHS_TEAMURL
      BODY=$DOWN_ALERT
   fi
fi

# SFTP_SRCH_STR
if [[ $FOUND = "N" ]] ; then
   CNT=`echo $MSGIN|grep "$SFTP_SRCH_STR"|wc -l`
   if [[ $CNT > 0 ]] ; then
      FOUND=Y
      TEAMURL=$NPSFTP_TEAMURL
      BODY=$CRITICAL_ALERT
   fi
fi

myecho "FOUND: $FOUND"
if [[ $FOUND = "Y" ]] ; then
   send_alert
   if [[ $? -eq 0 ]] ; then
      exit 0
   else
      myecho "ERROR!! Problem sending alert to Teams"
      exit 1
   fi
else
   myecho "ERROR!! Input message couldn't be handled"
   exit 1
fi

