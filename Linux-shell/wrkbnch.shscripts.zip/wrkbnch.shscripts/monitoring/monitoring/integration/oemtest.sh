teamurl="https://sierracedarinc.webhook.office.com/webhookb2/160f06c8-5b3d-4a48-8a72-d22971af897c@0f1fa860-6a95-4198-b969-fe5e480b6a85/IncomingWebhook/3e3c86ef02434f63bbc625dcdb994124/77dfdfc6-4df4-404f-bd13-739db9d440ae"

body=`echo $MESSAGE | awk -F: '{print $2 " is in CRITICAL STATUS!!. PLEASE CHECK"}'`

echo "curl -X POST -H 'Content-type: application/json' --data '{\"text\":\"$body\"}'" $teamurl > sendmsg.sh
sh sendmsg.sh
rm sendmsg.sh
