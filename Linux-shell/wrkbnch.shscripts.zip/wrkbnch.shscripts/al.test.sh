#!/bin/bash

#dttm=$(date '+%Y%m%d_%H%M%S')
#PROD:
echo "==================="
echo "PROD"
echo "Begin: $(date)"
bolt command run 'echo [$HOSTNAME] [$(date)];top -b -n 1 |head -5|tail -3;echo [$HOSTNAME] [$(date)]' -t '@/home/gjarvis/servers/all_prd_all' | grep -n Failed |grep -v target | tee /dev/tty | echo "Failure count: $(wc -l)"

echo "End:   $(date)"
echo "==================="

echo "==================="
echo "RPT - PROD"
echo "Begin: $(date)"
bolt command run 'echo [$HOSTNAME] [$(date)];top -b -n 1 |head -5|tail -3;echo [$HOSTNAME] [$(date)]' -t '@/home/gjarvis/servers/all_rpt_all' | grep -n Failed |grep -v target | tee /dev/tty | echo "Failure count: $(wc -l)"

echo "End:   $(date)"
echo "==================="


#PERF:
echo "==================="
echo "PERF"
echo "Begin: $(date)"
bolt command run 'echo [$HOSTNAME] [$(date)];top -b -n 1 |head -5|tail -3;echo [$HOSTNAME] [$(date)]' -t '@/home/gjarvis/servers/all_prf_all' | grep -n Failed |grep -v target | tee /dev/tty | echo "Failure count: $(wc -l)"

echo "End:   $(date)"
echo "==================="

#NP:
echo "==================="
echo "NP - DEV92"
echo "Begin: $(date)"
bolt command run 'echo [$HOSTNAME] [$(date)];top -b -n 1 |head -5|tail -3;echo [$HOSTNAME] [$(date)]' -t '@/home/gjarvis/servers/all_dev92_all' | grep -n Failed |grep -v target | tee /dev/tty | echo "Failure count: $(wc -l)"

echo "End:   $(date)"
echo "==================="

#DR:
echo "==================="
echo "DR"
echo "Begin: $(date)"
bolt command run 'echo [$HOSTNAME] [$(date)];top -b -n 1 |head -5|tail -3;echo [$HOSTNAME] [$(date)]' -t '@/home/gjarvis/servers/all_dr_all' | grep -n Failed |grep -v target | tee /dev/tty | echo "Failure count: $(wc -l)"

echo "End:   $(date)"
echo "==================="

