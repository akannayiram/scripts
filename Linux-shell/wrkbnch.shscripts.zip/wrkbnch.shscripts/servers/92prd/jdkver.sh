#!/bin/bash
ver=$(/appl/psft/pt86007/pt/jdk/bin/java -version|head -1)
echo "$HOSTNAME Java:[$ver]"
