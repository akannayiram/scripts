#!/bin/bash
inp=prdrpt_all_app_prcs_servers.txt
inp=prdrpt_all_web_servers.txt
bolt command run "ver=\$(/appl/psft/pt86007/pt/jdk/bin/java -version 2>&1|head -1);echo \$HOSTNAME Java:[\$ver]" -t @"$inp" --tty --no-host-key-check

#scr=./jdkver.sh
#bolt script run $scr -t @"$inp" --tty --no-host-key-check
