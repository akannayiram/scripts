# -L option in 'ls -L' dererences links and does not print "-> actual_file_or_dir"
# Note that 'ls -L' option selects all files and is not just limited to links
# Only the condition "[[ -L $line ]]" checks if it is a link
ls -L *txt|sort|while read -r line
do
if [[ -L $line ]] ; then
   echo "[$line] is a link"
   # '-e' condition checks if it exists regardless of type (file, directory, socket etc) 
   if [[ -e $line ]] ; then
      echo "[$line] points to a valid file"
   else
      echo "ERROR. [$line] points to a non-existent file"
   fi
else
  echo "ERROR. [$line] is not a link"
fi
done
