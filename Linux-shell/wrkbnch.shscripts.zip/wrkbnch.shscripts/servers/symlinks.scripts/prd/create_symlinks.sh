# App servers
ln -s /home/akannayiram/servers/9prd/by_pillar/prd_app_crm_servers.txt        prd_app_crm_servers.txt 
ln -s /home/akannayiram/servers/9prd/by_pillar/prd_app_css_servers.txt        prd_app_css_servers.txt 
ln -s /home/akannayiram/servers/92prd/prd_app_fs92_servers.txt                prd_app_fs_servers.txt  
ln -s /home/akannayiram/servers/92prd/prd_app_hc92_servers.txt                prd_app_hc_servers.txt  
ln -s /home/akannayiram/servers/9prd/by_pillar/prd_app_prt_servers.txt        prd_app_prt_servers.txt 
# Psunx servers
ln -s /home/akannayiram/servers/9prd/by_pillar/prd_prcs_crm_servers.txt      prd_prcs_crm_servers.txt
ln -s /home/akannayiram/servers/9prd/by_pillar/prd_prcs_css_servers.txt      prd_prcs_css_servers.txt
ln -s /home/akannayiram/servers/9prd/by_pillar/prd_prcs_prt_servers.txt      prd_prcs_prt_servers.txt
ln -s /home/akannayiram/servers/92prd/prd_prcs_fs92_servers.txt              prd_prcs_fs_servers.txt
ln -s /home/akannayiram/servers/92prd/prd_prcs_hc92_servers.txt              prd_prcs_hc_servers.txt
# Web servers
ln -s /home/akannayiram/servers/9prd/by_pillar/prd_web_crm_servers.txt        prd_web_crm_servers.txt
ln -s /home/akannayiram/servers/9prd/by_pillar/prd_web_css_servers.txt        prd_web_css_servers.txt
ln -s /home/akannayiram/servers/9prd/by_pillar/prd_web_prt_servers.txt        prd_web_prt_servers.txt
ln -s /home/akannayiram/servers/92prd/prd_web_fs92_servers.txt                prd_web_fs_servers.txt  
ln -s /home/akannayiram/servers/92prd/prd_web_hc92_servers.txt                prd_web_hc_servers.txt 
