# App servers
ln -s /home/akannayiram/servers/9prf/by_pillar/prf_app_crm_servers.txt        prf_app_crm_servers.txt 
ln -s /home/akannayiram/servers/9prf/by_pillar/prf_app_css_servers.txt        prf_app_css_servers.txt 
ln -s /home/akannayiram/servers/92prf/prf_app_fs92_servers.txt                prf_app_fs_servers.txt  
ln -s /home/akannayiram/servers/92prf/prf_app_hc92_servers.txt                prf_app_hc_servers.txt  
ln -s /home/akannayiram/servers/9prf/by_pillar/prf_app_prt_servers.txt        prf_app_prt_servers.txt 
# Psunx servers
ln -s /home/akannayiram/servers/9prf/by_pillar/prf_prcs_crm_servers.txt      prf_prcs_crm_servers.txt
ln -s /home/akannayiram/servers/9prf/by_pillar/prf_prcs_css_servers.txt      prf_prcs_css_servers.txt
ln -s /home/akannayiram/servers/9prf/by_pillar/prf_prcs_prt_servers.txt      prf_prcs_prt_servers.txt
ln -s /home/akannayiram/servers/92prf/prf_prcs_fs92_servers.txt              prf_prcs_fs_servers.txt
ln -s /home/akannayiram/servers/92prf/prf_prcs_hc92_servers.txt              prf_prcs_hc_servers.txt
# Web servers
ln -s /home/akannayiram/servers/9prf/by_pillar/prf_web_crm_servers.txt        prf_web_crm_servers.txt
ln -s /home/akannayiram/servers/9prf/by_pillar/prf_web_css_servers.txt        prf_web_css_servers.txt
ln -s /home/akannayiram/servers/9prf/by_pillar/prf_web_prt_servers.txt        prf_web_prt_servers.txt
ln -s /home/akannayiram/servers/92prf/prf_web_fs92_servers.txt                prf_web_fs_servers.txt  
ln -s /home/akannayiram/servers/92prf/prf_web_hc92_servers.txt                prf_web_hc_servers.txt 
