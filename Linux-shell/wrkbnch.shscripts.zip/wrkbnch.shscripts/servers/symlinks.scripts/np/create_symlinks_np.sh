# App servers
ln -s /home/akannayiram/servers/9np/by_pillar/np_app_crm_servers.txt        np_app_crm_servers.txt 
ln -s /home/akannayiram/servers/9np/by_pillar/np_app_css_servers.txt        np_app_css_servers.txt 
ln -s /home/akannayiram/servers/92np/by_pillar/np_app_fs92_servers.txt                np_app_fs_servers.txt  
ln -s /home/akannayiram/servers/92np/by_pillar/np_app_hc92_servers.txt                np_app_hc_servers.txt  
ln -s /home/akannayiram/servers/9np/by_pillar/np_app_prt_servers.txt        np_app_prt_servers.txt 
# Psunx servers
ln -s /home/akannayiram/servers/9np/by_pillar/np_prcs_crm_servers.txt      np_prcs_crm_servers.txt
ln -s /home/akannayiram/servers/9np/by_pillar/np_prcs_css_servers.txt      np_prcs_css_servers.txt
ln -s /home/akannayiram/servers/9np/by_pillar/np_prcs_prt_servers.txt      np_prcs_prt_servers.txt
ln -s /home/akannayiram/servers/92np/by_pillar/np_prcs_fs92_servers.txt              np_prcs_fs_servers.txt
ln -s /home/akannayiram/servers/92np/by_pillar/np_prcs_hc92_servers.txt              np_prcs_hc_servers.txt
# Web servers
ln -s /home/akannayiram/servers/9np/by_pillar/np_web_crm_servers.txt        np_web_crm_servers.txt
ln -s /home/akannayiram/servers/9np/by_pillar/np_web_css_servers.txt        np_web_css_servers.txt
ln -s /home/akannayiram/servers/9np/by_pillar/np_web_prt_servers.txt        np_web_prt_servers.txt
ln -s /home/akannayiram/servers/92np/by_pillar/np_web_fs92_servers.txt                np_web_fs_servers.txt  
ln -s /home/akannayiram/servers/92np/by_pillar/np_web_hc92_servers.txt                np_web_hc_servers.txt 
