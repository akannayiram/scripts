#!/bin/bash

#ps -aef|grep BBL|grep -v grep 
BBLLIST=$(ps -aef|grep BBL|grep -v grep|awk '{print $18 }'|awk  -F"/"  '{print $7 " " $8}'|sed -e "s/ LOGS//"|sed -e "s/prcs //"|sort )
SWMNT=$(df -h /software|tail -1)
#echo "Host:[$HOSTNAME]  BBL:[$BBLLIST]"
echo "Host:[$HOSTNAME]  BBL:[$BBLLIST]  Software:[$SWMNT]"
