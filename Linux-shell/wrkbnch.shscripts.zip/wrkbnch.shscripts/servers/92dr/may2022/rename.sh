#!/bin/bash
for i in `ls *.txt`
do
 new2=$(echo $i|tr '.' '_'|sed -e "s/_txt/.txt/")
 echo "mv $i dr_$new2"

done
