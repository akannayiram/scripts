#!/bin/bash

#
fromdir=/home/akannayiram/servers/92prd
tmpfile=/tmp/alk$$.tmp.txt
#find $fromdir -name "*[fh][sc]92*.txt" -type f -exec basename {} \; > $tmpfile
#cat $tmpfile

#while read line
#do
#  newln=`echo $line|sed -e "s/^prd/dr/"`
#  echo $newln
#  
#done < $tmpfile

#find $fromdir -name "*[fh][sc]92*.txt" -type f -exec basename {} \; | while read line
find $fromdir -name "*[fh][sc]92*.txt" -type f -print | while read line
do
  prdfile=$(basename $line)
  newfile=`echo $prdfile|sed -e "s/^prd/dr/"`
  echo "prdfile: $prdfile  newfile: $newfile" 
  cat $line|while read inp
  do
    newinp1=`echo $inp|sed -e "s/pr/dr/"|sed -e "s/101/201/"|sed -e "s/102/202/"|sed -e "s/103/203/"`
    newinp2=`echo $newinp1|sed -e "s/104/204/"|sed -e "s/105/205/"|sed -e "s/106/206/"|sed -e "s/107/207/"`
    newinp3=`echo $newinp2|sed -e "s/108/208/"|sed -e "s/109/209/"|sed -e "s/110/210/"|sed -e "s/111/211/"`
    echo $newinp3 >> $newfile

  done



done



