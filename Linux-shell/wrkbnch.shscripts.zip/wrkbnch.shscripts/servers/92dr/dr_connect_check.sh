#!/bin/bash

inp=/home/akannayiram/servers/92dr/dr_appprcs_servers.txt
scr=./bbl.sh

#bolt command run "echo Host: [\$HOSTNAME]" -t @"$inp" --tty
bolt script run $scr -t @"$inp" --tty
