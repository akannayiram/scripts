#!/bin/bash
#set -x
inp=$1
cat $inp|while read -r line
do
  ssh -n $line 'echo $HOSTNAME'
done | tee -a $inp.val.out.txt
