# ##########################################
#  Executing bolt command against the hosts 
#  to build host_vars files
#
#  Actual script that build the host_vars is 
#    /software/akannayiram/ansible/build_psdom_yaml/psdomyaml.sh
#
#  In this shell script, I'm setting hosts file and 
#  executing the bolt command.
#     - Al Kannayiram 3/8/2024
#
# ##########################################
#

# NP
#hosts=/home/akannayiram/servers/92np/np_all_app_prcs_servers.txt

# PRF
hosts=/home/akannayiram/servers/92prf/prf_all_app_prcs_servers.txt

# PRD
#hosts=/home/akannayiram/servers/92prd/prd_all_app_prcs_servers.txt

shscript=/software/akannayiram/ansible/build_psdom_yaml/psdomyaml.sh
bolt command run "$shscript" -t "@$hosts" --tty
