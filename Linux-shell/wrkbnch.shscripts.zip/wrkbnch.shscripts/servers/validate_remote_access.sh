#!/bin/bash
set -x
[[ ! -f $1 ]] && { echo "ERROR! No input file"; exit ; }
while read line 
do 
  bolt command run "echo $line; hostname; date; " -t $line --tty
done < $1
