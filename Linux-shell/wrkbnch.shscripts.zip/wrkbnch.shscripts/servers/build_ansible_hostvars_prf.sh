#
#
#bolt command run /software/akannayiram/ansible/build_psdom_yaml/psdomyaml_prf.sh -t "@prf_all_app_prcs_servers.txt" --tty
hosts=/home/akannayiram/servers/92prf/prf_all_app_prcs_servers.txt
#shscript=/software/akannayiram/ansible/build_psdom_yaml/psdomyaml_prf.sh
shscript=/software/akannayiram/ansible/build_psdom_yaml/psdomyaml.sh
bolt command run "$shscript" -t "@$hosts" --tty
