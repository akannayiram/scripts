#
#
hosts=/home/akannayiram/servers/92np/np_all_app_prcs_servers.txt
#shscript=/software/akannayiram/ansible/build_psdom_yaml/psdomyaml_np.sh
shscript=/software/akannayiram/ansible/build_psdom_yaml/psdomyaml.sh
bolt command run "$shscript" -t "@$hosts" --tty
