#
#
hosts=/home/akannayiram/servers/92prd/prd_all_app_prcs_servers.txt
#shscript=/software/akannayiram/ansible/build_psdom_yaml/psdomyaml_prd.sh
shscript=/software/akannayiram/ansible/build_psdom_yaml/psdomyaml.sh
bolt command run "$shscript" -t "@$hosts" --tty
