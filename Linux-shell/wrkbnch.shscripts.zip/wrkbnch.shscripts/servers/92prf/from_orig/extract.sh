# all app prcs
egrep "pfap|pfux" prf.app.prcs.val.out.txt|sort|awk -F"." '{print $1}' > ../prf_all_app_prcs_servers.txt
egrep "pfwl" prf.app.prcs.val.out.txt|sort|awk -F"." '{print $1}' > ../prf_all_web_servers.txt

