date
/appl/oracle/software_DPK_media/PT86007_LNX/setup/psft-dpk-setup.sh --silent --response_file=/appl/oracle/dummy_psft_dpk/response_file.txt
date

