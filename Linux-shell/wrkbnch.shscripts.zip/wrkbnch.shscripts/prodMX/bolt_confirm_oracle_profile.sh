#!/bin/bash
# #############################
# Al Kannayiram
# 9/20/2024
#   INFRA-DPK:
#      For successful INFRA-DPK deployment,
#      'oracle' user should not any PS env variables
#
# how_to_confirm_oracle_user_bash_profile.txt
#
# #############################

# I'm going to use a bolt command to 'cat' the contents 
# of both .bash_profile and .bashrc
# Both should not have any user env settings

appprcs=/home/akannayiram/servers/92prd/prdrpt_all_app_prcs_servers.txt
web=/home/akannayiram/servers/92prd/prdrpt_all_web_servers.txt
TMP=/tmp/alk.tmp.$$;rm -f $TMP
cat $appprcs $web > $TMP
#echo "ih92npap052" > $TMP
bolt command run "sudo su - oracle -c 'echo Host: \$HOSTNAME Login: \$LOGNAME;cat ~/.bash_profile;date;cat ~/.bashrc'" -t @"$TMP" --tty --no-host-key-check 2>&1 |tee -a how_to_confirm_oracle_user_bash_profile.$HOSTNAME.$LOGNAME.$(date '+%Y%m%d_%H%M%S').log

rm -f $TMP
