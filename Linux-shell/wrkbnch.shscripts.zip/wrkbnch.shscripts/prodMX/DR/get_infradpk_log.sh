#!/bin/bash
# #############################
# Al Kannayiram
# 9/20/2024
#   INFRA-DPK:
#      For successful INFRA-DPK deployment,
#      'oracle' user should not any PS env variables
#
# get_infradpk_log.sh
#
# #############################

TGTDIR=/tmp/alk.tmp.logs
#inp=/home/akannayiram/servers/92dr/dr_all_prcs_servers.txt
#inp=/home/akannayiram/servers/92dr/dr_all_app_servers.txt
inp=/home/akannayiram/servers/92dr/dr_all_web_servers.txt
while read -r line
do
 scp $line:/tmp/*infradpk*.log $TGTDIR
done < $inp

