#!/bin/bash
# #############################
# Al Kannayiram
# 9/20/2024
#   INFRA-DPK:
#      For successful INFRA-DPK deployment,
#      'oracle' user should not any PS env variables
#
# bolt_scr_confirm_oracle_profile.sh
#
# #############################

scr=/software/akannayiram/scripts/oracle_user_profile/chk_bash_profile.sh
appprcs=/home/akannayiram/servers/92prd/prdrpt_all_app_prcs_servers.txt
web=/home/akannayiram/servers/92prd/prdrpt_all_web_servers.txt
TMP=/tmp/alk.tmp.$$;rm -f $TMP
cat $appprcs $web > $TMP
bolt command run "sudo su - oracle -c $scr" -t @"$TMP" --tty --no-host-key-check 2>&1 |tee -a tee_scr_confirm_oracle_profile.$HOSTNAME.$LOGNAME.$(date '+%Y%m%d_%H%M%S').log

# Executing with single host
#echo "ih92npap051" > $TMP
#bolt command run "sudo su - oracle -c $scr" -t @"$TMP" --tty --no-host-key-check 

rm -f $TMP
