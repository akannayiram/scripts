#!/bin/bash
# Al Kannayiram
# 9/20/2024
# To check if any PS env variables are set
hst=$(echo $HOSTNAME|cut -d "." -f1)
[[ -z $PS_HOME ]] && pshome="NOT SET" || pshome=$PS_HOME
[[ -z $TUXDIR ]] && tuxdir="NOT SET" || tuxdir=$TUXDIR
echo "$hst  $LOGNAME  PS_HOME: $pshome  TUXDIR: $tuxdir"
