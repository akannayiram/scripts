ps -aef|grep BBL|grep -v grep|cut -d"-" -f6|sed -e "s/U /tail -100 /"|sed -e "s/TUXLOG/APPSRV_0730.LOG|grep 1.7.0_311/"
