srvr=/home/akannayiram/servers/dr/dr_app_servers.txt
#bolt command run 'sudo su - oracle -c "cd /appl/oracle/jdk; cp -p -r /psft/patches/july21cpu/jdk_p33045881_170311/jdk1.7.0_311 ."' -t @$srvr --no-host-key-check --connect-timeout 600 --tty
