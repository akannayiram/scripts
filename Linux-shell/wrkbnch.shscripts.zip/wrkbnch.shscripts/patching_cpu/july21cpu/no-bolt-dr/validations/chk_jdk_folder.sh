srvr=/home/akannayiram/servers/dr/dr_web_servers.txt
bolt command run 'echo $HOSTNAME;ls -l /appl/oracle/jdk|egrep "64bit|311";ls -l /appl/oracle/jdk|egrep "64bit|311"|wc -l' -t @$srvr --no-host-key-check --connect-timeout 600 --tty
