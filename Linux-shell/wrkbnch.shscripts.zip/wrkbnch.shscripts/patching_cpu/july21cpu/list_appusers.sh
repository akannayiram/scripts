ps -aef|grep BBL|grep -v grep|cut -d" "  -f1

