# must run as oracle
cd /appl/oracle/jre 
rm -f jre1.7_64bit
cp -p -r /psft/patches/july21cpu/jre1.7.0_311/ .
ln -s jre1.7.0_311 jre1.7_64bit

