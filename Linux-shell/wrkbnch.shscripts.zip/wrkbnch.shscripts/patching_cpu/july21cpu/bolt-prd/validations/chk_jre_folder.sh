bolt command run 'echo $HOSTNAME;ls -l /appl/oracle/jre|egrep "64bit|311";ls -l /appl/oracle/jre|egrep "64bit|311"|wc -l' -t @prod_app_prcs_servers.txt --no-host-key-check --connect-timeout 600 --tty
