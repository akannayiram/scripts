cat failed_app1.txt|while read -r line
do
bolt command run 'sudo su - oracle -c "cd /appl/oracle/jre; cp -p -r /psft/patches/july21cpu/jre1.7.0_311 ."' -t $line --no-host-key-check --connect-timeout 60 --tty
done
