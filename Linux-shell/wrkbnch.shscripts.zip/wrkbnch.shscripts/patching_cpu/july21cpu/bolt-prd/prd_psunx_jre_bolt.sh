bolt command run 'sudo su - oracle -c "cd /appl/oracle/jre; cp -p -r /psft/patches/july21cpu/jre1.7.0_311 ."' -t @prod_psunx_servers.txt --no-host-key-check --connect-timeout 600 --tty
