bolt command run 'echo $HOSTNAME;cd /appl/oracle/jre;ls -l;rm -f jre1.7_64bit;ls -l ' -t @../prod_psunx_servers.txt --no-host-key-check --connect-timeout 600 --tty
