# Confirm jre dir 
ls -ld $PS_HOME/jre
# get domain name 
ls -ld $PS_HOME/appserv/CNY*|awk -F"/" '{print $NF}'
DOM=`ls -ld $PS_HOME/appserv/CNY*|awk -F"/" '{print $NF}'`
psadmin -c sstatus -d $DOM 
