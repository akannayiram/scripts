# get domain name 
ls -ld $PS_HOME/appserv/CNY*|awk -F"/" '{print $NF}'
DOM=`ls -ld $PS_HOME/appserv/CNY*|awk -F"/" '{print $NF}'`
echo "=========================================================="
echo "Status of Domain $DOM"
echo "=========================================================="
psadmin -c sstatus -d $DOM 
# Stop domain
echo "=========================================================="
echo "Shutting down Domain $DOM"
echo "=========================================================="
psadmin -c stop -d $DOM 
echo "=========================================================="
echo "Re-configuring Domain $DOM"
echo "=========================================================="
psadmin -c configure -d $DOM 
echo "=========================================================="
echo "Starting Domain $DOM"
echo "=========================================================="
psadmin -c start -d $DOM 
echo "=========================================================="
echo "PSTUXCFG file of Domain $DOM"
echo "=========================================================="
ls -l $PS_HOME/appserv/${DOM}/PSTUXCFG
APPLOG=`ls -t $PS_HOME/appserv/${DOM}/LOGS/APPSRV*|head -1`
echo "=========================================================="
echo "Last 30 lines of App server log file: "
echo "     $APPLOG "
echo "=========================================================="
tail -30 $APPLOG
