# get domain name 
ls -ld $PS_HOME/appserv/CNY*|awk -F"/" '{print $NF}'
DOM=`ls -ld $PS_HOME/appserv/CNY*|awk -F"/" '{print $NF}'`
APPLOG=`ls -t $PS_HOME/appserv/${DOM}/LOGS/APPSRV*|head -1`
echo "=========================================================="
echo "Last 40 lines of App server log file: "
echo "     $APPLOG "
echo "=========================================================="
tail -40 $APPLOG
