#$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/app_crm_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/app_css_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/app_fin_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/app_hcm_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/app_prt_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
#$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/prd_psunx_crm_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/prd_psunx_css_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/prd_psunx_fin_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/prd_psunx_hcm_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
#$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/prd/by_pillar/prd_psunx_prt_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
#
