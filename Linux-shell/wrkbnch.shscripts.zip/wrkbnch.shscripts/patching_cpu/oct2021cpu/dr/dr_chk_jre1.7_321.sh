$BOLT/bolt_list_jrejdk.sh /home/akannayiram/servers/dr/dr_app_servers.txt /psft/akannayiram/oct21cpu_scripts/chk_jre1.7_321.sh
$BOLT/bolt_list_jrejdk.sh /home/akannayiram/servers/dr/dr_psunx_servers.txt /psft/akannayiram/oct21cpu_scripts/chk_jre1.7_321.sh
