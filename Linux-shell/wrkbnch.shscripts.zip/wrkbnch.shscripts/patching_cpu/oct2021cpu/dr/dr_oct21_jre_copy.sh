#$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_app_crm_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_app_css_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_app_fin_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_app_hcm_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_app_prt_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
#$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_psunx_crm_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_psunx_css_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_psunx_fin_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_psunx_hcm_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
#$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_psunx_prt_servers.txt /psft/akannayiram/oct21cpu_scripts/jre17copynosym.sh
#
