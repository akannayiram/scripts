$BOLT/bolt_list_jrejdk.sh /home/akannayiram/servers/dr/dr_web_servers.txt /psft/akannayiram/oct21cpu_scripts/chk_jdk1.7_321.sh
