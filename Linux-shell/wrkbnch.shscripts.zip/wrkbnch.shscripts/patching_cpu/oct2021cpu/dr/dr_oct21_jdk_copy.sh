#$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_web_crm_servers.txt /psft/akannayiram/oct21cpu_scripts/jdk17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_web_css_servers.txt /psft/akannayiram/oct21cpu_scripts/jdk17copynosym.sh
#$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_web_fin_servers.txt /psft/akannayiram/oct21cpu_scripts/jdk17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_web_hcm_servers.txt /psft/akannayiram/oct21cpu_scripts/jdk17copynosym.sh
$BOLT/bolt_jrejdk_validate.sh /home/akannayiram/servers/dr/by_pillar/dr_web_prt_servers.txt /psft/akannayiram/oct21cpu_scripts/jdk17copynosym.sh

