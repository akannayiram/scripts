#!/bin/bash
i=0
i=$((i+1))
let "i = $i + 1"
echo $i

j=10
j=$((j+1))
echo $j

