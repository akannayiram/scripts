#!/bin/bash

# Temp file
indexstatfile=/tmp/alk.indexstatfile.$$.tmp
rm -f $indexstatfile


# NP 
#curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE=" http://es92npwl051:8080/_cat/indices > $indexstatfile

# Test with one environment
curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE=" http://es92npwl051:8080/_cat/indices/*cnyihde2 > $indexstatfile

curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE=" http://es92npwl051:8080/_cat/indices/*cnyihde2
while read  -r line
do 
  health=$(echo $line|awk '{print $1}')
  status=$(echo $line|awk '{print $2}')
  index=$(echo $line|awk '{print $3}')
  uuid=$(echo $line|awk '{print $4}')
  priority=$(echo $line|awk '{print $5}')
  replica=$(echo $line|awk '{print $6}')
  docs_count=$(echo $line|awk '{print $7}')
  docs_deleted=$(echo $line|awk '{print $8}')
  store_size=$(echo $line|awk '{print $9}')
  pri_store_size=$(echo $line|awk '{print $10}')
  
  echo "health: [$health]"
  echo "status: [$status]"
  echo "index: [$index]"
  echo "uuid: [$uuid]"
  echo "priority: [$priority]"
  echo "replica: [$replica]"
  echo "docs_count: [$docs_count]"
  echo "docs_deleted: [$docs_deleted]"
  echo "store_size: [$store_size]"
  echo "pri_store_size: [$pri_store_size]"
done < $indexstatfile

rm -f $indexstatfile
