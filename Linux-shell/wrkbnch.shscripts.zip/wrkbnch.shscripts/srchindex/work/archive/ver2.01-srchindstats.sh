#!/bin/bash


# Initialize the Indices by Pillar
# These are hardcoded for now since they don't change often

init_ind ()
{

# CS 
CSIND=$(cat <<!EOF
ptportalregistry
ssr_browse_catalog_lff
ssr_browse_catalog_sff
ssr_class_search_lff
ssr_class_search_sff
!EOF
)


# HC 
HCIND=$(cat <<!EOF
hc_comp_compensation_history
hc_ep_perf_dev
hc_hr_career_plan
hc_hr_company_directory1
hc_hr_job_data
hc_hr_person
hc_hrs_app_index
hc_hrs_applicant
hc_hrs_application_content
hc_hrs_data_map
hc_hrs_job_content
hc_hrs_job_opening
hc_hrs_job_posting
hc_hr_succ_plan
hc_hr_wf_diversity
hc_hs_incident_data
hc_jpm_nonperson_profile
hc_jpm_person_profile
hc_tl_gbl_timesheet
ptportalregistry
ptwl_gen_msg_wl
!EOF
)


# FS 
FSIND=$(cat <<!EOF
ptportalregistry
!EOF
)


# IH 
IHIND=$(cat <<!EOF
ptportalregistry
rntrptst
!EOF
)

}


# Initialize the Environments by Pillar
init_env ()
{

# CS  ENV
CSENV=$(cat <<!EOF
cnycsdm2
cnycspdv
cnycspst
cnycsug2
!EOF
)


# HC  ENV
HCENV=$(cat <<!EOF
cnyhcdm2
cnyhcpdv
cnyhcpst
cnyhcug2
!EOF
)


# FS  ENV
FSENV=$(cat <<!EOF
cnyfsdm2
cnyfspdv
cnyfspst
cnyfsug2
!EOF
)


# IH  ENV
IHENV=$(cat <<!EOF
cnyihdm2
cnyihpdv
cnyihpst
cnyihug2
!EOF
)

}


gather_stats ()
{

#prod
#prdurl="curl -s -XGET -H \"Authorization: Basic "${prdauth}"\" http://"${prdhost}":8080/_cat/indices"
prdurl=""${cmdopt}" -H \"Authorization: Basic "${prdauth}"\" http://"${prdhost}":8080/_cat/indices"

#perf
#prfurl="curl -s -XGET -H \"Authorization: Basic "${prfauth}"\" http://"${prfhost}":8080/_cat/indices"
prfurl=""${cmdopt}" -H \"Authorization: Basic "${prfauth}"\" http://"${prfhost}":8080/_cat/indices"

#NP
#npurl="curl -s -XGET -H \"Authorization: Basic "${npauth}"\" http://"${nphost}":8080/_cat/indices"
npurl=""${cmdopt}" -H \"Authorization: Basic "${npauth}"\" http://"${nphost}":8080/_cat/indices"

echo prod: ["$prdurl"]
echo perf: ["$prfurl"]
echo NP:   ["$npurl"]

# use eval to execute the command in a variable
#   eval: eval [arg ...]    # Execute arguments as a shell command.

eval "$prdurl" |grep -v orcl_es_acl|grep -v ".tasks" > $PRDINDFL
eval "$prfurl" |grep -v orcl_es_acl|grep -v ".tasks" > $PRFINDFL
eval "$npurl" |grep -v orcl_es_acl|grep -v ".tasks" > $NPINDFL

prdcnt=$(cat "$PRDINDFL"|wc -l)
prfcnt=$(cat "$PRFINDFL"|wc -l)
npcnt=$(cat "$NPINDFL"|wc -l)

# Check if auths are successful
[[ $(cat "$PRDINDFL"|grep ".*error.*401.*" |wc -l) -ne 0 ]] && prdautherr=Y
[[ $(cat "$PRFINDFL"|grep ".*error.*401.*" |wc -l) -ne 0 ]] && prfautherr=Y
[[ $(cat "$NPINDFL"|grep ".*error.*401.*" |wc -l) -ne 0 ]] && npautherr=Y

echo prod auth: ["$prdautherr"]  prod count: [$prdcnt]
echo perf auth: ["$prfautherr"]  perf count: [$prfcnt]
echo NP auth:   ["$npautherr"]   NP count:   [$npcnt]

}


add_html_doctype ()
{
cat > $HTMLFL <<!EOF
<html><head><meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="author" content="Al Kannayiram">
<title>OpenSearch Index stats</title></head><body><br><center><h1>OpenSearch Index stats</h1>
<h3>$statdttm</h3></center>
!EOF

}

add_pillar_table ()
{
# $ENV has the uppercase pillar name
cat >> $HTMLFL <<!EOF
<h2>$ENV Search Index stats <span style="font-size: 20px;">&nbsp; &nbsp; &nbsp; 
(health / number of documents / total size of the index)</span></h2>
<center><table width="90%" cellspacing="2" cellpadding="2" border="1">
<thead><tr><th width="4%" valign="top">Seq<br></th>
<th width="30%" valign="top">SEARCH INDEX<br></th>
<th width="11%" valign="top">${ENV}PRD<br></th>
<th width="11%" valign="top">${ENV}PRF<br></th>
<th width="11%" valign="top">${ENV}DM2<br></th>
<th width="11%" valign="top">${ENV}PDV<br></th>
<th width="11%" valign="top">${ENV}PST<br></th>
<th width="11%" valign="top">${ENV}UG2<br></th></tr><tbody>
!EOF

}

add_ind_stat_line ()
{
# 
cat >> $HTMLFL <<!EOF
<tr><td valign="top">$seq<br></td><td valign="top">$SRCHIND<br></td>
<td valign="top">$health_prd<br>$docs_count_prd<br>$store_size_prd<br></td>
<td valign="top">$health_prf<br>$docs_count_prf<br>$store_size_prf<br></td>
<td valign="top">$health_dm2<br>$docs_count_dm2<br>$store_size_dm2<br></td>
<td valign="top">$health_pdv<br>$docs_count_pdv<br>$store_size_pdv<br></td>
<td valign="top">$health_pst<br>$docs_count_pst<br>$store_size_pst<br></td>
<td valign="top">$health_ug2<br>$docs_count_ug2<br>$store_size_ug2<br></td></tr>

!EOF

}

add_html_close_table ()
{
cat >> $HTMLFL <<!EOF
</tbody></table></center>
!EOF

}

add_html_doc_end ()
{
cat >> $HTMLFL <<!EOF
<br><br>Generated on $statdttm
</body></html>
!EOF

}


# Parse CS Status
parse_and_add_CS_stats () 
{

seq=0
# For each index in the input
# Search PRD, PRF, NP stat output files
# If the index stat is found, parse to extract the fields
# Otherwise, initialize to N/A

for inpind in $CSIND
do
  indname="${inpind}"_cnycsprd
  statline=$(grep "$indname" "$PRDINDFL")
  hitcnt=$(grep "$indname" "$PRDINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prd="MISSING"; docs_count_prd="N/A"; store_size_prd="N/A"
  else
      health_prd=$(echo $statline|awk '{print $1}')
      docs_count_prd=$(echo $statline|awk '{print $7}')
      store_size_prd=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycspr2
  statline=$(grep "$indname" "$PRFINDFL")
  hitcnt=$(grep "$indname" "$PRFINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prf="MISSING"; docs_count_prf="N/A"; store_size_prf="N/A"
  else
      health_prf=$(echo $statline|awk '{print $1}')
      docs_count_prf=$(echo $statline|awk '{print $7}')
      store_size_prf=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycsdm2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_dm2="MISSING"; docs_count_dm2="N/A"; store_size_dm2="N/A"
  else
      health_dm2=$(echo $statline|awk '{print $1}')
      docs_count_dm2=$(echo $statline|awk '{print $7}')
      store_size_dm2=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycspdv
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pdv="MISSING"; docs_count_pdv="N/A"; store_size_pdv="N/A"
  else
      health_pdv=$(echo $statline|awk '{print $1}')
      docs_count_pdv=$(echo $statline|awk '{print $7}')
      store_size_pdv=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycspst
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pst="MISSING"; docs_count_pst="N/A"; store_size_pst="N/A"
  else
      health_pst=$(echo $statline|awk '{print $1}')
      docs_count_pst=$(echo $statline|awk '{print $7}')
      store_size_pst=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycsug2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_ug2="MISSING"; docs_count_ug2="N/A"; store_size_ug2="N/A"
  else
      health_ug2=$(echo $statline|awk '{print $1}')
      docs_count_ug2=$(echo $statline|awk '{print $7}')
      store_size_ug2=$(echo $statline|awk '{print $9}')
  fi

  seq=$((seq + 1))
  SRCHIND=$(echo $inpind|tr '[a-z]' '[A-Z'])
   
  add_ind_stat_line

done

add_html_close_table

}


# Parse HC Status
parse_and_add_HC_stats () 
{

seq=0
# For each index in the input
# Search PRD, PRF, NP stat output files
# If the index stat is found, parse to extract the fields
# Otherwise, initialize to N/A

for inpind in $HCIND
do
  indname="${inpind}"_cnyhcprd
  statline=$(grep "$indname" "$PRDINDFL")
  hitcnt=$(grep "$indname" "$PRDINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prd="MISSING"; docs_count_prd="N/A"; store_size_prd="N/A"
  else
      health_prd=$(echo $statline|awk '{print $1}')
      docs_count_prd=$(echo $statline|awk '{print $7}')
      store_size_prd=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcpr2
  statline=$(grep "$indname" "$PRFINDFL")
  hitcnt=$(grep "$indname" "$PRFINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prf="MISSING"; docs_count_prf="N/A"; store_size_prf="N/A"
  else
      health_prf=$(echo $statline|awk '{print $1}')
      docs_count_prf=$(echo $statline|awk '{print $7}')
      store_size_prf=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcdm2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_dm2="MISSING"; docs_count_dm2="N/A"; store_size_dm2="N/A"
  else
      health_dm2=$(echo $statline|awk '{print $1}')
      docs_count_dm2=$(echo $statline|awk '{print $7}')
      store_size_dm2=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcpdv
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pdv="MISSING"; docs_count_pdv="N/A"; store_size_pdv="N/A"
  else
      health_pdv=$(echo $statline|awk '{print $1}')
      docs_count_pdv=$(echo $statline|awk '{print $7}')
      store_size_pdv=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcpst
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pst="MISSING"; docs_count_pst="N/A"; store_size_pst="N/A"
  else
      health_pst=$(echo $statline|awk '{print $1}')
      docs_count_pst=$(echo $statline|awk '{print $7}')
      store_size_pst=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcug2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_ug2="MISSING"; docs_count_ug2="N/A"; store_size_ug2="N/A"
  else
      health_ug2=$(echo $statline|awk '{print $1}')
      docs_count_ug2=$(echo $statline|awk '{print $7}')
      store_size_ug2=$(echo $statline|awk '{print $9}')
  fi

  seq=$((seq + 1))
  SRCHIND=$(echo $inpind|tr '[a-z]' '[A-Z'])
   
  add_ind_stat_line

done

add_html_close_table

}


# Parse FS Status
parse_and_add_FS_stats () 
{

seq=0
# For each index in the input
# Search PRD, PRF, NP stat output files
# If the index stat is found, parse to extract the fields
# Otherwise, initialize to N/A

for inpind in $FSIND
do
  indname="${inpind}"_cnyfsprd
  statline=$(grep "$indname" "$PRDINDFL")
  hitcnt=$(grep "$indname" "$PRDINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prd="MISSING"; docs_count_prd="N/A"; store_size_prd="N/A"
  else
      health_prd=$(echo $statline|awk '{print $1}')
      docs_count_prd=$(echo $statline|awk '{print $7}')
      store_size_prd=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfspr2
  statline=$(grep "$indname" "$PRFINDFL")
  hitcnt=$(grep "$indname" "$PRFINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prf="MISSING"; docs_count_prf="N/A"; store_size_prf="N/A"
  else
      health_prf=$(echo $statline|awk '{print $1}')
      docs_count_prf=$(echo $statline|awk '{print $7}')
      store_size_prf=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfsdm2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_dm2="MISSING"; docs_count_dm2="N/A"; store_size_dm2="N/A"
  else
      health_dm2=$(echo $statline|awk '{print $1}')
      docs_count_dm2=$(echo $statline|awk '{print $7}')
      store_size_dm2=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfspdv
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pdv="MISSING"; docs_count_pdv="N/A"; store_size_pdv="N/A"
  else
      health_pdv=$(echo $statline|awk '{print $1}')
      docs_count_pdv=$(echo $statline|awk '{print $7}')
      store_size_pdv=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfspst
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pst="MISSING"; docs_count_pst="N/A"; store_size_pst="N/A"
  else
      health_pst=$(echo $statline|awk '{print $1}')
      docs_count_pst=$(echo $statline|awk '{print $7}')
      store_size_pst=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfsug2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_ug2="MISSING"; docs_count_ug2="N/A"; store_size_ug2="N/A"
  else
      health_ug2=$(echo $statline|awk '{print $1}')
      docs_count_ug2=$(echo $statline|awk '{print $7}')
      store_size_ug2=$(echo $statline|awk '{print $9}')
  fi

  seq=$((seq + 1))
  SRCHIND=$(echo $inpind|tr '[a-z]' '[A-Z'])
   
  add_ind_stat_line

done

add_html_close_table

}


# Parse IH Status
parse_and_add_IH_stats () 
{

seq=0
# For each index in the input
# Search PRD, PRF, NP stat output files
# If the index stat is found, parse to extract the fields
# Otherwise, initialize to N/A

for inpind in $IHIND
do
  indname="${inpind}"_cnyihprd
  statline=$(grep "$indname" "$PRDINDFL")
  hitcnt=$(grep "$indname" "$PRDINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prd="MISSING"; docs_count_prd="N/A"; store_size_prd="N/A"
  else
      health_prd=$(echo $statline|awk '{print $1}')
      docs_count_prd=$(echo $statline|awk '{print $7}')
      store_size_prd=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihpr2
  statline=$(grep "$indname" "$PRFINDFL")
  hitcnt=$(grep "$indname" "$PRFINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prf="MISSING"; docs_count_prf="N/A"; store_size_prf="N/A"
  else
      health_prf=$(echo $statline|awk '{print $1}')
      docs_count_prf=$(echo $statline|awk '{print $7}')
      store_size_prf=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihdm2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_dm2="MISSING"; docs_count_dm2="N/A"; store_size_dm2="N/A"
  else
      health_dm2=$(echo $statline|awk '{print $1}')
      docs_count_dm2=$(echo $statline|awk '{print $7}')
      store_size_dm2=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihpdv
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pdv="MISSING"; docs_count_pdv="N/A"; store_size_pdv="N/A"
  else
      health_pdv=$(echo $statline|awk '{print $1}')
      docs_count_pdv=$(echo $statline|awk '{print $7}')
      store_size_pdv=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihpst
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pst="MISSING"; docs_count_pst="N/A"; store_size_pst="N/A"
  else
      health_pst=$(echo $statline|awk '{print $1}')
      docs_count_pst=$(echo $statline|awk '{print $7}')
      store_size_pst=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihug2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_ug2="MISSING"; docs_count_ug2="N/A"; store_size_ug2="N/A"
  else
      health_ug2=$(echo $statline|awk '{print $1}')
      docs_count_ug2=$(echo $statline|awk '{print $7}')
      store_size_ug2=$(echo $statline|awk '{print $9}')
  fi

  seq=$((seq + 1))
  SRCHIND=$(echo $inpind|tr '[a-z]' '[A-Z'])
   
  add_ind_stat_line

done

add_html_close_table

}



# Main

statdttm=$(date)

# Constants
prdhost=cnypres101; prdauth="b3NhZG1pbjpQbEdDRHdIYmhaSFRtb3k5ampjQTFjTUI="; prdautherr=N
prfhost=cnypfes301; prfauth="b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE="; prfautherr=N
nphost=es92npwl051;  npauth="b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE=";  npautherr=N
cmdopt="curl -s -XGET"; endpath="/_cat/indices"; port=8080

# temp files
PRDINDFL=/tmp/prdindfl.$$.tmp; rm -f $PRDINDFL
PRFINDFL=/tmp/prfindfl.$$.tmp; rm -f $PRFINDFL
NPINDFL=/tmp/npindfl.$$.tmp; rm -f $NPINDFL

HTMLFL=/tmp/srchstats.$$.html.txt;rm -f HTMLFL

# Initialize 
init_ind
init_env

gather_stats

# Abort if any connectivity issues to OS clusters
[[ "$prdautherr" == "Y" ]] && echo "ERROR connecting to PROD OS Cluster. Aborting..." && cat "$PRDINDFL"
[[ "$prfautherr" == "Y" ]] && echo "ERROR connecting to PERF OS Cluster. Aborting..." && cat "$PRFINDFL"
[[ "$npautherr" == "Y" ]] && echo "ERROR connecting to NP OS Cluster. Aborting..." && cat "$NPINDFL"
[[ "$prdautherr" == "Y" || "$prfautherr" == "Y" || "$npautherr" == "Y" ]] && echo "Exited" && exit

# html file
add_html_doctype

# Parse stats for CS Indicies 
ENV=CS
add_pillar_table
parse_and_add_CS_stats

# Parse stats for CS Indicies 
ENV=HC
add_pillar_table
parse_and_add_HC_stats

# Parse stats for CS Indicies 
ENV=FS
add_pillar_table
parse_and_add_FS_stats

# Parse stats for CS Indicies 
ENV=IH
add_pillar_table
parse_and_add_IH_stats



add_html_doc_end

#echo "$HCIND"
#for line in $HCIND
#do
#echo "$line"
#done


#echo "$CSENV"
#for line in $CSENV
#do
#echo "$line"
#done
echo "End: $(date) "
