#!/bin/bash
# 5/13/2024
TMPINDFILE=prf.srch.indices.txt
rm -f $TMPINDFILE

# Get all the indices (PERF)
curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE=" http://cnypfes301:8080/_cat/indices|grep -v orcl_es_acl|while read -r line
do

  # Third field contins: index + "_" + db (all lowercase)
  indice=$(echo $line|awk '{print $3}')
  env=$(echo $indice|awk -F"_" '{print $NF}')
  ind=$(echo $indice|sed 's/_cny[a-z0-9].*$//')
  echo "$env $ind" >> $TMPINDFILE
  echo -e "[$env]\t [$ind]\t[$indice]"
done

# Split by Pillar 
rm -f prf.hc.srchindex.txt prf.cs.srchindex.txt prf.fs.srchindex.txt prf.ih.srchindex.txt
grep hcpr2 $TMPINDFILE |sort |awk '{print$2}' > prf.hc.srchindex.txt

grep cspr2 $TMPINDFILE |sort |awk '{print$2}' > prf.cs.srchindex.txt

grep fspr2 $TMPINDFILE |sort |awk '{print$2}' > prf.fs.srchindex.txt

grep ihpr2 $TMPINDFILE |sort |awk '{print$2}' > prf.ih.srchindex.txt
