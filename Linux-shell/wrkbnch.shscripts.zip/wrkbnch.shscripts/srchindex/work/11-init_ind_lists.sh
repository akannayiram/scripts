#!/bin/bash


# Initialize the Indices by Pillar
# These are hardcoded for now since they don't change often

init_ind ()
{

# CS 
CSIND=$(cat <<!EOF
ptportalregistry
ssr_browse_catalog_lff
ssr_browse_catalog_sff
ssr_class_search_lff
ssr_class_search_sff
!EOF
)


# HC 
HCIND=$(cat <<!EOF
hc_comp_compensation_history
hc_ep_perf_dev
hc_hr_career_plan
hc_hr_company_directory1
hc_hr_job_data
hc_hr_person
hc_hrs_app_index
hc_hrs_applicant
hc_hrs_application_content
hc_hrs_data_map
hc_hrs_job_content
hc_hrs_job_opening
hc_hrs_job_posting
hc_hr_succ_plan
hc_hr_wf_diversity
hc_hs_incident_data
hc_jpm_nonperson_profile
hc_jpm_person_profile
hc_tl_gbl_timesheet
ptportalregistry
ptwl_gen_msg_wl
!EOF
)


# FS 
FSIND=$(cat <<!EOF
ptportalregistry
!EOF
)


# IH 
IHIND=$(cat <<!EOF
ptportalregistry
rntrptst
!EOF
)

}

init_env ()
{

# CS  ENV
CSENV=$(cat <<!EOF
cnycsdm2
cnycspdv
cnycspst
cnycsug2
!EOF
)


# HC  ENV
HCENV=$(cat <<!EOF
cnyhcdm2
cnyhcpdv
cnyhcpst
cnyhcug2
!EOF
)


# FS  ENV
FSENV=$(cat <<!EOF
cnyfsdm2
cnyfspdv
cnyfspst
cnyfsug2
!EOF
)


# IH  ENV
IHENV=$(cat <<!EOF
cnyihdm2
cnyihpdv
cnyihpst
cnyihug2
!EOF
)

}




# Initialize 

# Temp files
#CSIND=/tmp/csind.$$.tmp; rm -f $CSIND; init_cs_ind
#HCIND=/tmp/hcind.$$.tmp; rm -f $HCIND; init_hc_ind
#FSIND=/tmp/fsind.$$.tmp; rm -f $FSIND; init_fs_ind
#IHIND=/tmp/ihind.$$.tmp; rm -f $IHIND; init_ih_ind

# NP Enviornments
#CSENV=/tmp/csenv.$$.tmp; rm -f $CSENV; init_cs_env
#HCENV=/tmp/hcenv.$$.tmp; rm -f $HCENV; init_hc_env
#FSENV=/tmp/fsenv.$$.tmp; rm -f $FSENV; init_fs_env
#IHENV=/tmp/ihenv.$$.tmp; rm -f $IHENV; init_ih_env

init_ind
#echo "$HCIND"
for line in $HCIND
do
echo "$line"
done


echo " "
init_env
#echo "$CSENV"
for line in $CSENV
do
echo "$line"
done
















