#!/bin/bash

parse_stats ()
{
  health=$(echo $line|awk '{print $1}')
  status=$(echo $line|awk '{print $2}')
  index=$(echo $line|awk '{print $3}')
  uuid=$(echo $line|awk '{print $4}')
  priority=$(echo $line|awk '{print $5}')
  replica=$(echo $line|awk '{print $6}')
  docs_count=$(echo $line|awk '{print $7}')
  docs_deleted=$(echo $line|awk '{print $8}')
  store_size=$(echo $line|awk '{print $9}')
  pri_store_size=$(echo $line|awk '{print $10}')
  
  echo "health: [$health]"
  echo "status: [$status]"
  echo "index: [$index]"
  echo "uuid: [$uuid]"
  echo "priority: [$priority]"
  echo "replica: [$replica]"
  echo "docs_count: [$docs_count]"
  echo "docs_deleted: [$docs_deleted]"
  echo "store_size: [$store_size]"
  echo "pri_store_size: [$pri_store_size]"
}

