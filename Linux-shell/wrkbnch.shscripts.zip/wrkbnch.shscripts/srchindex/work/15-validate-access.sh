#!/bin/bash

# Get indicies stats
# Search the outfile if there are any 401 error

validate_access ()
{



}
