#!/bin/bash
# 5/13/2024
TMPINDFILE=prd.srch.indices.txt
rm -f $TMPINDFILE

# Get all the indices
curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpQbEdDRHdIYmhaSFRtb3k5ampjQTFjTUI=" http://cnypres101:8080/_cat/indices |grep -v orcl_es_acl|grep -v ".tasks"|while read -r line
do

  # Third field contins: index + "_" + db (all lowercase)
  indice=$(echo $line|awk '{print $3}')
  env=$(echo $indice|awk -F"_" '{print $NF}')
  ind=$(echo $indice|sed 's/_cny[a-z0-9].*$//')
  echo "$env $ind" >> $TMPINDFILE
  echo -e "[$env]\t [$ind]\t[$indice]"
done

# Split by Pillar 
rm -f hc.srchindex.txt cs.srchindex.txt fs.srchindex.txt ih.srchindex.txt
grep hcprd $TMPINDFILE |sort |awk '{print$2}' > hc.srchindex.txt

grep csprd $TMPINDFILE |sort |awk '{print$2}' > cs.srchindex.txt

grep fsprd $TMPINDFILE |sort |awk '{print$2}' > fs.srchindex.txt

grep ihprd $TMPINDFILE |sort |awk '{print$2}' > ih.srchindex.txt
