#!/bin/bash


# Initialize the Indices by Pillar
# These are hardcoded for now since they don't change often

init_ind ()
{

# CS 
CSIND=$(cat <<!EOF
ptportalregistry
ssr_browse_catalog_lff
ssr_browse_catalog_sff
ssr_class_search_lff
ssr_class_search_sff
!EOF
)

# HC 
HCIND=$(cat <<!EOF
hc_comp_compensation_history
hc_ep_perf_dev
hc_hr_career_plan
hc_hr_company_directory1
hc_hr_job_data
hc_hr_person
hc_hrs_app_index
hc_hrs_applicant
hc_hrs_application_content
hc_hrs_data_map
hc_hrs_job_content
hc_hrs_job_opening
hc_hrs_job_posting
hc_hr_succ_plan
hc_hr_wf_diversity
hc_hs_incident_data
hc_jpm_nonperson_profile
hc_jpm_person_profile
hc_tl_gbl_timesheet
ptportalregistry
ptwl_gen_msg_wl
!EOF
)

# FS 
FSIND=$(cat <<!EOF
ptportalregistry
!EOF
)

# IH 
IHIND=$(cat <<!EOF
ptportalregistry
rntrptst
!EOF
)

}


# Initialize the Environments by Pillar
init_env ()
{

# CS  ENV
CSENV=$(cat <<!EOF
cnycsdm2
cnycspdv
cnycspst
cnycsug2
!EOF
)

# HC  ENV
HCENV=$(cat <<!EOF
cnyhcdm2
cnyhcpdv
cnyhcpst
cnyhcug2
!EOF
)

# FS  ENV
FSENV=$(cat <<!EOF
cnyfsdm2
cnyfspdv
cnyfspst
cnyfsug2
!EOF
)

# IH  ENV
IHENV=$(cat <<!EOF
cnyihdm2
cnyihpdv
cnyihpst
cnyihug2
!EOF
)

}


gather_stats ()
{

#prod
prdurl=""${cmdopt}" -H \"Authorization: Basic "${prdauth}"\" http://"${prdhost}":"${port}"/_cat/indices"

#perf
prfurl=""${cmdopt}" -H \"Authorization: Basic "${prfauth}"\" http://"${prfhost}":"${port}"/_cat/indices"

#NP
npurl=""${cmdopt}" -H \"Authorization: Basic "${npauth}"\" http://"${nphost}":"${port}"/_cat/indices"

# use eval to execute the command in a variable
#   eval: eval [arg ...]    # Execute arguments as a shell command.

eval "$prdurl" |grep -v orcl_es_acl|grep -v ".tasks" > $PRDINDFL
eval "$prfurl" |grep -v orcl_es_acl|grep -v ".tasks" > $PRFINDFL
eval "$npurl" |grep -v orcl_es_acl|grep -v ".tasks" > $NPINDFL

prdcnt=$(cat "$PRDINDFL"|wc -l)
prfcnt=$(cat "$PRFINDFL"|wc -l)
npcnt=$(cat "$NPINDFL"|wc -l)

# Check if auths are successful
[[ $(cat "$PRDINDFL"|grep ".*error.*401.*" |wc -l) -ne 0 ]] && prdautherr=Y
[[ $(cat "$PRFINDFL"|grep ".*error.*401.*" |wc -l) -ne 0 ]] && prfautherr=Y
[[ $(cat "$NPINDFL"|grep ".*error.*401.*" |wc -l) -ne 0 ]] && npautherr=Y

#echo prod auth: ["$prdautherr"]  prod count: [$prdcnt]
#echo perf auth: ["$prfautherr"]  perf count: [$prfcnt]
#echo NP auth:   ["$npautherr"]   NP count:   [$npcnt]

}


add_html_doctype ()
{
cat > $HTMLFL <<!EOF
<html><head><meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="author" content="Al Kannayiram">
<title>OpenSearch Index stats</title><style>
html { font-family: Tahoma, Geneva, sans-serif; }
table.cstable { border-collapse: collapse; font-family: Tahoma, Geneva, sans-serif; }
table.cstable td { padding: 15px; }
table.cstable thead th { background-color: #54585d; color: #ffffff; font-weight: bold;
 font-size: 15px; border: 1px solid #54585d; }
table.cstable tbody td { color: #636363; border: 1px solid #b2beb5; }
table.cstable tbody tr { background-color: #f2f2f2; }
table.cstable tbody tr:nth-child(odd) { background-color: #ffffff; }
table.hctable { border-collapse: collapse; font-family: Tahoma, Geneva, sans-serif; }
table.hctable td { padding: 15px; }
table.hctable thead th { background-color: #54585d; color: #ffffff; font-weight: bold;
 font-size: 15px; border: 1px solid #54585d; }
table.hctable tbody td { color: #636363; border: 1px solid #b2beb5; }
table.hctable tbody tr { background-color: #f2f2f2; }
table.hctable tbody tr:nth-child(odd) { background-color: #ffffff; }
table.fstable { border-collapse: collapse; font-family: Tahoma, Geneva, sans-serif; }
table.fstable td { padding: 15px; }
table.fstable thead th { background-color: #54585d; color: #ffffff; font-weight: bold;
 font-size: 15px; border: 1px solid #54585d; }
table.fstable tbody td { color: #636363; border: 1px solid #b2beb5; }
table.fstable tbody tr { background-color: #f2f2f2; }
table.fstable tbody tr:nth-child(odd) { background-color: #ffffff; }
table.ihtable { border-collapse: collapse; font-family: Tahoma, Geneva, sans-serif; }
table.ihtable td { padding: 15px; }
table.ihtable thead th { background-color: #54585d; color: #ffffff; font-weight: bold;
 font-size: 15px; border: 1px solid #54585d; }
table.ihtable tbody td { color: #636363; border: 1px solid #b2beb5; }
table.ihtable tbody tr { background-color: #f2f2f2; }
table.ihtable tbody tr:nth-child(odd) { background-color: #ffffff; }
</style></head><body><br><center><font color="#484f4f"><h2>OpenSearch Index stats</h2>
<h5>$statdttm</h5></font></center>
!EOF

}

#<center><table class="$pillarclass" width="90%" cellspacing="2" cellpadding="2" border="1">
add_pillar_table ()
{
# $ENV has the uppercase pillar name
cat >> $HTMLFL <<!EOF
<font color="$pillarcolor"><h3>$ENV Search Index stats <span style="font-size: 15px;">&nbsp; &nbsp; &nbsp; 
(health / number of documents / total size of the index)</span></h3>
<center><table class="$pillarclass" width="90%">
<thead><tr bgcolor="#cccccc"><th width="4%" valign="top">Seq<br></th>
<th width="30%" valign="top">SEARCH INDEX<br></th>
<th width="11%" valign="top">${ENV}PRD<br></th>
<th width="11%" valign="top">${ENV}PRF<br></th>
<th width="11%" valign="top">${ENV}DM2<br></th>
<th width="11%" valign="top">${ENV}PDV<br></th>
<th width="11%" valign="top">${ENV}PST<br></th>
<th width="11%" valign="top">${ENV}UG2<br></th></tr></thead><tbody>
!EOF

}

add_ind_stat_line ()
{
# 
cat >> $HTMLFL <<!EOF
<tr><td valign="top">$seq<br></td><td valign="top">$SRCHIND<br></td>
<td valign="top">$health_prd<br>$docs_count_prd<br>$store_size_prd<br></td>
<td valign="top">$health_prf<br>$docs_count_prf<br>$store_size_prf<br></td>
<td valign="top">$health_dm2<br>$docs_count_dm2<br>$store_size_dm2<br></td>
<td valign="top">$health_pdv<br>$docs_count_pdv<br>$store_size_pdv<br></td>
<td valign="top">$health_pst<br>$docs_count_pst<br>$store_size_pst<br></td>
<td valign="top">$health_ug2<br>$docs_count_ug2<br>$store_size_ug2<br></td></tr>

!EOF

}

add_html_close_table ()
{
cat >> $HTMLFL <<!EOF
</tbody></table></center></font>
!EOF

}

add_html_doc_end ()
{
cat >> $HTMLFL <<!EOF
<br><br><span style="font-size: 10px;">Generated on $statdttm</span>
</body></html>
!EOF

}


# Parse CS Status
parse_and_add_CS_stats () 
{

seq=0
# For each index in the input
# Search PRD, PRF, NP stat output files
# If the index stat is found, parse to extract the fields
# Otherwise, initialize to N/A

for inpind in $CSIND
do
  indname="${inpind}"_cnycsprd
  statline=$(grep "$indname" "$PRDINDFL")
  hitcnt=$(grep "$indname" "$PRDINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prd="MISSING"; docs_count_prd="N/A"; store_size_prd="N/A"
  else
      health_prd=$(echo $statline|awk '{print $1}')
      docs_count_prd=$(echo $statline|awk '{print $7}')
      store_size_prd=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycspr2
  statline=$(grep "$indname" "$PRFINDFL")
  hitcnt=$(grep "$indname" "$PRFINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prf="MISSING"; docs_count_prf="N/A"; store_size_prf="N/A"
  else
      health_prf=$(echo $statline|awk '{print $1}')
      docs_count_prf=$(echo $statline|awk '{print $7}')
      store_size_prf=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycsdm2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_dm2="MISSING"; docs_count_dm2="N/A"; store_size_dm2="N/A"
  else
      health_dm2=$(echo $statline|awk '{print $1}')
      docs_count_dm2=$(echo $statline|awk '{print $7}')
      store_size_dm2=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycspdv
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pdv="MISSING"; docs_count_pdv="N/A"; store_size_pdv="N/A"
  else
      health_pdv=$(echo $statline|awk '{print $1}')
      docs_count_pdv=$(echo $statline|awk '{print $7}')
      store_size_pdv=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycspst
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pst="MISSING"; docs_count_pst="N/A"; store_size_pst="N/A"
  else
      health_pst=$(echo $statline|awk '{print $1}')
      docs_count_pst=$(echo $statline|awk '{print $7}')
      store_size_pst=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnycsug2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_ug2="MISSING"; docs_count_ug2="N/A"; store_size_ug2="N/A"
  else
      health_ug2=$(echo $statline|awk '{print $1}')
      docs_count_ug2=$(echo $statline|awk '{print $7}')
      store_size_ug2=$(echo $statline|awk '{print $9}')
  fi

  seq=$((seq + 1))
  SRCHIND=$(echo $inpind|tr '[a-z]' '[A-Z'])
   
  add_ind_stat_line

done

add_html_close_table

}


# Parse HC Status
parse_and_add_HC_stats () 
{

seq=0
# For each index in the input
# Search PRD, PRF, NP stat output files
# If the index stat is found, parse to extract the fields
# Otherwise, initialize to N/A

for inpind in $HCIND
do
  indname="${inpind}"_cnyhcprd
  statline=$(grep "$indname" "$PRDINDFL")
  hitcnt=$(grep "$indname" "$PRDINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prd="MISSING"; docs_count_prd="N/A"; store_size_prd="N/A"
  else
      health_prd=$(echo $statline|awk '{print $1}')
      docs_count_prd=$(echo $statline|awk '{print $7}')
      store_size_prd=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcpr2
  statline=$(grep "$indname" "$PRFINDFL")
  hitcnt=$(grep "$indname" "$PRFINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prf="MISSING"; docs_count_prf="N/A"; store_size_prf="N/A"
  else
      health_prf=$(echo $statline|awk '{print $1}')
      docs_count_prf=$(echo $statline|awk '{print $7}')
      store_size_prf=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcdm2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_dm2="MISSING"; docs_count_dm2="N/A"; store_size_dm2="N/A"
  else
      health_dm2=$(echo $statline|awk '{print $1}')
      docs_count_dm2=$(echo $statline|awk '{print $7}')
      store_size_dm2=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcpdv
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pdv="MISSING"; docs_count_pdv="N/A"; store_size_pdv="N/A"
  else
      health_pdv=$(echo $statline|awk '{print $1}')
      docs_count_pdv=$(echo $statline|awk '{print $7}')
      store_size_pdv=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcpst
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pst="MISSING"; docs_count_pst="N/A"; store_size_pst="N/A"
  else
      health_pst=$(echo $statline|awk '{print $1}')
      docs_count_pst=$(echo $statline|awk '{print $7}')
      store_size_pst=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyhcug2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_ug2="MISSING"; docs_count_ug2="N/A"; store_size_ug2="N/A"
  else
      health_ug2=$(echo $statline|awk '{print $1}')
      docs_count_ug2=$(echo $statline|awk '{print $7}')
      store_size_ug2=$(echo $statline|awk '{print $9}')
  fi

  seq=$((seq + 1))
  SRCHIND=$(echo $inpind|tr '[a-z]' '[A-Z'])
   
  add_ind_stat_line

done

add_html_close_table

}


# Parse FS Status
parse_and_add_FS_stats () 
{

seq=0
# For each index in the input
# Search PRD, PRF, NP stat output files
# If the index stat is found, parse to extract the fields
# Otherwise, initialize to N/A

for inpind in $FSIND
do
  indname="${inpind}"_cnyfsprd
  statline=$(grep "$indname" "$PRDINDFL")
  hitcnt=$(grep "$indname" "$PRDINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prd="MISSING"; docs_count_prd="N/A"; store_size_prd="N/A"
  else
      health_prd=$(echo $statline|awk '{print $1}')
      docs_count_prd=$(echo $statline|awk '{print $7}')
      store_size_prd=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfspr2
  statline=$(grep "$indname" "$PRFINDFL")
  hitcnt=$(grep "$indname" "$PRFINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prf="MISSING"; docs_count_prf="N/A"; store_size_prf="N/A"
  else
      health_prf=$(echo $statline|awk '{print $1}')
      docs_count_prf=$(echo $statline|awk '{print $7}')
      store_size_prf=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfsdm2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_dm2="MISSING"; docs_count_dm2="N/A"; store_size_dm2="N/A"
  else
      health_dm2=$(echo $statline|awk '{print $1}')
      docs_count_dm2=$(echo $statline|awk '{print $7}')
      store_size_dm2=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfspdv
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pdv="MISSING"; docs_count_pdv="N/A"; store_size_pdv="N/A"
  else
      health_pdv=$(echo $statline|awk '{print $1}')
      docs_count_pdv=$(echo $statline|awk '{print $7}')
      store_size_pdv=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfspst
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pst="MISSING"; docs_count_pst="N/A"; store_size_pst="N/A"
  else
      health_pst=$(echo $statline|awk '{print $1}')
      docs_count_pst=$(echo $statline|awk '{print $7}')
      store_size_pst=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyfsug2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_ug2="MISSING"; docs_count_ug2="N/A"; store_size_ug2="N/A"
  else
      health_ug2=$(echo $statline|awk '{print $1}')
      docs_count_ug2=$(echo $statline|awk '{print $7}')
      store_size_ug2=$(echo $statline|awk '{print $9}')
  fi

  seq=$((seq + 1))
  SRCHIND=$(echo $inpind|tr '[a-z]' '[A-Z'])
   
  add_ind_stat_line

done

add_html_close_table

}


# Parse IH Status
parse_and_add_IH_stats () 
{

seq=0
# For each index in the input
# Search PRD, PRF, NP stat output files
# If the index stat is found, parse to extract the fields
# Otherwise, initialize to N/A

for inpind in $IHIND
do
  indname="${inpind}"_cnyihprd
  statline=$(grep "$indname" "$PRDINDFL")
  hitcnt=$(grep "$indname" "$PRDINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prd="MISSING"; docs_count_prd="N/A"; store_size_prd="N/A"
  else
      health_prd=$(echo $statline|awk '{print $1}')
      docs_count_prd=$(echo $statline|awk '{print $7}')
      store_size_prd=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihpr2
  statline=$(grep "$indname" "$PRFINDFL")
  hitcnt=$(grep "$indname" "$PRFINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_prf="MISSING"; docs_count_prf="N/A"; store_size_prf="N/A"
  else
      health_prf=$(echo $statline|awk '{print $1}')
      docs_count_prf=$(echo $statline|awk '{print $7}')
      store_size_prf=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihdm2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_dm2="MISSING"; docs_count_dm2="N/A"; store_size_dm2="N/A"
  else
      health_dm2=$(echo $statline|awk '{print $1}')
      docs_count_dm2=$(echo $statline|awk '{print $7}')
      store_size_dm2=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihpdv
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pdv="MISSING"; docs_count_pdv="N/A"; store_size_pdv="N/A"
  else
      health_pdv=$(echo $statline|awk '{print $1}')
      docs_count_pdv=$(echo $statline|awk '{print $7}')
      store_size_pdv=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihpst
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_pst="MISSING"; docs_count_pst="N/A"; store_size_pst="N/A"
  else
      health_pst=$(echo $statline|awk '{print $1}')
      docs_count_pst=$(echo $statline|awk '{print $7}')
      store_size_pst=$(echo $statline|awk '{print $9}')
  fi

  indname="${inpind}"_cnyihug2
  statline=$(grep "$indname" "$NPINDFL")
  hitcnt=$(grep "$indname" "$NPINDFL"|wc -l)
  if [[ "$hitcnt" -eq 0 ]] ; then 
      health_ug2="MISSING"; docs_count_ug2="N/A"; store_size_ug2="N/A"
  else
      health_ug2=$(echo $statline|awk '{print $1}')
      docs_count_ug2=$(echo $statline|awk '{print $7}')
      store_size_ug2=$(echo $statline|awk '{print $9}')
  fi

  seq=$((seq + 1))
  SRCHIND=$(echo $inpind|tr '[a-z]' '[A-Z'])
   
  add_ind_stat_line

done

add_html_close_table

}

progressbar ()
{
  while true
  do
    echo -n "........"
    sleep 1
  done
}


# Main

progressbar &
childpid=$!
# Disown the childpid so that 'killed' info message will be suppressed
disown

statdttm=$(date)

# Constants
prdhost=cnypres101; prdauth="b3NhZG1pbjpQbEdDRHdIYmhaSFRtb3k5ampjQTFjTUI="; prdautherr=N
prfhost=cnypfes301; prfauth="b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE="; prfautherr=N
nphost=es92npwl051;  npauth="b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE=";  npautherr=N
cmdopt="curl -s -XGET"; endpath="/_cat/indices"; port=8080

# temp files
PRDINDFL=/tmp/prdindfl.$$.tmp; rm -f $PRDINDFL
PRFINDFL=/tmp/prfindfl.$$.tmp; rm -f $PRFINDFL
NPINDFL=/tmp/npindfl.$$.tmp; rm -f $NPINDFL

HTMLFL=/tmp/srchstats.$$.html.txt;rm -f HTMLFL

# Initialize 
init_ind
init_env

gather_stats

# Abort if any connectivity issues to OS clusters
[[ "$prdautherr" == "Y" ]] && echo "ERROR connecting to PROD OS Cluster. Aborting..." && cat "$PRDINDFL"
[[ "$prfautherr" == "Y" ]] && echo "ERROR connecting to PERF OS Cluster. Aborting..." && cat "$PRFINDFL"
[[ "$npautherr" == "Y" ]] && echo "ERROR connecting to NP OS Cluster. Aborting..." && cat "$NPINDFL"
[[ "$prdautherr" == "Y" || "$prfautherr" == "Y" || "$npautherr" == "Y" ]] && echo "Exited" && exit

# html file
add_html_doctype

# Parse stats for CS Indicies 
ENV=CS
pillarcolor="#4f3222"; pillarclass="cstable"
add_pillar_table
parse_and_add_CS_stats

# Parse stats for HC Indicies 
ENV=HC
pillarcolor="#405d27"; pillarclass="hctable"
add_pillar_table
parse_and_add_HC_stats

# Parse stats for FS Indicies 
ENV=FS
pillarcolor="#034f84"; pillarclass="fstable"
add_pillar_table
parse_and_add_FS_stats

# Parse stats for IH Indicies 
ENV=IH
pillarcolor="#454140"; pillarclass="ihtable"
add_pillar_table
parse_and_add_IH_stats

add_html_doc_end

rm -f search.html
cp -p $HTMLFL search.html
scp search.html ih92npwl050:/var/www/html/psa/search.html

kill -9 $childpid > /dev/null 2>&1
echo "End: $(date) "
