#!/bin/bash

add_html_doctype ()
{
cat > $HTMLFILE <<!EOF
<html><head><meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>NP Search Index stats</title></head><body><br><h2>NP Search Index stats</h2><br>
!EOF

}

add_pillar_hdr ()
{
# $ENV has the uppercase pillar name
cat >> $HTMLFILE <<!EOF
<h2>NP $ENV Search Index stats</h2>
<table width="90%" cellspacing="2" cellpadding="2" border="1">
<tbody><tr><td width="8%" valign="top">Seq<br></td>
<td width="32%" valign="top">SEARCH INDEX<br></td>
<td width="15%" valign="top">${ENV}DM2<br></td>
<td width="15%" valign="top">${ENV}PDV<br></td>
<td width="15%" valign="top">${ENV}PST<br></td>
<td width="15%" valign="top">${ENV}UG2<br></td></tr>
!EOF

}

add_ind_stat_line ()
{
# 
cat >> $HTMLFILE <<!EOF
<tr><td valign="top">$seq<br></td><td valign="top">$indname<br></td>
<td valign="top">$health_dm2<br>$docs_count_dm2<br>$store_size_dm2<br></td>
<td valign="top">$health_pdv<br>$docs_count_pdv<br>$store_size_pdv<br></td>
<td valign="top">$health_pst<br>$docs_count_pst<br>$store_size_pst<br></td>
<td valign="top">$health_ug2<br>$docs_count_ug2<br>$store_size_ug2<br></td></tr>

!EOF

}

HTMLFILE=/tmp/srchstats.$$.html.txt;rm -f HTMLFILE
