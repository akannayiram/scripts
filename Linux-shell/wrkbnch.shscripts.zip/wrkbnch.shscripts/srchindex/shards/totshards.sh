#!/bin/bash
# To get total shards in the cluster

# Constants

prdhost=cnypres101; prdauth="b3NhZG1pbjpTVFVzM2dUSEwwbTFiTkNiaWNGb0hyd1Q="; prdautherr=N
prfhost=cnypfes301; prfauth="b3NhZG1pbjpMVnNUcXJkV2taVTVVRVRqeHpQdHVWR3o="; prfautherr=N
nphost=es92npwl051;  npauth="b3NhZG1pbjpMVnNUcXJkV2taVTVVRVRqeHpQdHVWR3o=";  npautherr=N
#
#cmdopt="curl -s -XGET"; endpath="_cat/indices"; port=8080


#prod
#prdurl=""${cmdopt}" -H \"Authorization: Basic "${prdauth}"\" http://"${prdhost}":"${port}"/"${endpath}""

#perf
#prfurl=""${cmdopt}" -H \"Authorization: Basic "${prfauth}"\" http://"${prfhost}":"${port}"/"${endpath}""

#NP
#npurl=""${cmdopt}" -H \"Authorization: Basic "${npauth}"\" http://"${nphost}":"${port}"/"${endpath}""

# use eval to execute the command in a variable
#   eval: eval [arg ...]    # Execute arguments as a shell command.

# temp files
#PRDINDFL=/tmp/prdindfl.$$.tmp; rm -f $PRDINDFL
#PRFINDFL=/tmp/prfindfl.$$.tmp; rm -f $PRFINDFL
#NPINDFL=/tmp/npindfl.$$.tmp; rm -f $NPINDFL

#eval "$prdurl" |grep -v orcl_es_acl|grep -v ".tasks" > $PRDINDFL
#eval "$prfurl" |grep -v orcl_es_acl|grep -v ".tasks" > $PRFINDFL
#eval "$npurl" |grep -v orcl_es_acl|grep -v ".tasks" > $NPINDFL

#prdcnt=$(cat "$PRDINDFL"|wc -l)
#prfcnt=$(cat "$PRFINDFL"|wc -l)
#npcnt=$(cat "$NPINDFL"|wc -l)
# ################################################################
##################################################################

#prod
prdurl=""${cmdopt}" -H \"Authorization: Basic "${prdauth}"\" http://"${prdhost}":"${port}"/"${endpath}""

#perf
prfurl=""${cmdopt}" -H \"Authorization: Basic "${prfauth}"\" http://"${prfhost}":"${port}"/"${endpath}""

#NP
npurl=""${cmdopt}" -H \"Authorization: Basic "${npauth}"\" http://"${nphost}":"${port}"/"${endpath}""

# use eval to execute the command in a variable
#   eval: eval [arg ...]    # Execute arguments as a shell command.

# temp files
PRDSHARDFL=/tmp/prdshardfl.$$.tmp; rm -f $PRDINDFL
PRFSHARDFL=/tmp/prfshardfl.$$.tmp; rm -f $PRFINDFL
NPSHARDFL=/tmp/npshardfl.$$.tmp; rm -f $NPINDFL

# Option 1

cmdopt="curl -s -XGET"; endpath="_cat/shards"; port=8080
prdurl=""${cmdopt}" -H \"Authorization: Basic "${prdauth}"\" http://"${prdhost}":"${port}"/"${endpath}""
prfurl=""${cmdopt}" -H \"Authorization: Basic "${prfauth}"\" http://"${prfhost}":"${port}"/"${endpath}""
npurl=""${cmdopt}" -H \"Authorization: Basic "${npauth}"\" http://"${nphost}":"${port}"/"${endpath}""

eval "$prdurl"  > $PRDSHARDFL
eval "$prfurl"  > $PRFSHARDFL
eval "$npurl"   > $NPSHARDFL
echo "PROD Shards: $(cat $PRDSHARDFL|wc -l)"
echo "PERF Shards: $(cat $PRFSHARDFL|wc -l)"
echo "NP Shards: $(cat $NPSHARDFL|wc -l)"


# Option 2

cmdopt="curl -s -XGET"; endpath="_stats?level=cluster&filter_path=_shards.total"; port=8080
prdurl=""${cmdopt}" -H \"Authorization: Basic "${prdauth}"\" http://"${prdhost}":"${port}"/"${endpath}""
prfurl=""${cmdopt}" -H \"Authorization: Basic "${prfauth}"\" http://"${prfhost}":"${port}"/"${endpath}""
npurl=""${cmdopt}" -H \"Authorization: Basic "${npauth}"\" http://"${nphost}":"${port}"/"${endpath}""

eval "$prdurl" 
eval "$prfurl"
eval "$npurl"
