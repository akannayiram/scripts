#!/bin/bash
# To get total shards in the cluster

# Constants

prdhost=cnypres101; prdauth="b3NhZG1pbjpTVFVzM2dUSEwwbTFiTkNiaWNGb0hyd1Q="; prdautherr=N
prfhost=cnypfes301; prfauth="b3NhZG1pbjpMVnNUcXJkV2taVTVVRVRqeHpQdHVWR3o="; prfautherr=N
nphost=es92npwl051;  npauth="b3NhZG1pbjpMVnNUcXJkV2taVTVVRVRqeHpQdHVWR3o=";  npautherr=N
#

# use eval to execute the command in a variable
#   eval: eval [arg ...]    # Execute arguments as a shell command.

# temp files
PRDSRCHIDXFILE=/tmp/prdsrchindxfile.$$.tmp; rm -f $PRDINDFL
PRFSRCHIDXFILE=/tmp/prfsrchindxfile.$$.tmp; rm -f $PRFINDFL
NPSRCHIDXFILE=/tmp/npsrchindxfile.$$.tmp; rm -f $NPINDFL

index="hc_hrs_app_index*"

cmdopt="curl -s -XGET"; endpath="_cat/shards/${index}?v"; port=8080
prdurl=""${cmdopt}" -H \"Authorization: Basic "${prdauth}"\" http://"${prdhost}":"${port}"/"${endpath}""
prfurl=""${cmdopt}" -H \"Authorization: Basic "${prfauth}"\" http://"${prfhost}":"${port}"/"${endpath}""
npurl=""${cmdopt}" -H \"Authorization: Basic "${npauth}"\" http://"${nphost}":"${port}"/"${endpath}""

#eval "$prdurl"  > $PRDSRCHIDXFILE
#eval "$prfurl"  > $PRFSRCHIDXFILE
eval "$npurl"   > $NPSRCHIDXFILE
#echo "PROD Shards: $(cat $PRDSRCHIDXFILE|wc -l)"
#echo "PERF Shards: $(cat $PRFSRCHIDXFILE|wc -l)"
#echo "NP Shards: $(cat $NPSRCHIDXFILE|wc -l)"


