#!/bin/bash

#curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE=" http://es92npwl051:8080/_cat/indices
# http://es92npwl051.cf.cuny.edu:8080/ssr_browse_catalog_lff_cnycsug1/_count

#nphost=es92npwl051;  npauth="b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE=";  npautherr=N
#cmdopt="curl -s -XGET"; endpath="_cat/indices"; port=8080

while true
do
echo "============================================"
for i in ssr_browse_catalog_lff_cnycsug1 ssr_browse_catalog_sff_cnycsug1 ssr_class_search_lff_cnycsug1 ssr_class_search_sff_cnycsug1
do 
  echo $i
  curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpZVGlKZG1QZEJiV0lWRGo1aWswQWhBajE=" http://es92npwl051:8080/$i/_count
  echo " "
done
echo "============================================"
date
sleep 15
done



