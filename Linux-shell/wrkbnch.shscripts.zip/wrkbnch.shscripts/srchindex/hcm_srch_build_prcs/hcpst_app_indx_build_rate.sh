#!/bin/bash
# Al Kannayiram, 2/11/2025
# Monitoring rate of search index build in CNYHCPST
# for HC_HRS_APP_INDEX

# Loop 120 times at 10 min intervals for a total of 20 hours
#max=120
max=257
i=1
while [[ i -lt $max ]]
do
  echo $i
date
#curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpMVnNUcXJkV2taVTVVRVRqeHpQdHVWR3o=" http://es92npwl051:8080/_cat/indices?v|grep hc_hrs_app_index_cnyhcpst
curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpMVnNUcXJkV2taVTVVRVRqeHpQdHVWR3o=" http://es92npwl051:8080/_cat/indices/hc_hrs_app_index_cnyhcpst?v
#  i=(( $i + 1 ))
  let i=$i+1
  #sleep 600
  sleep 300
done
