#!/bin/bash
# Al Kannayiram, 2/11/2025
# Monitoring rate of search index build in CNYHCPST
# for HC_HRS_APP_INDEX

# Loop 120 times at 10 min intervals for a total of 20 hours
#max=120
max=513
i=1
while [[ i -lt $max ]]
do
  #echo $i
  [[ "$i" == "1" ]] && echo -e "Seq \t Time \t \t Num docs \t Size"
  dttm=$(date)
  tm=$(date '+%H:%M:%S')
  #curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpMVnNUcXJkV2taVTVVRVRqeHpQdHVWR3o=" http://es92npwl051:8080/_cat/indices?v|grep hc_hrs_app_index_cnyhcpst
  #curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpMVnNUcXJkV2taVTVVRVRqeHpQdHVWR3o=" http://es92npwl051:8080/_cat/indices/hc_hrs_app_index_cnyhcpst?v
  # Extract only Docs and Size
  rslt=$(curl -s -XGET -H "Authorization: Basic b3NhZG1pbjpMVnNUcXJkV2taVTVVRVRqeHpQdHVWR3o=" http://es92npwl051:8080/_cat/indices/hc_hrs_app_index_cnyhcpst?format=JSON|jq '.[] | "\(."docs.count") \(."store.size")"'|sed -e "s/\"//g")

  docs=$(echo $rslt|awk '{print $1}')
  size=$(echo $rslt|awk '{print $2}')
  echo -e "$i \t $tm \t $docs \t\t $size"
  let i=$i+1
  #sleep 600
  sleep 300
done
