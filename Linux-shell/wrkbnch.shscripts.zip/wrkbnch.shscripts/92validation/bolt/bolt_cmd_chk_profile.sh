#bolt command run 'ps -aef|grep BBL|grep -v grep' -t @np_app_servers.txt --no-host-key-check --connect-timeout 60 --tty
app=/home/akannayiram/servers/92np/92np_app_full.txt
psunx=/home/akannayiram/servers/92np/92np_psunx_full.txt
web=/home/akannayiram/servers/92np/92np_web_full.txt
full=/home/akannayiram/servers/92np/92_servers_full.txt

#bolt command run 'ps -aef|grep BBL|grep -v grep' -t @np_psunx_servers.txt --no-host-key-check --connect-timeout 60 --tty
bolt command run 'grep env $HOME/.profile' -t @${app} --no-host-key-check --connect-timeout 30 --tty
#bolt command run 'grep env $HOME/.profile' -t @${psunx} --no-host-key-check --connect-timeout 60 --tty
