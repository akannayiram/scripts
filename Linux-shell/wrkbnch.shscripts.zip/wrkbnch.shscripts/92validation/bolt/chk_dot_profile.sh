grep env $HOME/.profile
