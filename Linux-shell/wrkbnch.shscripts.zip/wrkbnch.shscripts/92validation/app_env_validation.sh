# ##########################################################
#  Validate the new 9.2 App Server environment setup
#   - Al Kannayiram
#
#
# ##########################################################
logmsg ()
{

}


logerror ()
{

}

chk_dot_profile ()
{
  # Ensure that 'env' file is sourced in
  envfile=`grep "^envfile:" $parmfile|cut -d":" -f2`
  CNT=`echo $

}

parmfile=/home/akannayiram/92validation/appenv.param
PROFILE=




