#!/bin/bash
# ======================================================
# Copy ssh public key to target hosts
#  Usage:
#    ./alagu_sshid_copy.sh <hosts_file>
#  Returns exit status of 0 (Success) or 1 (Failure)
# History:
# Who                When       Why and What
# -----------------  ---------- ------------------------
# Al Kannayiram      07/08/2021 Initial creation
#
# ======================================================

#
# functions
myecho()
{
 dttm=`date '+%Y-%m-%d %H:%M:%S'`
 echo "[$dttm]:: $1"
}

# Check if Input Hosts file parameter is passed or not
if [[ $# -eq 0 ]] ; then
    myecho 'ERROR!! Input Hosts file argument is required! Aborting...'
    exit 1
fi
INPFILE=$1

# check if input file exists
if [[ ! -f $INPFILE ]] || [[ ! -r $INPFILE ]] ; then
   myecho "ERROR! Input Hosts file missing or not readable [$INPFILE]"
   exit 1
fi

if [[ ! -f $INPFILE ]] ; then
   myecho "ERROR! Input Hosts file missing [$INPFILE]"
   exit 1
fi
if [[ ! -r $INPFILE ]] ; then
   myecho "ERROR! Input Hosts file not readable [$INPFILE]"
   exit 1
fi


#grep -v "#" $INPFILE |while read -r line
#do

#echo 'yes
#C@ny202!'|ssh-copy-id akannayiram@cssdrap215.cf.cuny.edu
#set -x
#echo "C@ny202!"|sshpass ssh-copy-id -f akannayiram@cssdrap216.cf.cuny.edu
#sshpass -f ./.al ssh-copy-id akannayiram@cssdrap216.cf.cuny.edu
#set +x

