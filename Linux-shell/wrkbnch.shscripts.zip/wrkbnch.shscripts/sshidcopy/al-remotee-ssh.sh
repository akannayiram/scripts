#echo 'yes
#C@ny202!'|ssh-copy-id akannayiram@cssdrap215.cf.cuny.edu
set -x
#echo "C@ny202!"|sshpass ssh-copy-id -f akannayiram@cssdrap216.cf.cuny.edu
#sshpass -f ./.al ssh-copy-id akannayiram@cssdrap216.cf.cuny.edu
#sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@cssprap126.cf.cuny.edu
echo "C@ny202!"|ssh -S -t akannayiram@cssdrux203 'sudo su - oracle; ls -l'
set +x

