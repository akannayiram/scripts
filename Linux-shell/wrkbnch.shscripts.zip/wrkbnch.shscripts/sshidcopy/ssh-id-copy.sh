#ssh-copy-id akannayiram@cnysftpxprd.cunyfirst.cuny.edu
#ssh-copy-id akannayiram@crmnpap002.cf.cuny.edu
#ssh-copy-id akannayiram@crmpfap302.cf.cuny.edu
#ssh-copy-id akannayiram@crmpfap303.cf.cuny.edu
#ssh-copy-id akannayiram@crmprwl105.cf.cuny.edu
#ssh-copy-id akannayiram@cssdrap201.cf.cuny.edu
#ssh-copy-id akannayiram@cssdrap202.cf.cuny.edu
#ssh-copy-id akannayiram@cssdrap210.cf.cuny.edu
#ssh-copy-id akannayiram@cssdrap211.cf.cuny.edu
#ssh-copy-id akannayiram@cssdrap212.cf.cuny.edu
#ssh-copy-id akannayiram@cssdrap213.cf.cuny.edu
#ssh-copy-id akannayiram@cssdrap214.cf.cuny.edu
#ssh-copy-id akannayiram@cssdrap215.cf.cuny.edu
#ssh-copy-id akannayiram@cssdrap216.cf.cuny.edu

#sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@cnyohsprd01

set -x
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssdrap217.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssdrap226.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssdrap227.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssdrap228.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssdrap229.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssdrap230.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssdrap231.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssdrap232.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssdrap233.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssnpap002.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssnpux002.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssprwl109.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@cssprwl110.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@finprwl107.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@finprwl108.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmdrap203.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmdrap204.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmdrap206.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmdrap207.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmdrap208.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmdrux201.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmdrux202.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmpfwl301.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmpfwl302.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmpfwl303.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmpfwl304.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmpfwl305.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmpfwl306.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmprux102.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@hcmprwl108.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtdrap202.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtdrap204.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtpfux302.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtpfwl301.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtpfwl302.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtpfwl303.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtpfwl304.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtprap117.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtprux101.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtprwl101.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtprwl102.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtprwl103.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtprwl104.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtprwl105.cf.cuny.edu
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@prtprwl106.cf.cuny.edu
set +x
