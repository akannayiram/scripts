#
#
# Build a temp file with list of servers
#
#set -x
function build_srvr_file 
{
cat > $TMPFILE <<EOF
finpfap301
finpfap302
finpfap303
finpfap304
finpfux301
finpfux302
hcmpfap301
hcmpfap302
hcmpfap303
hcmpfap304
hcmpfap305
hcmpfap306
hcmpfap307
hcmpfap308
hcmpfux301
hcmpfux302
EOF

}

function build_srvr_file3
{
cat > $TMPFILE <<EOF
csspfwl301
csspfwl302
csspfwl303
csspfwl304
csspfwl305
csspfwl306
csspfwl307
csspfwl308
EOF

}

function build_prf_srvr_file 
{
cat > $TMPFILE <<EOF
csspfap301
csspfap302
csspfap303
csspfap304
csspfap305
csspfap306
csspfap307
csspfap308
csspfap309
csspfap310
csspfap311
csspfap312
csspfap313
csspfap314
csspfap315
csspfap316
csspfap317
csspfap318
csspfap319
csspfap320
csspfap321
csspfap322
csspfap323
csspfap324
csspfap325
csspfap326
csspfap327
csspfap328
csspfap329
csspfap330
csspfap331
csspfap332
csspfap333
csspfap334
csspfap335
csspfap336
csspfap337
csspfap338
csspfap339
csspfux301
csspfux302
csspfux303
EOF
}

function build_prf_ih_srvr_file 
{
cat > $TMPFILE <<EOF
ihpfap301
ihpfap302
ihpfap303
ihpfap304
ihpfap305
ihpfap306
ihpfap307
ihpfap308
ihpfap309
ihpfap310
ihpfap311
ihpfap312
ihpfap313
ihpfap314
ihpfap315
ihpfap316
ihpfap317
ihpfap318
ihpfap319
ihpfap320
ihpfap321
ihpfap322
ihpfap323
ihpfap324
ihpfap325
ihpfap326
ihpfap327
ihpfap328
ihpfap329
ihpfap330
ihpfap331
ihpfap332
ihpfap333
ihpfap334
ihpfap335
ihpfap336
ihpfap337
ihpfap338
ihpfap339
ihpfux301
ihpfux302
ihpfux303
EOF
}
TMPFILE=/tmp/srvr$$.txt

#build_srvr_file
#build_prf_srvr_file 
#build_srvr_file3
build_prf_ih_srvr_file 

#cat $TMPFILE
# Build command in the format and execute
# sshpass -f ./.al ssh-copy-id akannayiram@cssdrap217.cf.cuny.edu
while read -r line
do
 echo "Copy ssh key to $line"
 sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@${line}
done < $TMPFILE

rm -f $TMPFILE
