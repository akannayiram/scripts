# Remove entries in known_hosts since Hostid has changed
ssh-keygen -R finpfap301
ssh-keygen -R finpfap302
ssh-keygen -R finpfap303
ssh-keygen -R finpfap304
ssh-keygen -R finpfux301
ssh-keygen -R finpfux302
ssh-keygen -R hcmpfap301
ssh-keygen -R hcmpfap302
ssh-keygen -R hcmpfap303
ssh-keygen -R hcmpfap304
ssh-keygen -R hcmpfap305
ssh-keygen -R hcmpfap306
ssh-keygen -R hcmpfap307
ssh-keygen -R hcmpfap308
ssh-keygen -R hcmpfux301
ssh-keygen -R hcmpfux302
