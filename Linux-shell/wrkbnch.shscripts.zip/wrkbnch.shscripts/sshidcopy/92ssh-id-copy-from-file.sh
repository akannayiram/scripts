#!/bin/bash
#
# Pass an input file with list of servers
#
#set -x

[[ ! -f $1 ]] && { echo "No input file. Error. Exiting...";exit; }
INPFILE=$1

#cat $INPFILE
# Build command in the format and execute
# sshpass -f ./.al ssh-copy-id akannayiram@cssdrap217.cf.cuny.edu
while read -r line
do
 echo "Copy ssh key to $line"
 sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@${line}
done < $INPFILE

