#
#
# Build a temp file with list of servers
#
#set -x
function build_srvr_file2
{
cat > $TMPFILE <<EOF
cs92npap050
cs92npap051
cs92npux050
cs92npux051
cs92npwl050
cs92npwl051
fs92npux050
fs92npux051
fs92npap050
fs92npap051
fs92npwl051
fs92npwl050
hc92npux050
hc92npux051
hc92npap050
hc92npap051
hc92npwl050
hc92npwl051
ih92npux050
ih92npux051
ih92npap050
ih92npap051
ih92npwl050
ih92npwl051
EOF

}

function build_srvr_file
{
cat > $TMPFILE <<EOF
cs92npap051
cs92npux051
fs92npux051
fs92npap051
hc92npux051
hc92npap051
EOF

}

[[ ! -f $1 ]] && { echo "No input file. Error. Exiting...";exit; }
#TMPFILE=/tmp/srvr$$.txt
TMPFILE=$1

#build_srvr_file
#build_srvr_file2
#cat /home/akannayiram/servers/92np/92_servers_full.txt > $TMPFILE

#cat $TMPFILE
# Build command in the format and execute
# sshpass -f ./.al ssh-copy-id akannayiram@cssdrap217.cf.cuny.edu
while read -r line
do
 echo "Copy sshk key to $line"
 sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@${line}
done < $TMPFILE

#rm -f $TMPFILE
