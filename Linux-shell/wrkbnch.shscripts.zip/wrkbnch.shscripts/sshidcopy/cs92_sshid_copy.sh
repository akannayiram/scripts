#!/bin/bash -x
# Testing the method to enumerate server names 
# by automatically incrementing the number
num=101 
while true 
do 
  srvr=cs92prap${num}
  echo "Copy ssh key to $srvr"
  sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@${srvr}
  num=$(($num + 1))
  [[ $num -ge "140" ]] && break
done
