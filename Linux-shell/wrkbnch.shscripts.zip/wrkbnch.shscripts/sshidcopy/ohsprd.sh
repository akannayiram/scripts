#set -x
#sshpass -f $PWFILE ssh-copy-id -o StrictHostKeyChecking=no
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@cnyohsprd01
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@cnyohsprd02
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@cnyohsprd03
sshpass -f ./.al ssh-copy-id -o StrictHostKeyChecking=no akannayiram@cnyohsprd04
