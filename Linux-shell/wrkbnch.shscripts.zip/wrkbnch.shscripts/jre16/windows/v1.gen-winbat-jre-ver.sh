# input file
inpfile=$1

outfile=$2
rm -f $outfile 
FIRST=Y 
cat $inpfile|while read -r line 
do
  # Strip spaces
  edited=`echo $line|sed -e "s/ //g"`
  # Skip empty lines
  if [[ $edited == "" ]] ; then
     continue
  fi
  # Line containing host name and ending with :
  if [[ $edited =~ ^[a-zA-Z0-9].*edu ]] ; then
     host=$edited
     if [[ $FIRST = "Y" ]] ; then 
         FIRST=N 
     else 
         echo "echo ------" >> $outfile
         echo "echo ------- END HOST: $host --------" >> $outfile
         echo "echo ------" >> $outfile
     fi
     echo "echo ------" >> $outfile
     echo "echo ------- BEGIN HOST: $host --------" >> $outfile
     echo "echo ------" >> $outfile
  else 
     echo "echo ------" >> $outfile
     echo "echo -- Host: $host Directory: ${edited} " >> $outfile
     echo "echo ------" >> $outfile
     echo "\"${edited}\\java\" -version" >> $outfile
  fi 
done 
echo "echo ------" >> $outfile
echo "echo ------- END HOST: $host --------" >> $outfile
echo "echo ------" >> $outfile
echo "echo ------" >> $outfile
echo "echo ------- END OF FILE --------" >> $outfile
echo "echo ------" >> $outfile

