# input file
inpfile=$1

dttm=`date '+%m_%d_%Y_%H_%M_%S'`
FIRST=Y 
#export outfile=""
#export host=""

#
# Pipes create SubShells, so the while read is running on a different shell than your script
# SubShell ends, variables and values are destroyed
# Add shopt -s lastpipe before the while loop.
# using the lastpipe will execute the last command in the pipeline in the foreground.
shopt -s lastpipe
cat $inpfile|while read -r line 
do
  # Strip spaces
  edited=`echo $line|sed -e "s/ //g"`
  # Skip empty lines
  if [[ $edited == "" ]] ; then
     continue
  fi
  # Line containing host name and ending with :
  if [[ $edited =~ ^[a-zA-Z0-9].*edu ]] ; then
     if [[ $FIRST = "Y" ]] ; then 
         FIRST=N 
     else 
         echo "echo ------" >> $outfile
         echo "echo ------- END HOST: $host --------" >> $outfile
         echo "echo ------" >> $outfile
     fi
     host=$edited
     outfile=${host}-jre-ver.${dttm}.bat
     echo "echo ------" >> $outfile
     echo "echo ------- BEGIN HOST: $host --------" >> $outfile
     echo "echo ------" >> $outfile
  else 
     echo "echo ------" >> $outfile
     echo "echo -- Host: $host Directory: ${edited} " >> $outfile
     echo "echo ------" >> $outfile
     echo "\"${edited}\\java\" -version" >> $outfile
  fi 
done 
echo "echo ------" >> "$outfile"
echo "echo ------- END HOST: $host --------" >> "$outfile"
echo "echo ------" >> "$outfile"

