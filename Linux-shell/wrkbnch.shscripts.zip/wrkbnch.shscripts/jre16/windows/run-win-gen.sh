#
# Inputfile contains of list of Linux hosts and the JRE/JDK locations
inpfile=./winservers_jre.txt

#dttm=`date '+%m_%d_%Y_%H_%M_%S'`
#outfile=win-bat-jre-version-exec.${dttm}.txt
#rm -f $outfile
#
# Generate Windows batch java version commands
#
./gen-winbat-jre-ver.sh  $inpfile

