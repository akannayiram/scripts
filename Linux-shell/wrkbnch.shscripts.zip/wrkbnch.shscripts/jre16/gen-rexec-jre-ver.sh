# input file
inpfile=$1

outfile=$2
rm -f $outfile 
FIRST=Y 
cat $inpfile|while read -r line 
do
  # Strip spaces
  edited=`echo $line|sed -e "s/ //g"`
  # Skip empty lines
  if [[ $edited == "" ]] ; then
     continue
  fi
  # Line containing host name and ending with :
  if [[ $edited =~ ^[a-zA-Z0-9].*edu.*\: ]] ; then
     if [[ $FIRST = "Y" ]] ; then 
         FIRST=N 
     else 
         echo "!EOF" >> $outfile
         echo "echo ------" >> $outfile
         echo "echo ------- END HOST: $host --------" >> $outfile
         echo "echo ------" >> $outfile
     fi
     host=`echo $edited|cut -d":" -f1`
     echo "echo ------" >> $outfile
     echo "echo ------- BEGIN HOST: $host --------" >> $outfile
     echo "echo ------" >> $outfile
     echo "ssh $host  /bin/bash <<!EOF" >> $outfile
  else 
     echo "echo ------" >> $outfile
     echo "echo -- Host: $host Directory: ${edited} " >> $outfile
     echo "echo ------" >> $outfile
     echo "${edited} -version" >> $outfile
  fi 
done 
echo "!EOF" >> $outfile         
echo "echo ------" >> $outfile
echo "echo ------- END HOST: $host --------" >> $outfile
echo "echo ------" >> $outfile
echo "echo ------" >> $outfile
echo "echo ------- END OF FILE --------" >> $outfile
echo "echo ------" >> $outfile

