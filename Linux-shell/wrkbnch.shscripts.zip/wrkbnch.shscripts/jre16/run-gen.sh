#
# Inputfile contains of list of Linux hosts and the JRE/JDK locations
inpfile=./linux_jre_dirs.txt

dttm=`date '+%m_%d_%Y_%H_%M_%S'`
execfile=rexec-gen-out.cmds.sh.${dttm}
rm -f $execfile
#
# Generate remote ssh execution of java version commands
#
./gen-rexec-jre-ver.sh  $inpfile $execfile

# Make the output file executable and then execute
chmod +x $execfile
outfile=jre-version-exec-output.${dttm}.txt
rm -f $outfile
./$execfile > $outfile 2>&1

#
# grep all java version 1.6 locations in remote ssh exec output
grepout=jre1.6_loc.${dttm}.txt
grep -B 2 "java version \"1.6" $outfile|egrep "Host|java" > $grepout

