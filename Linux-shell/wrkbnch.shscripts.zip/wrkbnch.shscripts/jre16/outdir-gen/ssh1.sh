ssh cssnpux002.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/cny/cu8/cs900/jre1.6.0/bin/java -version
/appl/psft/cu4/cs900/jre1.6.0/bin/java -version
/appl/psft/fit/cs900/jre1.6.0/bin/java -version
/appl/psft/prt/cs900/jre1.6.0/bin/java -version
/appl/psft/cu5/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/product/19/client/jdk/bin/java -version
/appl/oracle/product/19/client/jdk/jre/bin/java -version
/appl/oracle/product/19/client/OPatch/jre/bin/java -version
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/bin/java -version
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap211.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap226.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmdrap206.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/hc900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmdrap204.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/hc900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmdrap208.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/hc900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmdrux201.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
/appl/psoft/hc900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap217.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmdrux202.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
/appl/psoft/hc900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmpfwl303.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh cssprwl109.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
!EOF
ssh hcmpfwl306.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh prtpfwl304.cf.cuny.edu  /bin/bash <<!EOF
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh prtdrap204.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh prtprwl103.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap228.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap216.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap215.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap233.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssprwl110.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
!EOF
ssh prtprwl104.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmpfwl301.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh cssdrap212.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap213.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap214.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmdrap203.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/hc900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap227.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap202.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh prtpfwl302.cf.cuny.edu  /bin/bash <<!EOF
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh hcmprwl108.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/oem/agent_13.3.0.0.0/oracle_common/jdk/jre/bin/java -version
/oem/agent_13.3.0.0.0/oracle_common/jdk/bin/java -version
!EOF
ssh cssdrap230.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap210.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmdrap207.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/hc900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh prtdrap202.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh prtprwl101.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh prtprwl106.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap232.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap201.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/psoft/splunk/splunk/etc/apps/splunk_archiver/java-bin/jars/vendors/java/OpenJDK8U-jre_x64_linux_hotspot_8u212b03/bin/java -version
/appl/psoft/splunk/splunk/bin/jars/vendors/java/OpenJDK8U-jre_x64_linux_hotspot_8u212b03/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmpfwl302.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh cssdrap229.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh finprwl108.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle_lw/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle_lw/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
!EOF
ssh prtprwl105.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssdrap231.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cs900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh prtpfwl303.cf.cuny.edu  /bin/bash <<!EOF
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh prtprwl102.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmpfwl304.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh finprwl107.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle_lw/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle_lw/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
!EOF
ssh hcmpfwl305.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh prtpfwl301.cf.cuny.edu  /bin/bash <<!EOF
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
ssh crmprwl105.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh crmpfap302.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cm900_old/jre1.7.0/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/product/19/client/jdk/bin/java -version
/appl/oracle/product/19/client/jdk/jre/bin/java -version
/appl/oracle/product/19/client/OPatch/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh prtpfux302.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/product/19/client/jdk/bin/java -version
/appl/oracle/product/19/client/jdk/jre/bin/java -version
/appl/oracle/product/19/client/OPatch/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cssnpap002.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/cu4/cs900/jre1.6.0/bin/java -version
/appl/psft/fit/old_cs900/jre1.6.0/bin/java -version
/appl/psft/cu5/cs900/jre1.6.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/bin/java -version
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh crmpfap303.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cm900_old/jre1.7.0/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/product/19/client/jdk/bin/java -version
/appl/oracle/product/19/client/jdk/jre/bin/java -version
/appl/oracle/product/19/client/OPatch/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh crmnpap002.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/pst/cm900/jre1.7.0/bin/java -version
/appl/psft/pdv/cm900/jre1.7.0/bin/java -version
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/psoft/cm900/jre1.7.0/bin/java -version
/appl/psoft/pt854/jre1.7.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/bin/java -version
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh hcmprux102.cf.cuny.edu  /bin/bash <<!EOF
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh prtprux101.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh prtprap117.cf.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_291/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
ssh cnysftpxprd.cunyfirst.cuny.edu  /bin/bash <<!EOF
/appl/oracle_bak/product/18/client/jdk/bin/java -version
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
/appl/oracle/product/18/client/jdk/bin/java -version
/appl/oracle/product/18/client/jdk/jre/bin/java -version
/appl/oracle/jre/jre1.7.0_221/bin/java -version
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
