echo -------BEGIN HOST: cssnpux002.cf.cuny.edu--------
ssh cssnpux002.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/cny/cu8/cs900/jre1.6.0/bin/java 
/appl/psft/cny/cu8/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/psft/cu4/cs900/jre1.6.0/bin/java 
/appl/psft/cu4/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/psft/fit/cs900/jre1.6.0/bin/java 
/appl/psft/fit/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/psft/prt/cs900/jre1.6.0/bin/java 
/appl/psft/prt/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/psft/cu5/cs900/jre1.6.0/bin/java 
/appl/psft/cu5/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/19/client/jdk/bin/java 
/appl/oracle/product/19/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/19/client/jdk/jre/bin/java 
/appl/oracle/product/19/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/19/client/OPatch/jre/bin/java 
/appl/oracle/product/19/client/OPatch/jre/bin/java -version
echo --DIR: /appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/bin/java 
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/bin/java -version
echo --DIR: /appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/jre/bin/java 
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap211.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap211.cf.cuny.edu--------
ssh cssdrap211.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap226.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap226.cf.cuny.edu--------
ssh cssdrap226.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmdrap206.cf.cuny.edu--------
echo -------BEGIN HOST: hcmdrap206.cf.cuny.edu--------
ssh hcmdrap206.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prd/hc900/jre1.6.0/bin/java 
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/hc900/jre1.6.0/bin/java 
/appl/psoft/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmdrap204.cf.cuny.edu--------
echo -------BEGIN HOST: hcmdrap204.cf.cuny.edu--------
ssh hcmdrap204.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prd/hc900/jre1.6.0/bin/java 
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/hc900/jre1.6.0/bin/java 
/appl/psoft/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmdrap208.cf.cuny.edu--------
echo -------BEGIN HOST: hcmdrap208.cf.cuny.edu--------
ssh hcmdrap208.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/hc900/jre1.6.0/bin/java 
/appl/psoft/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmdrux201.cf.cuny.edu--------
echo -------BEGIN HOST: hcmdrux201.cf.cuny.edu--------
ssh hcmdrux201.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prd/hc900/jre1.6.0/bin/java 
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/psoft/hc900/jre1.6.0/bin/java 
/appl/psoft/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap217.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap217.cf.cuny.edu--------
ssh cssdrap217.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmdrux202.cf.cuny.edu--------
echo -------BEGIN HOST: hcmdrux202.cf.cuny.edu--------
ssh hcmdrux202.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prd/hc900/jre1.6.0/bin/java 
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/psoft/hc900/jre1.6.0/bin/java 
/appl/psoft/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmpfwl303.cf.cuny.edu--------
echo -------BEGIN HOST: hcmpfwl303.cf.cuny.edu--------
ssh hcmpfwl303.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: cssprwl109.cf.cuny.edu--------
echo -------BEGIN HOST: cssprwl109.cf.cuny.edu--------
ssh cssprwl109.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
!EOF
echo -------END HOST: hcmpfwl306.cf.cuny.edu--------
echo -------BEGIN HOST: hcmpfwl306.cf.cuny.edu--------
ssh hcmpfwl306.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: prtpfwl304.cf.cuny.edu--------
echo -------BEGIN HOST: prtpfwl304.cf.cuny.edu--------
ssh prtpfwl304.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: prtdrap204.cf.cuny.edu--------
echo -------BEGIN HOST: prtdrap204.cf.cuny.edu--------
ssh prtdrap204.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: prtprwl103.cf.cuny.edu--------
echo -------BEGIN HOST: prtprwl103.cf.cuny.edu--------
ssh prtprwl103.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap228.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap228.cf.cuny.edu--------
ssh cssdrap228.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap216.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap216.cf.cuny.edu--------
ssh cssdrap216.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap215.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap215.cf.cuny.edu--------
ssh cssdrap215.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap233.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap233.cf.cuny.edu--------
ssh cssdrap233.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssprwl110.cf.cuny.edu--------
echo -------BEGIN HOST: cssprwl110.cf.cuny.edu--------
ssh cssprwl110.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
!EOF
echo -------END HOST: prtprwl104.cf.cuny.edu--------
echo -------BEGIN HOST: prtprwl104.cf.cuny.edu--------
ssh prtprwl104.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmpfwl301.cf.cuny.edu--------
echo -------BEGIN HOST: hcmpfwl301.cf.cuny.edu--------
ssh hcmpfwl301.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap212.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap212.cf.cuny.edu--------
ssh cssdrap212.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap213.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap213.cf.cuny.edu--------
ssh cssdrap213.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap214.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap214.cf.cuny.edu--------
ssh cssdrap214.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmdrap203.cf.cuny.edu--------
echo -------BEGIN HOST: hcmdrap203.cf.cuny.edu--------
ssh hcmdrap203.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prd/hc900/jre1.6.0/bin/java 
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/hc900/jre1.6.0/bin/java 
/appl/psoft/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap227.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap227.cf.cuny.edu--------
ssh cssdrap227.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap202.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap202.cf.cuny.edu--------
ssh cssdrap202.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: prtpfwl302.cf.cuny.edu--------
echo -------BEGIN HOST: prtpfwl302.cf.cuny.edu--------
ssh prtpfwl302.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: hcmprwl108.cf.cuny.edu--------
echo -------BEGIN HOST: hcmprwl108.cf.cuny.edu--------
ssh hcmprwl108.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /oem/agent_13.3.0.0.0/oracle_common/jdk/jre/bin/java 
/oem/agent_13.3.0.0.0/oracle_common/jdk/jre/bin/java -version
echo --DIR: /oem/agent_13.3.0.0.0/oracle_common/jdk/bin/java 
/oem/agent_13.3.0.0.0/oracle_common/jdk/bin/java -version
!EOF
echo -------END HOST: cssdrap230.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap230.cf.cuny.edu--------
ssh cssdrap230.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap210.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap210.cf.cuny.edu--------
ssh cssdrap210.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmdrap207.cf.cuny.edu--------
echo -------BEGIN HOST: hcmdrap207.cf.cuny.edu--------
ssh hcmdrap207.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prd/hc900/jre1.6.0/bin/java 
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/hc900/jre1.6.0/bin/java 
/appl/psoft/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: prtdrap202.cf.cuny.edu--------
echo -------BEGIN HOST: prtdrap202.cf.cuny.edu--------
ssh prtdrap202.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: prtprwl101.cf.cuny.edu--------
echo -------BEGIN HOST: prtprwl101.cf.cuny.edu--------
ssh prtprwl101.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: prtprwl106.cf.cuny.edu--------
echo -------BEGIN HOST: prtprwl106.cf.cuny.edu--------
ssh prtprwl106.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap232.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap232.cf.cuny.edu--------
ssh cssdrap232.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap201.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap201.cf.cuny.edu--------
ssh cssdrap201.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/psoft/splunk/splunk/etc/apps/splunk_archiver/java-bin/jars/vendors/java/OpenJDK8U-jre_x64_linux_hotspot_8u212b03/bin/java 
/appl/psoft/splunk/splunk/etc/apps/splunk_archiver/java-bin/jars/vendors/java/OpenJDK8U-jre_x64_linux_hotspot_8u212b03/bin/java -version
echo --DIR: /appl/psoft/splunk/splunk/bin/jars/vendors/java/OpenJDK8U-jre_x64_linux_hotspot_8u212b03/bin/java 
/appl/psoft/splunk/splunk/bin/jars/vendors/java/OpenJDK8U-jre_x64_linux_hotspot_8u212b03/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmpfwl302.cf.cuny.edu--------
echo -------BEGIN HOST: hcmpfwl302.cf.cuny.edu--------
ssh hcmpfwl302.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap229.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap229.cf.cuny.edu--------
ssh cssdrap229.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: finprwl108.cf.cuny.edu--------
echo -------BEGIN HOST: finprwl108.cf.cuny.edu--------
ssh finprwl108.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle_lw/jdk/jdk1.7.0_231/bin/java 
/appl/oracle_lw/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle_lw/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle_lw/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
!EOF
echo -------END HOST: prtprwl105.cf.cuny.edu--------
echo -------BEGIN HOST: prtprwl105.cf.cuny.edu--------
ssh prtprwl105.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssdrap231.cf.cuny.edu--------
echo -------BEGIN HOST: cssdrap231.cf.cuny.edu--------
ssh cssdrap231.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prod/cs900/jre1.6.0/bin/java 
/appl/psft/prod/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cs900/jre1.6.0/bin/java 
/appl/psoft/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: prtpfwl303.cf.cuny.edu--------
echo -------BEGIN HOST: prtpfwl303.cf.cuny.edu--------
ssh prtpfwl303.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: prtprwl102.cf.cuny.edu--------
echo -------BEGIN HOST: prtprwl102.cf.cuny.edu--------
ssh prtprwl102.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmpfwl304.cf.cuny.edu--------
echo -------BEGIN HOST: hcmpfwl304.cf.cuny.edu--------
ssh hcmpfwl304.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: finprwl107.cf.cuny.edu--------
echo -------BEGIN HOST: finprwl107.cf.cuny.edu--------
ssh finprwl107.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle_lw/jdk/jdk1.7.0_231/bin/java 
/appl/oracle_lw/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle_lw/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle_lw/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
!EOF
echo -------END HOST: hcmpfwl305.cf.cuny.edu--------
echo -------BEGIN HOST: hcmpfwl305.cf.cuny.edu--------
ssh hcmpfwl305.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: prtpfwl301.cf.cuny.edu--------
echo -------BEGIN HOST: prtpfwl301.cf.cuny.edu--------
ssh prtpfwl301.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_291/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_291/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk.b4Patch/jdk1.7.0_231/jre/bin/java -version
!EOF
echo -------END HOST: crmprwl105.cf.cuny.edu--------
echo -------BEGIN HOST: crmprwl105.cf.cuny.edu--------
ssh crmprwl105.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/bin/java -version
echo --DIR: /appl/oracle/jdk/jdk1.7.0_231/jre/bin/java 
/appl/oracle/jdk/jdk1.7.0_231/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: crmpfap302.cf.cuny.edu--------
echo -------BEGIN HOST: crmpfap302.cf.cuny.edu--------
ssh crmpfap302.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cm900_old/jre1.7.0/bin/java 
/appl/psoft/cm900_old/jre1.7.0/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/19/client/jdk/bin/java 
/appl/oracle/product/19/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/19/client/jdk/jre/bin/java 
/appl/oracle/product/19/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/19/client/OPatch/jre/bin/java 
/appl/oracle/product/19/client/OPatch/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: prtpfux302.cf.cuny.edu--------
echo -------BEGIN HOST: prtpfux302.cf.cuny.edu--------
ssh prtpfux302.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/19/client/jdk/bin/java 
/appl/oracle/product/19/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/19/client/jdk/jre/bin/java 
/appl/oracle/product/19/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/19/client/OPatch/jre/bin/java 
/appl/oracle/product/19/client/OPatch/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cssnpap002.cf.cuny.edu--------
echo -------BEGIN HOST: cssnpap002.cf.cuny.edu--------
ssh cssnpap002.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/cu4/cs900/jre1.6.0/bin/java 
/appl/psft/cu4/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/psft/fit/old_cs900/jre1.6.0/bin/java 
/appl/psft/fit/old_cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/psft/cu5/cs900/jre1.6.0/bin/java 
/appl/psft/cu5/cs900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/bin/java 
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/bin/java -version
echo --DIR: /appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/jre/bin/java 
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: crmpfap303.cf.cuny.edu--------
echo -------BEGIN HOST: crmpfap303.cf.cuny.edu--------
ssh crmpfap303.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cm900_old/jre1.7.0/bin/java 
/appl/psoft/cm900_old/jre1.7.0/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/19/client/jdk/bin/java 
/appl/oracle/product/19/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/19/client/jdk/jre/bin/java 
/appl/oracle/product/19/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/19/client/OPatch/jre/bin/java 
/appl/oracle/product/19/client/OPatch/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java 
/appl/oracle/jre.b4Patch/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: crmnpap002.cf.cuny.edu--------
echo -------BEGIN HOST: crmnpap002.cf.cuny.edu--------
ssh crmnpap002.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/pst/cm900/jre1.7.0/bin/java 
/appl/psft/pst/cm900/jre1.7.0/bin/java -version
echo --DIR: /appl/psft/pdv/cm900/jre1.7.0/bin/java 
/appl/psft/pdv/cm900/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/psoft/cm900/jre1.7.0/bin/java 
/appl/psoft/cm900/jre1.7.0/bin/java -version
echo --DIR: /appl/psoft/pt854/jre1.7.0/bin/java 
/appl/psoft/pt854/jre1.7.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/bin/java 
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/bin/java -version
echo --DIR: /appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/jre/bin/java 
/appl/oracle/product/agent13c/agent_13.5.0.0.0/oracle_common/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo.b4Patch/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: hcmprux102.cf.cuny.edu--------
echo -------BEGIN HOST: hcmprux102.cf.cuny.edu--------
ssh hcmprux102.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/psft/prd/hc900/jre1.6.0/bin/java 
/appl/psft/prd/hc900/jre1.6.0/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: prtprux101.cf.cuny.edu--------
echo -------BEGIN HOST: prtprux101.cf.cuny.edu--------
ssh prtprux101.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: prtprap117.cf.cuny.edu--------
echo -------BEGIN HOST: prtprap117.cf.cuny.edu--------
ssh prtprap117.cf.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_291/bin/java 
/appl/oracle/jre/jre1.7.0_291/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: cnysftpxprd.cunyfirst.cuny.edu--------
echo -------BEGIN HOST: cnysftpxprd.cunyfirst.cuny.edu--------
ssh cnysftpxprd.cunyfirst.cuny.edu  /bin/bash <<!EOF
echo --DIR: /appl/oracle_bak/product/18/client/jdk/bin/java 
/appl/oracle_bak/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle_bak/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle_bak/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle_bak/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle_bak/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/bin/java 
/appl/oracle/product/18/client/jdk/bin/java -version
echo --DIR: /appl/oracle/product/18/client/jdk/jre/bin/java 
/appl/oracle/product/18/client/jdk/jre/bin/java -version
echo --DIR: /appl/oracle/jre/jre1.7.0_221/bin/java 
/appl/oracle/jre/jre1.7.0_221/bin/java -version
echo --DIR: /appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java 
/appl/oracle/oracle_client_software/client/stage/bootstrap/jre/bin/java -version
echo --DIR: /appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java 
/appl/oracle/tuxedo/tuxedo12.1.1.0/jre/bin/java -version
!EOF
echo -------END HOST: --------
