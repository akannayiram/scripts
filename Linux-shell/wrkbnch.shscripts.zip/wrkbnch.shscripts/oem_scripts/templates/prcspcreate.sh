echo "<?xml version = '1.0' encoding = 'UTF-8'?>
<transaction-template template_type=\"generic_service\" xmlns=\"template\">
   <variables/>
   <transactions>
      <mgmt_bcn_transaction>
         <mgmt_bcn_txn_with_props>
            <mgmt_bcn_txn is_representative=\"true\" name=\"`echo $1` Processes In Not Posted Status\" monitoring=\"true\" txn_type=\"OS\"/>
            <properties>
               <property name=\"Command\" string_value=\"/rac/backup01/oemscripts/prcspstchk.sh `echo $1`\" prop_type=\"1\" encrypt=\"false\"/>
               <property name=\"Timeout\" num_value=\"60.0\" prop_type=\"2\" encrypt=\"false\"/>
               <property name=\"Collection Interval\" num_value=\"5.0\" prop_type=\"2\" encrypt=\"false\"/>
               <property name=\"RetryInterval\" num_value=\"1.0\" prop_type=\"2\" encrypt=\"false\"/>
               <property name=\"isSecureCommand\" string_value=\"TRUE\" prop_type=\"1\" encrypt=\"false\"/>
               <property name=\"numretries\" num_value=\"0.0\" prop_type=\"2\" encrypt=\"false\"/>
            </properties>
            <per_bcn_properties/>
         </mgmt_bcn_txn_with_props>
         <steps_defn_with_props/>
         <stepgroups_defn/>
         <txn_thresholds>
            <mgmt_bcn_threshold warning_threshold=\"0.0\" warning_operator=\"1\" critical_threshold=\"0.0\" critical_operator=\"1\" num_occurrences=\"1\">
               <mgmt_bcn_threshold_key metric_name=\"os_response\" metric_column=\"status\"/>
            </mgmt_bcn_threshold>
            <mgmt_bcn_threshold warning_threshold=\"10000.0\" warning_operator=\"0\" critical_threshold=\"30000.0\" critical_operator=\"0\" num_occurrences=\"1\">
               <mgmt_bcn_threshold_key metric_name=\"os_response\" metric_column=\"total_time\"/>
            </mgmt_bcn_threshold>
         </txn_thresholds>
         <step_thresholds/>
         <stepgroup_thresholds/>
      </mgmt_bcn_transaction>
   </transactions>
</transaction-template>" > prcsintcheck.xml


echo "emcli create_service -name='`echo $1` Processes In Not Posted Status' -type='generic_service' -availType='test' -availOp='or' -input_file=template:prcsintcheck.xml -beacons='`echo $2`:Y'" > em.sh
sh em.sh
rm em.sh
