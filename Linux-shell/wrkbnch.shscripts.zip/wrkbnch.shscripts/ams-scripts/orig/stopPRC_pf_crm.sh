# CRM Batch
bolt script run psa.sh -t crmpfux301,crmpfux302 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 stop prcs CNYCMPR1
