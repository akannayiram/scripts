#PERF WEB
bolt script run psa.sh -t csspfwl301,csspfwl302,csspfwl303,csspfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854csa stop web

bolt script run psa.sh -t csspfwl301,csspfwl302,csspfwl303,csspfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854csb stop web

bolt script run psa.sh -t csspfwl301,csspfwl302,csspfwl303,csspfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854csc stop web

bolt script run psa.sh -t csspfwl301,csspfwl302,csspfwl303,csspfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854csd stop web

bolt script run psa.sh -t csspfwl305,csspfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854csi stop web  

bolt script run psa.sh -t csspfwl307,csspfwl308 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854csy stop web
