#PERF APP
bolt script run psa.sh -t CRMPFAP301,CRMPFAP302 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 start app CNYCMPR1
bolt script run psa.sh -t CRMPFAP303 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 start app CNYCMAM1
bolt script run psa.sh -t CRMPFAP304 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 start app CNYCMCM1

