#PEF CSS
bolt script run psa.sh -t @pf-cs-as-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start app CNYCSPR1
#OIM

bolt script run psa.sh -t csspfap333 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start app CNYCSIM1
#Messaging
bolt script run psa.sh -t csspfap334 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start app CNYCSAM1

bolt script run psa.sh -t csspfap335 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start app CNYCSSL1

bolt script run psa.sh -t csspfap336 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start app CNYCSSL2

bolt script run psa.sh -t csspfap337 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start app CNYCSSL3

bolt script run psa.sh -t csspfap338,csspfap339 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start app CNYCSCM1

bolt script run psa.sh -t csspfap338,csspfap339 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start app CNYCSRR1
