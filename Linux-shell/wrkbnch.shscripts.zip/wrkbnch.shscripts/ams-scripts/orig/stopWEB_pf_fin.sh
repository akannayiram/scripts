#Performance Web
bolt script run psa.sh -t finpfwl301,finpfwl302 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854fsa stop web  

bolt script run psa.sh -t finpfwl303,finpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854fsi stop web  

bolt script run psa.sh -t finpfwl305,finpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854fsz stop web  

bolt script run psa.sh -t finpfwl305,finpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854fsy stop web  
