#Portal BATCH
bolt script run psa.sh -t @pf-epp-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnyepprd stop prcs all
