#!/bin/bash
#--------------------------------------------#
# psa.sh                                     #
# CUNY-AMS                                   #
# March 2021                                 #
# 1.0										 #	
#--------------------------------------------#
#############################################################################################################################
# Modification History:
#
#    Date         PSA                              Description
# ---------------------------------------------------------------------------------------------------------------------------
#
# 22-March-2021  dfreeman	  Added action 'console-pwd' => routine to roll-out new pwds for the WLS console
# 23-March-2021  dfreeman	  Added action 'tux-patch' => routine to roll-out patched tuxedo accross appServers and PRCS
# 31-March-2021  dfreeman     Added to the conditional tree setting the correct ps_cfg_home for the reporting instances
# 13-April-2021  dfreeman     Added to the conditional tree setting the correct ps_cfg_home for the non-production instances
#
##############################################################################################################################
# set tabstop=8 softtabstop=0 expandtab shiftwidth=4 smarttab
##########################
# Actions
##########################
    
function action_app
{
    if [ $domparam = "all" ] ; then
        list=("${app_doms[@]}")
    else
        list=($domparam)
    fi
    
    for dom in "${list[@]}"
    do
        act_type=app
        print_action_info
        case $act in

        status)
            exec_cmd "psadmin -c sstatus -d $dom" 2>&1
            exec_cmd "psadmin -c cstatus -d $dom" 2>&1
            exec_cmd "psadmin -c qstatus -d $dom" 2>&1
            exec_cmd "psadmin -c pslist -d $dom" 2>&1
        ;;

        start)
            exec_cmd "psadmin -c boot -d $dom" 2>&1
        ;;

        stop)
            exec_cmd "psadmin -c shutdown -d $dom" 2>&1
        ;;

        kill)
            exec_cmd "psadmin -c shutdown! -d $dom" 2>&1
        ;;

	preload)
           exec_cmd "psadmin -c preload -d $dom" 2>&1
        
	;;

	configure)
            exec_cmd "psadmin -c configure -d $dom" 2>&1
        ;;

        purge)    
            exec_cmd "psadmin -c purge -d $dom" 2>&1
            echo "$domain cache purged."
        ;;

        flush)
            exec_cmd "psadmin -c cleanipc -d $dom" 2>&1
        ;;

        restart)
            exec_cmd "psadmin -c shutdown -d $dom" 2>&1
            exec_cmd "psadmin -c boot -d $dom" 2>&1
        ;;

        bounce)
            exec_cmd "psadmin -c shutdown -d $dom" 2>&1
            exec_cmd "psadmin -c cleanipc -d $dom" 2>&1
            exec_cmd "psadmin -c purge -d $dom" 2>&1
            exec_cmd "psadmin -c configure -d $dom" 2>&1
            exec_cmd "psadmin -c boot -d $dom" 2>&1
        ;;
		
		senderSMTP)
		    exec_cmd "sed -i 's/SMTPSender=DO-NOT-REPLY@CUNYFIRST.CUNY.EDU/SMTPSender=cunyfirst-do-not-reply@cuny.edu/g' \${PS_CFG_HOME?}/appserv/$dom/psappsrv.cfg"
			           
        ;;

        esac
    done    
    echo ""
}

function action_prcs
{
    if [ $domparam = "all" ] ; then
        list=("${prcs_doms[@]}")
    else
        list=($domparam)
    fi
    for dom in "${list[@]}"
    do
        act_type=prcs
        print_action_info
        case $act in
        status)
            exec_cmd "psadmin -p sstatus -d $dom" 2>&1
        ;;

        start)
            exec_cmd "psadmin -p start -d $dom" 2>&1
        ;;

        stop)
            exec_cmd "psadmin -p stop -d $dom" 2>&1
        ;;

	kill)
            exec_cmd "psadmin -p kill -d $dom" 2>&1
        ;;

        configure)
            exec_cmd "psadmin -p configure -d $dom" 2>&1
        ;;

        flush)
            exec_cmd "psadmin -p cleanipc -d $dom" 2>&1
        ;;

        restart)
            exec_cmd "psadmin -p stop -d $dom" 2>&1
            exec_cmd "psadmin -p start -d $dom" 2>&1
        ;;

        bounce)
            exec_cmd "psadmin -p stop -d $dom" 2>&1
            exec_cmd "psadmin -p cleanipc -d $dom" 2>&1
            exec_cmd "psadmin -p configure -d $dom" 2>&1
            exec_cmd "psadmin -p start -d $dom" 2>&1
        ;;
		
		senderSMTP)
		    exec_cmd "sed -i 's/SMTPSender=DO-NOT-REPLY@CUNYFIRST.CUNY.EDU/SMTPSender=cunyfirst-do-not-reply@cuny.edu/g' \${PS_CFG_HOME?}/appserv/prcs/$dom/psprcs.cfg"
			           
        ;;
        
        esac
    done
}

function action_web
{	
    if [ $domparam = "all" ] ; then
        list=("${web_doms[@]}")
    else
        list=($domparam)
    fi
    
    for dom in "${list[@]}"
    do
        act_type=web
        print_action_info
        case $act in
            status)
                echo "Webserver status $dom"
                #exec_cmd "psadmin -w status -d $dom"
                exec_cmd "ps -ef|grep -i ${PS_RUNTIME_USER}" 2>&1
            ;;
            start)
                echo "Starting webserver"
                exec_cmd "\${PS_CFG_HOME?}/webserv/$dom/bin/startPIA.sh"
                #exec_cmd "psadmin -w start -d $dom"
            ;;
            stop)
                echo "Stopping webserver"
                exec_cmd "\${PS_CFG_HOME?}/webserv/$dom/bin/stopPIA.sh"
            ;;
            purge)
                echo "Purging webserver cache"
                exec_cmd "rm -rf \${PS_CFG_HOME?}/webserv/$dom/applications/peoplesoft/PORTAL*/*/cache*/"
            ;;
            restart)
                echo "Stopping webserver"
                exec_cmd "\${PS_CFG_HOME?}/webserv/$dom/bin/stopPIA.sh"
                echo "Starting webserver"
                exec_cmd "\${PS_CFG_HOME?}/webserv/$dom/bin/startPIA.sh"
                #exec_cmd "psadmin -w start -d $dom"
            ;;
            bounce)
                echo "Stopping webserver"
                exec_cmd "\${PS_CFG_HOME?}/webserv/$dom/bin/stopPIA.sh"
                echo "Purging webserver cache"
	        exec_cmd "rm -rf \${PS_CFG_HOME?}/webserv/$dom/applications/peoplesoft/PORTAL*/*/cache*/"
                echo "Starting webserver"
                exec_cmd "\${PS_CFG_HOME?}/webserv/$dom/bin/startPIA.sh"
                #exec_cmd "psadmin -w start -d $dom"
            ;;
            console-pwd)
			    echo "Stopping PIA.........."
    			exec_cmd "\${PS_CFG_HOME?}/webserv/$dom/bin/stopPIA.sh"
				exec_cmd "sleep 5"
				echo "Is PIA down?.........."
				exec_cmd "ps -ef|grep -i ${PS_RUNTIME_USER}" 2>&1
				echo "Backup ladap files.........."
				exec_cmd "cp -R \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/data/ldap/ldapfiles \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/data/ldap/ldapfiles.orig"
				echo "Remove ldapfiles dir........."
				exec_cmd "rm -rf \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/data/ldap/ldapfiles"
				echo "copy new ldap file tar ball..........."
				exec_cmd "cp -f /psft/console-pwd/ldapfiles.tar.gz \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/data/ldap"
				exec_cmd "ls -ltr \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/data/ldap"
				echo "Backup boot.properties file.........."
				exec_cmd "mv -f \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/security/boot.properties \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/security/boot.properties.orig"
				echo "copy new boot.properties file.........."
				exec_cmd "cp -f /psft/console-pwd/boot.properties \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/security"
				exec_cmd "ls -ltr \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/security"
				echo "untar new ldap files.........."
				exec_cmd "tar xvfz \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/data/ldap/ldapfiles.tar.gz --directory \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/data/ldap"
				echo "remove tarball.........."
				exec_cmd "rm -rf \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/data/ldap/ldapfiles.tar.gz"
				exec_cmd "ls -ltr \${PS_CFG_HOME?}/webserv/$dom/servers/PIA/data/ldap"
				echo "Starting PIA.........."
				exec_cmd "\${PS_CFG_HOME?}/webserv/$dom/bin/startPIA.sh"
				exec_cmd "sleep 5"
				echo "Is PIA up?.........."
				exec_cmd "ps -ef|grep -i ${PS_RUNTIME_USER}" 2>&1
            ;;
            
			esac
    done
}

function print_action_info
{
    echo ""	
    echo "$(echo_color "+------------------------------------------------------------------------------------------------+" "brown")"	
    echo "  $(echo_color "Action:" "brown") $(echo_color "$act" "lred") | $(echo_color "Type:" "brown") $(echo_color "$act_type" "lred") | $(echo_color "Domain:" "brown") $(echo_color "$dom" "lred") | $(echo_color "Node:" "brown") $(echo_color "$host" "lred") | $(echo_color "User:" "brown") $(echo_color "$PS_RUNTIME_USER" "lred")"			
    echo "$(echo_color "+------------------------------------------------------------------------------------------------+" "brown")"	
    echo ""
}

###########################
### Menus   
###########################

function print_header
{
    clear
    echo "+-------------------------------------------------+" 
    echo "| $(echo_color $title "lblue")   host: $(echo_color $host "lgreen") "	
    echo "+-------------------------------------------------+"
}

function print_help
{
    echo " "
    echo "Usage: psa.sh <user> <action> <type> domain"
    echo " "
	echo "User: SA UID"
	echo " "
    echo "Actions:"
    echo "        "
    echo "    help           display this help message"
    echo "    list           list domains"
    echo "    status         status of the domain"
    echo "    start          start the domain"
    echo "    stop           stop the domain"
    echo "    preload  	     Preload Cache project for File/DB and in-memory Cache"
    echo "    restart        stop and start the domain"
    echo "    purge          clear domain cache"
    echo "    bounce         stop, flush, purge, configure and start the domain"
    echo "    kill           force stop the domain"
    echo "    configure      configure the domain"
    echo "    flush          clear domain IPC"
	echo "    console-pwd    roll-out new pwds for the WLS console"
	echo "    tux-patch      roll-out patched tuxedo accross appServers and PRCS, as the psoft UID"
    echo "      "
    echo "Types:"
    echo "      "
    echo "    app            act on application domains"
    echo "    prcs           act on process scheduler domains"
    echo "    web            act on web domains"
    echo "        "
    echo "Domains:"
    echo "        "
    echo "    dom            act on specific domains"
    echo "    all,<blank>    act on all domains"
    echo " "
    
}

# display text in colors
function echo_color
{
    text=$1
    color=$2
	
    case $color in
        red) code="0;31m" ;;
        green) code="0;32m" ;;
        brown) code="0;33m" ;;
        blue) code="0;34m" ;;
        purple) code="0;35m" ;;
        cyan) code="0;36m" ;;
        gray) code="1;30m" ;;
        lred) code="1;31m" ;;
        lgreen) code="1;32m" ;;	
        yellow) code="1;33m" ;;
        lblue) code="1;34m" ;;
        lpurple) code="1;35m" ;;
        lcyan) code="1;36m" ;;
        lgray) code="0;37m" ;;
        *) code="0m" ;;
    esac
    
    echo -e "\e[$code$text\e[0m"
}

###########################
### Misc   
###########################

function set_domains
{	
    web_dirs=(${PS_CFG_HOME}/webserv/*)
    app_dirs=(${PS_CFG_HOME}/appserv/CNY*)
    prcs_dirs=(${PS_CFG_HOME}/appserv/prcs/CNY*)
	
    web_doms=()
    shopt -s nullglob # handles empty dirs
    for dir in "${web_dirs[@]}"
    do
        if [ -d "$dir" ]
        then
            dirname=${dir##*/} # strip fullpath
            if [[ "$dirname" != "Search" && "$dirname" != "prcs" ]]
	    then
                web_doms+=($dirname) 
            fi
        fi
    done
	
    app_doms=()
    shopt -s nullglob # handles empty dirs
    for dir in "${app_dirs[@]}"
    do
        if [ -d "$dir" ]
        then
            dirname=${dir##*/} # strip fullpath
            if [[ "$dirname" != "Search" && "$dirname" != "prcs" ]]
	    then
                app_doms+=($dirname) 
            fi
        fi
    done
	
    prcs_doms=()
    shopt -s nullglob # handles empty dirs
    for dir in "${prcs_dirs[@]}"
    do
        if [ -d "$dir" ]
        then
            dirname=${dir##*/} # strip fullpath
            if [[ "$dirname" != "Search" && "$dirname" != "prcs" ]]
	    then
               prcs_doms+=($dirname) 
            fi
        fi
    done
}
function call_list
{
    printf '%s\n' "---"
    printf 'hostname:      %s\n' "$(hostname)"
    printf 'ps-home:       %s\n' "$PS_HOME"
    printf 'ps-cfg-home:   %s\n' "$PS_CFG_HOME"

    if [ ${#app_doms[@]} -ne 0 ]; then
        printf '\n%s\n' "app:"
        printf '  - name: %s\n' "${app_doms[@]}"
    fi

    if [ ${#prcs_doms[@]} -ne 0 ]; then
        printf '\n%s\n' "prcs:"
        printf '  - name: %s\n' "${prcs_doms[@]}"
    fi
    
    if [ ${#web_doms[@]} -ne 0 ]; then
        printf '\n%s\n' "web:"
        printf '  - name: %s\n' "${web_doms[@]}"
    fi
}

function call_psadmin
{ 
	clear
	echo " Running psadmin as $PS_RUNTIME_USER ..."
	exec_cmd "psadmin"	
}

function exec_cmd
{
	
	cmd=$1
	if [ "`whoami`" = "$PS_RUNTIME_USER" ]; then
		bash -c "$cmd"
	else
		sudo su - $PS_RUNTIME_USER -c "$cmd"
				
		
	fi
}

function set_prd_ps_cfg_home
{

#PIA
if [[ "$type" == "web" ]];
then
                export PS_CFG_HOME=/appl/oracle/weblogic/$PS_RUNTIME_USER
fi
				
#appServers and PRCS
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"csprd" ]];
then
                export PS_CFG_HOME=/appl/psft/prod/cs900/
				
fi

if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hcprd" ]];
then
                export PS_CFG_HOME=/appl/psft/prd/hc900/
				
fi

if [[ "$type" != "web" && $PS_RUNTIME_USER == *"fsprd" ]];
then
                export PS_CFG_HOME=/appl/psft/prd/fs900/
				
fi

if [[ "$type" != "web" && $PS_RUNTIME_USER == *"epprd" ]];
then
                export PS_CFG_HOME=/appl/psft/prd/ep900/
				
fi

if [[ "$type" != "web" && $PS_RUNTIME_USER == *"cmprd" ]];
then
                export PS_CFG_HOME=/appl/psft/prd/cm900/
				
fi

#reporting instances
if [[ "$type" != "web" && $PS_RUNTIME_USER == "cnyhc003" ]];
then
                export PS_CFG_HOME=/appl/psft/003/hc900/
				
fi

if [[ "$type" != "web" && $PS_RUNTIME_USER == "cnyfs001" ]];
then
                export PS_CFG_HOME=/appl/psft/001/fs900/
				
fi

if [[ "$type" != "web" && $PS_RUNTIME_USER == "cnyhcup1" ]];
then
                export PS_CFG_HOME=/appl/psft/up1/cs900/
				
fi
}

function set_np_ps_cfg_home
{
#PIA
if [[ "$type" == "web" ]];
then
                export PS_CFG_HOME=/appl/oracle/weblogic/$PS_RUNTIME_USER
fi
#appServers and PRCS
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"cmpst" ]];
then
                export PS_CFG_HOME=/appl/psft/pst/cm900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"cmpdv" ]];
then
                export PS_CFG_HOME=/appl/psft/pdv/cm900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"cmdm2" ]];
then
                export PS_CFG_HOME=/appl/psft/dm2/cm900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"cmdm" ]];
then
                export PS_CFG_HOME=/appl/psft/dem/cm900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == "cssuatrpt" ]];
then
                export PS_CFG_HOME=/appl/psft/rpt/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hrsnd" ]];
then
                export PS_CFG_HOME=/appl/psft/snd/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hcfit" ]];
then
                export PS_CFG_HOME=/appl/psft/fit/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hccu8" ]];
then
                export PS_CFG_HOME=/appl/psft/cu8/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hccu5" ]];
then
                export PS_CFG_HOME=/appl/psft/cu5/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hccu4" ]];
then
                export PS_CFG_HOME=/appl/psft/cu4/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hccu1" ]];
then
                export PS_CFG_HOME=/appl/psft/cu1/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hc005" ]];
then
                export PS_CFG_HOME=/appl/psft/005/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hc001" ]];
then
                export PS_CFG_HOME=/appl/psft/001/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"csprt" ]];
then
                export PS_CFG_HOME=/appl/psft/prt/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"csprt" ]];
then
                export PS_CFG_HOME=/appl/psft/prt/cs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"eppst" ]];
then
                export PS_CFG_HOME=/appl/psft/pst/ep900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"eppdv" ]];
then
                export PS_CFG_HOME=/appl/psft/pdv/ep900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"epdm2" ]];
then
                export PS_CFG_HOME=/appl/psft/dm2/ep900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"epdem" ]];
then
                export PS_CFG_HOME=/appl/psft/dem/ep900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == "finuatrpt" ]];
then
                export PS_CFG_HOME=/appl/psft/rpt/fs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"fstrn" ]];
then
                export PS_CFG_HOME=/appl/psft/trn/fs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"fspst" ]];
then
                export PS_CFG_HOME=/appl/psft/pst/fs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"fspdv" ]];
then
                export PS_CFG_HOME=/appl/psft/pdv/fs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"fsfit" ]];
then
                export PS_CFG_HOME=/appl/psft/fit/fs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"fsdm2" ]];
then
                export PS_CFG_HOME=/appl/psft/dm2/fs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"fsdem" ]];
then
                export PS_CFG_HOME=/appl/psft/dem/fs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"fscfg" ]];
then
                export PS_CFG_HOME=/appl/psft/cfg/fs900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == "hcmuatrpt" ]];
then
                export PS_CFG_HOME=/appl/psft/rpt/hc900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hcpst" ]];
then
                export PS_CFG_HOME=/appl/psft/pst/hc900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hcpdv" ]];
then
                export PS_CFG_HOME=/appl/psft/pdv/hc900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hcpdm2" ]];
then
                export PS_CFG_HOME=/appl/psft/dm2/hc900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hcdem" ]];
then
                export PS_CFG_HOME=/appl/psft/dem/hc900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"hccu7" ]];
then
                export PS_CFG_HOME=/appl/psft/cu7/hc900/
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == *"cssnd" ]];
then
                export PS_CFG_HOME=/appl/psft/snd/hc900/
fi
}

function tux_patch
{

if [[ "$type" == "app" ]];
then
	act_type=app
else
    act_type=prcs
fi
	print_action_info
    echo "cleanup previous tuxedo backup.........."
	exec_cmd "rm -rf /appl/oracle/tuxedo.b4Patch"
	echo "patch level before patch from patchlev repo..........."
	exec_cmd "tail -n 1 $tuxdir/udataobj/patchlev"
	echo "backup tuxedo.........."
	exec_cmd "mv /appl/oracle/tuxedo /appl/oracle/tuxedo.b4Patch"
	echo "copy patched tuxedo tar ball........."
	exec_cmd "cp -f /psft/patches/tuxedoRP.tar.gz /appl/oracle"
	echo "untar patched tuxedo tar ball.........."
	exec_cmd "tar xfz /appl/oracle/tuxedoRP.tar.gz --directory /appl/oracle"
	echo "confirm patch level after patch from patchlev repo..........."
	exec_cmd "tail -n 1 $tuxdir/udataobj/patchlev"
	echo "cleanup tuxedo tar ball.........."
	exec_cmd "rm -rf /appl/oracle/tuxedoRP.tar.gz"
	exec_cmd "ls -ltr /appl/oracle/"
	
}

###########################
### Main 
###########################
PS_RUNTIME_USER=$1
act=$2
type=$3
domparam=$4
tuxdir=/appl/oracle/tuxedo/tuxedo12.1.1.0

domparam=${domparam:-all}

title=psa.sh
host=$(hostname)

if [[ -z "$PS_RUNTIME_USER"  || -z "$act" || -z "$type" ]];
then
	print_header
	print_help
fi
if [[ "$type" != "web" && $PS_RUNTIME_USER == "psoft" && "$act" == "tux_patch" ]];
then
    
    tux_patch
fi
if [[ "$host" == *"np"* ]];
then
    set_np_ps_cfg_home
    set_domains
    case $act in 
        summary ) call_summary;;
        list    ) call_list;;
        help    ) print_help;;
        *       ) case $type in
                      app  ) action_app;;
                      prcs ) action_prcs;;
                      web  ) action_web;;
                      *    ) echo "invalid type";;
                  esac;;              
    esac	
else	
    set_prd_ps_cfg_home
    set_domains
    case $act in 
        summary ) call_summary;;
        list    ) call_list;;
        help    ) print_help;;
        *       ) case $type in
                      app  ) action_app;;
                      prcs ) action_prcs;;
                      web  ) action_web;;
                      *    ) echo "invalid type";;
                  esac;;              
    esac
fi
