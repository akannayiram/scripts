#CSS Batch
bolt script run psa.sh -t @pf-css-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start prcs CNYCSPR1

bolt script run psa.sh -t @pf-css-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 start prcs CNYCSPR2
