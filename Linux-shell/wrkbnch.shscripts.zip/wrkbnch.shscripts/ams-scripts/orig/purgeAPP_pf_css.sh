#PEF CSS
bolt script run psa.sh -t @pf-cs-as-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 purge app CNYCSPR1
#OIM
bolt script run psa.sh -t csspfap333 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 purge app CNYCSIM1
#Master
bolt script run psa.sh -t csspfap334 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 purge app CNYCSAM1

bolt script run psa.sh -t csspfap335 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 purge app CNYCSSL1

bolt script run psa.sh -t csspfap336 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 purge app CNYCSSL2

bolt script run psa.sh -t csspfap337 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 purge app CNYCSSL3

bolt script run psa.sh -t csspfap338,csspfap339 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 purge app CNYCSCM1

bolt script run psa.sh -t csspfap338,csspfap339 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 purge app CNYCSRR1

