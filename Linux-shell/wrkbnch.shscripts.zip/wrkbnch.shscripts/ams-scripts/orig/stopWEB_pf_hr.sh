#Perf HR

bolt script run psa.sh -t hcmpfwl301,hcmpfwl302 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hca stop web

bolt script run psa.sh -t hcmpfwl301,hcmpfwl302 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hcb stop web

bolt script run psa.sh -t hcmpfwl303,hcmpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hci stop web

bolt script run psa.sh -t hcmpfwl305,hcmpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hcz stop web

bolt script run psa.sh -t hcmpfwl305,hcmpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hcy stop web
