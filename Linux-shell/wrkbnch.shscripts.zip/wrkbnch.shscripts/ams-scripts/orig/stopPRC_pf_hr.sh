#HR BATCH
bolt script run psa.sh -t @pf-hcm-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnyhcprd stop prcs all
