##Preload HR Cache
bolt script run psa.sh -t hcmpfap301,hcmpfap302,hcmpfap303,hcmpfap304 --no-host-key-check --connect-timeout 600 --tty --u $USER cnyhcprd preload app CNYHCPR1

##Preload CS Cache
bolt script run psa.sh -t @pf-cs-as-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 preload app CNYCSPR1
