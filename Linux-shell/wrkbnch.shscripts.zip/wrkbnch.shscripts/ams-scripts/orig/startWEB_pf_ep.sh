#PERF EP

bolt script run psa.sh -t Prtpfwl301,Prtpfwl302,Prtpfwl303,Prtpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epa start web

bolt script run psa.sh -t Prtpfwl301,Prtpfwl302,Prtpfwl303,Prtpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epb start web

bolt script run psa.sh -t Prtpfwl301,Prtpfwl302,Prtpfwl303,Prtpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epc start web

bolt script run psa.sh -t Prtpfwl305,Prtpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epi start web

bolt script run psa.sh -t Prtpfwl305,Prtpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epy start web

bolt script run psa.sh -t Prtpfwl305,Prtpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epz start web
