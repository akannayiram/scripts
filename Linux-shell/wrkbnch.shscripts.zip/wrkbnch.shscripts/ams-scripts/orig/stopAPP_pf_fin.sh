#PERF APP

bolt script run psa.sh -t finpfap301,finpfap302 --no-host-key-check --connect-timeout 600 --tty --u $USER cnyfsprd stop app CNYFSPR1

bolt script run psa.sh -t finpfap303 --no-host-key-check --connect-timeout 600 --tty --u $USER cnyfsprd stop app CNYFSAM1

bolt script run psa.sh -t finpfap304 --no-host-key-check --connect-timeout 600 --tty --u $USER cnyfsprd stop app CNYFSIM1
