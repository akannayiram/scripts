#PERF APP
bolt script run psa.sh -t hcmpfap301,hcmpfap302,hcmpfap303,hcmpfap304 --no-host-key-check --connect-timeout 600 --tty --u $USER cnyhcprd stop app CNYHCPR1

bolt script run psa.sh -t hcmpfap305  --no-host-key-check --connect-timeout 600 --tty --u $USER cnyhcprd stop app CNYHCAM1

bolt script run psa.sh -t hcmpfap306  --no-host-key-check --connect-timeout 600 --tty --u $USER cnyhcprd stop app CNYHCIM1

bolt script run psa.sh -t hcmpfap307  --no-host-key-check --connect-timeout 600 --tty --u $USER cnyhcprd stop app CNYHCPR1
