#Perf HR

bolt script run psa.sh -t hcmpfwl301,hcmpfwl302 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hca start web

bolt script run psa.sh -t hcmpfwl301,hcmpfwl302 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hcb start web

bolt script run psa.sh -t hcmpfwl303,hcmpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hci start web

bolt script run psa.sh -t hcmpfwl305,hcmpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hcz start web

bolt script run psa.sh -t hcmpfwl305,hcmpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854hcy start web
