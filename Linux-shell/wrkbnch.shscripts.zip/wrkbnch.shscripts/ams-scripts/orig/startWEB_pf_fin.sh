#Performance Web

bolt script run psa.sh -t finpfwl301,finpfwl302 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854fsa start web  

bolt script run psa.sh -t finpfwl303,finpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854fsi start web  

bolt script run psa.sh -t finpfwl305,finpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854fsz start web  

bolt script run psa.sh -t finpfwl305,finpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854fsy start web  
