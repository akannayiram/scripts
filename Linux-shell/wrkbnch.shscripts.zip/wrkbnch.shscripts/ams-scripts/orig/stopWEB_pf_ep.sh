#PERF EP
bolt script run psa.sh -t Prtpfwl301,Prtpfwl302,Prtpfwl303,Prtpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epa stop web

bolt script run psa.sh -t Prtpfwl301,Prtpfwl302,Prtpfwl303,Prtpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epb stop web

bolt script run psa.sh -t Prtpfwl301,Prtpfwl302,Prtpfwl303,Prtpfwl304 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epc stop web

bolt script run psa.sh -t Prtpfwl305,Prtpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epi stop web

bolt script run psa.sh -t Prtpfwl305,Prtpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epy stop web

bolt script run psa.sh -t Prtpfwl305,Prtpfwl306 --no-host-key-check --connect-timeout 600  --tty --u $USER  cnyp854epz stop web
