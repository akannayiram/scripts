#FIN BATCH
bolt script run psa.sh -t @pf-fin-ps-servers --no-host-key-check --connect-timeout 600 --tty --u agreen cnyfsprd start prcs CNYFSPR1
