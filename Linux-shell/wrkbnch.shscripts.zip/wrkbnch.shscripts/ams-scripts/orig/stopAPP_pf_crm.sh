#PERF APP

bolt script run psa.sh -t CRMPFAP301,CRMPFAP302 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 stop app CNYCMPR1

bolt script run psa.sh -t CRMPFAP303 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 stop app CNYCMAM1

bolt script run psa.sh -t CRMPFAP304 --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 stop app CNYCMCM1
