#!/bin/bash
#	SCSI_Mapping.sh
#
#	Find all SCSI devices for /data* mounts
#
for device in `pvs | grep "/dev" | awk '{print $1}'`
do
    mount=$(pvs | grep $device | awk '{print $2 " " $5}')
    #   Trim /dev/sda1 to /dev/sda
    scsi=$(lsscsi | grep ${device:0:8} | awk '{print $1}')
    echo $(hostname -s) $scsi $mount $device
done
#	One liner
#for device in `pvs | grep "/dev" | awk '{print $1}'`;do mount=$(pvs | grep $device | awk '{print $2 " " $5}');scsi=$(lsscsi | grep ${device:0:8} | awk '{print $1}');echo $(hostname -s) $scsi $mount $device;done;

