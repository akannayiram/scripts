#!/bin/bash
#
#       Create_Developer_PSHOME_Mounts.sh
#
#       By Mark Daneman
#       Created: 12-DEC-2022
#       Updated: 09-FEB-2023
#
#       REQ0028371 / RITM0029787 / SCTASK0033215 / INTERNAL - Setup Developer LOG and CUSTOM access
#
#       NOTE: Assumption is that 050 and 051 servers will never have the same PSHOME
#               Check for conflicts with
#                       bash /psft/team_server/Check_Developer_NonProd_LOG_CUSTOM_Directories.sh
#
#       Create
#               /developer/pshome/cs92npap/ad1 ad2 dm2 rpu ug1 ug2 005  cu5  de2  dem  dev  dmo  pdv  pst
#               /developer/pshome/cs92npux/ad1 ad2 dm2 rpu ug1 ug2 005  cu5  de2  dem  dev  dmo  pdv  pst
#
#       Owned by root:root permissions 750
#
#       Assign group ownership to limit access
#
#       Mount --bind custom and logs from
#               /sftp/servers/cs92npap050/ad1/cs920/appserv/CNYCSAD1/LOGS
#               /sftp/servers/cs92npap050/ad1/cs920/custom
#               /sftp/servers/cs92npap050/ad1/cs920/src/cbl
#               /sftp/servers/cs92npap050/ad1/cs920/sqr
#               /sftp/servers/cs92npux050/ad1/cs920/appserv/prcs/CNYCSAD1/LOGS
#               /sftp/servers/cs92npux050/ad1/cs920/custom
#               /sftp/servers/cs92npux050/ad1/cs920/src/cbl
#               /sftp/servers/cs92npux050/ad1/cs920/sqr
#
#	Add to crontab to run 60 seconds after every reboot
#	# Mount local PSHOME binds after reboot
#	@reboot (sleep 60; /psft/team_server/Create_Developer_PSHOME_Mounts.sh)
#
echo -e "\nCreate Developer PSHOME mounts on cnysftpxdev92"

if [[ "ft92npux050" != "${HOSTNAME%%.*}" ]]
then
        echo "ERROR: This script only works on ft92npux050"
        exit
fi

#
#       Create /developer/pshome if needed
#	Allow only World eXecute access to /developer to prevent users from navigating up in Filezilla
#
if [ ! -d "/developer" ]
then
  echo -e "\nCreate /developer and assign ownership and permissions"
  mkdir /developer
  chown root:root /developer
  chmod 711 /developer
fi

if [ ! -d "/developer/pshome" ]
then
  echo -e "\nCreate /pshome and assign ownership and permissions"
  mkdir /developer/pshome
  chown root:root /developer/pshome
  chmod 755 /developer/pshome
fi

for PILLAR in cs fs hc ih
do
    echo -e "\nCreate directories, assign permissions, and mount --bind custom and LOGS for ${PILLAR}"

    #
    #   Cycle through directories for both developer permission groups, i.e. pshome_cs and pshome_cs_dm2_pst
    #
    for GROUP in pshome_${PILLAR} pshome_${PILLAR}_dm2_pst
    do

        echo -e "\nGroup: $GROUP"

        #
        #  Find all existing server directories, i.e. /sftp/servers/cs92npap050
        #
        for SERVER in `find /sftp/servers/ -mindepth 1 -maxdepth 1 -type d`
        do
            #
            #   Get server name, i.e. cs92npap050
            #
            LHOST=${SERVER: -11}
            UHOST=${LHOST^^}

                echo "  Server: $LHOST"
            
            #
            #   Get pillar name from host name, i.e. cs92npap
            #
            PNAME=${LHOST:0:8}

                echo "  Pillar name: $PNAME"

            #
            #   Find all sftp directories for each server, i.e. /sftp/servers/cs92npap050/ad1
            #
            for DIR in `find $SERVER/ -mindepth 1 -maxdepth 1 -type d`
            do
                #
                #   Skip /sftp/servers/*/psft, i.e. /sftp/servers/cs92npap050/psft
                #
                if [ "$DIR" = "$SERVER/psft" ]
                then
                   echo -e "\nSkip Link: $DIR"
                   continue
                fi

                #
                #   Generate permission group names, i.e. pshome_cs and pshome_cs_dm2_pst
                #
                GRPNONPRD="pshome_${LHOST:0:2}"
                GRPDM2PST="pshome_${LHOST:0:2}_dm2_pst"
                
                #
                #   Generate psdomain, i.e. ad1, ug1, etc.
                #   Generate sftp CUST, APPLOG, and PRCSLOG directories
                #
                UDIR=${DIR^^}
                PSDOMAIN=${UDIR: -3}
                CUSTDIR="$DIR/${LHOST:0:2}920/custom"
                CBLDIR="$DIR/${LHOST:0:2}920/src/cbl"
                SQRDIR="$DIR/${LHOST:0:2}920/sqr"
                APPLOGDIR="$DIR/${LHOST:0:2}920/appserv/CNY${UHOST:0:2}$PSDOMAIN/LOGS"
                PRCSLOGDIR="$DIR/${LHOST:0:2}920/appserv/prcs/CNY${UHOST:0:2}$PSDOMAIN/LOGS"

                #
                #   Do not grant access to
                #       RPT - Reporting
                #       PR2 - Performance
                #       PRD - Production
                #   Skip to next directory
                #
                if [ "$PSDOMAIN" = "RPT" ] || [ "$PSDOMAIN" = "PR2" ] || [ "$PSDOMAIN" = "PRD" ]
                then
                    echo "  Skip RPT/PR2/PRD: $DIR"
                    continue
                fi

                #
                #   DM2 and PST PSDOMAIN directories have special developer group (DEVGRP) access
                #
                if [ "$PSDOMAIN" = "DM2" ] || [ "$PSDOMAIN" = "PST" ]
                then
                    DEVGRP=$GRPDM2PST
                else
                    DEVGRP=$GRPNONPRD
                fi

                #
                #   Create directories and assign group access if directories match the current group, i.e.
                #               pshome_cs or pshome_cs_dm2_pst
                #
                if [ "$GROUP" = "$DEVGRP" ]
                then

                    #
                    #   Create pshome directory structure if custom or LOGS sftp directory was found
                    #       i.e. /developer/pshome/cs92npap/ad1
                    #   and grant group permissions
                    #
                    if [ -d "$CUSTDIR" ] || [ -d "$CBLDIR" ] || [ -d "$SQRDIR" ] || [ -d "$APPLOGDIR" ] || [ -d "$PRCSLOGDIR" ]
                    then
                         if [ ! -d "/developer/pshome/${PNAME}" ]
                         then
                             echo "  Create /developer/pshome/${PNAME} and set permissions $DEVGRP"
                             mkdir /developer/pshome/${PNAME}
                             chown root:root /developer/pshome/${PNAME}
                             chmod 750 /developer/pshome/${PNAME}

                             #      Set default FACLs on directory for read access
                             setfacl --default --modify group:$DEVGRP:rx --modify mask::rx /developer/pshome/${PNAME}
                             #      Set FACLs on existing directory for read access
                             setfacl --modify group:$DEVGRP:rx --modify mask::rx /developer/pshome/${PNAME}

                         fi

                         if [ ! -d "/developer/pshome/${PNAME}/${PSDOMAIN,,}" ]
                         then
                             echo "  Create /developer/pshome/${PNAME}/${PSDOMAIN,,} and set permissions $DEVGRP"
                             mkdir /developer/pshome/${PNAME}/${PSDOMAIN,,}
                             chown root:root /developer/pshome/${PNAME}/${PSDOMAIN,,}
                             chmod 750 /developer/pshome/${PNAME}/${PSDOMAIN,,}

                             #      Set default FACLs on directory for read access
                             setfacl --default --modify group:$DEVGRP:rx --modify mask::rx /developer/pshome/${PNAME}/${PSDOMAIN,,}
                             #      Set FACLs on existing directory for read access
                             setfacl --modify group:$DEVGRP:rx --modify mask::rx /developer/pshome/${PNAME}/${PSDOMAIN,,}

                         fi
                    fi

                    #
                    #   Create mount --bind for custom and LOGS if they exist, i.e.
                    #       /developer/pshome/cs92npux/ad1/custom ->
                    #          /sftp/servers/cs92npap050/ad1/cs920/custom
                    #       /developer/pshome/cs92npux/ad1/cbl ->
                    #          /sftp/servers/cs92npap050/ad1/cs920/src/cbl
                    #       /developer/pshome/cs92npux/ad1/sqr ->
                    #          /sftp/servers/cs92npap050/ad1/cs920/sqr
                    #       /developer/pshome/cs92npap/ad1/LOGS ->
                    #          /sftp/servers/cs92npap050/ad1/cs920/appserv/CNYCSAD1/LOGS
                    #
                    #       /developer/pshome/cs92npux/ad1/custom ->
                    #          /sftp/servers/cs92npux050/ad1/cs920/src/cbl
                    #       /developer/pshome/cs92npux/ad1/src/cbl ->
                    #          /sftp/servers/cs92npux050/ad1/cs920/custom
                    #       /developer/pshome/cs92npux/ad1/sqr ->
                    #          /sftp/servers/cs92npux050/ad1/cs920/sqr
                    #       /developer/pshome/cs92npap/ad1/LOGS ->
                    #          /sftp/servers/cs92npux050/ad1/cs920/appserv/prcs/CNYCSAD1/LOGS

                    #
                    if [ -d "$CUSTDIR" ]
                    then
                         if [ ! -d "/developer/pshome/${PNAME}/${PSDOMAIN,,}/custom" ]
                         then
                             echo "  Create directory /developer/pshome/${PNAME}/${PSDOMAIN,,}/custom"
                             mkdir /developer/pshome/${PNAME}/${PSDOMAIN,,}/custom
                             chown root:root /developer/pshome/${PNAME}/${PSDOMAIN,,}/custom
                             chmod 755 /developer/pshome/${PNAME}/${PSDOMAIN,,}/custom
                             touch /developer/pshome/${PNAME}/${PSDOMAIN,,}/custom/ERROR_Filesystem_Not_Mounted.txt
                         fi
                         if [ "`mountpoint /developer/pshome/${PNAME}/${PSDOMAIN,,}/custom | grep 'is not a mountpoint' | wc -l`" == "1" ]
                         then
                             echo "  Mount Custom: ${CUSTDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/custom"
                             mount --bind ${CUSTDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/custom
                         fi
                    fi
                    if [ -d "$CBLDIR" ]
                    then
                         if [ ! -d "/developer/pshome/${PNAME}/${PSDOMAIN,,}/cbl" ]
                         then
                             echo "  Create directory /developer/pshome/${PNAME}/${PSDOMAIN,,}/cbl"
                             mkdir /developer/pshome/${PNAME}/${PSDOMAIN,,}/cbl
                             chown root:root /developer/pshome/${PNAME}/${PSDOMAIN,,}/cbl
                             chmod 755 /developer/pshome/${PNAME}/${PSDOMAIN,,}/cbl
                             touch /developer/pshome/${PNAME}/${PSDOMAIN,,}/cbl/ERROR_Filesystem_Not_Mounted.txt
                         fi
                         if [ "`mountpoint /developer/pshome/${PNAME}/${PSDOMAIN,,}/cbl | grep 'is not a mountpoint' | wc -l`" == "1" ]
                         then
                             echo "  Mount Custom: ${CBLDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/cbl"
                             mount --bind ${CBLDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/cbl
                         fi
                    fi
                    if [ -d "$SQRDIR" ]
                    then
                         if [ ! -d "/developer/pshome/${PNAME}/${PSDOMAIN,,}/sqr" ]
                         then
                             echo "  Create directory /developer/pshome/${PNAME}/${PSDOMAIN,,}/sqr"
                             mkdir /developer/pshome/${PNAME}/${PSDOMAIN,,}/sqr
                             chown root:root /developer/pshome/${PNAME}/${PSDOMAIN,,}/sqr
                             chmod 755 /developer/pshome/${PNAME}/${PSDOMAIN,,}/sqr
                             touch /developer/pshome/${PNAME}/${PSDOMAIN,,}/sqr/ERROR_Filesystem_Not_Mounted.txt
                         fi
                         if [ "`mountpoint /developer/pshome/${PNAME}/${PSDOMAIN,,}/sqr | grep 'is not a mountpoint' | wc -l`" == "1" ]
                         then
                             echo "  Mount Custom: ${SQRDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/sqr"
                             mount --bind ${SQRDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/sqr
                         fi
                    fi
                    if [ -d "$APPLOGDIR" ]
                    then
                         if [ ! -d "/developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS" ]
                         then
                             echo "  Create directory /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS"
                             mkdir /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS
                             chown root:root /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS
                             chmod 755 /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS
                             touch /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS/ERROR_Filesystem_Not_Mounted.txt
                         fi
                         if [ "`mountpoint /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS | grep 'is not a mountpoint' | wc -l`" == "1" ]
                         then
                             echo "  Mount AppLOG: ${APPLOGDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS"
                             mount --bind ${APPLOGDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS
                         fi
                    fi

                    if [ -d "$PRCSLOGDIR" ]
                    then
                         if [ ! -d "/developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS" ]
                         then
                             echo "  Create directory /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS"
                             mkdir /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS
                             chown root:root /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS
                             chmod 755 /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS
                             touch /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS/ERROR_Filesystem_Not_Mounted.txt
                         fi
                         if [ "`mountpoint /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS | grep 'is not a mountpoint' | wc -l`" == "1" ]
                         then
                             echo "  Mount PrcsLOG: ${PRCSLOGDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS"
                             mount --bind ${PRCSLOGDIR} /developer/pshome/${PNAME}/${PSDOMAIN,,}/LOGS
                         fi
                    fi

                fi

            done

        done

    done

done

#
#
#
echo -e "\nCOMPLETED: Create_Developer_PSHOME_Mounts\n"

