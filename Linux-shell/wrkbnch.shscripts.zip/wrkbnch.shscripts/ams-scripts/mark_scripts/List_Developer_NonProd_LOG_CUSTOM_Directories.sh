#!/bin/bash
#
#	List_Developer_NonProd_LOG_CUSTOM_Directories.sh
#
#	By Mark Daneman
#	Created: 08-DEC-2022
#	Updated: 08-DEC-2022
#
#	REQ0028371 / RITM0029787 / SCTASK0033215 / INTERNAL - Setup Developer LOG and CUSTOM access
#
#*******************************************************************************
#
#	List LOG and custom directories on cnysftpxdev92.cf.cuny.edu
#		and the developer AD group needed to update them
#	i.e.
#	/sftp/servers/cs92npap050/ad1/cs920/custom
#	    default:group:pshome_cs:rwx
#	/sftp/servers/cs92npap050/ad1/cs920/appserv/CNYCSAD1/LOGS
#	    default:group:pshome_cs:rwx
#	/sftp/servers/cs92npap050/ug1/cs920/custom
#	/sftp/servers/cs92npap050/ug1/cs920/appserv/CNYCSUG1/LOGS
#	    default:group:pshome_cs:rwx
#
#	NOTE: Developers must have the correct Windows AD group in order to update the files
#
#*******************************************************************************
echo -e "\nList LOG and custom directories on cnysftpxdev92.cf.cuny.edu"
echo -e "    and the developer AD group needed to update them\n"

if [[ "ft92npux050" != "${HOSTNAME%%.*}" ]]
then
	echo "ERROR: This script only works on ft92npux050"
	exit
fi

#
#
#
for DIR in `find /sftp/servers -mindepth 1 -maxdepth 1 -type d`; do
    LHOST=${DIR: -11}
    UHOST=${LHOST^^}
    
#	Find /sftp/servers/cs92npap050...

    for SUBDIR in `find $DIR -mindepth 1 -maxdepth 1 -type d`; do

#	Find /sftp/servers/cs92npap050/ad1...

        PDOMAIN=${SUBDIR: -3}
        PDOMAIN=${PDOMAIN^^}

        CUSTDIR="$SUBDIR/${LHOST:0:2}920/custom"
        APPLOGDIR="$SUBDIR/${LHOST:0:2}920/appserv/CNY${UHOST:0:2}$PDOMAIN/LOGS"
        PRCSLOGDIR="$SUBDIR/${LHOST:0:2}920/appserv/prcs/CNY${UHOST:0:2}$PDOMAIN/LOGS"

        if [ -d "$CUSTDIR" ]
        then
            echo "$CUSTDIR"
            getfacl -p $CUSTDIR | grep 'default:group:pshome\|default:group:14388' | sed 's/^/    /'
        fi

        if [ -d "$APPLOGDIR" ]
        then
            echo "$APPLOGDIR"
            getfacl -p $APPLOGDIR | grep 'default:group:pshome\|default:group:14388' | sed 's/^/    /'
        fi

        if [ -d "$PRCSLOGDIR" ]
        then
            echo "$PRCSLOGDIR"
            getfacl -p $PRCSLOGDIR | grep 'default:group:pshome\|default:group:14388' | sed 's/^/    /'
        fi

    done

done

#
#
#
echo ""

