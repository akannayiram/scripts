#!/bin/bash
#
#	Check_Developer_NonProd_LOG_CUSTOM_Directories.sh
#
#	By Mark Daneman
#	Created: 09-JAN-2022
#	Updated: 11JAN-2022
#
#	REQ0028371 / RITM0029787 / SCTASK0033215 / INTERNAL - Setup Developer LOG and CUSTOM access
#
#*******************************************************************************
#
#	List LOG and custom directories on cnysftpxdev92.cf.cuny.edu
#		and the developer AD group needed to update them
#	i.e.
#	/sftp/servers/cs92npap050/ad1/cs920/custom
#	    default:group:pshome_cs:rwx
#	/sftp/servers/cs92npap050/ad1/cs920/appserv/CNYCSAD1/LOGS
#	    default:group:pshome_cs:rwx
#	/sftp/servers/cs92npap050/ug1/cs920/custom
#	/sftp/servers/cs92npap050/ug1/cs920/appserv/CNYCSUG1/LOGS
#	    default:group:pshome_cs:rwx
#
#	NOTE: Developers must have the correct Windows AD group in order to update the files
#
#*******************************************************************************
echo -e "\nCheck for conflicts for LOG and custom directories on cnysftpxdev92.cf.cuny.edu\n"

if [[ "ft92npux050" != "${HOSTNAME%%.*}" ]]
then
	echo "ERROR: This script only works on ft92npux050"
	exit
fi

#
#
#
for DIR in `find /sftp/servers -mindepth 1 -maxdepth 1 -type d`; do
    LHOST=${DIR: -11}
    UHOST=${LHOST^^}
    
#	Find /sftp/servers/cs92npap050...

    for SUBDIR in `find $DIR -mindepth 1 -maxdepth 1 -type d`; do

#	Find /sftp/servers/cs92npap050/ad1...

	PRIDIR="${LHOST: -3}"
	
	#
	#	Check 050 to 051 directories for LOG and custom conflicts
	#
	OTHDIR="INVALID"
        if [ $PRIDIR = "050" ]
        then
            OTHDIR="051"
        fi
        if [ $PRIDIR = "051" ]
        then
            OTHDIR="050"
        fi

        if [ $OTHDIR = "INVALID" ]
        then
            echo "ERROR: Invalid directory"
            exit
        fi

	ALTDIR="${SUBDIR/$PRIDIR/$OTHDIR}"

        PDOMAIN=${SUBDIR: -3}
        PDOMAIN=${PDOMAIN^^}

        CUSTDIR="$SUBDIR/${LHOST:0:2}920/custom"
        CBLDIR="$DIR/${LHOST:0:2}920/src/cbl"
        SQRDIR="$DIR/${LHOST:0:2}920/sqr"
        APPLOGDIR="$SUBDIR/${LHOST:0:2}920/appserv/CNY${UHOST:0:2}$PDOMAIN/LOGS"
        PRCSLOGDIR="$SUBDIR/${LHOST:0:2}920/appserv/prcs/CNY${UHOST:0:2}$PDOMAIN/LOGS"

        ALTCUSTDIR="$ALTDIR/${LHOST:0:2}920/custom"
        ALTCBLDIR="$DIR/${LHOST:0:2}920/src/cbl"
        ALTSQRDIR="$DIR/${LHOST:0:2}920/sqr"
        ALTAPPLOGDIR="$ALTDIR/${LHOST:0:2}920/appserv/CNY${UHOST:0:2}$PDOMAIN/LOGS"
        ALTPRCSLOGDIR="$ALTDIR/${LHOST:0:2}920/appserv/prcs/CNY${UHOST:0:2}$PDOMAIN/LOGS"


        if [ -d "$CUSTDIR" ] && [ -d "$ALTCUSTDIR" ]
        then
            echo "ERROR conflict: $CUSTDIR and $ALTCUSTDIR"
        fi

        if [ -d "$CBLDIR" ] && [ -d "$ALTCBLDIR" ]
        then
            echo "ERROR conflict: $CBLDIR and $ALTCBLDIR"
        fi

        if [ -d "$SQRDIR" ] && [ -d "$ALTSQRDIR" ]
        then
            echo "ERROR conflict: $SQRDIR and $ALTSQRDIR"
        fi

        if [ -d "$APPLOGDIR" ] && [ -d "$ALTAPPLOGDIR" ]
        then
            echo "ERROR conflict: $APPLOGDIR $ALTAPPLOGDIR"
        fi

        if [ -d "$PRCSLOGDIR" ] && [ -d "$ALTPRCSLOGDIR" ]
        then
            echo "ERROR conflict: $PRCSLOGDIR $ALTPRCSLOGDIR"
        fi

    done

done

#
#
#
echo ""

