#!/bin/bash
#
#	Dismount_Developer_SFTP_Server_mounts.sh
#
#	By Mark Daneman
#	Created: 08-DEC-2022
#	Updated: 08-DEC-2022
#
#	REQ0028371 / RITM0029787 / SCTASK0033215 / INTERNAL - Setup Developer LOG and CUSTOM access
#
#	Dismount developer SFTP mount points
#
echo -e "\nDismount developer SFTP mount points on cnysftpxdev92\n"

if [[ "ft92npux050" != "${HOSTNAME%%.*}" ]]
then
	echo "ERROR: This script only works on ft92npux050"
	exit
fi

for SERVER in \
    cs92npap050 cs92npap051 cs92npux050 cs92npux051 \
    fs92npap050 fs92npap051 fs92npux050 fs92npux051 \
    hc92npap050 hc92npap051 hc92npux050 hc92npux051 \
    ih92npap050 ih92npap051 ih92npux050 ih92npux051 
do
    echo "Dismount mount point for $SERVER"
    umount /sftp/servers/$SERVER
done

#
#
#
echo -e "\nCOMPLETED: Dismount_Developer_SFTP_Server_mounts.sh\n"

