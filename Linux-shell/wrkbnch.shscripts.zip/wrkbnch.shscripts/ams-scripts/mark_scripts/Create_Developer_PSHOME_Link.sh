#!/bin/bash
#
#	Create_Developer_PSHOME_Link.sh
#
#	By Mark Daneman
#	Created: 12-DEC-2022
#	Updated: 10-JAN-2023
#
#	REQ0028371 / RITM0029787 / SCTASK0033215 / INTERNAL - Setup Developer LOG and CUSTOM access
#
#	Create pshome mount in developers home directory to /pshome
#
#	Add to root crontab
#	# Create Developer PSHOME LOGS/custom links
#	30 * * * * bash /psft/team_server/Create_Developer_PSHOME_Link.sh > /dev/null
#
#
echo -e "\nSetup Developer PSHOME links on cnysftpxdev92"

if [[ "ft92npux050" != "${HOSTNAME%%.*}" ]]
then
	echo "ERROR: This script only works on ft92npux050"
	exit
fi

#
#	Parameter 1 can be used to update a single user i.e. amstest
#
if [ "$1" != "" ]
then
    SUSER=$1
    CUSER=`id $1`
    if [ ${#CUSER} -lt 8 ]
    then
        echo "ERROR: Invalid user $SUSER"
        exit
    fi
fi

for PILLAR in cs fs hc ih
do
    echo -e "\nCreate PSHOME developer links for ${PILLAR}"

    for GROUP in pshome_${PILLAR} pshome_${PILLAR}_dm2_pst
    do

	echo "  Group: $GROUP"

        #
        #	Get all users in the group
        #
        for UNAME in `getent group ${GROUP} | awk -F : '{print $4}'| sed s/,/\ /g`
        do
             #
             #  Run for a single user if specified
             #
             if [ "$SUSER" != "" ]
             then
                 if [ "$SUSER" != "$UNAME" ]
                 then
                     continue
                 fi
             fi

             #
             #  Only create links if user directory exists
             #
             if [ ! -d "/home/$UNAME" ]
             then
                     continue
             fi

             
             #
             #   Create pshome link if it is not mounted
             #
             if [ ! -L "/home/$UNAME/pshome" ]
             then
                 echo "    User: $UNAME, link /home/$UNAME/pshome"
                 ln -s /developer/pshome /home/$UNAME
             fi

             #
             #   NOTE: Nested mounts did not work
             #       custom and LOGS were not visible and instead saw ERROR_Filesystem_Not_Mounted.txt
             #       via the /home/<user>/pshome mount
             #
             #   Create /home/<user>/pshome directory and mount /pshome to it
             #
             #if [ ! -d "/home/$UNAME/pshome" ]
             #then
             #    echo "Create /home/$UNAME/pshome"
             #    mkdir /home/$UNAME/pshome
             #    chown root:root /home/$UNAME/pshome
             #    chmod 755 /home/$UNAME/pshome
             #    touch /home/$UNAME/pshome/ERROR_Filesystem_Not_Mounted.txt
             #fi
             
             #
             #   Mount /pshome if it is not mounted
             #
             #if [ -f "/home/$UNAME/pshome/ERROR_Filesystem_Not_Mounted.txt" ]
             #then
             #    echo "Mount /home/$UNAME/pshome"
             #    mount --bind /pshome /home/$UNAME/pshome
             #fi

        done

    done

done

#
#
#
echo -e "\nCOMPLETED: Create_Developer_PSHOME_Link.sh\n"

