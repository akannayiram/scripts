#!/bin/bash
#
#	Setup_Developer_SFTP_Server_mounts.sh
#
#	By Mark Daneman
#	Created: 08-DEC-2022
#	Updated: 08-DEC-2022
#
#	REQ0028371 / RITM00297871 / SCTASK0033215 / INTERNAL - Setup Developer LOG and CUSTOM access
#
#	Create mount points and /etc/fstab for Developer SFTP mounts
#
echo -e "\nSetup Developer SFTP Server mounts on cnysftpxdev92\n"

if [[ "ft92npux050" != "${HOSTNAME%%.*}" ]]
then
	echo "ERROR: This script only works on ft92npux050"
	exit
fi

#
#	Grant developer Windows AD groups access to the SFTP server
#
echo -e "\nGrant developer Windows AD groups access to the SFTP server"

realm permit --groups pshome_cs pshome_fs pshome_hc pshome_ih \
	pshome_cs_dm2_pst pshome_fs_dm2_pst pshome_hc_dm2_pst pshome_ih_dm2_pst

realm list | grep permitted-groups

#	Command to remove access
#realm permit --withdraw --groups pshome_cs pshome_fs pshome_hc pshome_ih \
#	pshome_cs_dm2_pst pshome_fs_dm2_pst pshome_hc_dm2_pst pshome_ih_dm2_pst

#
#	Create sftp top level directories and mount points
#		on cnysftpxdev92.cf.cuny.edu
#

if [ ! -d "/sftp" ]
then
    mkdir /sftp
fi
chown root:root /sftp
chmod 755 /sftp

if [ ! -d "/sftp/servers" ]
then
    mkdir /sftp/servers
fi
chown root:root /sftp/servers
chmod 755 /sftp/servers

for SERVER in \
    cs92npap050 cs92npap051 cs92npux050 cs92npux051 \
    fs92npap050 fs92npap051 fs92npux050 fs92npux051 \
    hc92npap050 hc92npap051 hc92npux050 hc92npux051 \
    ih92npap050 ih92npap051 ih92npux050 ih92npux051 
do
    echo "Create mount points for $SERVER"
    if [ ! -d "/sftp/servers/$SERVER" ]
    then
        mkdir /sftp/servers/$SERVER
    fi
    chown root:root /sftp/servers/$SERVER
    chmod 755 /sftp/servers/$SERVER
    touch /sftp/servers/$SERVER/ERROR_NFS_filesystem_not_mounted
done

#
#	List NFS mount points
#
echo "List NFS mount points"
ls /sftp/servers

#
#	Create /etc/fstab entries
#
echo -e "\nAdd NFS mountsto /etc/fstab\nAnd execute mount -a\n"

sed -i '/RITM0029787\|92npap05\|92npux05\|########\|--------/d' /etc/fstab

echo "#############################################################################################################" >> /etc/fstab
echo "#    Developer LOGS and custom access - RITM0029787" >> /etc/fstab
echo "#############################################################################################################" >> /etc/fstab

LSERVER="cs"
for SERVER in \
    cs92npap050 cs92npap051 cs92npux050 cs92npux051 \
    fs92npap050 fs92npap051 fs92npux050 fs92npux051 \
    hc92npap050 hc92npap051 hc92npux050 hc92npux051 \
    ih92npap050 ih92npap051 ih92npux050 ih92npux051 
do
    if [ "${SERVER:0:2}" != "$LSERVER" ]
    then
        echo "#------------------------------------------------------------------------------------------------------------" >> /etc/fstab
        LSERVER=${SERVER:0:2}
    fi
    echo "$SERVER.cf.cuny.edu:/appl/psft     /sftp/servers/$SERVER    nfs     rw,vers=3,bg,hard,intr  0       0" >> /etc/fstab
done

echo "#############################################################################################################" >> /etc/fstab

echo -e "\nExecute mount -a\n"
mount -a

#
#
#
echo -e "\nCOMPLETED: Setup_Developer_SFTP_Server_mounts.sh\n"

