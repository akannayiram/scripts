#FIN Batch
bolt script run psa.sh -t @pf-fin-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnyfsprd stop prcs CNYFSPR1
