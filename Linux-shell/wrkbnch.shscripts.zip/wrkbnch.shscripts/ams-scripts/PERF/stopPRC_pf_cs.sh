#CSS Batch
bolt script run psa.sh -t @pf-css-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 stop prcs CNYCSPR1

bolt script run psa.sh -t @pf-css-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 stop prcs CNYCSPR2

bolt script run psa.sh -t @pf-css-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 status prcs CNYCSPR1

bolt script run psa.sh -t @pf-css-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycspr2 status prcs CNYCSPR2
