# CRM Batch
bolt script run psa.sh -t @pf-crm-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 stop prcs CNYCMPR1
