bolt command run 'ls -l /appl/oracle/jre/ && ps -aef|grep BBL|grep -v grep' -t @pf-css-ps-servers --tty
bolt command run 'ls -l /appl/oracle/jre/ && ps -aef|grep BBL|grep -v grep' -t @pf-crm-ps-servers --tty
bolt command run 'ls -l /appl/oracle/jre/ && ps -aef|grep BBL|grep -v grep' -t @pf-epp-ps-servers --tty
bolt command run 'ls -l /appl/oracle/jre/ && ps -aef|grep BBL|grep -v grep' -t @pf-fin-ps-servers --tty
bolt command run 'ls -l /appl/oracle/jre/ && ps -aef|grep BBL|grep -v grep' -t @pf-hcm-ps-servers --tty
