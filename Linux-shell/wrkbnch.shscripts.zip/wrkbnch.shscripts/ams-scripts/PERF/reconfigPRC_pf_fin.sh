#FIN BATCH
bolt script run psa.sh -t @pf-fin-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnyfsprd configure prcs CNYFSPR1

bolt script run psa.sh -t @pf-fin-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnyfsprd start prcs CNYFSPR1

bolt script run psa.sh -t @pf-fin-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnyfsprd status prcs CNYFSPR1
