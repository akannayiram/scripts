# CRM Batch
bolt script run psa.sh -t @pf-crm-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 configure prcs CNYCMPR1

bolt script run psa.sh -t @pf-crm-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 start prcs CNYCMPR1

bolt script run psa.sh -t @pf-crm-ps-servers --no-host-key-check --connect-timeout 600 --tty --u $USER cnycmpr2 status prcs CNYCMPR1
