set -x
inp_hostname=$1
f1=$HOME/sshidcopy/.al
sshpass -f $f1 ssh-copy-id -o StrictHostKeyChecking=no  akannayiram@${inp_hostname}
set +x
