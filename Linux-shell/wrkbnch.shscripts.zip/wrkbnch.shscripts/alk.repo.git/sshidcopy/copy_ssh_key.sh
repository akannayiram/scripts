#!/bin/bash
# ======================================================
# Copy ssh public key to target hosts
#  Usage:
#    ./copy_ssh_key.sh <hosts_file> <pwfile>
#  Returns exit status of 0 (Success) or 1 (Failure)
# History:
# Who                When       Why and What
# -----------------  ---------- ------------------------
# Al Kannayiram      07/08/2021 Initial creation
#
# ======================================================

#
# Constants
USR=$USER

#
# functions
myecho()
{
 dttm=`date '+%Y-%m-%d %H:%M:%S'`
 echo "[$dttm]:: $1"
}

# Check if Input Hosts file parameter is passed or not
if [[ $# -lt 2 ]] ; then
    myecho 'ERROR!! Input Hosts and pw files arguments are required! Aborting...'
    exit 1
fi
INPFILE=$1
PWFILE=$2

# check if input file exists
if [[ ! -f $INPFILE ]] || [[ ! -r $INPFILE ]] ; then
   myecho "ERROR! Input Hosts file missing or not readable [$INPFILE]"
   exit 1
fi

# check if pw file exists
if [[ ! -f $PWFILE ]] || [[ ! -r $PWFILE ]] ; then
   myecho "ERROR! pw file missing or not readable [$PWFILE]"
   exit 1
fi

set -x
grep -v "#" $INPFILE |while read -r line
do
sshpass -f $PWFILE ssh-copy-id -o StrictHostKeyChecking=no ${USR}@${line}
done
set +x

