#!/bin/bash

function build_srvr_file
{
cat > $TMPFILE <<EOF
fs92prap101
fs92prap102
fs92prap103
fs92prap104
fs92prux101
fs92prux102
fs92prwl101
fs92prwl102
fs92prwl103
fs92prwl104
fs92prwl105
fs92prwl106
hc92prap101
hc92prap102
hc92prap103
hc92prap104
hc92prap105
hc92prap106
hc92prap107
hc92prux101
hc92prux102
hc92prwl101
hc92prwl102
hc92prwl103
hc92prwl104
hc92prwl105
hc92prwl106
EOF

}
TMPFILE=/tmp/al.92prd.$$
build_srvr_file
date
while read -r line
do
echo "Checking $line"
bolt command run 'echo `hostname`;grep "^cny*" /etc/passwd' -t $line --no-host-key-check --connect-timeout 60 --tty
done < $TMPFILE
echo " "
date

