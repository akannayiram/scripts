#!/bin/bash

function build_srvr_file
{
cat > $TMPFILE <<EOF
cs92npap051
cs92npux051
fs92npux051
fs92npap051
hc92npux051
hc92npap051
ih92npux051
ih92npap051
EOF

}
TMPFILE=/tmp/al.92np.$$
build_srvr_file
while read -r line
do
echo "Checking $line"
bolt command run 'echo `hostname`;grep "^cny*" /etc/passwd' -t $line --no-host-key-check --connect-timeout 60 --tty
done < $TMPFILE
