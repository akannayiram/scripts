#!/bin/bash
scr=build_web_from_etc_hosts.sh

#TMPFILE=/tmp/al.92prf.$$
#build_srvr_file
TMPFILE=$1
scrloc1=/software/akannayiram/bin
scrloc2=/psft/akannayiram/bin
scr1=$scrloc1/$scr
scr2=$scrloc2/$scr
date
while read -r line
do
echo "Checking $line"
scr=$scr1
pillar=`echo $line|cut -c1-3`
[[ $pillar == "fin" ]] && scr=$scr2
[[ $pillar == "prt" ]] && scr=$scr2
[[ $pillar == "crm" ]] && scr=$scr2

bolt command run $scr -t $line --no-host-key-check --connect-timeout 60 --tty
done < $TMPFILE
echo " "
date

