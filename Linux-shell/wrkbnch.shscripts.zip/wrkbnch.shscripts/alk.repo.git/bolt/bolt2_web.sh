#bolt script run gen-rmtweb.sh -t crmnpwl001 --no-host-key-check --connect-timeout 600 --tty
bolt script run gen-rmtweb.sh -t @web_np.txt --no-host-key-check --connect-timeout 600 --tty
