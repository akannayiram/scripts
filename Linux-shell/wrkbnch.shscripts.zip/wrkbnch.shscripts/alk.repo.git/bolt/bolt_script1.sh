#bolt script run gen-rmtssh.sh -t crmnpap001 --no-host-key-check --connect-timeout 600 --tty
bolt script run gen-rmtssh.sh -t @app_np.txt --no-host-key-check --connect-timeout 600 --tty 
