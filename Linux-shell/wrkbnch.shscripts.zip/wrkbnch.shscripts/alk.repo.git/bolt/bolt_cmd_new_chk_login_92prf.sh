#!/bin/bash

#TMPFILE=/tmp/al.92prf.$$
#build_srvr_file
TMPFILE=$1
scr1=/software/akannayiram/bin/grep_etc_passwd.sh
scr2=/psft/akannayiram/bin/grep_etc_passwd.sh
date
while read -r line
do
echo "Checking $line"
scr=$scr1
pillar=`echo $line|cut -c1,3`
if [[ $pillar -eq "prt" ]] ; then
   scr=$scr2
fi
if [[ $pillar -eq "crm" ]] ; then
   scr=$scr2
fi

bolt command run $scr -t $line --no-host-key-check --connect-timeout 60 --tty
done < $TMPFILE
echo " "
date

