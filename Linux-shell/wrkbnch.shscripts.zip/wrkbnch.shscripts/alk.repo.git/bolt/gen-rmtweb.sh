# Grab user names from BBL
SRCHJRE=1.7.0_311
echo ""
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"
echo "=========================================================="
# web server: get ps_home from java process
ps -aef|grep java|grep ps_home|sed -e "s?.*ps_home=??"|sed -e "s# weblogic.Server##"|while read -r PSHOME
do
USR=`echo $PSHOME|awk -F"/" '{print $NF}'`
WEBLOG="$PSHOME//webserv/peoplesoft/servers/PIA/logs/PIA_weblogic.log"
echo ""
echo ""
echo "=========================================================="
echo "USR: $USR"
echo "WEBLOG: $WEBLOG"
echo "=========================================================="
CNT=`grep $SRCHJRE $WEBLOG|wc -l`
if [[ $CNT -gt 0 ]] ; then
   egrep "$SRCHJRE|RUNNING" $WEBLOG|tail -6
else
   echo "ERROR ERROR: $SRCHJRE not found"
fi
done
echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME"
echo "=========================================================="
echo ""
echo ""
