# Grab user names from BBL
SRCHJRE=1.7.0_311
echo ""
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"
echo "=========================================================="
#USR=`ps -aef|grep BBL|grep -v grep|cut -d" "  -f1`
ps -aef|grep BBL|grep -v grep|cut -d" "  -f1|while read -r USR
do
APPDOM=`ps -aef|grep BBL|grep $USR|grep -v grep|sed -e "s?^.*appserv/??"|sed -e "s#/LOGS.*##"`
APPLOGS=`ps -aef|grep BBL|grep $USR|grep -v grep|cut -d"-" -f6|sed -e "s/U //"|sed -e "s#TUXLOG#APPSRV*.LOG#"`
echo ""
echo ""
echo "=========================================================="
echo "USR: $USR"
echo "APPDOM: $APPDOM"
echo "APPLOGS: $APPLOGS"
# get domain name 
APPLOG=`ls -t $APPLOGS|head -1`
echo "APPLOG: $APPLOG "
echo "=========================================================="
CNT=`grep $SRCHJRE $APPLOG|wc -l`
if [[ $CNT -gt 0 ]] ; then
   grep $SRCHJRE $APPLOG|tail -1
else
   echo "ERROR ERROR: $SRCHJRE not found"
fi
done
echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME"
echo "=========================================================="
echo ""
echo ""
