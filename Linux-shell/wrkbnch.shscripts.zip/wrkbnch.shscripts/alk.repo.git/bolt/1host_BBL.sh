bolt command run 'ps -aef|grep BBL|grep -v grep' -t $1 --no-host-key-check --connect-timeout 60 --tty
