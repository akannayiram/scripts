#!/bin/bash
# ######################################
# Who: Al Kannyiram 
# When: 11/17/2021
# What:
#   I'm trying to create a script to validate/deploy JRE/JDK patch
#      - Must sudo to oracle
#      - Copy JRE folder on App/Prcs, JDK folder on Web
#      - Source patch location will be different each time
#      - Target location is always the same:
#           jre: /appl/oracle/jre/
#           jdk: /appl/oracle/jdk/
#      - Remove current symbolic link and create a new symbolic link
# ######################################
# Execute this script with two arguments:
#    <script> <arg1> <arg2>
#       <arg1>: Server List (App, Prcs, Web servers)
#       <arg2>: Validation Script
#########################################
#

# ========================
#    F U N C T I O N S
# ========================
FUNCLIB=/home/akannayiram/bin/global_func.sh
if [[ -x $FUNCLIB ]] ; then
. $FUNCLIB
elif [[ -f $FUNCLIB ]] ; then
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is not executable"
  exit
else
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is missing"
  exit
fi


function check_arguments
{
# Check if input parameter is passed
if [[ $# -eq 0 ]] ; then
   echo "$(echo_color "$0: Missing input parameters" "lred")"
   echo "$(echo_color "$0: Call with two arguments" "lred")"
   echo "$(echo_color "ERROR ERROR...Aborting" "lred")"
   exit
fi

if [[ $# -ne 2 ]] ; then
   echo "$(echo_color "$0: Incorrect input parameters" "lred")"
   echo "$(echo_color "$0: Call with two arguments" "lred")"
   echo "$(echo_color "ERROR ERROR...Aborting" "lred")"
   exit
fi

}


# ========================
#    M A I N
# ========================

# Expect 1 argument: Parmfile containing the servers
check_arguments $@

srvrfile=$1
#srvrfile=/home/akannayiram/servers/prd/prd_web_servers.txt
#srvrfile=/home/akannayiram/servers/prd/by_pillar/app_crm_servers.txt
validate_if_file_exists $srvrfile

scr=$2
#scr=/psft/akannayiram/oct21cpu_scripts/jre1.7_validate.sh
validate_if_script_exists $scr

usr=oracle

   
echo "$(echo_color "Execuing bolt command run $scr -t @$srvrfile --tty" "ld")"

bolt command run "$scr" -t "@$srvrfile" --tty

#bolt command run 'sudo su - oracle -c "/psft/akannayiram/oct21cpu_scripts/jre1.7_validate.sh"' -t '@/home/akannayiram/servers/prd/prd_app_servers.txt' --tty


