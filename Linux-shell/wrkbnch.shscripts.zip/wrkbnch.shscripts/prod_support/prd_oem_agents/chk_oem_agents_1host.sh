bolt command run 'cnt=$(ps -fu oracle|grep oracle.sysman.gcagent.tmmain.TMMain|wc -l);echo "[$HOSTNAME] [$cnt]"' -t "fs92prap101" --tty
