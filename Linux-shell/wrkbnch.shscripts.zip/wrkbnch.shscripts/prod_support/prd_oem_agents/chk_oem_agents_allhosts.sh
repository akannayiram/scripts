bolt command run 'cnt=$(ps -fu oracle|grep oracle.sysman.gcagent.tmmain.TMMain|wc -l);echo "[$HOSTNAME] [$cnt]"' -t "@/home/gjarvis/servers/all_prd_all" --tty
