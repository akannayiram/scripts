#!/bin/bash -x

#TMPFILE=/tmp/al.92prf.$$
#build_srvr_file
TMPFILE=$1
TIER=$2
if [[ "$2" == "app" ]] ; then
  scr1=/software/akannayiram/bin/grep_app_BBL.sh
  scr2=/psft/akannayiram/bin/grep_app_BBL.sh
elif [[ "$2" == "prcs" ]] ; then
  scr1=/software/akannayiram/bin/grep_psunx_BBL.sh
  scr2=/psft/akannayiram/bin/grep_psunx_BBL.sh
else
  echo "ERROR. Incorrect value [$2]. Must be app or prcs"
  exit
fi
date
while read -r line
do
echo "Checking $line"
scr=$scr1
pillar=`echo $line|cut -c1-3`
[[ "$pillar" == "crm" ]] && scr=$scr2
[[ "$pillar" == "prt" ]] && scr=$scr2
[[ "$pillar" == "css" ]] && scr=$scr2

bolt command run $scr -t $line --no-host-key-check --connect-timeout 60 --tty
done < $TMPFILE
echo " "
date

