#!/bin/bash
# ######################################
# Who: Al Kannyiram 
# When: 11/17/2021
# What:
# ######################################
# Execute this script with two arguments:
#    <script> <arg1> <arg2>
#       <arg1>: Server List (App, Prcs, Web servers)
#       <arg2>: Validation Script
#########################################
#

# ========================
#    F U N C T I O N S
# ========================
FUNCLIB=/home/akannayiram/bin/global_func.sh
if [[ -x $FUNCLIB ]] ; then
. $FUNCLIB
elif [[ -f $FUNCLIB ]] ; then
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is not executable"
  exit
else
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is missing"
  exit
fi


function check_arguments
{
# Check if input parameter is passed
if [[ $# -eq 0 ]] ; then
   echo "$(echo_color "$0: Missing input parameters" "lred")"
   echo "$(echo_color "$0: Call with two arguments" "lred")"
   echo "$(echo_color "ERROR ERROR...Aborting" "lred")"
   exit
fi

if [[ $# -ne 1 ]] ; then
   echo "$(echo_color "$0: Incorrect input parameters" "lred")"
   echo "$(echo_color "$0: Call with two arguments" "lred")"
   echo "$(echo_color "ERROR ERROR...Aborting" "lred")"
   exit
fi

}


# ========================
#    M A I N
# ========================

# Expect 1 argument: Parmfile containing the servers
check_arguments $@

srvrfile=$1
#srvrfile=/home/akannayiram/servers/prd/prd_web_servers.txt
#srvrfile=/home/akannayiram/servers/prd/by_pillar/app_crm_servers.txt
validate_if_file_exists $srvrfile

scr=/psft/akannayiram/misc/grep_appsrvlog.sh

while read -r line
do
 hostnm=`echo $line|awk '{print $1}'`
 usr=`echo $line|awk '{print $3}'`
# dom=`echo $line|awk '{print $4}'`
# cmmnd="egrep \"23658899|23794424|23816071|23926168|23930647|24009840|24094464|24183948|24187495|24187495\" ./appserv/${dom}/LOGS/APPSRV_1230.LOG"  
#  echo "Cmd: [$cmmnd]"
#echo "$(echo_color "Execuing bolt command run sudo su - $usr -c $cmmnd -t $hostnm --tty" "ld")"

bolt command run "sudo su - $usr -c $scr" -t $hostnm --no-host-key-check --tty

#bolt command run 'sudo su - oracle -c "/psft/akannayiram/oct21cpu_scripts/jre1.7_validate.sh"' -t '@/home/akannayiram/servers/prd/prd_app_servers.txt' --tty
done < $srvrfile

