#!/bin/bash
script1=/home/akannayiram/bin/grep_ect_passwd_as_alk.sh
[[ ! -f $1 ]] && { echo "Input file [$1] missing. Aborting..."; exit; }
[[ ! -x $script1 ]] && { echo "Script [$script1] missing. Aborting..."; exit; }

inpfile=$1

#bolt script run gen-rmtssh.sh -t crmnpap001 --no-host-key-check --connect-timeout 600 --tty
bolt script run $script1 -t @$inpfile --no-host-key-check --connect-timeout 60 --tty 
