bolt command run 'ps -aef|grep BBL|grep -v grep' -t @np_app_servers.txt --no-host-key-check --connect-timeout 60 --tty
bolt command run 'ps -aef|grep BBL|grep -v grep' -t @np_psunx_servers.txt --no-host-key-check --connect-timeout 60 --tty
