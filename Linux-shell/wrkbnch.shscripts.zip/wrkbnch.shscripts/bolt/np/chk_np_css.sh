/home/akannayiram/bolt/np/1host_BBL.sh cssnpap001.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh cssnpap002.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh cssnpux002.cf.cuny.edu
