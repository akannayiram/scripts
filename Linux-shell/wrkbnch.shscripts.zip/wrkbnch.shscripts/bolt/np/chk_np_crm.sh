/home/akannayiram/bolt/np/1host_BBL.sh crmnpap001.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh crmnpap002.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh crmnpux001.cf.cuny.edu
