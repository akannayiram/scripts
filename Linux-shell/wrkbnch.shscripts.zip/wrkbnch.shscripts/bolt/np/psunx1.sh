bolt command run 'sudo su - oracle -c "cd /appl/oracle/jre; cp -p -r /psft/patches/july21cpu/jre1.7.0_311 ."' -t finprux101 --no-host-key-check --connect-timeout 600 --tty
