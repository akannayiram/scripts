/home/akannayiram/bolt/np/1host_BBL.sh finnpap001.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh finnpap002.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh finnpux001.cf.cuny.edu
