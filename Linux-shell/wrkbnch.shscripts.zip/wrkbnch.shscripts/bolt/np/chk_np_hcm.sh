/home/akannayiram/bolt/np/1host_BBL.sh hcmnpap001.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh hcmnpap002.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh hcmnpux001.cf.cuny.edu
