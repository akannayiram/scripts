/home/akannayiram/bolt/np/1host_BBL.sh prtnpap001.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh prtnpap002.cf.cuny.edu
/home/akannayiram/bolt/np/1host_BBL.sh prtnpux001.cf.cuny.edu
