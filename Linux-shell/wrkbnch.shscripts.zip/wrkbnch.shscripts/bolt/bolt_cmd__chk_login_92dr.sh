#!/bin/bash

TMPFILE=$1
date
while read -r line
do
echo "Checking $line"
bolt command run 'echo `hostname`;grep "^cny*" /etc/passwd' -t $line --no-host-key-check --connect-timeout 60 --tty
done < $TMPFILE
echo " "
date

