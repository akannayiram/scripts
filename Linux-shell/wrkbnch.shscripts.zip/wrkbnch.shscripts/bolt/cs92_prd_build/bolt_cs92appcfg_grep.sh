#!/bin/bash
# ######################################
# Who: Al Kannyiram 
# When: 2/9/2022
# What:
#   List parameters from psappsrv.cfg
# ######################################

srvrfile=/home/akannayiram/servers/92prd/prd_app_cs92_servers.txt
script1=/software/akannayiram/cs92_prod_pshome_copy/grep_appcfg.sh

usr=cnycsprd


bolt command run "sudo su - $usr -c $script1" -t "@$srvrfile" --tty


