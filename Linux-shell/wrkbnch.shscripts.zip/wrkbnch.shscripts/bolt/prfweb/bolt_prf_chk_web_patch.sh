#!/bin/bash
SCRIPTDIR=/software/akannayiram/workarea/prfweb
SCRIPT=prf_chk_web_patch.sh
usr=oracle
#bolt command run "sudo su - $usr -c "${SCRIPTDIR}/${SCRIPT}" -t @inpfile --no-host-key-check --tty
# For testing on 1 host
tgthost=ihpfwl306
bolt command run "sudo su - $usr -c ${SCRIPTDIR}/${SCRIPT}" -t $tgthost --no-host-key-check --tty --connect-timeout 60 --debug

