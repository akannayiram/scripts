echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"
echo "=========================================================="
HOST=`echo $HOSTNAME|cut -d"." -f1`
# web server: get ps_home from java process
cat /etc/hosts|grep cny|grep -v grep|while read -r line
do
ip=`echo $line|sed "s/  / /g"|sed "s#^ ##"|awk '{print $1}'`
usr=`echo $line|sed "s/  / /g"|sed "s#^ ##"|awk '{print $2}'`
echo "webserver on $HOST in $usr http://${ip}:8080/biphealth.html   $line"
done
echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME"
echo "=========================================================="
echo ""
