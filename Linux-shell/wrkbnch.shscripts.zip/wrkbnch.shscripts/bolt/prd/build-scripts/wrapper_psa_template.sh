# ###################################################
#  PeopleSoft App, Prcs Domains
#     - Start/Stop/Status script
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 09/10/2021 Al Kannayiram    Initial develoment
#
# ###################################################

# ========================
#    F U N C T I O N S
# ========================
FUNCLIB=./global_psa_func.sh
if [[ -x $FUNCLIB ]] ; then
. $FUNCLIB
elif [[ -f $FUNCLIB ]] ; then
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is not executable"
  exit
else
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is missing"
  exit
fi
  
# ========================
#    M A I N 
# ========================

check_arguments "$@"

validate_logdir_psa_if_exists

# Call the function with TGTHOST DMTYPE PSDOM UNXLOGIN ACTION
