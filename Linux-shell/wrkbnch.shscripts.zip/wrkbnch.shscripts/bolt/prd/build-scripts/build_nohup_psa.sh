#
#  Build Stat/Stop/Sttus scripts 
#
APPINP=./build_submit_bolt_app_output.txt
PRCSINP=./build_submit_bolt_prcs_output.txt
TEMPLATE=./wrapper_psa_template.sh
# ###################################################
#  Pillar: 
grep submit build_submit_bolt_app_output.txt|grep CNYCS
#
PILLARS="csspr crmpr finpr hcmpr prtpr"
for i in $PILLARS
do
  SCRIPTOUT=${i}_nohup.sh
  echo "# ###################################################" > $SCRIPTOUT
  echo "#  Pillar: $i" >> $SCRIPTOUT
  cat $TEMPLATE >> $SCRIPTOUT
  echo "#  APP SERVER DOMAINS" >> $SCRIPTOUT
  echo " " >> $SCRIPTOUT
  echo "# #######################################"
  echo $i
  grep $i $APPINP|grep submit|sed "s/^    //"|sort >> $SCRIPTOUT 2>&1
  echo " " >> $SCRIPTOUT
  echo "#  PRCS SCHEDULER DOMAINS" >> $SCRIPTOUT
  grep $i $PRCSINP|grep submit|sed "s/^    //"|sort >> $SCRIPTOUT 2>&1
  echo "#wait_on_pids" >> $SCRIPTOUT
  echo "wait_on_pids_with_timeout" >> $SCRIPTOUT
  echo " " >> $SCRIPTOUT
  echo "get_exec_status" >> $SCRIPTOUT
  echo "# #######################################"
done
