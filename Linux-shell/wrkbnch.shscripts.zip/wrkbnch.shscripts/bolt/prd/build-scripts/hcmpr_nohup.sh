# ###################################################
#  Pillar: hcmpr
# ###################################################
#  PeopleSoft App, Prcs Domains
#     - Start/Stop/Status script
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 09/10/2021 Al Kannayiram    Initial develoment
#
# ###################################################

# ========================
#    F U N C T I O N S
# ========================
FUNCLIB=./global_psa_func.sh
if [[ -x $FUNCLIB ]] ; then
. $FUNCLIB
elif [[ -f $FUNCLIB ]] ; then
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is not executable"
  exit
else
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is missing"
  exit
fi
  
# ========================
#    M A I N 
# ========================

check_arguments "$@"

validate_logdir_psa_if_exists

# Call the function with TGTHOST DMTYPE PSDOM UNXLOGIN ACTION
#  APP SERVER DOMAINS
 
submit_bolt_run hcmprap101 app cnyhcprd CNYHCPR1 $ACTN
submit_bolt_run hcmprap102 app cnyhcprd CNYHCPR1 $ACTN
submit_bolt_run hcmprap103 app cnyhcprd CNYHCPR1 $ACTN
submit_bolt_run hcmprap104 app cnyhcprd CNYHCPR1 $ACTN
submit_bolt_run hcmprap105 app cnyhcprd CNYHCAM1 $ACTN
submit_bolt_run hcmprap106 app cnyhcprd CNYHCIM1 $ACTN
submit_bolt_run hcmprap107 app cnyhcprd CNYHCCM1 $ACTN
submit_bolt_run hcmprap108 app cnyhc003 CNYHC003 $ACTN
 
#  PRCS SCHEDULER DOMAINS
submit_bolt_run hcmprux101 prcs cnyhcprd CNYHCPR1 $ACTN
submit_bolt_run hcmprux101 prcs cnyhcprd CNYHCPR2 $ACTN
submit_bolt_run hcmprux102 prcs cnyhcprd CNYHCPR1 $ACTN
submit_bolt_run hcmprux102 prcs cnyhcprd CNYHCPR2 $ACTN
submit_bolt_run hcmprux103 prcs cnyhc003 CNYHC003 $ACTN
#wait_on_pids
wait_on_pids_with_timeout
 
get_exec_status
