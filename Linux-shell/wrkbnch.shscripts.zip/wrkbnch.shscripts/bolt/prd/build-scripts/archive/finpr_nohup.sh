# ###################################################
#  Pillar: finpr
# ###################################################
#  PeopleSoft App, Prcs Domains
#     - Start/Stop/Status script
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 09/10/2021 Al Kannayiram    Initial develoment
#
# ###################################################

# ========================
#    F U N C T I O N S
# ========================
FUNCLIB=./global_psa_func.sh
if [[ -x $FUNCLIB ]] ; then
. $FUNCLIB
elif [[ -f $FUNCLIB ]] ; then
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is not executable"
  exit
else
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is missing"
  exit
fi
  
# ========================
#    M A I N 
# ========================

check_arguments "$@"

validate_logdir_psa_if_exists

# Call the function with TGTHOST DMTYPE PSDOM UNXLOGIN ACTION
#  APP SERVER DOMAINS
 
submit_bolt_run finprap101 app cnyfsprd CNYFSPR1 $ACTN
submit_bolt_run finprap102 app cnyfsprd CNYFSPR1 $ACTN
submit_bolt_run finprap103 app cnyfsprd CNYFSAM1 $ACTN
submit_bolt_run finprap104 app cnyfsprd CNYFSIM1 $ACTN
submit_bolt_run finprap105 app cnyfs001 CNYFS001 $ACTN
 
#  PRCS SCHEDULER DOMAINS
submit_bolt_run finprux101 prcs cnyfsprd CNYFSPR1 $ACTN
submit_bolt_run finprux102 prcs cnyfsprd CNYFSPR1 $ACTN
submit_bolt_run finprux103 prcs cnyfs001 CNYFS001 $ACTN
#wait_on_pids
wait_on_pids_with_timeout
 
get_exec_status
