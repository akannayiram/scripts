# ###################################################
#  Pillar: prtpr
# ###################################################
#  PeopleSoft App, Prcs Domains
#     - Start/Stop/Status script
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 09/10/2021 Al Kannayiram    Initial develoment
#
# ###################################################

# ========================
#    F U N C T I O N S
# ========================
FUNCLIB=./global_psa_func.sh
if [[ -x $FUNCLIB ]] ; then
. $FUNCLIB
elif [[ -f $FUNCLIB ]] ; then
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is not executable"
  exit
else
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is missing"
  exit
fi
  
# ========================
#    M A I N 
# ========================

check_arguments "$@"

validate_logdir_psa_if_exists

# Call the function with TGTHOST DMTYPE PSDOM UNXLOGIN ACTION
#  APP SERVER DOMAINS
 
submit_bolt_run prtprap101 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap102 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap103 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap104 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap105 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap106 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap107 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap108 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap109 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap110 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap111 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap112 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap113 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap114 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap115 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap116 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap117 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap118 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap119 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap120 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap121 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap122 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap123 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap124 app cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprap125 app cnyepprd CNYEPAM1 $ACTN
submit_bolt_run prtprap126 app cnyepprd CNYEPIM1 $ACTN
 
#  PRCS SCHEDULER DOMAINS
submit_bolt_run prtprux101 prcs cnyepprd CNYEPPR1 $ACTN
submit_bolt_run prtprux102 prcs cnyepprd CNYEPPR1 $ACTN
#wait_on_pids
wait_on_pids_with_timeout
 
get_exec_status
