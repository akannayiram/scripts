# ###################################################
#  Pillar: csspr
# ###################################################
#  PeopleSoft App, Prcs Domains
#     - Start/Stop/Status script
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 09/10/2021 Al Kannayiram    Initial develoment
#
# ###################################################

# ========================
#    F U N C T I O N S
# ========================
FUNCLIB=./global_psa_func.sh
if [[ -x $FUNCLIB ]] ; then
. $FUNCLIB
elif [[ -f $FUNCLIB ]] ; then
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is not executable"
  exit
else
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is missing"
  exit
fi
  
# ========================
#    M A I N 
# ========================

check_arguments "$@"

validate_logdir_psa_if_exists

# Call the function with TGTHOST DMTYPE PSDOM UNXLOGIN ACTION
#  APP SERVER DOMAINS
 
submit_bolt_run cssprap101 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap102 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap103 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap104 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap105 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap106 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap107 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap108 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap109 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap110 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap111 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap112 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap113 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap114 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap115 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap116 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap117 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap118 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap119 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap120 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap121 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap122 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap123 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap124 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap125 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap126 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap127 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap128 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap129 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap130 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap131 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap132 app cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprap133 app cnycsprd CNYCSIM1 $ACTN
submit_bolt_run cssprap134 app cnycsprd CNYCSAM1 $ACTN
submit_bolt_run cssprap135 app cnycsprd CNYCSSL1 $ACTN
submit_bolt_run cssprap136 app cnycsprd CNYCSSL2 $ACTN
submit_bolt_run cssprap137 app cnycsprd CNYCSSL3 $ACTN
submit_bolt_run cssprap138 app cnycsprd CNYCSCM1 $ACTN
submit_bolt_run cssprap138 app cnycsprd CNYCSCM1 $ACTN
submit_bolt_run cssprap138 app cnycsprd CNYCSRR1 $ACTN
submit_bolt_run cssprap138 app cnycsprd CNYCSRR1 $ACTN
submit_bolt_run cssprap139 app cnycsprd CNYCSCM1 $ACTN
submit_bolt_run cssprap139 app cnycsprd CNYCSCM1 $ACTN
submit_bolt_run cssprap139 app cnycsprd CNYCSRR1 $ACTN
submit_bolt_run cssprap139 app cnycsprd CNYCSRR1 $ACTN
submit_bolt_run cssprap140 app cnyhcup1 CNYHCUP1 $ACTN
 
#  PRCS SCHEDULER DOMAINS
submit_bolt_run cssprux101 prcs cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprux101 prcs cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprux101 prcs cnycsprd CNYCSPR2 $ACTN
submit_bolt_run cssprux101 prcs cnycsprd CNYCSPR2 $ACTN
submit_bolt_run cssprux102 prcs cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprux102 prcs cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprux102 prcs cnycsprd CNYCSPR2 $ACTN
submit_bolt_run cssprux102 prcs cnycsprd CNYCSPR2 $ACTN
submit_bolt_run cssprux103 prcs cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprux103 prcs cnycsprd CNYCSPR1 $ACTN
submit_bolt_run cssprux103 prcs cnycsprd CNYCSPR2 $ACTN
submit_bolt_run cssprux103 prcs cnycsprd CNYCSPR2 $ACTN
submit_bolt_run cssprux104 prcs cnyhcup1 CNYHCUP1 $ACTN
#wait_on_pids
wait_on_pids_with_timeout
 
get_exec_status
