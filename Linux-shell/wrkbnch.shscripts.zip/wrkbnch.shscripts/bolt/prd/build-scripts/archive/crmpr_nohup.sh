# ###################################################
#  Pillar: crmpr
# ###################################################
#  PeopleSoft App, Prcs Domains
#     - Start/Stop/Status script
#
# When       Who              Why/What
# ---------- ---------------- ---------------------------
# 09/10/2021 Al Kannayiram    Initial develoment
#
# ###################################################

# ========================
#    F U N C T I O N S
# ========================
FUNCLIB=./global_psa_func.sh
if [[ -x $FUNCLIB ]] ; then
. $FUNCLIB
elif [[ -f $FUNCLIB ]] ; then
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is not executable"
  exit
else
  echo "ERROR! ERROR!! [$FUNCLIB]: Function Script is missing"
  exit
fi
  
# ========================
#    M A I N 
# ========================

check_arguments "$@"

validate_logdir_psa_if_exists

# Call the function with TGTHOST DMTYPE PSDOM UNXLOGIN ACTION
#  APP SERVER DOMAINS
 
submit_bolt_run crmprap101 app cnycmprd CNYCMPR1 $ACTN
submit_bolt_run crmprap102 app cnycmprd CNYCMPR1 $ACTN
submit_bolt_run crmprap103 app cnycmprd CNYCMAM1 $ACTN
submit_bolt_run crmprap104 app cnycmprd CNYCMCM1 $ACTN
 
#  PRCS SCHEDULER DOMAINS
submit_bolt_run crmprux101 prcs cnycmprd CNYCMPR1 $ACTN
#wait_on_pids
wait_on_pids_with_timeout
 
get_exec_status
