# Call the function with TGTHOST DMTYPE PSDOM UNXLOGIN ACTION
#submit_bolt_run crmnpap001 app cnycmdm2 CNYCMDM2 $ACTN

# Grab user names from BBL
DMTYPE=app
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"
echo "=========================================================="
HOST=`echo $HOSTNAME|cut -d"." -f1`
#USR=`ps -aef|grep BBL|grep -v grep|cut -d" "  -f1`
ps -aef|grep BBL|grep -v grep|cut -d" "  -f1|sort -u|while read -r USR
do

# Handle cases when multtiple domains are run by a single user
#APPDOM=`ps -aef|grep BBL|grep $USR|grep -v grep|sed -e "s?^.*appserv/??"|sed -e "s#/LOGS.*##"`
ps -aef|grep BBL|grep $USR|grep -v grep|while read -r BBLPROCESS
do
APPDOM=`echo $BBLPROCESS|sed -e "s?^.*appserv/??"|sed -e "s#/LOGS.*##"`
#appdomain=`echo $APPDOM | tr '[:upper:]' '[:lower:]'`
#echo ""
#echo ""
#echo "=========================================================="
echo "HOST: $HOST USR: $USR  APPDOM: $APPDOM "
echo "submit_bolt_run $HOST $DMTYPE $USR $APPDOM \$ACTN"
#echo "=========================================================="
done
done
echo "=========================================================="
echo "END Hostname: $HOSTNAME"
echo "=========================================================="
echo ""
