nohup ./bolt_get_webjava.sh > nohup_bolt_get_webjava.out 2>&1 &
