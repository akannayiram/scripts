WEBSRV=/home/akannayiram/servers/prd/prd_web_servers.txt
#bolt script run gen-rmtssh.sh -t crmnpap001 --no-host-key-check --connect-timeout 600 --tty
bolt script run get_web_oemtext.sh -t @$WEBSRV --no-host-key-check --connect-timeout 20 --tty 
