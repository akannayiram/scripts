echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"
echo "=========================================================="
HOST=`echo $HOSTNAME|cut -d"." -f1`
# web server: get ps_home from java process
ps -aef|grep java|grep ps_home|sed -e "s?.*ps_home=??"|sed -e "s# weblogic.Server##"|while read -r PSHOME
do
USR=`echo $PSHOME|awk -F"/" '{print $NF}'`
echo ""
echo "=========================================================="
echo "HOST: $HOST   USR: $USR"   
echo "=========================================================="
done
echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME"
echo "=========================================================="
echo ""
