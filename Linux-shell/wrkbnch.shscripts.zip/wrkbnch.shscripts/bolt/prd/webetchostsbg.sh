nohup ./bolt_get_webetchosts.sh > nohup_bolt_get_webetchosts.out 2>&1 &
