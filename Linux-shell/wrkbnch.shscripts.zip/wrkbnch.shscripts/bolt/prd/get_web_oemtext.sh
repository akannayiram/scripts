echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"
echo "=========================================================="
HOST=`echo $HOSTNAME|cut -d"." -f1`
# web server: get ps_home from java process
#cat /etc/hosts|grep cny|grep 85|grep -v grep
 
cat /etc/hosts|grep cny|grep -v grep|while read -r line
do
ip=`echo $line|sed "s/  / /g"|sed "s#^ ##"|awk '{print $1}'`
usr=`echo $line|sed "s/  / /g"|sed "s#^ ##"|awk '{print $2}'`
last3=`echo $usr|cut -c8-`
#echo "/etc/hosts entry: $line"
case $last3 in
   "csa"|"csb"|"csc"|"csd")
      txt="CSS OAM fronted"
      ;;
    "csi")
      txt="CSS Backdoor"
      ;;
    "csy")
      txt="CSS Reporting"
      ;;
    "csz")
      txt="CSS Gateway"
      ;;
   "cma"|"cmb"|"cmc"|"cmd")
      txt="CRM OAM fronted"
      ;;
    "cmi")
      txt="CRM Backdoor"
      ;;
    "cmy")
      txt="CRM Reporting"
      ;;
    "cmz")
      txt="CRM Gateway"
      ;;
   "fsa"|"fsb"|"fsc"|"fsd")
      txt="FIN OAM fronted"
      ;;
    "fsi")
      txt="FIN Backdoor"
      ;;
    "fsy")
      txt="FIN Reporting"
      ;;
    "fsz")
      txt="FIN Gateway"
      ;;
   "hca"|"hcb"|"hcc"|"hcd")
      txt="HCM OAM fronted"
      ;;
    "hci")
      txt="HCM Backdoor"
      ;;
    "hcy")
      txt="HCM Reporting"
      ;;
    "hcz")
      txt="HCM Gateway"
      ;;
   "epa"|"epb"|"epc"|"epd")
      txt="PRT OAM fronted"
      ;;
    "epi")
      txt="PRT Backdoor"
      ;;
    "epy")
      txt="PRT Reporting"
      ;;
    "epz")
      txt="PRT Gateway"
      ;;
esac
echo "$txt webserver on $HOST in $usr http://${ip}:8080/biphealth.html   $line"
#echo "$txt webserver on $HOST in $usr"
#echo "http://${ip}:8080/biphealth.html"
done
#echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME"
echo "=========================================================="
echo ""
