# Grab user names from BBL
echo ""
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"
echo "=========================================================="
HOST=`echo $HOSTNAME|cut -d"." -f1`
#USR=`ps -aef|grep BBL|grep -v grep|cut -d" "  -f1`
ps -aef|grep BBL|grep -v grep|cut -d" "  -f1|while read -r USR
do
#APPDOM=`ps -aef|grep BBL|grep $USR|grep -v grep|sed -e "s?^.*appserv/??"|sed -e "s#/LOGS.*##"`
APPDOM=`ps -aef|grep BBL|grep $USR|grep -v grep|awk '{print $18}'|sed -e "s#/LOGS.*$*##"`
appcfg=$APPDOM/psappsrv.cfg
if [[ -r $appcfg ]] ; then
   grep "^DBName=" $appcfg
else
  echo "Not found $appcfg"
fi
#echo ""
#echo ""
#echo "=========================================================="
echo "USR: $USR  APPDOM: $APPDOM    appcfg: $appcfg"
#echo "=========================================================="
done
echo "=========================================================="
echo "END Hostname: $HOSTNAME"
echo "=========================================================="
echo ""
echo ""
