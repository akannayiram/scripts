inp=$1
WEBSRV=/home/akannayiram/servers/prd/prd_web_servers.txt
APPSRV=/home/akannayiram/servers/prd/prd_app_servers.txt
PRCSSRV=/home/akannayiram/servers/prd/prd_psunx_servers.txt
#srvr=$APPSRV
srvr=$PRCSSRV
#bolt script run gen-rmtssh.sh -t crmnpap001 --no-host-key-check --connect-timeout 600 --tty

# comment this line for single host runs
#bolt script run $1 -t @$srvr --no-host-key-check --connect-timeout 20 --tty 



# Reporting App server: (Prod)
# comment these linefor multiple hosts input file above
singlehost=hcmprap108.cf.cuny.edu
bolt script run $1 -t $singlehost --no-host-key-check --connect-timeout 20 --tty 
singlehost=finprap105.cf.cuny.edu
bolt script run $1 -t $singlehost --no-host-key-check --connect-timeout 20 --tty 
singlehost=cssprap140.cf.cuny.edu
bolt script run $1 -t $singlehost --no-host-key-check --connect-timeout 20 --tty 
