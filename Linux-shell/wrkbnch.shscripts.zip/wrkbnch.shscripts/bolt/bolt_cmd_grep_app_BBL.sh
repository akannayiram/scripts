#!/bin/bash

#TMPFILE=/tmp/al.92prf.$$
#build_srvr_file
TMPFILE=$1
scr1=/software/akannayiram/bin/grep_app_BBL.sh
scr2=/psft/akannayiram/bin/grep_app_BBL.sh
date
while read -r line
do
echo "Checking $line"
scr=$scr1
pillar=`echo $line|cut -c1-3`
[[ $pillar -eq "crm" ]] && scr=$scr2
[[ $pillar -eq "prt" ]] && scr=$scr2
[[ $pillar -eq "crm" ]] && scr=$scr2

bolt command run $scr -t $line --no-host-key-check --connect-timeout 60 --tty
done < $TMPFILE
echo " "
date

