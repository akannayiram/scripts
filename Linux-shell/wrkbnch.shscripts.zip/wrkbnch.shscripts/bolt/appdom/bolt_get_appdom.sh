APPSRV=/home/akannayiram/servers/prd/prd_app_servers.txt
#bolt script run gen-rmtssh.sh -t crmnpap001 --no-host-key-check --connect-timeout 600 --tty
bolt script run get_appdom.sh -t @$APPSRV --no-host-key-check --connect-timeout 20 --tty 
