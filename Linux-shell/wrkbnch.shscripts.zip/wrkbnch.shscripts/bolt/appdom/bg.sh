nohup ./bolt_get_appdom.sh > nohup_bolt_get_appdom.out 2>&1 &
