# Grab user names from BBL
echo ""
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"
echo "=========================================================="
HOST=`echo $HOSTNAME|cut -d"." -f1`
#USR=`ps -aef|grep BBL|grep -v grep|cut -d" "  -f1`
ps -aef|grep BBL|grep -v grep|cut -d" "  -f1|while read -r USR
do
APPDOM=`ps -aef|grep BBL|grep $USR|grep -v grep|sed -e "s?^.*appserv/??"|sed -e "s#/LOGS.*##"`
appdomain=`echo $APPDOM | tr '[:upper:]' '[:lower:]'`
#echo ""
#echo ""
#echo "=========================================================="
echo "USR: $USR  APPDOM: $APPDOM    appdomain: $appdomain"
echo "./appcheckcreate.sh $appdomain $HOST"
#echo "=========================================================="
done
echo "=========================================================="
echo "END Hostname: $HOSTNAME"
echo "=========================================================="
echo ""
echo ""
