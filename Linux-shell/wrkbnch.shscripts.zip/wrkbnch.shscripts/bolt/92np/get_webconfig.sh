echo ""
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"   Login: $USER
echo "=========================================================="
echo "From configuration.properties"
egrep "^psserver=|^WebProfile=" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties
echo "From integrationGateway.properties"
grep DE2 ./webserv/peoplesoft/applications/peoplesoft/PSIGW.war/WEB-INF/integrationGateway.properties
echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME"
echo "=========================================================="
echo ""
echo ""
