#!/bin/bash -x

function build_srvr_file
{
cat > $TMPFILE <<EOF
cs92npap051
cs92npux051
fs92npux051
fs92npap051
hc92npux051
hc92npap051
ih92npux051
ih92npap051
EOF

}

function build_pslogin_file
{
cat > $TMPFILE2 <<EOF
cs92npap051 cnycsde2
cs92npux051 cnycsde2
fs92npux051 cnyfsde2
fs92npap051 cnyfsde2
hc92npux051 cnyhcde2
hc92npap051 cnyhcde2
ih92npux051 cnyihde2
ih92npap051 cnyihde2
EOF

}

TMPFILE=/tmp/alk.92np.$$
TMPFILE2=/tmp/alk.2.92np.$$
#build_srvr_file
build_pslogin_file
while read -r line
do
host=`echo $line|awk '{print $1}'`
pslogin=`echo $line|awk '{print $2}'`
echo "Processing [$line]   Host: [$host]   Ps Login: [$pslogin]"
bolt command run "sudo su - $pslogin -c \"pwd;ls -l\"" -t $host --no-host-key-check --connect-timeout 60 --tty
done < $TMPFILE2
