# IH
bolt command run 'sudo su - cnydih858a -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t ih92npwl050 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydih858b -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t ih92npwl050 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydih858y -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t ih92npwl051 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydih858z -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t ih92npwl051 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydih858z -c "grep DE2 ./webserv/peoplesoft/applications/peoplesoft/PSIGW.war/WEB-INF/integrationGateway.properties"' -t ih92npwl051 --no-host-key-check --connect-timeout 20 --tty



# FS
bolt command run 'sudo su - cnydfs858a -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t fs92npwl050 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydfs858b -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t fs92npwl050 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydfs858y -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t fs92npwl051 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydfs858z -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t fs92npwl051 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydfs858z -c "grep DE2 ./webserv/peoplesoft/applications/peoplesoft/PSIGW.war/WEB-INF/integrationGateway.properties"' -t fs92npwl051 --no-host-key-check --connect-timeout 20 --tty



# HC
bolt command run 'sudo su - cnydhc858a -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t hc92npwl050 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydhc858b -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t hc92npwl050 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydhc858y -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t hc92npwl051 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydhc858z -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t hc92npwl051 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydhc858z -c "grep DE2 ./webserv/peoplesoft/applications/peoplesoft/PSIGW.war/WEB-INF/integrationGateway.properties"' -t hc92npwl051 --no-host-key-check --connect-timeout 20 --tty



# CS
bolt command run 'sudo su - cnydcs858a -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t cs92npwl050 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydcs858b -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t cs92npwl050 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydcs858y -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t cs92npwl051 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydcs858z -c "egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties"' -t cs92npwl051 --no-host-key-check --connect-timeout 20 --tty
bolt command run 'sudo su - cnydcs858z -c "grep DE2 ./webserv/peoplesoft/applications/peoplesoft/PSIGW.war/WEB-INF/integrationGateway.properties"' -t cs92npwl051 --no-host-key-check --connect-timeout 20 --tty



