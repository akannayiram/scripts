/home/akannayiram/bolt/1host_BBL.sh cs92npap050
#/home/akannayiram/bolt/1host_BBL.sh cs92npap051
/home/akannayiram/bolt/1host_BBL.sh cs92npux050
#/home/akannayiram/bolt/1host_BBL.sh cs92npux051
