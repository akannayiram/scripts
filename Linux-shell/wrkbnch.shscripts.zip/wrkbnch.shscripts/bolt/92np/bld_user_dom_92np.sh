#!/bin/bash -x

APP92=/home/akannayiram/servers/92np/92np_app_full.txt
PSUNX92=/home/akannayiram/servers/92np/92np_psunx_full.txt
SCRDIR=/software/akannayiram/bin
SCR=$SCRDIR/build_appprcs_host_user_dom.sh


while read -r line
do
bolt command run $SCR  -t $line --no-host-key-check --connect-timeout 60 --tty
done < $APP92


while read -r line
do
bolt command run $SCR  -t $line --no-host-key-check --connect-timeout 60 --tty
done < $PSUNX92
