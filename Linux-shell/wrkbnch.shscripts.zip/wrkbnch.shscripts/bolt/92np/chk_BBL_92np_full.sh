#!/bin/bash -x

APP92=/home/akannayiram/servers/92np/92np_app_full.txt
PSUNX92=/home/akannayiram/servers/92np/92np_psunx_full.txt
SCRDIR=/software/akannayiram/bin
APPSCR=$SCRDIR/grep_app_BBL.sh
PSUNXSCR=$SCRDIR/grep_psunx_BBL.sh


while read -r line
do
bolt command run $APPSCR  -t $line --no-host-key-check --connect-timeout 60 --tty
#/home/akannayiram/bolt/1host_BBL.sh $line
done < $APP92


while read -r line
do
bolt command run $PSUNXSCR  -t $line --no-host-key-check --connect-timeout 60 --tty
#/home/akannayiram/bolt/1host_BBL.sh $line
done < $PSUNX92
