#!/bin/bash -x
cs92npwl050
cs92npwl051
fs92npwl051
fs92npwl050
hc92npwl050
hc92npwl051
ih92npwl050
ih92npwl051

function build_srvr_file
{
cat > $TMPFILE <<EOF
cs92npwl050
cs92npwl051
fs92npwl051
fs92npwl050
hc92npwl050
hc92npwl051
ih92npwl050
ih92npwl051
EOF

}

function build_pslogin_file
{
cat > $TMPFILE2 <<EOF
cs92npwl050 cnydcs858a
cs92npwl050 cnydcs858b
cs92npwl051 cnydcs858y
cs92npwl051 cnydcs858z
fs92npwl051 cnydfs858y
fs92npwl051 cnydfs858y
fs92npwl050 cnydfs858a
fs92npwl050 cnydfs858b
hc92npwl050 cnydhc858a
hc92npwl050 cnydhc858b
hc92npwl051 cnydhc858y
hc92npwl051 cnydhc858z
ih92npwl050 cnydih858a
ih92npwl050 cnydih858b
ih92npwl051 cnydih858y
ih92npwl051 cnydih858z
EOF

}

TMPFILE=/tmp/alk.92np.$$
TMPFILE2=/tmp/alk.2.92np.$$
#build_srvr_file
build_pslogin_file
while read -r line
do
host=`echo $line|awk '{print $1}'`
pslogin=`echo $line|awk '{print $2}'`
echo "Processing [$line]   Host: [$host]   Ps Login: [$pslogin]"
bolt command run "sudo su - $pslogin -c \'egrep \"^psserver=|^WebProfile=\" ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties\'" -t $host --no-host-key-check --connect-timeout 20 --tty
bolt command run "sudo su - $pslogin -c \'grep \"CNY..DE2\" ./webserv/peoplesoft/applications/peoplesoft/PSIGW.war/WEB-INF/integrationGateway.properties\'" -t $host --no-host-key-check --connect-timeout 20 --tty
done < $TMPFILE2
