#bolt command run 'ps -aef|grep BBL|grep -v grep' -t @np_app_servers.txt --no-host-key-check --connect-timeout 60 --tty
#bolt command run 'ps -aef|grep BBL|grep -v grep' -t @np_psunx_servers.txt --no-host-key-check --connect-timeout 60 --tty
hcm=/home/akannayiram/servers/prf/prf_hcm_app_psunx.txt
fin=/home/akannayiram/servers/prf/prf_fin_app_psunx.txt
bolt command run 'ls -l /appl/oracle/jre' -t @${hcm} --no-host-key-check --connect-timeout 60 --tty
bolt command run 'ls -l /appl/oracle/jre' -t @${fin} --no-host-key-check --connect-timeout 60 --tty
