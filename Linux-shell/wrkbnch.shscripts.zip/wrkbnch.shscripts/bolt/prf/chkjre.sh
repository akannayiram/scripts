# check jre
echo "Check jre by $USER"
#sudo su - oracle -c "id;cd /appl/oracle/jre/;ls -l"
sudo su - oracle -c "ls -l"
