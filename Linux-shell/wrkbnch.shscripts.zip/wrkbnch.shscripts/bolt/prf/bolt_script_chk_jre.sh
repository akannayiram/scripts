#bolt command run 'ps -aef|grep BBL|grep -v grep' -t @np_app_servers.txt --no-host-key-check --connect-timeout 60 --tty
#bolt command run 'ps -aef|grep BBL|grep -v grep' -t @np_psunx_servers.txt --no-host-key-check --connect-timeout 60 --tty
hcm=/home/akannayiram/servers/prf/prf_hcm_app_psunx.txt
fin=/home/akannayiram/servers/prf/prf_fin_app_psunx.txt
#bolt command run 'ls -l /appl/oracle/jre' -t @${hcm} --no-host-key-check --connect-timeout 60 --tty
#bolt command run 'ls -l /appl/oracle/jre' -t @${fin} --no-host-key-check --connect-timeout 60 --tty

# use this format to execute 'bolt script'
#bolt script run psa.sh -t cssnpap001.cf.cuny.edu --no-host-key-check --connect-timeout 600 --tty --u $USER cnyhc005 start app CNYHC005
#bolt script run ./chkjre.sh -t @${fin} --no-host-key-check --connect-timeout 60 --tty --u $USER 
#bolt script run 'sudo su - oracle ./chkjre.sh' -t @${fin} --no-host-key-check --connect-timeout 60 --tty --u $USER 
bolt command run 'sudo su - oracle ./chkjre.sh' -t @${fin} --no-host-key-check --connect-timeout 60 --tty --u $USER 

