cd /appl/oracle/jre
cp -p -r /software/patches/92SepMX/jre-jdk/jre1.8.0_301 .
rm -f jre1.8_64bit
ln -s jre1.8.0_301 jre1.8_64bit
