inp=$1
# Build mkdir commands
cat $inp |awk '{print "mkdir -p " $2}'
# Build ln -s commands
cat $inp |awk '{print "ln -s " $2 " " $1}'
