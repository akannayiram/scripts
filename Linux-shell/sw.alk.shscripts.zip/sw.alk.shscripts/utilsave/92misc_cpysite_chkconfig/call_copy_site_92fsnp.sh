#!/bin/bash
if [[ ! $HOSTNAME =~ fs ]] || [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on FS NP Web servers"
   exit
fi
for i in `grep cnyd /etc/hosts |grep 858|awk  '{print $2}'`
do
sudo su - $i -c "/software/akannayiram/92misc/copy_site_92np.sh fs"
done
