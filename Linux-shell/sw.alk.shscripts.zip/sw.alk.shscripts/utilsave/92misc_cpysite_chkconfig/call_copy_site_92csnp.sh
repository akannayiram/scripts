#!/bin/bash
src_site=cnycsdm2
tgt_site=cnycsrpu
if [[ ! $HOSTNAME =~ cs ]] || [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on CS NP Web servers"
   exit
fi
for i in `grep cnyd /etc/hosts |grep 858|awk  '{print $2}'`
do
sudo su - $i -c "/software/akannayiram/92misc/copy_site_92np.sh $src_site $tgt_site"
done
