ls -l ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cny??de2/configuration.properties
ls -l ./webserv/peoplesoft/applications/peoplesoft/PSIGW.war/WEB-INF/integrationGateway.properties

