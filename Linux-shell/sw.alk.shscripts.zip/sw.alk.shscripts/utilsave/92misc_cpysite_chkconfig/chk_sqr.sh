#!/bin/bash
TMPFILE=/tmp/usrs$$.txt
cat <<!EOF >> $TMPFILE
cnyhcrpu
cnyhcug1
cnyhcdm2
cnyhcug2
!EOF
#cat $TMPFILE
srch=fghr021*.sq?
#srch=psappsrv.cfg
while read -r line
do
  homedir=`cat /etc/passwd|grep $line|cut -d":" -f6`
  echo "Login: $line  Home: $homedir  Search: $srch"
  sudo su - $line -c "find $homedir -name "$srch" -type f"  
done < $TMPFILE  
rm -f $TMPFILE
