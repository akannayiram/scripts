src_pshome=/appl/psft/dm2/cs920
#tgt_pshome=/appl/psft/rpu/cs920
tgt_pshome=/appl/psft/rpu
src_app_domain=CNYCSDM2
src_prcs_domain=CNYCSDM2
#rsync -av -n --progress $src_pshome $tgt_pshome --exclude appserv/$src_app_domain --exclude appserv/prcs/$src_prcs_domain
rsync -av --progress $src_pshome $tgt_pshome --exclude appserv/$src_app_domain --exclude appserv/prcs/$src_prcs_domain
