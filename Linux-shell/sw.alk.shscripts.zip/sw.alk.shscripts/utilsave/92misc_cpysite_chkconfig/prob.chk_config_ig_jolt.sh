#!/bin/bash -x
# ####################################################
# - pass two character pillar in lowercase
# - Search psserver in configuration.properties
#   and PSFT Jolt entries for *DE2 in integrationGateway.properties
#      ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war
# ####################################################
function build_script 
{
cat > $TMPFILE <<EOF
PORTAL_BASE="./webserv/peoplesoft/applications/peoplesoft/PORTAL.war"
PSIGW_BASE="./webserv/peoplesoft/applications/peoplesoft/PSIGW.war"
src_site=cny${pillar}de2
node=CNY${pillar}DE2
configcfg=${PORTAL_BASE}/WEB-INF/psftdocs/${src_site}/configuration.properties
igprop=${PSIGW_BASE}/WEB-INF/integrationGateway.properties


echo " Hostname: $HOSTNAME    User: $USER    Pillar: $pillar"

if [[ ! -f ${configcfg} ]] ; then
   echo "[$dttm] ERROR! ERROR!! Config [${configcfg}] does not exist"
   echo "[$dttm] Exiting the script"
   exit
fi

if [[ -f ${igprop} ]] ; then
   echo "[$dttm] ERROR! ERROR!! IG Prop [${igprop}] exists"
   echo "[$dttm] Exiting the script"
   exit
fi

echo "ls -l configcfg"
ls -l ${configcfg}
grep "^psserver=" ${configcfg}

echo "ls -l igprop"
ls -l ${igprop}
grep ${node} ${igprop}
echo "##########################################"
EOF
}


dttm=`date '+%Y-%m-%d_%H:%M:%S'`

# Check if input parameter is passed
if [[ $# -eq 0 ]] ; then
   echo "Input parameter is required"
   exit
fi

TMPFILE=/tmp/al.92np.chkwebcfg.$$
pillar=$1
build_script
chmod +x $TMPFILE

if [[ ! $HOSTNAME =~ $pillar ]] || [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on pillar specific NP Web servers"
   exit
fi
for i in `grep cnyd /etc/hosts |grep 858|awk  '{print $2}'`
do
sudo su - $i -c "$TMPFILE $pillar"
done

#rm -f $TMPFILE
