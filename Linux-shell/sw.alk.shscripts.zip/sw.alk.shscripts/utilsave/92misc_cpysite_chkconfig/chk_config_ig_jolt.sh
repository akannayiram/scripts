#!/bin/bash
# ####################################################
# - pass two character pillar in lowercase
# - Search psserver in configuration.properties
#   and PSFT Jolt entries for *DE2 in integrationGateway.properties
#      ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war
# ####################################################

dttm=`date '+%Y-%m-%d_%H:%M:%S'`

# Check if input parameter is passed
if [[ $# -eq 0 ]] ; then
   echo "[$dttm]: Input parameter is required"
   exit
fi

pillar=$1
PILLAR=`echo $pillar|tr [a-z] [A-Z]`

PORTAL_BASE="./webserv/peoplesoft/applications/peoplesoft/PORTAL.war"
PSIGW_BASE="./webserv/peoplesoft/applications/peoplesoft/PSIGW.war"
src_site=cny${pillar}de2
node=CNY${PILLAR}DE2
configcfg=${PORTAL_BASE}/WEB-INF/psftdocs/${src_site}/configuration.properties
igprop=${PSIGW_BASE}/WEB-INF/integrationGateway.properties

echo " Hostname: $HOSTNAME    User: $USER    Pillar: $pillar"

if [[ ! -f ${configcfg} ]] ; then
   echo "[$dttm] ERROR! ERROR!! Config [${configcfg}] does not exist"
   echo "[$dttm] Exiting the script"
   exit
fi

if [[ ! -f ${igprop} ]] ; then
   echo "[$dttm] ERROR! ERROR!! IG Prop [${igprop}] exists"
   echo "[$dttm] Exiting the script"
   exit
fi
echo "-----------"
echo "psserver in $configcfg"
#ls -l ${configcfg}
grep "^psserver=" ${configcfg}
echo "-----------"

echo " "
echo "-----------"
echo "Node[CNY..DE2] entries in ${igprop}"
#grep ${node} ${igprop}
#echo grep "CNY..DE2" ${igprop}
grep CNY..DE2 ${igprop}
echo "-----------"
echo "##########################################"
