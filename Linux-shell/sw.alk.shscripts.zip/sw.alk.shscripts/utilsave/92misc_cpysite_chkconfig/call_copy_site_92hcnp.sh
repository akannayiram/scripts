#!/bin/bash
if [[ ! $HOSTNAME =~ hc ]] || [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on HC NP Web servers"
   exit
fi
for i in `grep cnyd /etc/hosts |grep 858|awk  '{print $2}'`
do
sudo su - $i -c "/software/akannayiram/92misc/copy_site_92np.sh hc"
done
