#!/bin/bash
# ####################################################
#  This script was called from 
#  NOT A STANDALONE SCRIPT
# - pass two character pillar in lowercase
# - Then copy the 'dm2' site to de2 site
# - Create a constant PORTAL_BASE
#      ./webserv/peoplesoft/applications/peoplesoft/PORTAL.war
# - Create two variables and intialize
#   $site_base_dir to $PORTAL_BASE/cny${pillar}de2
#    $site_res_dir  to $PORTAL_BASE/WEB-INF/psftdocs/cny${pillar}de2
# ####################################################
src_site=$1
tgt_site=$2
PORTAL_BASE="./webserv/peoplesoft/applications/peoplesoft/PORTAL.war"
src_site_base_dir=$PORTAL_BASE/$src_site
src_site_res_dir=$PORTAL_BASE/WEB-INF/psftdocs/$src_site

tgt_site_base_dir=$PORTAL_BASE/${tgt_site}
tgt_site_res_dir=$PORTAL_BASE/WEB-INF/psftdocs/${tgt_site}
dttm=`date '+%Y-%m-%d_%H:%M:%S'`
echo ""
echo "======================================================================="
date
echo " Hostname: $HOSTNAME    User: $USER    Source site: $src_site    Target site: $tgt_site"
echo "======================================================================="

if [[ ! -d $PORTAL_BASE ]] ; then
   echo "[$dttm] ERROR! ERROR!! Portal [$PORTAL_BASE] does not exist"
   echo "[$dttm] Exiting the script"
   exit
fi

if [[ ! -d $src_site_base_dir ]] ; then
   echo "[$dttm] ERROR! ERROR!! Source [$src_site_base_dir] does not exist"
   echo "[$dttm] Exiting the script"
   exit
fi

if [[ ! -d $src_site_res_dir ]] ; then
   echo "[$dttm] ERROR! ERROR!! Source [$src_site_res_dir] does not exist"
   echo "[$dttm] Exiting the script"
   exit
fi

if [[ -d $tgt_site_base_dir ]] ; then
   echo "[$dttm] ERROR! ERROR!! Target [$tgt_site_base_dir] exists"
   echo "[$dttm] Exiting the script"
   exit
fi

if [[ -d $tgt_site_res_dir ]] ; then
   echo "[$dttm] ERROR! ERROR!! Target [$tgt_site_res_dir] exists"
   echo "[$dttm] Exiting the script"
   exit
fi
echo "ls -ld src_site_base_dir src_site_res_dir"
ls -ld $src_site_base_dir $src_site_res_dir

echo "cp -p -r $src_site_base_dir $tgt_site_base_dir"
cp -p -r $src_site_base_dir $tgt_site_base_dir
echo "cp -p -r $src_site_res_dir  $tgt_site_res_dir"
cp -p -r $src_site_res_dir  $tgt_site_res_dir

echo "ls -ld tgt_site_base_dir tgt_site_res_dir"
ls -ld $tgt_site_base_dir $tgt_site_res_dir
echo ""
echo "======================================================================="
echo ""
