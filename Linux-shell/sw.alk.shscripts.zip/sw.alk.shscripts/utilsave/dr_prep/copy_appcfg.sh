#!/bin/bash
# Find the app domain directory
tagetdir=/software/akannayiram/dr_prep/prdcfg
#tagetdir=/software/akannayiram/dr_prep/drcfg
hostnm=$(echo $HOSTNAME|cut -d"." -f1)
for domdir in `find $HOME -name "CNY*" -type d`
do
  echo "domdir: [$domdir]"
  dom=$(basename $domdir)
  echo "domdir: [$domdir] dom: [$dom]"
  psappsrvpath=`find $domdir -maxdepth 1 -name psappsrv.cfg`
  echo "psappsrvpath: [$psappsrvpath]"
#  psappsrvfile=$(basename $psappsrvpath)
  if [[ -f $psappsrvpath ]] ; then
     #cp $psappsrvpath $tagetdir/${HOSTNAME}.${USER}.${dom}.psappsrv_cfg.txt
     cp $psappsrvpath $tagetdir/${hostnm}.${USER}.${dom}.psappsrv.cfg.txt
  else
     echo "ERROR ERROR [$psappsrvpath] is worng. check the script"
  fi
done

