#!/bin/bash
# ####################################
# This sript was cretaed for cnyihpr2
# Defined variables at the beginning and change these values
#   for any other environment/pillar (al kannayiram jan 2022)
# ####################################


# ------------------
# Begin - Env specific variables
# ------------------
pillar2chr=ih
srcdir=/software/Custom/web/cnyihpr2
site=cnyihprd
# ------------------
# End - Env specific variables
# ------------------


echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME    User: $USER "
echo "=========================================================="

if [[ ! $HOSTNAME =~ ${pillar2chr}pfwl ]] ; then
   echo "Wrong host. Run on [$pillar2chr] PERF Web servers"
   exit
fi

PORTAL_DIR=$HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war
psftdocs_site=$PORTAL_DIR/WEB-INF/psftdocs/${site}
sitehome=$PORTAL_DIR/${site}
imagedir=$sitehome/images


# Check if Source and Target directories exist
[[ ! -d $srcdir ]] && { echo "[$srcdir] is missing. Aborting...."; exit; }
[[ ! -d $PORTAL_DIR ]] && { echo "[$PORTAL_DIR] is missing. Aborting...."; exit; }
[[ ! -d $psftdocs_site ]] && { echo "[$psftdocs_site] is missing. Aborting...."; exit; }
[[ ! -d $imagedir ]] && { echo "[$imagedir] is missing. Aborting...."; exit; }

# Display Environment details
echo "Site: [$site]  Source dir: [$srcdir]"

# Copy only when custome files don't exist already
if [[ ! -f $psftdocs_site/cu_cookiesrequired.html ]] ; then
   echo "Copying $srcdir/psftdocs/cu_cookiesrequired.html to $psftdocs_site/"
   cp -p $srcdir/psftdocs/cu_cookiesrequired.html  $psftdocs_site/
else
   echo "Custom file [$psftdocs_site/cu_cookiesrequired.html] already exists"
fi

if [[ ! -f $psftdocs_site/cu_exception.html ]] ; then
   echo "Copying] $srcdir/psftdocs/cu_exception.html to $psftdocs_site/"
   cp -p $srcdir/psftdocs/cu_exception.html  $psftdocs_site/
else
   echo "Custom file [$psftdocs_site/cu_exception.html] already exists"
fi

if [[ ! -f $psftdocs_site/cu_expire.html ]] ; then
   echo "Copying] $srcdir/psftdocs/cu_expire.html to $psftdocs_site/"
   cp -p $srcdir/psftdocs/cu_expire.html  $psftdocs_site/
else
   echo "Custom file [$psftdocs_site/cu_expire.html] already exists"
fi

if [[ ! -f $psftdocs_site/cu_expire_oam.html ]] ; then
   echo "Copying] $srcdir/psftdocs/cu_expire_oam.html to $psftdocs_site/"
   cp -p $srcdir/psftdocs/cu_expire_oam.html  $psftdocs_site/
else
   echo "Custom file [$psftdocs_site/cu_expire_oam.html] already exists"
fi

if [[ ! -f $psftdocs_site/cu_signin.html ]] ; then
   echo "Copying] $srcdir/psftdocs/cu_signin.html to $psftdocs_site/"
   cp -p $srcdir/psftdocs/cu_signin.html  $psftdocs_site/
else
   echo "Custom file [$psftdocs_site/cu_signin.html] already exists"
fi

if [[ ! -f $psftdocs_site/cu_signout.html ]] ; then
   echo "Copying] $srcdir/psftdocs/cu_signout.html to $psftdocs_site/"
   cp -p $srcdir/psftdocs/cu_signout.html  $psftdocs_site/
else
   echo "Custom file [$psftdocs_site/cu_signout.html] already exists"
fi

if [[ ! -f $psftdocs_site/cu_signout_oam.html ]] ; then
   echo "Copying] $srcdir/psftdocs/cu_signout_oam.html to $psftdocs_site/"
   cp -p $srcdir/psftdocs/cu_signout_oam.html  $psftdocs_site/
else
   echo "Custom file [$psftdocs_site/cu_signout_oam.html] already exists"
fi

if [[ ! -f $sitehome/cu_signin.css ]] ; then
   echo "Copying] $srcdir/site/cu_signin.css to $sitehome/"
   cp -p $srcdir/site/cu_signin.css  $sitehome/
else
   echo "Custom file [$sitehome/cu_signin.css] already exists"
fi

if [[ ! -f $imagedir/cu_logo_cunyfirst_color.svg ]] ; then
   echo "Copying] $srcdir/site/images/cu_logo_cunyfirst_color.svg to $imagedir/"
   cp -p $srcdir/site/images/cu_logo_cunyfirst_color.svg $imagedir/
else
   echo "Custom file [$imagedir/cu_logo_cunyfirst_color.svg] already exists"
fi


# List the custom files in the Target directory
echo "List the custom files in the Target directory"
ls -l $psftdocs_site/cu_cookiesrequired.html 
 
ls -l $psftdocs_site/cu_exception.html 
 
ls -l $psftdocs_site/cu_expire.html 
 
ls -l $psftdocs_site/cu_expire_oam.html 
 
ls -l $psftdocs_site/cu_signin.html 
 
ls -l $psftdocs_site/cu_signout.html 
   
ls -l $psftdocs_site/cu_signout_oam.html 
   
ls -l $sitehome/cu_signin.css 
 
ls -l $imagedir/cu_logo_cunyfirst_color.svg 

echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME    User: $USER "
echo "=========================================================="
echo ""

