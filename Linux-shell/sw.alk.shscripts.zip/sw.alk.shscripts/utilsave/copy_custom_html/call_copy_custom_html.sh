#!/bin/bash
if [[ ! $HOSTNAME =~ pfwl ]] ; then
   echo "Wrong host. Run on PERF Web servers"
   exit
fi
for i in `grep cnyp /etc/hosts |grep 858|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c /software/akannayiram/copy_custom_html/copy_custom_html.sh  ; echo "on" `cat /etc/hosts |grep $i`
done
