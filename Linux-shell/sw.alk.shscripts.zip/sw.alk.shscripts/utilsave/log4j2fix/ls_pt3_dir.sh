#!/bin/bash
echo "[$HOSTNAME] [$(ls -ld $1)]"
