#!/bin/bash -x
export PS_SERVER_CFG=/appl/psft/prf/fs920/appserv/prcs/CNYFSPF1/psprcs.cfg
INP=$1
INP=/software/akannayiram/92perf/storedsql/dms/alk.dms
DB=CNYFSPR2
USR=APSADM
PSWD=LuMspHfDMAXvVkS7\@BdjKxwO
#PSWD=Im34R5wSfzU62I\*mAjB1K\(61
CONN=people
CPSWD=y6yNFNqJ
psdmtx -CT ORACLE -CD $DB -CO $USR -CP $PSWD -CI $CONN -CW $CPSWD -FP $INP
#psdmtx -CT ORACLE -CD $DB -CO $USR -CP $PSWD -CI $CONN -CW LuMspHfDMAXvVkS7@BdjKxwO -FP $INP
#psdmtx -CT ORACLE -CD $DB -CO $USR -CP $PSWD -CI $CONN -CW Im34R5wSfzU62I*mAjB1K(61 -FP $INP
