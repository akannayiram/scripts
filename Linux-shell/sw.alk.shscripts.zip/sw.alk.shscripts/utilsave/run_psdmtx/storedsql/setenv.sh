export PS_DM_DATA=/software/akannayiram/92perf/storedsql/data
export PS_DM_LOG=/software/akannayiram/92perf/storedsql/log
