#!/bin/bash
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME    User: $USER "
echo "=========================================================="
date

dt=`date '+%Y-%m-%d'`
dttm=`date '+%Y-%m-%d %H:%M:%S'`

srcdir=/software/akannayiram/psemenv_copy_for_oem
scriptname=psemenv.sh
[[ ! -f ${srcdir}/${scriptname} ]] && { echo "${srcdir}/${scriptname} is missing. Aborting....."; exit 1; }
# Check if the psemen.sh already exists 
if [[ -f ./${scriptname} ]] ; then
   echo "[$dttm]:[$HOSTNAME]:[$USER] Moving the original to [${scriptname}.bkup.${dt}]"
   mv ./${scriptname} ./${scriptname}.bkup.${dt}
else
   echo "[$dttm]:[$HOSTNAME]:[$USER] Missing the script [${scriptname}]"
fi
cp -p ${srcdir}/${scriptname} ${scriptname}
chmod 775 ./${scriptname}
ls -l ./${scriptname}

echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME    User: $USER "
echo "=========================================================="
echo ""

