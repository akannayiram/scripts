ORACLE_HOME=/appl/oracle/product/19/client; export ORACLE_HOME
TNS_ADMIN=/psft/env; export TNS_ADMIN
TUXDIR=/appl/oracle/tuxedo/tuxedo12.2.2.0.0; export TUXDIR
LD_LIBRARY_PATH=$TUXDIR/lib:$ORACLE_HOME/lib:$LD_LIBRARY_PATH; export LD_LIBRARY_PATH
PATH=$TUXDIR/bin:$ORACLE_HOME/bin:$PATH; export PATH

if [ -d /appl/oracle/vcob ]
then
  COBDIR=/appl/oracle/vcob; export COBDIR
  PATH=$COBDIR/bin:$PATH; export PATH
  LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$COBDIR/lib; export LD_LIBRARY_PATH
fi

SHLIB_PATH=$LD_LIBRARY_PATH; export SHLIB_PATH
LIBPATH=$LD_LIBRARY_PATH; export LIBPATH

