#!/bin/bash
# ###########################################
# OHS Servers:
# Run-time location Versus staging location 
# Validate runtime files:
#         ssl.conf 
#         admin.conf 
#         httpd.conf 
#         webgate.conf 
# -----------------------------------
#  Al Kannayiram 9/12/2023
# ###########################################

#set -x

# functions
check_file () {
 inpfile=$1
 err=0
 echo "============================================================"
 echo "Checking [$inpfile]"
 echo "======================"
 [[ ! -f ${STGLOC}/${inpfile} ]] && { echo "ERROR [$inpfile] missing at [$STGLOC]" ; err=1; }
 [[ ! -f ${RUNLOC}/${inpfile} ]] && { echo "ERROR [$inpfile] missing at [$RUNLOC]" ; err=1; }
 
 [[ $err -eq 0 ]] && compare_files $inpfile

}

compare_files () {
 inpfile=$1
 echo "======================"
 echo "Comparing [$inpfile] in Stage Vs Instance"
 echo "======================"
 #echo "############################################################"
 diff -w ${STGLOC}/${inpfile} ${RUNLOC}/${inpfile}
 echo "############################################################"
}


grep_ssl_conf () {

 inpfile=$1
# -------------
#  Remove the hostname from the VirtualHost line and add a * in its place.
#        <VirtualHost *:4443>
#
#  Comment out the SSLWallet line and below it add the following:
#        SSLWallet "/appl/oracle/wallet"
#
# Comment out the following lines:
#   # Add the following directive to add HSTS
#   #<IfModule mod_headers.c>
#   #   Header always set Strict-Transport-Security "max-age=63072000; preload; includeSubDomains"
#   #</IfModule>
# ---------------
grep -n -E "VirtualHost|SSLWallet" $inpfile

grep -n -B 1 -A 3 "IfModule mod_headers.c" $inpfile

}


grep_admin_conf () {

 inpfile=$1
# -------------
# Update the serverName line: 
# ServerName ohs92prf03.cf.cuny.edu {actual hostname} 
#
# Comment out the SSLWallet line and add the following below it: 
# SSLWallet "/appl/oracle/wallet" 
# -------------
grep -n -E "ServerName|SSLWallet" $inpfile

}

grep_httpd_conf () {

 inpfile=$1
# -------------
# uncomment the following line: 
# #LoadModule proxy_wstunnel_module ${PRODUCT_HOME}/modules/mod_proxy_wstunnel.so 
# 
echo "Enure that proxy_wstunnel_module line is commented out"
grep -n  "proxy_wstunnel_module" $inpfile

# Add the following third line after these existing first two: 
# LogFormat "%h %l %u %t %E \"%r\" %>s %b \"%{Referer}i\" \"%{User-Agent}i\"" combined 
# LogFormat "%h %l %u %t %E \"%r\" %>s %b" common 
# LogFormat "%{X-Forwarded-For}i %h %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-Agent}i\" **%T/%D**" showMicroseconds 
# 
echo "Enure that third LogFormat line exists and contains X-Forwarded-For"
grep -n  "proxy_wstunnel_module" $inpfile

# Update the mpm_event_module section with these key values: 
# (Al K: The following values are for production and performance. 
# NP (UAT and SIT) environments will have lower values for StartServers, StartServers etc.) 
# 
# <IfModule mpm_event_module> 
#     StartServers              10 
#     ServerLimit              128 
#     ThreadLimit               96 
#     MinSpareThreads          192 
#     MaxSpareThreads          640 
#     ThreadsPerChild           64 
#     MaxRequestWorkers       8192 
#     MaxConnectionsPerChild 10000 
#     AsyncRequestWorkerFactor   2 
#     Mutex fcntl:${ORACLE_INSTANCE}/servers/${COMPONENT_NAME}/logs 
# </IfModule> 
# 
echo "Enure that mpm_event_module has correct values (non-default to be added - Al K)"
grep -n  "proxy_wstunnel_module" $inpfile

# Change timeout from 60 to 300: 
# Timeout 300 
# 
echo "Ensure that Timeout was changed from 60 to 300"
grep -n  "^Timeout" $inpfile

# Find the following line:  
# 
# HostnameLookups Off 
# … and add this line after it: 
# LimitRequestFieldSize 12288 
# 
echo "Enure that LimitRequestFieldSize line exists after the HostnameLookups line"
grep -n -E -B 1  "LimitRequestFieldSize|HostnameLookups" $inpfile

# Comment out the following line: 
# 
# Header always set Referrer-Policy "same-origin" 
# 
# Comment out the following line: 
# Header always unset X-Powered-By 
# 
# Comment out the following line: 
# Header setifempty X-Frame-Options SAMEORIGIN 
# 
echo "Enure that these lines are commented out: Referrer-Policy, X-Powered-By, X-Frame-Options"
grep -n  "^Header" $inpfile|grep -E "Referrer-Policy|X-Powered-By|X-Frame-Options"

# Add the following line to the end of the file: 
# include  "webgate.conf" 
# 
# -------------


}



STGLOC=$DOMAIN_HOME/config/fmwconfig/components/OHS/ohs1
RUNLOC=$DOMAIN_HOME/config/fmwconfig/components/OHS/instances/ohs1
date 

grep_ssl_conf $RUNLOC/ssl.conf

#check_file httpd.conf 
#check_file ssl.conf 
#check_file admin.conf 
#check_file webgate.conf 

date
# ################################################
