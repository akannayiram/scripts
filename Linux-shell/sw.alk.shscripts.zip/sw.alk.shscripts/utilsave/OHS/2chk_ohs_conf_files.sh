#!/bin/bash
# ###########################################
# OHS Servers:
# Run-time location Versus staging location 
# Validate these files:
#         ssl.conf 
#         admin.conf 
#         httpd.conf 
#         webgate.conf 
# -----------------------------------
#  Al Kannayiram 9/12/2023
# ###########################################
# functions
check_file () {
 inpfile=$1
 err=0
 echo "============================================================"
 echo "Checking [$inpfile]"
 echo "======================"
 [[ ! -f ${STGLOC}/${inpfile} ]] && { echo "ERROR [$inpfile] missing at [$STGLOC]" ; err=1; } || ls -lh  ${STGLOC}/${inpfile}
 [[ ! -f ${RUNLOC}/${inpfile} ]] && { echo "ERROR [$inpfile] missing at [$RUNLOC]" ; err=1; } || ls -lh  ${RUNLOC}/${inpfile}
 
 [[ $err -eq 0 ]] && compare_files $inpfile

}

# compare_files: Called only the file is present at both STGLOC and RUNLOC
compare_files () {
 inpfile=$1
 echo "======================"
 echo "Comparing [$inpfile] in Stage Vs Instance"
 echo "======================"
 #echo "############################################################"
 diff -w ${STGLOC}/${inpfile} ${RUNLOC}/${inpfile}
 echo "############################################################"
}


STGLOC=$DOMAIN_HOME/config/fmwconfig/components/OHS/ohs1
RUNLOC=$DOMAIN_HOME/config/fmwconfig/components/OHS/instances/ohs1
date 

check_file httpd.conf 
check_file ssl.conf 
check_file admin.conf 
check_file webgate.conf 

date
# ################################################
