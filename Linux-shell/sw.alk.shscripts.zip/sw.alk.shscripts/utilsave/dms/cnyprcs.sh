DB=$1
psdmtx -CT ORACLE -CD $DB -CO sysadm -CP wlbE4Sz6 -FP encrypt_CNYPRCS.dms

