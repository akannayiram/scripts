#!/bin/bash
#
#	Email_Relay_Check.sh
#
#	This script finds all the CUNY email relay servers that resolve
#		to a single DNS name
#	The script then connects to each server and tests if it can setup an email
#		by sending it a from/to address
#	At that point it ends the connection without actually sending an email
#
#	NOTE: Since we have noticed that one or more relays are permenantly ffline,
#		it is better not to hard code the IPs and instead use the DNS lookup
#

email_relay_dns="mail-relay.cuny.edu"

mail_server_port="25"
recipient="test@sierra-cedar.com"
sender="\"CUNYfirst\"<cunyfirst@cuny.edu>"

#
#	Lookup the IPs associated with the email relay DNS
#	Skip the first 5 lines and extract the IP addresses into ips.log
#
rm -f ips.log
nslookup $email_relay_dns | tail -n +5 | grep Addr > ips.log
sed -i 's/Address:\s//g' ips.log

#
#	Loop through the IP addresses
#
cat ips.log | while read mail_server_ip
do

rm -f checkmail.log

#
#	Connect to the mail server and setup the from/to,
#	but exit before including the body data so it does not send an email
#	save session information to checkmail.log
#
nc ${mail_server_ip} ${mail_server_port} << EOF >> checkmail.log
ehlo cuny.edu
mail from:${sender}
rcpt to:${recipient}
quit
EOF

#
#	Check the log for "Recipient ok"
#	If not found, the email relay is not working
#
#	The session log could be checked for additional information, i.e.
#	Could be the unknown 421 error
#		421 4.7.0 ppa3.cuny.edu closing connection
#
count=`cat checkmail.log | grep -ci  'Recipient ok'`
if [[ "$count" -eq "0" ]]
then
	echo "CUNY mail relay" $mail_server_ip "is not OK"
else
	echo "CUNY mail relay" $mail_server_ip "is OK"
fi

done

#
#	File cleanup
#
rm -f ips.log
rm -f checkmail.log

