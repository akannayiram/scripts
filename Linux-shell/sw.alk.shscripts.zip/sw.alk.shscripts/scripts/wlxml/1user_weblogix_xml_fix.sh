#!/bin/bash
# #############################################
# Add the following two lines after the <cookie-domain> line:
#    <cookie-http-only>true</cookie-http-only>
#    <cookie-secure>true</cookie-secure>
#
#  Al Kannayiram 2/29/2024
#
# #############################################
#set -x
dttm=$(date '+%Y-%m-%d %H:%M:%S')
dt=$(date '+%Y-%m-%d')
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME    User: $LOGNAME     $(date)"
echo "=========================================================="

# Uncomment for NON-PROD hosts
[[ ! $HOSTNAME =~ npwl || ! $HOSTNAME =~ 05[01] ]] && { echo "[$dttm]:: Wrong host. Run on NP Web servers"; exit; }


# Uncomment for PERFORMANCE hosts
# [[ ! $HOSTNAME =~ pfwl || ! $HOSTNAME =~ 3[012][0-9] ]] && { echo "[$dttm]:: Wrong host. Run on PERF Web servers"; exit; }


[[ ! $LOGNAME =~ 86 || ! $LOGNAME =~ cny ]] && { echo "[$dttm]:: Wrong User $LOGNAME. Run using service account"; exit; }


# Location of weblogic.xml
wlxml=$PS_CFG_HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/weblogic.xml

[[ ! -w $wlxml ]] && { echo "[$dttm]:: ERROR! Missing file [$wlxml]"; exit; }

# Check the entry  <cookie-http-only> exists in $wlxml
# Check the entry  <cookie-secure> exists in $wlxml

httponly=Y;csecure=Y
[[ $(grep "<cookie-http-only>" $wlxml|wc -l) -eq 0 ]] && httponly=N
[[ $(grep "<cookie-secure>" $wlxml|wc -l) -eq 0 ]] && csecure=N

[[ "$httponly" == "Y" && "$csecure" == "Y" ]] && { echo "Both cookie-http-only and cookie-secure exist already.  Exiting..."; exit; }

echo "[$dttm]:: Making a backup of $wlxml"
cp -p $wlxml $wlxml.b4.httponly.fix.${dt}

if [[ "$httponly" == "N" ]] ; then

   echo "[$dttm]:: Adding <cookie-http-only>true</cookie-http-only> in weblogic.xml"
   sed -i "/cookie-domain/a\  <cookie-http-only>true</cookie-http-only>" $wlxml
fi

if [[ "$csecure" == "N" ]] ; then

   echo "[$dttm]:: Adding <cookie-secure>true</cookie-secure> in weblogic.xml"
   sed -i "/cookie-http-only/a\  <cookie-secure>true</cookie-secure>" $wlxml
fi

echo ""
echo "[$dttm]:: After making the change"
echo ""
echo "[$dttm]:: Difference between before and after httponly fix in weblogic.xml"
diff $wlxml $wlxml.b4.httponly.fix.${dt}
echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME    User: $LOGNAME     $(date)"
echo "=========================================================="
echo ""

