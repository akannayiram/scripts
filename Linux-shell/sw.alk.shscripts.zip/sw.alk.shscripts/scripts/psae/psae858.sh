DB=$1
SCRIPT=$2
PS_HOME=$3
#export PS_HOME
[[ ! -r "$SCRIPT" ]] && { echo "ERROR! [$SCRIPT] is not accessible. Aborting..."; exit; }            
[[ ! -d "$PS_HOME" ]] && { echo "ERROR! [$PS_HOME] is not accessible. Aborting..."; exit; }
[[ ! -x "$PS_HOME/bin/psdmtx" ]] && { echo "ERROR! [$PS_HOME/bin/psdmtx] is not accessible. Aborting..."; exit; }
[[ -f /psft/env/setora19c.env ]] && /psft/env/setora19c.env
export PATH=$PS_HOME/bin:$PATH
export LD_LIBRARY_PATH=$PS_HOME/lib:$LD_LIBRARY_PATH
USR=SYSADM
PSWD=wlbE4Sz6
DM_HOME=/software/akannayiram/scripts/psae
mkdir -p $DM_HOME/log
psdmtx -CT ORACLE  -CD $DB -CO $USR -CP $PSWD -FP $SCRIPT
