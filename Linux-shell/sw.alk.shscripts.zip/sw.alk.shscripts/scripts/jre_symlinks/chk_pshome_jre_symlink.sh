ps -aef|grep BBL|grep -v grep|awk '{print $1 " " $18}'|sed -e "s/appserv.*$/jre/"|while read -r line 
do
  jredir=$(echo $line|awk '{print $2}')
  usr=$(echo $line|awk '{print $1}')
  echo "$usr  $(file $jredir)"
  
done
