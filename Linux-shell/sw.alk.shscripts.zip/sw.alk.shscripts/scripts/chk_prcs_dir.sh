#!/bin/bash 
#set -x 
hst=$(hostname|cut -d"." -f1)
[[ ! $hst =~ npux051 ]] && { echo "ERROR! Wrong host. Must run on xxxxnpux051"; exit; }
grep "^cny" /etc/passwd|grep -E "dem|dmo"|while read -r line 
#grep "^cny" /etc/passwd|grep -E "dev"|while read -r line 
do 
  echo "Processing: $line"
  usr=$(echo $line|cut -d":" -f1)
  homedir=$(echo $line|cut -d":" -f6)
  echo "User: [$usr]   Home: [$homedir]"
  #sudo su - $usr -c "find $homedir -name prcs -type d"
  sudo su - $usr -c "find $homedir/appserv/prcs -mindepth 1 -maxdepth 1 -name CNY* -type d"
  
done
