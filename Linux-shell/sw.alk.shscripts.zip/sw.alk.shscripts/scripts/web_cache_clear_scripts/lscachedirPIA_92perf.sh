#!/bin/bash
if [[ ! $HOSTNAME =~ pfwl ]] ; then
   echo "Wrong host. Run on PERF Web servers"
   exit
fi
for i in `grep cnyp /etc/hosts |grep 858|awk  '{print $2}'|sed -e "s/\r//"`
do
#sudo su - $i -c "ls -ld /appl/oracle/weblogic/$i/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/psftcache/ ; ls -ld /appl/oracle/weblogic/$i/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/*/cache858"  ; echo "on" `cat /etc/hosts |grep $i`
sudo su - $i -c "/software/akannayiram/buildcacheclearPIA_92perf.sh $i" 
echo "# on" `cat /etc/hosts |grep $i`
done
