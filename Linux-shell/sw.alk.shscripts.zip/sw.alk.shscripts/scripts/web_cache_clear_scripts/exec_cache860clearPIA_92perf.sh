#!/bin/bash
if [[ ! $HOSTNAME =~ pfwl ]] ; then
   echo "Wrong host. Run on PERF Web servers"
   exit
fi
for i in `grep cnyp /etc/hosts |grep -v "#"|grep 860|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c /software/akannayiram/buildcache860clearPIA_92perf.sh  ; echo "on" `cat /etc/hosts |grep $i`
done
