#!/bin/bash
#set -x
if [[ ! $HOSTNAME =~ pfwl ]] ; then
   echo "Wrong host. Run on PERF Web servers"
   exit
fi
[[ "$#" -ne 1 ]] && { echo "ERROR ERROR Exiting. "; exit 1; }
usr=$1
PSFTCACHEDIR="/appl/oracle/weblogic/$usr/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/psftcache"
CACHEDIR="/appl/oracle/weblogic/$usr/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/*/cache858"  
if [[ -d  $PSFTCACHEDIR ]] ; then
#   echo "[$PSFTCACHEDIR] exists. Cleared cache"
    echo "sudo su - $usr -c "\""rm -rf $PSFTCACHEDIR/*"\"" "
fi   
#if [[ -d  $CACHEDIR ]] ; then
for j in $(ls -d $CACHEDIR 2>/dev/null) 
do

#   echo "[$CACHEDIR] exists. Cleared cache"
    echo "sudo su - $usr -c "\""rm -rf $j/*"\"" "
done
CACHEDIR2="/appl/oracle/weblogic/$usr/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/*/cache"  
for j in $(ls -d $CACHEDIR2 2>/dev/null) 
do

#   echo "[$CACHEDIR] exists. Cleared cache"
    echo "sudo su - $usr -c "\""rm -rf $j/*"\"" "
done

