#!/bin/bash
#set -x
#if [[ ! $HOSTNAME =~ pfwl ]] ; then
#   echo "Wrong host. Run on PERF Web servers"
if [[ ! $HOSTNAME =~ pfwl && ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on NP or PERF Web servers"
   exit
fi
echo "BEGIN: [$LOGNAME]"; echo " "
#[[ "$#" -ne 1 ]] && { echo "ERROR ERROR Exiting. "; exit 1; }

# Get the cache directrories
for cachedir in $(find $HOME -path "*/PORTAL.war/cny*/cache*" -type d)
do
  echo " "
  echo "Cache Dir: [$cachedir]"
  dirowner=$(ls -ld "$cachedir"|awk '{print $3}')
  [[ "$dirowner" != "$LOGNAME" ]] && { echo "ERROR! ["$dirowner"] not same as [$LOGNAME]"; exit; }
  cachecount=$(ls -ld $cachedir/* 2>/dev/null|wc -l)
  leafnode=$(basename $cachedir)
  echo "BEFORE: Number of objects in [$leafnode]: [$cachecount]"
#  rm -rf $cachedir/*
  cachecount2=$(ls -ld $cachedir/* 2>/dev/null|wc -l)
  ls -d $cachedir
  echo "AFTER: Number of objects in [$leafnode]: [$cachecount2]"
  echo " "
#   echo "[$cachedir] exists. Cleared cache"

done

