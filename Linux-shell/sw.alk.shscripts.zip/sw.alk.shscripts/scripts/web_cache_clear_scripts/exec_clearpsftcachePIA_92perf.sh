#!/bin/bash
if [[ ! $HOSTNAME =~ pfwl ]] ; then
   echo "Wrong host. Run on PERF Web servers"
   exit
fi
for i in `grep cnyp /etc/hosts |grep 858|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c "rm -rf /appl/oracle/weblogic/$i/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/psftcache/*"  ; echo "on" `cat /etc/hosts |grep $i`
done
