#!/bin/bash
# #############################################
#  copy 2 files to PORTAL.war. 
#    PT_NUI_BACK_PRIM_IMG.svg
#    favicon.ico
#  And copy the ico file every site within PORTAL.war
#
#  Al Kannayiram 2/29/2024
#
# #############################################
#set -x
dttm=$(date '+%Y-%m-%d %H:%M:%S')
dt=$(date '+%Y-%m-%d')
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME    User: $LOGNAME     $(date)"
echo "=========================================================="

# Uncomment for NON-PROD hosts
[[ ! $HOSTNAME =~ npwl || ! $HOSTNAME =~ 05[01] ]] && { echo "[$dttm]:: Wrong host. Run on NP Web servers"; exit; }


# Uncomment for PERFORMANCE hosts
# [[ ! $HOSTNAME =~ pfwl || ! $HOSTNAME =~ 3[012][0-9] ]] && { echo "[$dttm]:: Wrong host. Run on PERF Web servers"; exit; }


[[ ! $LOGNAME =~ 86 || ! $LOGNAME =~ cny ]] && { echo "[$dttm]:: Wrong User $LOGNAME. Run using service account"; exit; }

# Source files
srcdir=/software/akannayiram/scripts/wlcopy
favicon=favicon.ico
svg=PT_NUI_BACK_PRIM_IMG.svg

[[ ! -f $srcdir/$favicon ]] && { echo "[$dttm]:: ERROR! Missing file [$srcdir/$favicon]"; exit; }
[[ ! -f $srcdir/$svg ]] && { echo "[$dttm]:: ERROR! Missing file [$srcdir/$svg]"; exit; }


# Location of PORTAL.war
wlportal=$PS_CFG_HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war
#wlportal=./PORTAL.war

[[ ! -d $wlportal && ! -w $wlportal ]] && { echo "[$dttm]:: ERROR! Missing folder [$wlportal]"; exit; }

# Copy if the files do not exist already

[[ ! -f $wlportal/$favicon ]] && { cp -p $srcdir/$favicon $wlportal/$favicon; echo "Copied $favicon"; ls -lh $wlportal/$favicon; }
[[ ! -f $wlportal/$svg ]] && { cp -p $srcdir/$svg $wlportal/$svg; echo "Copied $svg"; ls -lh $wlportal/$svg; }

# Loop thru sites and copy favicon.ico
for site in $(find $wlportal -maxdepth 1 -name "cny*" -type d)
do
  echo "Site: [$site]"
  [[ ! -f $site/$favicon ]] && { cp -p $srcdir/$favicon $site/$favicon; echo "Copied $favicon to $site"; ls -lh $site/$favicon; }
done

echo ""
echo "=========================================================="
echo "END Hostname: $HOSTNAME    User: $LOGNAME     $(date)"
echo "=========================================================="
echo ""

