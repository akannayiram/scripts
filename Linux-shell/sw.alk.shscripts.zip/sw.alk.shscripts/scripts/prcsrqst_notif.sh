#!/bin/bash
PRCSFAILED=/tmp/prcsfailed$$.log
sqlplus -s $USR/$PSWD@$SID << !EOF > $PRCSFAILED
set feed off lines 140 pages 3000
col OPRID for a10 wrap; 
col PRCSTYPE for a20 wrap; 
col PRCSNAME for a15 wrap; 
col STATUS for a10 wrap; 
col START for a24 wrap; 
col END for a24 wrap; 
SELECT A.PRCSINSTANCE
     , A.OPRID
     , A.PRCSTYPE
     , A.PRCSNAME
     , A5X.XLATSHORTNAME "STATUS"
     , TO_CHAR(A.BEGINDTTM, 'MM/DD/YYYY HH:MI:SS AM') "START"
     , TO_CHAR(A.ENDDTTM, 'MM/DD/YYYY HH:MI:SS AM') "END"
FROM SYSADM.PSPRCSRQST A LEFT OUTER JOIN 
       (SELECT * FROM SYSADM.PSXLATITEM TA 
         WHERE TA.FIELDNAME='RUNSTATUS' 
           AND TA.EFF_STATUS = 'A' 
           AND TA.EFFDT = (SELECT MAX(EFFDT) FROM SYSADM.PSXLATITEM TB 
                            WHERE TB.FIELDNAME= 'RUNSTATUS' 
                              AND TA.FIELDVALUE=TB.FIELDVALUE 
                              AND TB.EFF_STATUS = 'A' 
                              AND TB.EFFDT <= SYSDATE)
       ) A5X ON A5X.FIELDVALUE = A.RUNSTATUS AND A5X.FIELDNAME='RUNSTATUS'  
WHERE A.ENDDTTM > SYSDATE - 1
-- AND A.OPRID = 'APSADM'
 AND A5X.XLATSHORTNAME in ('No Success', 'Error');
exit;
!EOF
outcnt=$(cat $PRCSFAILED|wc -l)
if [[ "$outcnt" -gt 0 ]] ; then
   echo "Errors"
 #  exit 1;
else
 echo "No errors"
 #  exit 0;
fi
