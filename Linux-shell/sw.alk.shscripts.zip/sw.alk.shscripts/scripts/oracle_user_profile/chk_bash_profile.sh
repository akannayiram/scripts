#!/bin/bash
# Al Kannayiram
# 9/20/2024
# To check if any PS env variables are set

ptver=pt86014
ptbase=/appl/psft/${ptver}

hst=$(echo $HOSTNAME|cut -d "." -f1)
[[ -z $PS_HOME ]] && pshome="NOT SET" || pshome=$PS_HOME
[[ -z $TUXDIR ]] && tuxdir="NOT SET" || tuxdir=$TUXDIR

[[ -d $ptbase/dpk ]] && dpkdir="Exists" || dpkdir="Missing"
#[[ -d /appl/psft/dpk ]] && psftdpk="Exists" || psftdpk="Missing"
#[[ -L /appl/psft/pt && -d /appl/psft/pt ]] && psftpt="Symlink" || psftpt="Missing"

filesys=$(df -k /appl/psft|tail -1|awk '{print $5}')

echo "$hst  $LOGNAME  PS_HOME:[$pshome] TUXDIR:[$tuxdir] $ptbase/dpk:[$dpkdir] Filesys%:[$filesys]"
