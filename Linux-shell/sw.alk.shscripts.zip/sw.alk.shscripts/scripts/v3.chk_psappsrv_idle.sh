# #####################################################
# To monitor PSAPPSRV processes and 
#    to alert if all but two of them are busy
#   - Al Kannayiram August 2023
# USAGE:
#       /software/scripts/chk_psappsrv_idle.sh <appdomain>
# E.g.
#       /software/scripts/chk_psappsrv_idle.sh CNYFSAM1
#
# #####################################################
#set -x
send_email () 
{
  echo "[$(date '+%m/%d/%Y %H:%M:%S')]: Placeholder for email"

}
# Constants
emaillist="al.kannayiram@sierracedar.com:al.kannayiram@sierracedar.com"
MINPSAPPRV=3
IDLECUTOFF=2
#dttm=$(date '+%m/%d/%Y %H:%M:%S')

# Expect one parameter: App server domain name
[[ $# -ne 1 ]] && { echo "[$(date '+%m/%d/%Y %H:%M:%S')]: ERROR! App Server Domain name is required. Exiting......"; exit 1; }
# set the app server domain name
dom=$1

# Exit if the domain is not running
cnt=$(ps -aef|grep BBL|grep -v grep|sed -e "s#^.*-U ##"|grep $dom|wc -l)
[[ $cnt -ne 1 ]] && { echo "[$(date '+%m/%d/%Y %H:%M:%S')]: ERROR! App Server Domain [$dom] is not running. Please check. Exiting......"; exit 1; }

# Exit when the Count of PSAPPSRV is < Min
appcnt=$(ps -aef|grep $dom|grep PSAPPSRV|wc -l)
[[ $appcnt -lt $MINPSAPPRV ]] && { echo "[$(date '+%m/%d/%Y %H:%M:%S')]: ERROR! Count of PSAPPRV is [$appcnt]. Too low. Please check. Exiting......"; exit 1; }

# capture psadmin output in tmp file for parsing
ststmp=/tmp/${dom}.$$
# Loop until psadmin has produced valid output
loopcnt=1
while true; do
  rm -f $ststmp
  echo q|psadmin -c sstatus -d $dom 2>&1 |grep PSAPPSRV > $ststmp 2>&1
  appcnt=$(grep PSAPPSRV $ststmp|wc -l)
  [[ $appcnt -gt 1 ]] && break ;
  loopcnt=$((loopcnt + 1))
  echo "[$(date '+%m/%d/%Y %H:%M:%S')]: Attempt: [$loopcnt]. Trying psadmin again...."
  sleep 2
done

# Parse the output and look for not IDLE status
idlecnt=0
busycnt=0
while read -r line
do
  sts=$(echo $line|awk '{print $8 }')
  if [[ "$sts" == "IDLE" ]] ; then
	  idlecnt=$((idlecnt + 1))
  else
	  busycnt=$((busycnt + 1))
  fi
done < $ststmp

# if both idlecnt and busycnt are zeros, then tmadmin issue and no status output
# Just dump the contents of the $ststmp
if [[ $idlecnt == 0 ]] && [[ $busycnt == 0 ]] ; then
   echo "[$(date '+%m/%d/%Y %H:%M:%S')]: WARNING: Both Idle and Busy counts zeros."
   echo "[$(date '+%m/%d/%Y %H:%M:%S')]: WARNING: Server status may not have worked. Dumping the contents of the output."
   cat $ststmp
   exit 1
fi

[[ $idlecnt -le $IDLECUTOFF ]] && { echo "[$(date '+%m/%d/%Y %H:%M:%S')]: ALERT! ALERT! Idle PSAPPSRV count [$idlecnt] is too low."; send_email; exit 1; }

echo "[$(date '+%m/%d/%Y %H:%M:%S')]: No issues. PSAPPSRV Idle count: [$idlecnt]"

# delete the tmp file
rm -f $ststmp
