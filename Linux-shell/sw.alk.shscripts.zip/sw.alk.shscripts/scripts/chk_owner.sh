#!/bin/bash 
#set -x 
hst=$(hostname|cut -d"." -f1)
domown=$(find $HOME/appserv -maxdepth 3 -name CNY????? -type d -exec ls -ld {} \;)
homeown=$(ls -ld $HOME)
#echo "Host: [$hst] Login: [$LOGNAME]  HOME: [$homeown]  Domain: [$domown]"
echo "[$hst] [$LOGNAME] [$homeown] [$domown]"
  
