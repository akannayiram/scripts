#!/bin/bash
# To get App server domains on prod servers (for SW monitoring)

# Must run on App servers
[[ ! $HOSTNAME =~ prap ]] && { echo "ERROR! Must run on Prod App servers"; exit; }

envdb="NULL"
[[ $HOSTNAME =~ cs92prap ]] && envdb="CNYCSPRD"
[[ $HOSTNAME =~ fs92prap ]] && envdb="CNYFSPRD"
[[ $HOSTNAME =~ hc92prap ]] && envdb="CNYHCPRD"
[[ $HOSTNAME =~ ihprap ]] && envdb="CNYIHPRD"

hst=$(echo $HOSTNAME|awk -F"." '{print $1}')
[[ $(find $HOME/appserv -name "CNY*" -type d |wc -l) -eq 0 ]] && { echo "ERROR: [$envdb]  [$hst]: No domains found"; exit; }

for dom in $(find $HOME/appserv -name "CNY*" -type d -exec basename {} \;)
do
  echo -e "$envdb \t $hst - $dom"
done

