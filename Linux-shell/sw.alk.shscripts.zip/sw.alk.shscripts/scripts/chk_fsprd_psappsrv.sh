# #####################################################
# To monitor PSAPPSRV processes and to if all of them are busy
#   - Al Kannayiram August 2023
# #####################################################
#set -x

# set the app server domain name
dom=CNYFSAM1
dttm=$(date '+%m/%d/%Y %H:%M:%S')

# chk if the domain is running
ps -aef|grep BBL|grep -v grep|sed -e "s#.*/appserv/##"|sed -e 's#/LOGS.*$##'|while read -r line
do 
  [[ ! "$line" == "$dom" ]] && { echo "[$dttm]: ERROR! [$dom] not found. Exiting..."; exit 1; }
done

# chk if running on Prod App server
hst=$(hostname|cut -d"." -f1)
[[ ! $hst =~ prap ]] && { echo "[$dttm]: ERROR! Run on prod app server. Exiting..."; exit 1; }

# capture psadmin output in tmp file for parsing
ststmp=/tmp/$dom.$$
rm -f $ststmp
echo q|psadmin -c sstatus -d $dom |grep PSAPPSRV > $ststmp 2>&1

# Parse the output and look for not IDLE status
cnt=$(cat $ststmp|wc -l)
[[ $cnt -eq 0 ]] && { echo "[$dttm]: ERROR! PSAPPSRV service count: [$cnt]. Exiting..."; exit 1; }

idlecnt=0
busycnt=0
while read -r line
do
  sts=$(echo $line|awk '{print $8 }')
  if [[ "$sts" == "IDLE" ]] ; then
	  idlecnt=$((idlecnt + 1))
  else
	  busycnt=$((busycnt + 1))
  fi
done < $ststmp

[[ $idlecnt -eq 0 ]] && { echo "[$dttm]: ALERT! ALERT! PSAPPSRV are all busy. Busy count: [$busycnt] "; exit 1; }

echo "[$dttm]: No issues. PSAPPSRV Idle count: [$idlecnt]"

# delete the tmp file
rm -f $ststmp
