#!/bin/bash
# ##############################
# After copying the PIA PS_HOME from ose user to another user
#   For example from 'a' user to 'b' user etc.
# This script is useful to find out the files/scripts that contain the source username
# The 'sed' command in the script below, just prints the lines that were changed.
# The second the 'sed' command is used to make the changes in-place
#     - Al Kannayiram (Oct 2022)
#################################
srcusr=$1
cnt=$(grep $srcusr /etc/hosts|wc -l)
[[ $cnt -ne 1 ]] && { echo "ERROR! invalid user; not found in /etc/hosts"; exit 1; }
tgtusr=$USER
workdir=$2
[[ ! -d $workdir ]] && { echo "ERROR! Not a directory [$workdir]"; exit 1; }
cd $workdir 
echo "Working dir: $workdir"
ls -lh
for filenm in $(grep $srcusr *|cut -d":" -f1|sort -u)
do

  echo "Filename: $filenm"
  # print just the changed lines; good for debugging
  sed -n -e "s/$srcusr/$tgtusr/gp" $filenm

  # Make the changes in-place
  sed -i -e "s/$srcusr/$tgtusr/g" $filenm 

  # Check again. There should not be any match and the output should be empty
  sed -n -e "s/$srcusr/$tgtusr/gp" $filenm

done 
