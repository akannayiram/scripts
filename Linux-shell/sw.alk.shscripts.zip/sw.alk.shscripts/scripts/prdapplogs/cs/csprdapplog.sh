#!/bin/bash

# ####################################
# To identify which app server has the PIA trace file:
#    Script to list APSADM*tracesql
#    and also to list today's APPSRV_MMDD.LOG
# Al Kannayiram, October 2024
# ####################################

scr=/software/akannayiram/scripts/prdapplogs/cs/listapplog.sh

# Build CS prod app server list
tmpfl=/tmp/cs92prdapp.$$.tmp;rm -f $tmpfl
for i in {101..132}
do
  echo cs92prap${i} >> $tmpfl
done

bolt command run "sudo su - cnycsprd -c $scr" -t @$tmpfl --no-host-key-check --tty
