#!/bin/bash

#set -x
#inp=prf_cs_32hosts.txt
#str="fatal|error|exception"
#logfile=/appl/psft/cfg/cnycsprf/appserv/CNYCSPR1/LOGS/APPSRV_0916.LOG
#bolt command run 'sudo su - cnycsprf -c "grep -n -i -E $str $logfile"' -t @"$inp" --tty 
#bolt command run "sudo su - cnycsprf -c \"grep -n -i -E \"$str\" $logfile\"" -t "csspfap301" --tty 

mmdd=$(date '+%m%d')
APPLOG=APPSRV_$(date '+%m%d').LOG

out1=$(ls -ld $PS_CFG_HOME/appserv/CNYCSPR1/LOGS/${APPLOG})
out2=$(ls -ld $PS_CFG_HOME/appserv/CNYCSPR1/LOGS/APSADM*tracesql)
hst=$(echo $HOSTNAME|cut -d"." -f1)
echo "HOST:[$hst] [$out1] [$out2]"
