#!/bin/bash

# ####################################
# To identify which server as the trace:
# Script to list APSADM*tracesql
# and also to list today's APPSRV_MMDD.LOG
#
# ####################################

#set -x

scr=/software/akannayiram/scripts/prdapplogs/cs/listapplog.sh
mmdd=$(date '+%m%d')
APPLOG=APPSRV_$(date '+%m%d').LOG

# Build CS prod app server list
tmpfl=/tmp/cs92prdapp.$$.tmp;rm -f $tmpfl
for i in {101..132}
do
  echo cs92prap${i} >> $tmpfl
done



#bolt command run 'sudo su - cnycsprd -c "ls -ld \$PS_CFG_HOME/appserv/CNYCSPR1/LOGS/\${APPLOG};ls -ld \$PS_CFG_HOME/appserv/CNYCSPR1/LOGS/APSADM*tracesql"' -t @$tmpfl --no-host-key-check --tty
bolt command run "sudo su - cnycsprd -c $scr" -t @$tmpfl --no-host-key-check --tty
