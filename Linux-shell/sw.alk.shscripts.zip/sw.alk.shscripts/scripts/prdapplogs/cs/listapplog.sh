#!/bin/bash

# ####################################
# To identify which app server has the PIA trace file:
#    Script to list APSADM*tracesql
#    and also to list today's APPSRV_MMDD.LOG
# Al Kannayiram, October 2024
# ####################################

APPLOG=APPSRV_$(date '+%m%d').LOG
out1=$(ls -ld $PS_CFG_HOME/appserv/CNYCSPR1/LOGS/${APPLOG})
out2=$(ls -ld $PS_CFG_HOME/appserv/CNYCSPR1/LOGS/APSADM*tracesql)
hst=$(echo $HOSTNAME|cut -d"." -f1)
echo "HOST:[$hst] [$out1] [$out2]"
