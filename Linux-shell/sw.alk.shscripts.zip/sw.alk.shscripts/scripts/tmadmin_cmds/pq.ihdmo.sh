echo q|psadmin -c qstatus -d CNYIHDMO 
