# when: 9/13/2023
# who:  Al Kannayiram
# what: Shell snippet to get the PS_APP_HOME 
#       For NP environments, get the PS_APP_HOME from a config file.
#       Conf file format (colon delimited):
#            loginuser:<PS_APP_HOME>  <= Full path
#
#set -x
# 

myecho ()
{
  [[ "$debug" == "Y" ]] && echo "$1"

}


set_psapphome () 
{
CFGFILE=/psft/env/npapphomes.conf

# Ensure CFGFILE exists
[[ ! -r $CFGFILE ]] && { echo "ERROR! [$CFGFILE] is missing. Exiting..."; return ; }


if [[ $(grep -v "#" $CFGFILE|grep -i -m1 "^$LOGNAME"|wc -l) -gt 0 ]] ; then
   myecho "Found [$LOGNAME] entry in [$CFGFILE]"
   # extract app_home
   apphome=$(grep -v "#" $CFGFILE|grep -i -m1 "^$LOGNAME"|awk -F":" '{print $2}')
   
   # Check if the app home directory exists 
   if [[ -d "$apphome" ]] && [[ -r "$apphome" ]] && [[ -x "$apphome" ]]; then
      myecho "[$apphome] Found"
   else
      echo "ERROR! [$apphome] directory is missing or not accessible"
      return
   fi
else
  echo "ERROR! [$LOGNAME] entry is missing in [$CFGFILE]"
  return
fi
export PS_APP_HOME=$apphome
}

#debug=N
debug=Y
unset PS_APP_HOME
set_psapphome

