# when: 12/19/2023
# who:  Al Kannayiram
# what: 
#   Get the PS_HOME and PS_APP_HOME from a config file.
#   Conf file format (space delimited):
#       ENV <PS_HOME_PART> <PS_APP_HOME_PART>  <= Relative path
#
#set -x
# 

myecho ()
{
  [[ "$debug" == "Y" ]] && echo "$1"

}

unset PS_HOME
unset PS_APP_HOME

# CONSTANTS
#CFGFILE=/psft/env/pshomes.conf
#CFGFILE=/software/akannayiram/scripts/psft_env/pshomes.conf
PS_HOME_BASE=/appl/psft/pt
PS_APP_HOME_BASE=/appl/psft/app

# Abort if CFGFILE does not exist
[[ ! -r $CFGFILE ]] && { echo "ERROR! [$CFGFILE] is missing. Exiting..."; exit ; }

# Abort if no entry exists for login user
#[[ $(grep -v "#" $CFGFILE|awk '{print $1}'|grep -m1 "^$LOGNAME"|wc -l) -eq 0 ]] &&  { echo "ERROR! [$LOGNAME] entry is missing in [$CFGFILE]"; exit; }
[[ $(grep -m1 "^$LOGNAME" $CFGFILE|wc -l) -eq 0 ]] &&  { echo "ERROR! [$LOGNAME] entry is missing in [$CFGFILE]"; exit; }


#debug=N
debug=Y

# extract ps_home
#pshome_rel_path=$(grep -v "#" $CFGFILE|grep -i -m1 "^$LOGNAME"|awk '{print $2}')
pshome_rel_path=$(grep -i -m1 "^$LOGNAME" $CFGFILE|awk '{print $2}')
pshome="${PS_HOME_BASE}/${pshome_rel_path}" 
# Check if the pshome directory exists 
[[ -d "$pshome" ]] && [[ -r "$pshome" ]] && [[ -x "$pshome" ]] && export PS_HOME=$pshome
#export PS_HOME=$pshome


# extract app_home
#apphome_rel_path=$(grep -v "#" $CFGFILE|grep -i -m1 "^$LOGNAME"|awk '{print $3}')
apphome_rel_path=$(grep -i -m1 "^$LOGNAME" $CFGFILE|awk '{print $3}')
apphome="${PS_APP_HOME_BASE}/${apphome_rel_path}" 
   
# Check if the app home directory exists 
[[ -d "$apphome" ]] && [[ -r "$apphome" ]] && [[ -x "$apphome" ]] && export PS_APP_HOME=$apphome
#export PS_APP_HOME=$apphome

[[ -z "$PS_HOME" ]] && [[ -z "$PS_APP_HOME" ]] && { echo "ERROR! [pshome: $pshome] [apphome: $apphome] Both directories are missing or not accessible"; exit; }
[[ -z "$PS_HOME" ]] && { echo "ERROR! [pshome: $pshome] directory is missing or not accessible"; exit; }
[[ -z "$PS_APP_HOME" ]] && { echo "ERROR! [apphome: $apphome] directory is missing or not accessible"; exit; }
myecho "[PS_HOME=$pshome] Found" && myecho "[PS_APP_HOME=$apphome] Found"
