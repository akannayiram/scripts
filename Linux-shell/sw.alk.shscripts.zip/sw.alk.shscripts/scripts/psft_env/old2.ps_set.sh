# when: 12/19/2023
# who:  Al Kannayiram
# what: 
#   Get the PS_HOME and PS_APP_HOME from a config file.
#   Conf file format (space delimited):
#       ENV <PS_HOME_PART> <PS_APP_HOME_PART>  <= Relative path
#
#set -x
# 

myecho ()
{
  [[ "$debug" == "Y" ]] && echo "$1"

}




set_pshome () 
{

if [[ $(grep -v "#" $CFGFILE|grep -i -m1 "^$LOGNAME"|wc -l) -gt 0 ]] ; then
   myecho "Found [$LOGNAME] entry in [$CFGFILE]"
   # extract app_home
   apphome=$(grep -v "#" $CFGFILE|grep -i -m1 "^$LOGNAME"|awk -F":" '{print $2}')
   
   # Check if the app home directory exists 
   if [[ -d "$apphome" ]] && [[ -r "$apphome" ]] && [[ -x "$apphome" ]]; then
      myecho "[$apphome] Found"
   else
      echo "ERROR! [$apphome] directory is missing or not accessible"
      return
   fi
else
  echo "ERROR! [$LOGNAME] entry is missing in [$CFGFILE]"
  return
fi
export PS_APP_HOME=$apphome
}


set_psapphome () 
{

if [[ $(grep -v "#" $CFGFILE|grep -i -m1 "^$LOGNAME"|wc -l) -gt 0 ]] ; then
   myecho "Found [$LOGNAME] entry in [$CFGFILE]"
   # extract app_home
   apphome=$(grep -v "#" $CFGFILE|grep -i -m1 "^$LOGNAME"|awk -F":" '{print $2}')
   
   # Check if the app home directory exists 
   if [[ -d "$apphome" ]] && [[ -r "$apphome" ]] && [[ -x "$apphome" ]]; then
      myecho "[$apphome] Found"
   else
      echo "ERROR! [$apphome] directory is missing or not accessible"
      return
   fi
else
  echo "ERROR! [$LOGNAME] entry is missing in [$CFGFILE]"
  return
fi
export PS_APP_HOME=$apphome
}

unset PS_HOME
unset PS_APP_HOME
CFGFILE=/psft/env/pshomes.conf

# Ensure CFGFILE exists
[[ ! -r $CFGFILE ]] && { echo "ERROR! [$CFGFILE] is missing. Exiting..."; exit ; }

# check if an entry exits 
#[[ $(grep -v "#" $CFGFILE|grep -i -m1 "^$LOGNAME"|wc -l) -eq 0 ]] &&  { echo "ERROR! [$LOGNAME] entry is missing in [$CFGFILE]"; exit; }
[[ $(grep -v "#" $CFGFILE|awk '{print $1}'|grep -m1 "^$LOGNAME"|wc -l) -eq 0 ]] &&  { echo "ERROR! [$LOGNAME] entry is missing in [$CFGFILE]"; exit; }


#debug=N
debug=Y
set_psapphome

