#!/bin/bash
# ####################################
# when: 12/19/2023
# who:  Al Kannayiram
# what: 
#   Set the PS_HOME and PS_APP_HOME from a config file.
#   Conf file format (space delimited):
#       ENV <PS_HOME_PATH> <PS_APP_HOME_PATH>  <= Relative path
#
# ####################################
#set -x
# 

myecho ()
{
  [[ "$verbose" == "Y" ]] && echo "$1"

}



## Bash allows return statements only from functions and
## , in a script's top-level scope, only if the script is sourced.
## If return is used in the top-level scope of a non-sourced script, 
## an error message is emitted, and the exit code is set to 1.

## (return 0 2>/dev/null) executes in a subshell and suppresses the error message; 
## afterwards the exit code indicates whether the script was sourced (0) or not (1), 
## which is used with the && and || operators to set the sourced variable accordingly.
## Use of a subshell is necessary, because executing return in the top-level scope 
## of a sourced script would exit the script.
## Explicit zero "return 0": "If omitted, the return status is that of the last command." 
## So, unpredictable depneding on the last command on the user's shell.

# Check if sourced or not
#(return 0 2>/dev/null) && sourced=1 || sourced=0
(return 0 2>/dev/null) && sourced=1 || { echo "ERROR! Please source this script. Do not execute [$0]. Aborting..."; exit; }


# BASH_SOURCE variable always represents name of the script being executed i.e. ./setup.sh 
# irrespective of the fact whether you are sourcing it in or not.
# On the other hand $0 can be name of script when you directly execute it 
# or be equal to -bash when you source it in.
# Abort if not sourced
#[[ "$0" = "$BASH_SOURCE" ]] && { echo "Please source this script. Do not execute [$0]. Aborting..."; exit; }


unset PS_HOME
unset PS_APP_HOME

# CONSTANTS
#CFGFILE=/psft/env/pshomes.conf
CFGFILE=/software/akannayiram/scripts/psft_env/pshomes.conf
PS_HOME_BASE=/appl/psft/pt
PS_APP_HOME_BASE=/appl/psft/app

# Abort if CFGFILE does not exist
[[ ! -r $CFGFILE ]] && { echo "ERROR! [Config file: $CFGFILE] is missing. Aborting..."; return ; }

# Abort if no entry exists for login user
[[ $(grep -m1 "^$LOGNAME" $CFGFILE|wc -l) -eq 0 ]] &&  { echo "ERROR! [$LOGNAME] entry is missing in [$CFGFILE]. Aborting..."; return; }


#verbose=N
verbose=Y

# extract ps_home
pshome="${PS_HOME_BASE}/$(grep -i -m1 "^$LOGNAME" $CFGFILE|awk '{print $2}')"
# Check if the pshome directory exists 
[[ -d "$pshome" ]] && [[ -r "$pshome" ]] && [[ -x "$pshome" ]] && export PS_HOME=$pshome


# extract app_home
apphome="${PS_APP_HOME_BASE}/$(grep -i -m1 "^$LOGNAME" $CFGFILE|awk '{print $3}')"
# Check if the app home directory exists 
[[ -d "$apphome" ]] && [[ -r "$apphome" ]] && [[ -x "$apphome" ]] && export PS_APP_HOME=$apphome


# Alert if PS_HOME or PS_APP_HOME is not usable
[[ -z "$PS_HOME" ]] && [[ -z "$PS_APP_HOME" ]] && { echo "ERROR! [pshome: $pshome] [apphome: $apphome] Both directories are missing or not accessible"; return; }
[[ -z "$PS_HOME" ]] && { echo "ERROR! [pshome: $pshome] directory is missing or not accessible"; return; }
[[ -z "$PS_APP_HOME" ]] && { echo "ERROR! [apphome: $apphome] directory is missing or not accessible"; return; }
myecho "[PS_HOME=$pshome] sourced" && myecho "[PS_APP_HOME=$apphome] sourced"
