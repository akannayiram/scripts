#!/bin/bash
# ##########################
# Al Kannayiram December 2024
#    Configure ACL Permissions on PS_CUST_HOME
# ---------------------------
# Location: /software/akannayiram/scripts/dev_access_setfacl/set_cfg_hm_acls.sh
# ---------------------------
# ##########################

# 

# Configure ACL Permissions on PS_CFG_HOME

set_acl ()
{

echo "Set FACLs for $TARGETDIR"

echo "Checking the ACLs before the change"
getfacl $TARGETDIR/ 

echo "Executing setfacl commands"
#      Set default FACLs on directories for all files created in the future
#setfacl --recursive --default --modify group:${GRP}:rwx --modify mask::rwx $TARGETDIR
#      Set FACLs on existing directories and files
#setfacl --recursive --modify group:${GRP}:rwx --modify mask::rwx $TARGETDIR

echo "Checking the ACLs after the change"
getfacl $TARGETDIR/ 


}


dttm=$(date '+%m/%d/%Y %H:%M:%S')
echo "Begin: Host:[$HOSTNAME]  User:[$LOGNAME]  Date/time:[$dttm]"

GRP=pshome_${HOSTNAME:0:2}
echo "Setting ACLs for group: $GRP"

DOM=${LOGNAME^^}

APPLOGDIR="$PS_CFG_HOME/appserv/${DOM}/LOGS"
[[ -d $APPLOGDIR ]] && TARGETDIR=$APPLOGDIR && set_acl

PRCSLOGDIR="$PS_CFG_HOME/appserv/prcs/${DOM}/LOGS"
[[ -d $PRCSLOGDIR ]] && TARGETDIR=$PRCSLOGDIR && set_acl

DATAFILES="$PS_CFG_HOME/datafiles"
[[ -d $DATAFILES ]] && TARGETDIR=$DATAFILES && set_acl


dttm=$(date '+%m/%d/%Y %H:%M:%S')
echo "End: Host:[$HOSTNAME]  User:[$LOGNAME]  Date/time:[$dttm]"
