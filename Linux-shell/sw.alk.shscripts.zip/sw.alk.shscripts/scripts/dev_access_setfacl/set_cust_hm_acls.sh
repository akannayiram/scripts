#!/bin/bash
# ##########################
# Al Kannayiram December 2024
#    Configure ACL Permissions on PS_CUST_HOME
# ---------------------------
# Location: /software/akannayiram/scripts/dev_access_setfacl/set_cust_hm_acls.sh
# ---------------------------
# ##########################

#
# Configure ACL Permissions on PS_CUST_HOME

set_acl ()
{

echo "Set FACLs for $TARGETDIR"

echo "Checking the ACLs before the change"
getfacl $TARGETDIR/ 

echo "Executing setfacl commands"
#      Set default FACLs on directories for all files created in the future
setfacl --recursive --default --modify group:${GRP}:rwx --modify mask::rwx $TARGETDIR
#      Set FACLs on existing directories and files
setfacl --recursive --modify group:${GRP}:rwx --modify mask::rwx $TARGETDIR

echo "Checking the ACLs after the change"
getfacl $TARGETDIR/ 


}

dttm=$(date '+%m/%d/%Y %H:%M:%S')
echo "Begin: Host:[$HOSTNAME]  User:[$LOGNAME]  Date/time:[$dttm]"

GRP=pshome_${HOSTNAME:0:2}
echo "Setting ACLs for group: $GRP"

# Checking the ACLs before the change for sqr
[[ -d $PS_CUST_HOME/sqr ]] && getfacl $PS_CUST_HOME/sqr

## PS_CUST_HOME
[[ -d $PS_CUST_HOME ]] && TARGETDIR=$PS_CUST_HOME && set_acl

# Checking the ACLs after the change for sqr
[[ -d $PS_CUST_HOME/sqr ]] && getfacl $PS_CUST_HOME/sqr

dttm=$(date '+%m/%d/%Y %H:%M:%S')
echo "End: Host:[$HOSTNAME]  User:[$LOGNAME]  Date/time:[$dttm]"
