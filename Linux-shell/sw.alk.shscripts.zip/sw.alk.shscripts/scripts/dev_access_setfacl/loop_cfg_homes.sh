#!/bin/bash
# ##########################
# Al Kannayiram December 2024
#    Loop through CFG HOMES
#    and set developer access
# ---------------------------
# Location: /software/akannayiram/scripts/dev_access_setfacl/loop_cfg_homes.sh
# ---------------------------
# ##########################

scr=/software/akannayiram/scripts/dev_access_setfacl/set_cfg_hm_acls.sh
# get the cust homes
for i in $(find /appl/psft/cfg  -maxdepth 1 -path */cny*)
do
#  echo $i
  leaf=$(basename $i)
  echo "Working on $leaf"

  sudo su - "$leaf" -c "$scr"

done
