#!/bin/bash
# Memory stats
echo " ";echo "====================================";date
echo "Memory stats"
free -m | awk 'NR==2{printf "Memory Usage: %s/%sMB (%.2f%%)\n", $3,$2,$3*100/$2 }'
# Disk usage
echo "Disk usage"
df -h | awk '$NF=="/"{printf "Disk Usage: %d/%dGB (%s)\n", $3,$2,$5}'
# CPU average load from top command
echo "CPU average load from top command"
top -bn1 | grep load | awk '{printf "CPU Load: %.2f\n", $(NF-2)}' 
# Top memory usage processes
echo "Top memory usage processes"
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head
