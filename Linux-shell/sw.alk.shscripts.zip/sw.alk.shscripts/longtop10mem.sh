#!/bin/bash
# ##################################################
# Get the top 10 Memory hog processes
# History:
# Who                When      Why and What
# -----------------  --------- ------------------------
# Al Kannayiram      6/18/2021 Initial creation
#
# ##################################################

echo "---------FREE MEMORY---------------"
free -m

echo " "
echo "---------PERCENTAGE USAGE---------- "
mempct=`free -m|grep "^Mem:"|awk '{print $3*100/$2}'`
swppct=`free -m|grep "^Swap:"|awk '{print $3*100/$2}'`
echo "Memory %Used: $mempct     Swap %Used: $swppct"
echo " "

# I used tab first; but formatting is disturbed by larger number in a column
# Replaced echo with fixed position and then printf
#echo -e "Memory      \t Login        \t PID          \t Process "
#echo -e "----------- \t ------------ \t ------------ \t ----------------"

echo -e "Memory       %Memory  Login          PID            Process "
echo -e "-----------  -------  -------------  -------------  -----------------"
#
#         1         2         3         4         5         6         7         8
#123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
#-----------  -------  -------------  -------------  -----------------
#       11+1     7+1        13+1              13+1      17+1
# For fixed-length formatting, take the width of the column and add 1 to it
#     since there are two spaces between columns.
#     Another space is provided by the space between the format strings. e.g. %-2s^%-3s

ps -eo pid,rss,%mem,comm,user|sort -k 2,2 -nr|head -10|while read line
do
pid=`echo $line|awk '{print $1}'`
mem=`echo $line|awk '{print $2}'`
pctmem=`echo $line|awk '{print $3}'`
cmd=`echo $line|awk '{print $4}'`
unixuser=`echo $line|awk '{print $5}'`
#
# ================================================================
#echo -e "$mem \t $unixuser \t $pid    \t $cmd "
printf "%-12s %-8s %-14s %-14s %-18s \n" $mem $pctmem $unixuser $pid $cmd
done

