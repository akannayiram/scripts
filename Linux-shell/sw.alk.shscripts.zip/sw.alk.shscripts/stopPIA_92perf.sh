#!/bin/bash -x
if [[ ! $HOSTNAME =~ pfwl ]] ; then
   echo "Wrong host. Run on PERF Web servers"
   exit
fi
#for i in `grep cnyp /etc/hosts |grep -v "#"|grep 858|awk  '{print $2}'|sed -e "s/\r//"`
for i in `grep cnyp /etc/hosts |grep -v "#"|grep 860|awk  '{print $2}'|sed -e "s/\r//"`
do
#sudo su - $i -c /appl/oracle/weblogic/$i/webserv/peoplesoft/bin/stopPIA.sh  ; echo "on" `cat /etc/hosts |grep $i`
sudo su - $i -c /appl/psft/pia/$i/webserv/peoplesoft/bin/stopPIA.sh  ; echo "on" `cat /etc/hosts |grep $i`
done
