#!/bin/bash
# ##################################################
# Get the top 10 Memory hog processes
# History:
# Who                When      Why and What
# -----------------  --------- ------------------------
# Al Kannayiram      6/18/2021 Initial creation
#
# ##################################################

echo -e "Memory       %Memory  Login          PID            Process "
echo -e "-----------  -------  -------------  -------------  -----------------"

ps -eo pid,rss,%mem,comm,user|sort -k 2,2 -nr|head -10|while read line
do
pid=`echo $line|awk '{print $1}'`
mem=`echo $line|awk '{print $2}'`
pctmem=`echo $line|awk '{print $3}'`
cmd=`echo $line|awk '{print $4}'`
unixuser=`echo $line|awk '{print $5}'`
printf "%-12s %-8s %-14s %-14s %-18s \n" $mem $pctmem $unixuser $pid $cmd
done
