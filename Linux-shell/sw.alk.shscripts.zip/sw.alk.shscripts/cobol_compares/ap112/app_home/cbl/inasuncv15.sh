#!/bin/sh
#
# inasuncv.mak
#


TARGET_SAVE=`echo $1`
TARGET=`echo $1 |  tr abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ`

#echo ${TARGET}

PS_compile_apps=N; export PS_compile_apps
PS_compile_cust=N; export PS_compile_cust
if [ "${TARGET}" = "" ]; then
    if [ "${PS_APP_HOME}" = "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_APP_HOME}" != "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_HOME}" != "${PS_HOME}" ]; then
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_APP_HOME}" != "${PS_APP_HOME}" ]; then
        PS_compile_cust=Y
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
    fi    
else
    case "${TARGET}" in
    "PS_HOME")
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
        ;;
    "PS_APP_HOME")
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_HOME")
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_APP_HOME")
        PS_compile_apps=Y
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
        ;;
    *)    
        echo "Wrong usage of the program"
        PS_Usage || return $?
        ;;
    esac
fi

#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################
echo
echo "$0 : ** PS_HOME          = ${PS_HOME} **"
echo "$0 : ** PS_APP_HOME      = ${PS_APP_HOME} **"
echo "$0 : ** PS_CUST_HOME     = ${PS_CUST_HOME} **"
echo "$0 : ** PS_CUST_APP_HOME = ${PS_CUST_APP_HOME} **"
echo
echo "$0 : ** PS_SRC_HOME      = ${PS_SRC_HOME} **"
echo
#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################

echo "    "
echo "$0 : INAS 2015-2016 Unicode conversion routine beginning on `date`..."
echo "    "


#######################################################################################
# Create Work Area folders and set appropriate folder permissions
#######################################################################################

echo "    "
echo "$0 : Creating Work Area 1 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk15 ]
 then
      mkdir inaswk15
      chmod a+rwx inaswk15
fi 

echo "     "
echo "$0 : Creating Work Area 2 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk2 ]
 then
      mkdir inaswk2
      chmod a+rwx inaswk2 
fi


#######################################################################################
echo "     "
echo "$0 : Creating Unicode COBOL Conversion Output Area..."
cd $PS_SRC_HOME
cd src
if [  ! -x cblunicode ]
 then
      mkdir cblunicode
      chmod a+rwx cblunicode
fi
#######################################################################################


#######################################################################################
# Copy INAS Objects to Work Area #1
#######################################################################################

echo "     "
echo "$0 : Copying INAS 2015-2016 COBOL files to Work Area 1..."

# 2015 INAS Programs 

cp $PS_SRC_HOME/src/cbl/FMCALC15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/FMRJCT15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/FMSNT15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/FMTWEK15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IMCALC15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IMMAPI15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IMMAPO15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IMMSGE15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IMPLUS15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IMTWEK15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/INAS2015.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/INCOMP15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/INFUNC15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/ININAR15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/INLCL15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/INMIGR15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/INTAX15.cbl $PS_SRC_HOME/inaswk15

# 2015 INAS Copybooks 

cp $PS_SRC_HOME/src/cbl/FMR15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/FMREXT15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/FEDWRK15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/FMCNST15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/FUNCWA15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/GLOBAL15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IMCNST15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/INAR15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/PLUSWA15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IMR15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IMREXT15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/PROWRK15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/TAXPRM15.cbl $PS_SRC_HOME/inaswk15
cp $PS_SRC_HOME/src/cbl/IWKGLB15.cbl $PS_SRC_HOME/inaswk15


echo "     "
echo "$0 : Renaming INAS COBOL files in Work Area 1 to PS Standard..."

cd $PS_SRC_HOME
cd inaswk15

#######################################################################################
# Rename all INAS Objects in Work Area #1 to conform to the PeopleSoft naming standard 
#######################################################################################

mv FMCALC15.cbl INP15001.cbl
mv FMRJCT15.cbl INP15002.cbl
mv FMSNT15.cbl  INP15003.cbl
mv FMTWEK15.cbl INP15004.cbl
mv IMCALC15.cbl INP15005.cbl
mv IMMAPI15.cbl INP15006.cbl
mv IMMAPO15.cbl INP15007.cbl
mv IMMSGE15.cbl INP15008.cbl
mv IMPLUS15.cbl INP15009.cbl
mv IMTWEK15.cbl INP15010.cbl
mv INAS2015.cbl INP15011.cbl
mv INCOMP15.cbl INP15012.cbl
mv INFUNC15.cbl INP15013.cbl
mv ININAR15.cbl INP15014.cbl
mv INLCL15.cbl  INP15015.cbl
mv INMIGR15.cbl INP15016.cbl
mv INTAX15.cbl  INP15017.cbl

mv FMR15.cbl    INC15001.cbl
mv FMREXT15.cbl INC15002.cbl
mv FEDWRK15.cbl INC15004.cbl
mv FMCNST15.cbl INC15005.cbl
mv FUNCWA15.cbl INC15006.cbl
mv GLOBAL15.cbl INC15007.cbl
mv IMCNST15.cbl INC15008.cbl
mv INAR15.cbl   INC15009.cbl
mv PLUSWA15.cbl INC15010.cbl
mv IMR15.cbl    INC15011.cbl
mv IMREXT15.cbl INC15012.cbl
mv PROWRK15.cbl INC15013.cbl
mv TAXPRM15.cbl INC15014.cbl
mv IWKGLB15.cbl INC15015.cbl


#######################################################################################
# Run PeopleSoft COBOL Unicode Conversion program against INAS modules in Work Area #1.
# Converted INAS modules will be written to Work Area #2. 
#######################################################################################

echo "     "
echo "$0 : Converting all INAS 2015-2016 COBOL files in Work Area 1 to Unicode..."

#cd $PS_SRC_HOME/bin

$PS_HOME/bin/pscblucvrt -s:$PS_SRC_HOME/inaswk15 -t:$PS_SRC_HOME/inaswk2 -rd:$PS_SRC_HOME/inaswk2


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error.log ]
then
     mv $PS_SRC_HOME/inaswk2/cblcvrt_error.log $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1516.log
fi

#######################################################################################
# If INAS Unicode conversion is not successful, display Warning message and terminate
# processing.  If INAS Unicode conversion is successful, rename converted files back to
# original file names, and copy renamed files to Unicode COBOL source code folder. 
#######################################################################################


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1516.log ]
then
    echo "     "
    echo "$0 : Warning: Not all INAS 2015-2016 COBOL files were converted for Unicode successfully"
    echo "$0 : Warning: See $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1516.log for messages"
    echo "     "
else

mv $PS_SRC_HOME/inaswk2/cblcvrt_summary.log $PS_SRC_HOME/inaswk2/cblcvrt_summary_inas1516.log
mv $PS_SRC_HOME/inaswk2/convert_bindsetup.log $PS_SRC_HOME/inaswk2/convert_bindsetup_inas1516.log
mv $PS_SRC_HOME/inaswk2/convert_date_exception.log $PS_SRC_HOME/inaswk2/convert_date_exception_inas1516.log
mv $PS_SRC_HOME/inaswk2/convert_exception.log $PS_SRC_HOME/inaswk2/convert_exception_inas1516.log

echo "     "
echo "$0 : All INAS COBOL files converted for Unicode successfully and written to Work Area 2.. "
echo "     "
echo "$0 : Renaming INAS 2015-2016 COBOL files back to original file names..."

cd $PS_SRC_HOME
cd inaswk2

# Rename all INAS Objects back to original filenames 

mv INP15001.cbl FMCALC15.cbl
mv INP15002.cbl FMRJCT15.cbl 
mv INP15003.cbl FMSNT15.cbl  
mv INP15004.cbl FMTWEK15.cbl 
mv INP15005.cbl IMCALC15.cbl 
mv INP15006.cbl IMMAPI15.cbl 
mv INP15007.cbl IMMAPO15.cbl 
mv INP15008.cbl IMMSGE15.cbl 
mv INP15009.cbl IMPLUS15.cbl 
mv INP15010.cbl IMTWEK15.cbl 
mv INP15011.cbl INAS2015.cbl 
mv INP15012.cbl INCOMP15.cbl 
mv INP15013.cbl INFUNC15.cbl 
mv INP15014.cbl ININAR15.cbl 
mv INP15015.cbl INLCL15.cbl  
mv INP15016.cbl INMIGR15.cbl 
mv INP15017.cbl INTAX15.cbl  

mv INC15001.cbl FMR15.cbl    
mv INC15002.cbl FMREXT15.cbl 
mv INC15004.cbl FEDWRK15.cbl 
mv INC15005.cbl FMCNST15.cbl 
mv INC15006.cbl FUNCWA15.cbl 
mv INC15007.cbl GLOBAL15.cbl 
mv INC15008.cbl IMCNST15.cbl 
mv INC15009.cbl INAR15.cbl   
mv INC15010.cbl PLUSWA15.cbl 
mv INC15011.cbl IMR15.cbl    
mv INC15012.cbl IMREXT15.cbl 
mv INC15013.cbl PROWRK15.cbl 
mv INC15014.cbl TAXPRM15.cbl
mv INC15015.cbl IWKGLB15.cbl


# Copy converted INAS Objects from Work Area #2 to Unicode Source area 

echo "     "
echo "$0 : Copying Converted INAS 2015-2016 COBOL files to COBOL Unicode Source area..."

cp FMCALC15.cbl $PS_SRC_HOME/src/cblunicode
cp FMRJCT15.cbl $PS_SRC_HOME/src/cblunicode
cp FMSNT15.cbl $PS_SRC_HOME/src/cblunicode
cp FMTWEK15.cbl $PS_SRC_HOME/src/cblunicode
cp IMCALC15.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPI15.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPO15.cbl $PS_SRC_HOME/src/cblunicode
cp IMMSGE15.cbl $PS_SRC_HOME/src/cblunicode
cp IMPLUS15.cbl $PS_SRC_HOME/src/cblunicode
cp IMTWEK15.cbl $PS_SRC_HOME/src/cblunicode
cp INAS2015.cbl $PS_SRC_HOME/src/cblunicode
cp INCOMP15.cbl $PS_SRC_HOME/src/cblunicode
cp INFUNC15.cbl $PS_SRC_HOME/src/cblunicode
cp ININAR15.cbl $PS_SRC_HOME/src/cblunicode
cp INLCL15.cbl $PS_SRC_HOME/src/cblunicode
cp INMIGR15.cbl $PS_SRC_HOME/src/cblunicode
cp INTAX15.cbl $PS_SRC_HOME/src/cblunicode

cp FMR15.cbl $PS_SRC_HOME/src/cblunicode
cp FMREXT15.cbl $PS_SRC_HOME/src/cblunicode
cp FEDWRK15.cbl $PS_SRC_HOME/src/cblunicode
cp FMCNST15.cbl $PS_SRC_HOME/src/cblunicode
cp FUNCWA15.cbl $PS_SRC_HOME/src/cblunicode
cp GLOBAL15.cbl $PS_SRC_HOME/src/cblunicode
cp IMCNST15.cbl $PS_SRC_HOME/src/cblunicode
cp INAR15.cbl $PS_SRC_HOME/src/cblunicode
cp PLUSWA15.cbl $PS_SRC_HOME/src/cblunicode
cp IMR15.cbl $PS_SRC_HOME/src/cblunicode
cp IMREXT15.cbl $PS_SRC_HOME/src/cblunicode
cp PROWRK15.cbl $PS_SRC_HOME/src/cblunicode
cp TAXPRM15.cbl $PS_SRC_HOME/src/cblunicode
cp IWKGLB15.cbl $PS_SRC_HOME/src/cblunicode

echo "     "
echo "$0 : Converted INAS 2015-2016 COBOL files successfully copied to COBOL Unicode Source area..."


# To facilitate Batch INAS Compile, copy batch compile input file to Unicode Source area 

if [ -r $PS_SRC_HOME/src/cbl/INASBL15.cbl ]
  then
       cp $PS_SRC_HOME/src/cbl/INASBL15.cbl $PS_SRC_HOME/src/cblunicode
       chmod a+rwx $PS_SRC_HOME/src/cblunicode/INASBL15.cbl
       echo "     "
       echo "$0 : Batch compile input driver file staged to COBOL Unicode Source area."
fi


echo "     "
echo "$0 : All INAS 2015-2016 COBOL files successfully converted and staged."
echo "     "
echo "     "
echo "$0 : INAS 2015-2016 Unicode conversion routine ending on `date`..."
echo "     "

fi
