#!/bin/sh
#
# inasuncv.mak
#


TARGET_SAVE=`echo $1`
TARGET=`echo $1 |  tr abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ`

#echo ${TARGET}

PS_compile_apps=N; export PS_compile_apps
PS_compile_cust=N; export PS_compile_cust
if [ "${TARGET}" = "" ]; then
    if [ "${PS_APP_HOME}" = "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_APP_HOME}" != "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_HOME}" != "${PS_HOME}" ]; then
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_APP_HOME}" != "${PS_APP_HOME}" ]; then
        PS_compile_cust=Y
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
    fi    
else
    case "${TARGET}" in
    "PS_HOME")
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
        ;;
    "PS_APP_HOME")
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_HOME")
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_APP_HOME")
        PS_compile_apps=Y
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
        ;;
    *)    
        echo "Wrong usage of the program"
        PS_Usage || return $?
        ;;
    esac
fi

#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################
echo
echo "$0 : ** PS_HOME          = ${PS_HOME} **"
echo "$0 : ** PS_APP_HOME      = ${PS_APP_HOME} **"
echo "$0 : ** PS_CUST_HOME     = ${PS_CUST_HOME} **"
echo "$0 : ** PS_CUST_APP_HOME = ${PS_CUST_APP_HOME} **"
echo
echo "$0 : ** PS_SRC_HOME      = ${PS_SRC_HOME} **"
echo
#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################

echo "    "
echo "$0 : INAS 2014-2015 Unicode conversion routine beginning on `date`..."
echo "    "


#######################################################################################
# Create Work Area folders and set appropriate folder permissions
#######################################################################################

echo "    "
echo "$0 : Creating Work Area 1 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk14 ]
 then
      mkdir inaswk14
      chmod a+rwx inaswk14
fi 

echo "     "
echo "$0 : Creating Work Area 2 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk2 ]
 then
      mkdir inaswk2
      chmod a+rwx inaswk2 
fi


#######################################################################################
echo "     "
echo "$0 : Creating Unicode COBOL Conversion Output Area..."
cd $PS_SRC_HOME
cd src
if [  ! -x cblunicode ]
 then
      mkdir cblunicode
      chmod a+rwx cblunicode
fi
#######################################################################################


#######################################################################################
# Copy INAS Objects to Work Area #1
#######################################################################################

echo "     "
echo "$0 : Copying INAS 2014-2015 COBOL files to Work Area 1..."

# 2014 INAS Programs 

cp $PS_SRC_HOME/src/cbl/FMCALC14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/FMRJCT14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/FMSNT14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/FMTWEK14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IMCALC14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IMMAPI14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IMMAPO14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IMMSGE14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IMPLUS14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IMTWEK14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/INAS2014.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/INCOMP14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/INFUNC14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/ININAR14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/INLCL14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/INMIGR14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/INTAX14.cbl $PS_SRC_HOME/inaswk14

# 2014 INAS Copybooks 

cp $PS_SRC_HOME/src/cbl/FMR14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/FMREXT14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/FEDWRK14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/FMCNST14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/FUNCWA14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/GLOBAL14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IMCNST14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/INAR14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/PLUSWA14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IMR14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IMREXT14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/PROWRK14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/TAXPRM14.cbl $PS_SRC_HOME/inaswk14
cp $PS_SRC_HOME/src/cbl/IWKGLB14.cbl $PS_SRC_HOME/inaswk14


echo "     "
echo "$0 : Renaming INAS COBOL files in Work Area 1 to PS Standard..."

cd $PS_SRC_HOME
cd inaswk14

#######################################################################################
# Rename all INAS Objects in Work Area #1 to conform to the PeopleSoft naming standard 
#######################################################################################

mv FMCALC14.cbl INP14001.cbl
mv FMRJCT14.cbl INP14002.cbl
mv FMSNT14.cbl  INP14003.cbl
mv FMTWEK14.cbl INP14004.cbl
mv IMCALC14.cbl INP14005.cbl
mv IMMAPI14.cbl INP14006.cbl
mv IMMAPO14.cbl INP14007.cbl
mv IMMSGE14.cbl INP14008.cbl
mv IMPLUS14.cbl INP14009.cbl
mv IMTWEK14.cbl INP14010.cbl
mv INAS2014.cbl INP14011.cbl
mv INCOMP14.cbl INP14012.cbl
mv INFUNC14.cbl INP14013.cbl
mv ININAR14.cbl INP14014.cbl
mv INLCL14.cbl  INP14015.cbl
mv INMIGR14.cbl INP14016.cbl
mv INTAX14.cbl  INP14017.cbl

mv FMR14.cbl    INC14001.cbl
mv FMREXT14.cbl INC14002.cbl
mv FEDWRK14.cbl INC14004.cbl
mv FMCNST14.cbl INC14005.cbl
mv FUNCWA14.cbl INC14006.cbl
mv GLOBAL14.cbl INC14007.cbl
mv IMCNST14.cbl INC14008.cbl
mv INAR14.cbl   INC14009.cbl
mv PLUSWA14.cbl INC14010.cbl
mv IMR14.cbl    INC14011.cbl
mv IMREXT14.cbl INC14012.cbl
mv PROWRK14.cbl INC14013.cbl
mv TAXPRM14.cbl INC14014.cbl
mv IWKGLB14.cbl INC14015.cbl


#######################################################################################
# Run PeopleSoft COBOL Unicode Conversion program against INAS modules in Work Area #1.
# Converted INAS modules will be written to Work Area #2. 
#######################################################################################

echo "     "
echo "$0 : Converting all INAS 2014-2015 COBOL files in Work Area 1 to Unicode..."

#cd $PS_SRC_HOME/bin

$PS_HOME/bin/pscblucvrt -s:$PS_SRC_HOME/inaswk14 -t:$PS_SRC_HOME/inaswk2 -rd:$PS_SRC_HOME/inaswk2


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error.log ]
then
     mv $PS_SRC_HOME/inaswk2/cblcvrt_error.log $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1415.log
fi

#######################################################################################
# If INAS Unicode conversion is not successful, display Warning message and terminate
# processing.  If INAS Unicode conversion is successful, rename converted files back to
# original file names, and copy renamed files to Unicode COBOL source code folder. 
#######################################################################################


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1415.log ]
then
    echo "     "
    echo "$0 : Warning: Not all INAS 2014-2015 COBOL files were converted for Unicode successfully"
    echo "$0 : Warning: See $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1415.log for messages"
    echo "     "
else

mv $PS_SRC_HOME/inaswk2/cblcvrt_summary.log $PS_SRC_HOME/inaswk2/cblcvrt_summary_inas1415.log
mv $PS_SRC_HOME/inaswk2/convert_bindsetup.log $PS_SRC_HOME/inaswk2/convert_bindsetup_inas1415.log
mv $PS_SRC_HOME/inaswk2/convert_date_exception.log $PS_SRC_HOME/inaswk2/convert_date_exception_inas1415.log
mv $PS_SRC_HOME/inaswk2/convert_exception.log $PS_SRC_HOME/inaswk2/convert_exception_inas1415.log

echo "     "
echo "$0 : All INAS COBOL files converted for Unicode successfully and written to Work Area 2.. "
echo "     "
echo "$0 : Renaming INAS 2014-2015 COBOL files back to original file names..."

cd $PS_SRC_HOME
cd inaswk2

# Rename all INAS Objects back to original filenames 

mv INP14001.cbl FMCALC14.cbl
mv INP14002.cbl FMRJCT14.cbl 
mv INP14003.cbl FMSNT14.cbl  
mv INP14004.cbl FMTWEK14.cbl 
mv INP14005.cbl IMCALC14.cbl 
mv INP14006.cbl IMMAPI14.cbl 
mv INP14007.cbl IMMAPO14.cbl 
mv INP14008.cbl IMMSGE14.cbl 
mv INP14009.cbl IMPLUS14.cbl 
mv INP14010.cbl IMTWEK14.cbl 
mv INP14011.cbl INAS2014.cbl 
mv INP14012.cbl INCOMP14.cbl 
mv INP14013.cbl INFUNC14.cbl 
mv INP14014.cbl ININAR14.cbl 
mv INP14015.cbl INLCL14.cbl  
mv INP14016.cbl INMIGR14.cbl 
mv INP14017.cbl INTAX14.cbl  

mv INC14001.cbl FMR14.cbl    
mv INC14002.cbl FMREXT14.cbl 
mv INC14004.cbl FEDWRK14.cbl 
mv INC14005.cbl FMCNST14.cbl 
mv INC14006.cbl FUNCWA14.cbl 
mv INC14007.cbl GLOBAL14.cbl 
mv INC14008.cbl IMCNST14.cbl 
mv INC14009.cbl INAR14.cbl   
mv INC14010.cbl PLUSWA14.cbl 
mv INC14011.cbl IMR14.cbl    
mv INC14012.cbl IMREXT14.cbl 
mv INC14013.cbl PROWRK14.cbl 
mv INC14014.cbl TAXPRM14.cbl
mv INC14015.cbl IWKGLB14.cbl


# Copy converted INAS Objects from Work Area #2 to Unicode Source area 

echo "     "
echo "$0 : Copying Converted INAS 2014-2015 COBOL files to COBOL Unicode Source area..."

cp FMCALC14.cbl $PS_SRC_HOME/src/cblunicode
cp FMRJCT14.cbl $PS_SRC_HOME/src/cblunicode
cp FMSNT14.cbl $PS_SRC_HOME/src/cblunicode
cp FMTWEK14.cbl $PS_SRC_HOME/src/cblunicode
cp IMCALC14.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPI14.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPO14.cbl $PS_SRC_HOME/src/cblunicode
cp IMMSGE14.cbl $PS_SRC_HOME/src/cblunicode
cp IMPLUS14.cbl $PS_SRC_HOME/src/cblunicode
cp IMTWEK14.cbl $PS_SRC_HOME/src/cblunicode
cp INAS2014.cbl $PS_SRC_HOME/src/cblunicode
cp INCOMP14.cbl $PS_SRC_HOME/src/cblunicode
cp INFUNC14.cbl $PS_SRC_HOME/src/cblunicode
cp ININAR14.cbl $PS_SRC_HOME/src/cblunicode
cp INLCL14.cbl $PS_SRC_HOME/src/cblunicode
cp INMIGR14.cbl $PS_SRC_HOME/src/cblunicode
cp INTAX14.cbl $PS_SRC_HOME/src/cblunicode

cp FMR14.cbl $PS_SRC_HOME/src/cblunicode
cp FMREXT14.cbl $PS_SRC_HOME/src/cblunicode
cp FEDWRK14.cbl $PS_SRC_HOME/src/cblunicode
cp FMCNST14.cbl $PS_SRC_HOME/src/cblunicode
cp FUNCWA14.cbl $PS_SRC_HOME/src/cblunicode
cp GLOBAL14.cbl $PS_SRC_HOME/src/cblunicode
cp IMCNST14.cbl $PS_SRC_HOME/src/cblunicode
cp INAR14.cbl $PS_SRC_HOME/src/cblunicode
cp PLUSWA14.cbl $PS_SRC_HOME/src/cblunicode
cp IMR14.cbl $PS_SRC_HOME/src/cblunicode
cp IMREXT14.cbl $PS_SRC_HOME/src/cblunicode
cp PROWRK14.cbl $PS_SRC_HOME/src/cblunicode
cp TAXPRM14.cbl $PS_SRC_HOME/src/cblunicode
cp IWKGLB14.cbl $PS_SRC_HOME/src/cblunicode

echo "     "
echo "$0 : Converted INAS 2014-2015 COBOL files successfully copied to COBOL Unicode Source area..."


# To facilitate Batch INAS Compile, copy batch compile input file to Unicode Source area 

if [ -r $PS_SRC_HOME/src/cbl/INASBL14.cbl ]
  then
       cp $PS_SRC_HOME/src/cbl/INASBL14.cbl $PS_SRC_HOME/src/cblunicode
       chmod a+rwx $PS_SRC_HOME/src/cblunicode/INASBL14.cbl
       echo "     "
       echo "$0 : Batch compile input driver file staged to COBOL Unicode Source area."
fi


echo "     "
echo "$0 : All INAS 2014-2015 COBOL files successfully converted and staged."
echo "     "
echo "     "
echo "$0 : INAS 2014-2015 Unicode conversion routine ending on `date`..."
echo "     "

fi
