#!/bin/sh
#
# inasuncv.mak
#


TARGET_SAVE=`echo $1`
TARGET=`echo $1 |  tr abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ`

#echo ${TARGET}

PS_compile_apps=N; export PS_compile_apps
PS_compile_cust=N; export PS_compile_cust
if [ "${TARGET}" = "" ]; then
    if [ "${PS_APP_HOME}" = "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_APP_HOME}" != "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_HOME}" != "${PS_HOME}" ]; then
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_APP_HOME}" != "${PS_APP_HOME}" ]; then
        PS_compile_cust=Y
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
    fi    
else
    case "${TARGET}" in
    "PS_HOME")
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
        ;;
    "PS_APP_HOME")
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_HOME")
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_APP_HOME")
        PS_compile_apps=Y
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
        ;;
    *)    
        echo "Wrong usage of the program"
        PS_Usage || return $?
        ;;
    esac
fi

#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################
echo
echo "$0 : ** PS_HOME          = ${PS_HOME} **"
echo "$0 : ** PS_APP_HOME      = ${PS_APP_HOME} **"
echo "$0 : ** PS_CUST_HOME     = ${PS_CUST_HOME} **"
echo "$0 : ** PS_CUST_APP_HOME = ${PS_CUST_APP_HOME} **"
echo
echo "$0 : ** PS_SRC_HOME      = ${PS_SRC_HOME} **"
echo
#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################

echo "    "
echo "$0 : INAS 2017-2018 Unicode conversion routine beginning on `date`..."
echo "    "


#######################################################################################
# Create Work Area folders and set appropriate folder permissions
#######################################################################################

echo "    "
echo "$0 : Creating Work Area 1 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk17 ]
 then
      mkdir inaswk17
      chmod a+rwx inaswk17
fi 

echo "     "
echo "$0 : Creating Work Area 2 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk2 ]
 then
      mkdir inaswk2
      chmod a+rwx inaswk2 
fi


#######################################################################################
echo "     "
echo "$0 : Creating Unicode COBOL Conversion Output Area..."
cd $PS_SRC_HOME
cd src
if [  ! -x cblunicode ]
 then
      mkdir cblunicode
      chmod a+rwx cblunicode
fi
#######################################################################################


#######################################################################################
# Copy INAS Objects to Work Area #1
#######################################################################################

echo "     "
echo "$0 : Copying INAS 2017-2018 COBOL files to Work Area 1..."

# 2017 INAS Programs 

cp $PS_SRC_HOME/src/cbl/FMCALC17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/FMRJCT17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/FMSNT17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/FMTWEK17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IMCALC17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IMMAPI17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IMMAPO17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IMMSGE17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IMPLUS17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IMTWEK17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/INAS2017.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/INCOMP17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/INFUNC17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/ININAR17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/INLCL17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/INMIGR17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/INTAX17.cbl $PS_SRC_HOME/inaswk17

# 2017 INAS Copybooks 

cp $PS_SRC_HOME/src/cbl/FMR17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/FMREXT17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/FEDWRK17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/FMCNST17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/FUNCWA17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/GLOBAL17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IMCNST17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/INAR17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/PLUSWA17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IMR17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IMREXT17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/PROWRK17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/TAXPRM17.cbl $PS_SRC_HOME/inaswk17
cp $PS_SRC_HOME/src/cbl/IWKGLB17.cbl $PS_SRC_HOME/inaswk17


echo "     "
echo "$0 : Renaming INAS COBOL files in Work Area 1 to PS Standard..."

cd $PS_SRC_HOME
cd inaswk17

#######################################################################################
# Rename all INAS Objects in Work Area #1 to conform to the PeopleSoft naming standard 
#######################################################################################

mv FMCALC17.cbl INP17001.cbl
mv FMRJCT17.cbl INP17002.cbl
mv FMSNT17.cbl  INP17003.cbl
mv FMTWEK17.cbl INP17004.cbl
mv IMCALC17.cbl INP17005.cbl
mv IMMAPI17.cbl INP17006.cbl
mv IMMAPO17.cbl INP17007.cbl
mv IMMSGE17.cbl INP17008.cbl
mv IMPLUS17.cbl INP17009.cbl
mv IMTWEK17.cbl INP17010.cbl
mv INAS2017.cbl INP17011.cbl
mv INCOMP17.cbl INP17012.cbl
mv INFUNC17.cbl INP17013.cbl
mv ININAR17.cbl INP17014.cbl
mv INLCL17.cbl  INP17015.cbl
mv INMIGR17.cbl INP17016.cbl
mv INTAX17.cbl  INP17017.cbl

mv FMR17.cbl    INC17001.cbl
mv FMREXT17.cbl INC17002.cbl
mv FEDWRK17.cbl INC17004.cbl
mv FMCNST17.cbl INC17005.cbl
mv FUNCWA17.cbl INC17006.cbl
mv GLOBAL17.cbl INC17007.cbl
mv IMCNST17.cbl INC17008.cbl
mv INAR17.cbl   INC17009.cbl
mv PLUSWA17.cbl INC17010.cbl
mv IMR17.cbl    INC17011.cbl
mv IMREXT17.cbl INC17012.cbl
mv PROWRK17.cbl INC17013.cbl
mv TAXPRM17.cbl INC17014.cbl
mv IWKGLB17.cbl INC17015.cbl


#######################################################################################
# Run PeopleSoft COBOL Unicode Conversion program against INAS modules in Work Area #1.
# Converted INAS modules will be written to Work Area #2. 
#######################################################################################

echo "     "
echo "$0 : Converting all INAS 2017-2018 COBOL files in Work Area 1 to Unicode..."

#cd $PS_SRC_HOME/bin

$PS_HOME/bin/pscblucvrt -s:$PS_SRC_HOME/inaswk17 -t:$PS_SRC_HOME/inaswk2 -rd:$PS_SRC_HOME/inaswk2


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error.log ]
then
     mv $PS_SRC_HOME/inaswk2/cblcvrt_error.log $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1718.log
fi

#######################################################################################
# If INAS Unicode conversion is not successful, display Warning message and terminate
# processing.  If INAS Unicode conversion is successful, rename converted files back to
# original file names, and copy renamed files to Unicode COBOL source code folder. 
#######################################################################################


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1718.log ]
then
    echo "     "
    echo "$0 : Warning: Not all INAS 2017-2018 COBOL files were converted for Unicode successfully"
    echo "$0 : Warning: See $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1718.log for messages"
    echo "     "
else

mv $PS_SRC_HOME/inaswk2/cblcvrt_summary.log $PS_SRC_HOME/inaswk2/cblcvrt_summary_inas1718.log
mv $PS_SRC_HOME/inaswk2/convert_bindsetup.log $PS_SRC_HOME/inaswk2/convert_bindsetup_inas1718.log
mv $PS_SRC_HOME/inaswk2/convert_date_exception.log $PS_SRC_HOME/inaswk2/convert_date_exception_inas1718.log
mv $PS_SRC_HOME/inaswk2/convert_exception.log $PS_SRC_HOME/inaswk2/convert_exception_inas1718.log

echo "     "
echo "$0 : All INAS COBOL files converted for Unicode successfully and written to Work Area 2.. "
echo "     "
echo "$0 : Renaming INAS 2017-2018 COBOL files back to original file names..."

cd $PS_SRC_HOME
cd inaswk2

# Rename all INAS Objects back to original filenames 

mv INP17001.cbl FMCALC17.cbl
mv INP17002.cbl FMRJCT17.cbl 
mv INP17003.cbl FMSNT17.cbl  
mv INP17004.cbl FMTWEK17.cbl 
mv INP17005.cbl IMCALC17.cbl 
mv INP17006.cbl IMMAPI17.cbl 
mv INP17007.cbl IMMAPO17.cbl 
mv INP17008.cbl IMMSGE17.cbl 
mv INP17009.cbl IMPLUS17.cbl 
mv INP17010.cbl IMTWEK17.cbl 
mv INP17011.cbl INAS2017.cbl 
mv INP17012.cbl INCOMP17.cbl 
mv INP17013.cbl INFUNC17.cbl 
mv INP17014.cbl ININAR17.cbl 
mv INP17015.cbl INLCL17.cbl  
mv INP17016.cbl INMIGR17.cbl 
mv INP17017.cbl INTAX17.cbl  

mv INC17001.cbl FMR17.cbl    
mv INC17002.cbl FMREXT17.cbl 
mv INC17004.cbl FEDWRK17.cbl 
mv INC17005.cbl FMCNST17.cbl 
mv INC17006.cbl FUNCWA17.cbl 
mv INC17007.cbl GLOBAL17.cbl 
mv INC17008.cbl IMCNST17.cbl 
mv INC17009.cbl INAR17.cbl   
mv INC17010.cbl PLUSWA17.cbl 
mv INC17011.cbl IMR17.cbl    
mv INC17012.cbl IMREXT17.cbl 
mv INC17013.cbl PROWRK17.cbl 
mv INC17014.cbl TAXPRM17.cbl
mv INC17015.cbl IWKGLB17.cbl


# Copy converted INAS Objects from Work Area #2 to Unicode Source area 

echo "     "
echo "$0 : Copying Converted INAS 2017-2018 COBOL files to COBOL Unicode Source area..."

cp FMCALC17.cbl $PS_SRC_HOME/src/cblunicode
cp FMRJCT17.cbl $PS_SRC_HOME/src/cblunicode
cp FMSNT17.cbl $PS_SRC_HOME/src/cblunicode
cp FMTWEK17.cbl $PS_SRC_HOME/src/cblunicode
cp IMCALC17.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPI17.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPO17.cbl $PS_SRC_HOME/src/cblunicode
cp IMMSGE17.cbl $PS_SRC_HOME/src/cblunicode
cp IMPLUS17.cbl $PS_SRC_HOME/src/cblunicode
cp IMTWEK17.cbl $PS_SRC_HOME/src/cblunicode
cp INAS2017.cbl $PS_SRC_HOME/src/cblunicode
cp INCOMP17.cbl $PS_SRC_HOME/src/cblunicode
cp INFUNC17.cbl $PS_SRC_HOME/src/cblunicode
cp ININAR17.cbl $PS_SRC_HOME/src/cblunicode
cp INLCL17.cbl $PS_SRC_HOME/src/cblunicode
cp INMIGR17.cbl $PS_SRC_HOME/src/cblunicode
cp INTAX17.cbl $PS_SRC_HOME/src/cblunicode

cp FMR17.cbl $PS_SRC_HOME/src/cblunicode
cp FMREXT17.cbl $PS_SRC_HOME/src/cblunicode
cp FEDWRK17.cbl $PS_SRC_HOME/src/cblunicode
cp FMCNST17.cbl $PS_SRC_HOME/src/cblunicode
cp FUNCWA17.cbl $PS_SRC_HOME/src/cblunicode
cp GLOBAL17.cbl $PS_SRC_HOME/src/cblunicode
cp IMCNST17.cbl $PS_SRC_HOME/src/cblunicode
cp INAR17.cbl $PS_SRC_HOME/src/cblunicode
cp PLUSWA17.cbl $PS_SRC_HOME/src/cblunicode
cp IMR17.cbl $PS_SRC_HOME/src/cblunicode
cp IMREXT17.cbl $PS_SRC_HOME/src/cblunicode
cp PROWRK17.cbl $PS_SRC_HOME/src/cblunicode
cp TAXPRM17.cbl $PS_SRC_HOME/src/cblunicode
cp IWKGLB17.cbl $PS_SRC_HOME/src/cblunicode

echo "     "
echo "$0 : Converted INAS 2017-2018 COBOL files successfully copied to COBOL Unicode Source area..."


# To facilitate Batch INAS Compile, copy batch compile input file to Unicode Source area 

if [ -r $PS_SRC_HOME/src/cbl/INASBL17.cbl ]
  then
       cp $PS_SRC_HOME/src/cbl/INASBL17.cbl $PS_SRC_HOME/src/cblunicode
       chmod a+rwx $PS_SRC_HOME/src/cblunicode/INASBL17.cbl
       echo "     "
       echo "$0 : Batch compile input driver file staged to COBOL Unicode Source area."
fi


echo "     "
echo "$0 : All INAS 2017-2018 COBOL files successfully converted and staged."
echo "     "
echo "     "
echo "$0 : INAS 2017-2018 Unicode conversion routine ending on `date`..."
echo "     "

fi
