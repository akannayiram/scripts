#!/bin/sh
#
# inasuren.mak
#


PS_SRC_HOME=${PS_HOME}
if [ "${PS_compile_apps}" = "Y" ]; then
    PS_SRC_HOME=${PS_APP_HOME}
    if [ "${PS_compile_cust}" = "Y" ]; then
        if [ ! -x $PS_CUST_APP_HOME/temp ]
        then
            mkdir $PS_CUST_APP_HOME/temp
        fi
        rm -rf $PS_CUST_APP_HOME/temp/*
        PS_SRC_HOME=${PS_CUST_APP_HOME}
    fi
elif [ "${PS_compile_cust}" = "Y" ]; then
    if [ ! -x $PS_CUST_HOME/temp ]
    then
        mkdir $PS_CUST_HOME/temp
    fi
    rm -rf $PS_CUST_HOME/temp/*
    PS_SRC_HOME=${PS_CUST_HOME}
fi

#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################

#PS_SRC_HOME=${PS_HOME}

echo "$0 :     "
echo "$0 : Renaming INAS COBOL files in Work Area 3 back to original file names..."

cd ${PS_SRC_HOME}
cd inaswk3


#######################################################################################
# Rename all INAS Objects in Work Area #1 to conform to the PeopleSoft naming standard 
#######################################################################################

# Rename all INAS Objects back to original filenames 


mv INP10001.cbl FMCALC10.cbl
mv INP10002.cbl FMRJCT10.cbl 
mv INP10003.cbl FMSNT10.cbl  
mv INP10004.cbl FMTWEK10.cbl 
mv INP10005.cbl IMCALC10.cbl 
mv INP10006.cbl IMMAPI10.cbl 
mv INP10007.cbl IMMAPO10.cbl 
mv INP10008.cbl IMMSGE10.cbl 
mv INP10009.cbl IMPLUS10.cbl 
mv INP10010.cbl IMTWEK10.cbl 
mv INP10011.cbl INAS2010.cbl 
mv INP10012.cbl INCOMP10.cbl 
mv INP10013.cbl INFUNC10.cbl 
mv INP10014.cbl ININAR10.cbl 
mv INP10015.cbl INLCL10.cbl  
mv INP10016.cbl INMIGR10.cbl 
mv INP10017.cbl INTAX10.cbl  

mv INC10001.cbl FED10.cbl    
mv INC10002.cbl FEDEXT10.cbl 
mv INC10003.cbl FEDORI10.cbl 
mv INC10004.cbl FEDWRK10.cbl 
mv INC10005.cbl FMCNST10.cbl 
mv INC10006.cbl FUNCWA10.cbl 
mv INC10007.cbl GLOBAL10.cbl 
mv INC10008.cbl IMCNST10.cbl 
mv INC10009.cbl INAR10.cbl   
mv INC10010.cbl PLUSWA10.cbl 
mv INC10011.cbl IMR10.cbl    
mv INC10012.cbl IMREXT10.cbl 
mv INC10013.cbl PROWRK10.cbl 
mv INC10014.cbl TAXPRM10.cbl
mv INC10015.cbl IWKGLB10.cbl

mv INP11001.cbl FMCALC11.cbl
mv INP11002.cbl FMRJCT11.cbl 
mv INP11003.cbl FMSNT11.cbl  
mv INP11004.cbl FMTWEK11.cbl 
mv INP11005.cbl IMCALC11.cbl 
mv INP11006.cbl IMMAPI11.cbl 
mv INP11007.cbl IMMAPO11.cbl 
mv INP11008.cbl IMMSGE11.cbl 
mv INP11009.cbl IMPLUS11.cbl 
mv INP11010.cbl IMTWEK11.cbl 
mv INP11011.cbl INAS2011.cbl 
mv INP11012.cbl INCOMP11.cbl 
mv INP11013.cbl INFUNC11.cbl 
mv INP11014.cbl ININAR11.cbl 
mv INP11015.cbl INLCL11.cbl  
mv INP11016.cbl INMIGR11.cbl 
mv INP11017.cbl INTAX11.cbl  

mv INC11001.cbl FED11.cbl    
mv INC11002.cbl FEDEXT11.cbl 
mv INC11003.cbl FEDORI11.cbl 
mv INC11004.cbl FEDWRK11.cbl 
mv INC11005.cbl FMCNST11.cbl 
mv INC11006.cbl FUNCWA11.cbl 
mv INC11007.cbl GLOBAL11.cbl 
mv INC11008.cbl IMCNST11.cbl 
mv INC11009.cbl INAR11.cbl   
mv INC11010.cbl PLUSWA11.cbl 
mv INC11011.cbl IMR11.cbl    
mv INC11012.cbl IMREXT11.cbl 
mv INC11013.cbl PROWRK11.cbl 
mv INC11014.cbl TAXPRM11.cbl
mv INC11015.cbl IWKGLB11.cbl

mv INP12001.cbl FMCALC12.cbl
mv INP12002.cbl FMRJCT12.cbl 
mv INP12003.cbl FMSNT12.cbl  
mv INP12004.cbl FMTWEK12.cbl 
mv INP12005.cbl IMCALC12.cbl 
mv INP12006.cbl IMMAPI12.cbl 
mv INP12007.cbl IMMAPO12.cbl 
mv INP12008.cbl IMMSGE12.cbl 
mv INP12009.cbl IMPLUS12.cbl 
mv INP12010.cbl IMTWEK12.cbl 
mv INP12011.cbl INAS2012.cbl 
mv INP12012.cbl INCOMP12.cbl 
mv INP12013.cbl INFUNC12.cbl 
mv INP12014.cbl ININAR12.cbl 
mv INP12015.cbl INLCL12.cbl  
mv INP12016.cbl INMIGR12.cbl 
mv INP12017.cbl INTAX12.cbl  

mv INC12001.cbl FMR12.cbl    
mv INC12002.cbl FMREXT12.cbl 
mv INC12004.cbl FEDWRK12.cbl 
mv INC12005.cbl FMCNST12.cbl 
mv INC12006.cbl FUNCWA12.cbl 
mv INC12007.cbl GLOBAL12.cbl 
mv INC12008.cbl IMCNST12.cbl 
mv INC12009.cbl INAR12.cbl   
mv INC12010.cbl PLUSWA12.cbl 
mv INC12011.cbl IMR12.cbl    
mv INC12012.cbl IMREXT12.cbl 
mv INC12013.cbl PROWRK12.cbl 
mv INC12014.cbl TAXPRM12.cbl
mv INC12015.cbl IWKGLB12.cbl

mv INP13001.cbl FMCALC13.cbl
mv INP13002.cbl FMRJCT13.cbl 
mv INP13003.cbl FMSNT13.cbl  
mv INP13004.cbl FMTWEK13.cbl 
mv INP13005.cbl IMCALC13.cbl 
mv INP13006.cbl IMMAPI13.cbl 
mv INP13007.cbl IMMAPO13.cbl 
mv INP13008.cbl IMMSGE13.cbl 
mv INP13009.cbl IMPLUS13.cbl 
mv INP13010.cbl IMTWEK13.cbl 
mv INP13011.cbl INAS2013.cbl 
mv INP13012.cbl INCOMP13.cbl 
mv INP13013.cbl INFUNC13.cbl 
mv INP13014.cbl ININAR13.cbl 
mv INP13015.cbl INLCL13.cbl  
mv INP13016.cbl INMIGR13.cbl 
mv INP13017.cbl INTAX13.cbl  

mv INC13001.cbl FMR13.cbl    
mv INC13002.cbl FMREXT13.cbl 
mv INC13004.cbl FEDWRK13.cbl 
mv INC13005.cbl FMCNST13.cbl 
mv INC13006.cbl FUNCWA13.cbl 
mv INC13007.cbl GLOBAL13.cbl 
mv INC13008.cbl IMCNST13.cbl 
mv INC13009.cbl INAR13.cbl   
mv INC13010.cbl PLUSWA13.cbl 
mv INC13011.cbl IMR13.cbl    
mv INC13012.cbl IMREXT13.cbl 
mv INC13013.cbl PROWRK13.cbl 
mv INC13014.cbl TAXPRM13.cbl
mv INC13015.cbl IWKGLB13.cbl

mv INP14001.cbl FMCALC14.cbl
mv INP14002.cbl FMRJCT14.cbl 
mv INP14003.cbl FMSNT14.cbl  
mv INP14004.cbl FMTWEK14.cbl 
mv INP14005.cbl IMCALC14.cbl 
mv INP14006.cbl IMMAPI14.cbl 
mv INP14007.cbl IMMAPO14.cbl 
mv INP14008.cbl IMMSGE14.cbl 
mv INP14009.cbl IMPLUS14.cbl 
mv INP14010.cbl IMTWEK14.cbl 
mv INP14011.cbl INAS2014.cbl 
mv INP14012.cbl INCOMP14.cbl 
mv INP14013.cbl INFUNC14.cbl 
mv INP14014.cbl ININAR14.cbl 
mv INP14015.cbl INLCL14.cbl  
mv INP14016.cbl INMIGR14.cbl 
mv INP14017.cbl INTAX14.cbl  

mv INC14001.cbl FMR14.cbl    
mv INC14002.cbl FMREXT14.cbl 
mv INC14004.cbl FEDWRK14.cbl 
mv INC14005.cbl FMCNST14.cbl 
mv INC14006.cbl FUNCWA14.cbl 
mv INC14007.cbl GLOBAL14.cbl 
mv INC14008.cbl IMCNST14.cbl 
mv INC14009.cbl INAR14.cbl   
mv INC14010.cbl PLUSWA14.cbl 
mv INC14011.cbl IMR14.cbl    
mv INC14012.cbl IMREXT14.cbl 
mv INC14013.cbl PROWRK14.cbl 
mv INC14014.cbl TAXPRM14.cbl
mv INC14015.cbl IWKGLB14.cbl

mv INP15001.cbl FMCALC15.cbl
mv INP15002.cbl FMRJCT15.cbl 
mv INP15003.cbl FMSNT15.cbl  
mv INP15004.cbl FMTWEK15.cbl 
mv INP15005.cbl IMCALC15.cbl 
mv INP15006.cbl IMMAPI15.cbl 
mv INP15007.cbl IMMAPO15.cbl 
mv INP15008.cbl IMMSGE15.cbl 
mv INP15009.cbl IMPLUS15.cbl 
mv INP15010.cbl IMTWEK15.cbl 
mv INP15011.cbl INAS2015.cbl 
mv INP15012.cbl INCOMP15.cbl 
mv INP15013.cbl INFUNC15.cbl 
mv INP15014.cbl ININAR15.cbl 
mv INP15015.cbl INLCL15.cbl  
mv INP15016.cbl INMIGR15.cbl 
mv INP15017.cbl INTAX15.cbl  

mv INC15001.cbl FMR15.cbl    
mv INC15002.cbl FMREXT15.cbl 
mv INC15004.cbl FEDWRK15.cbl 
mv INC15005.cbl FMCNST15.cbl 
mv INC15006.cbl FUNCWA15.cbl 
mv INC15007.cbl GLOBAL15.cbl 
mv INC15008.cbl IMCNST15.cbl 
mv INC15009.cbl INAR15.cbl   
mv INC15010.cbl PLUSWA15.cbl 
mv INC15011.cbl IMR15.cbl    
mv INC15012.cbl IMREXT15.cbl 
mv INC15013.cbl PROWRK15.cbl 
mv INC15014.cbl TAXPRM15.cbl
mv INC15015.cbl IWKGLB15.cbl

mv INP16001.cbl FMCALC16.cbl
mv INP16002.cbl FMRJCT16.cbl 
mv INP16003.cbl FMSNT16.cbl  
mv INP16004.cbl FMTWEK16.cbl 
mv INP16005.cbl IMCALC16.cbl 
mv INP16006.cbl IMMAPI16.cbl 
mv INP16007.cbl IMMAPO16.cbl 
mv INP16008.cbl IMMSGE16.cbl 
mv INP16009.cbl IMPLUS16.cbl 
mv INP16010.cbl IMTWEK16.cbl 
mv INP16011.cbl INAS2016.cbl 
mv INP16012.cbl INCOMP16.cbl 
mv INP16013.cbl INFUNC16.cbl 
mv INP16014.cbl ININAR16.cbl 
mv INP16015.cbl INLCL16.cbl  
mv INP16016.cbl INMIGR16.cbl 
mv INP16017.cbl INTAX16.cbl  

mv INC16001.cbl FMR16.cbl    
mv INC16002.cbl FMREXT16.cbl 
mv INC16004.cbl FEDWRK16.cbl 
mv INC16005.cbl FMCNST16.cbl 
mv INC16006.cbl FUNCWA16.cbl 
mv INC16007.cbl GLOBAL16.cbl 
mv INC16008.cbl IMCNST16.cbl 
mv INC16009.cbl INAR16.cbl   
mv INC16010.cbl PLUSWA16.cbl 
mv INC16011.cbl IMR16.cbl    
mv INC16012.cbl IMREXT16.cbl 
mv INC16013.cbl PROWRK16.cbl 
mv INC16014.cbl TAXPRM16.cbl
mv INC16015.cbl IWKGLB16.cbl

mv INP17001.cbl FMCALC17.cbl
mv INP17002.cbl FMRJCT17.cbl 
mv INP17003.cbl FMSNT17.cbl  
mv INP17004.cbl FMTWEK17.cbl 
mv INP17005.cbl IMCALC17.cbl 
mv INP17006.cbl IMMAPI17.cbl 
mv INP17007.cbl IMMAPO17.cbl 
mv INP17008.cbl IMMSGE17.cbl 
mv INP17009.cbl IMPLUS17.cbl 
mv INP17010.cbl IMTWEK17.cbl 
mv INP17011.cbl INAS2017.cbl 
mv INP17012.cbl INCOMP17.cbl 
mv INP17013.cbl INFUNC17.cbl 
mv INP17014.cbl ININAR17.cbl 
mv INP17015.cbl INLCL17.cbl  
mv INP17016.cbl INMIGR17.cbl 
mv INP17017.cbl INTAX17.cbl  

mv INC17001.cbl FMR17.cbl    
mv INC17002.cbl FMREXT17.cbl 
mv INC17004.cbl FEDWRK17.cbl 
mv INC17005.cbl FMCNST17.cbl 
mv INC17006.cbl FUNCWA17.cbl 
mv INC17007.cbl GLOBAL17.cbl 
mv INC17008.cbl IMCNST17.cbl 
mv INC17009.cbl INAR17.cbl   
mv INC17010.cbl PLUSWA17.cbl 
mv INC17011.cbl IMR17.cbl    
mv INC17012.cbl IMREXT17.cbl 
mv INC17013.cbl PROWRK17.cbl 
mv INC17014.cbl TAXPRM17.cbl
mv INC17015.cbl IWKGLB17.cbl


# To facilitate Batch INAS Compile, copy batch compile input file to Work Area 3 

echo "     "
echo "$0 : Copying compile input files to Work Area 3..."

cp ${PS_SRC_HOME}/src/cbl/*.CFG ${PS_SRC_HOME}/inaswk3

cp ${PS_SRC_HOME}/src/cbl/INASBL*.cbl ${PS_SRC_HOME}/inaswk3
chmod a+rwx ${PS_SRC_HOME}/inaswk3/INASBL*.cbl

echo "     "
echo "$0 : Batch compile input files staged to Work Area 3."

#if [ ! -r ${PS_SRC_HOME}/src/cbl/INASBL*.cbl ]
#  then
#       cp ${PS_SRC_HOME}/src/cbl/INASBL*.cbl ${PS_SRC_HOME}/inaswk3
#       chmod a+rwx ${PS_SRC_HOME}/inaswk3/INASBL*.cbl
#       echo " > Batch compile input files staged to cblunicode folder."
#fi


# Copy converted INAS Objects from Work Area #3 to Unicode Source area 

echo "     "
echo "$0 : Copying Converted COBOL files to COBOL Unicode Source area..."

cp ${PS_SRC_HOME}/inaswk3/*.* ${PS_SRC_HOME}/src/cblunicode


echo "     "
echo "$0 : All Campus Solutions COBOL files successfully converted and staged."
echo "     "
echo "     "
echo "$0 : INAS Unicode conversion routine ending on `date`..."
echo "     "


