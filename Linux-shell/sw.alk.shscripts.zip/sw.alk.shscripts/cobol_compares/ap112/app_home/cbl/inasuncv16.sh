#!/bin/sh
#
# inasuncv.mak
#


TARGET_SAVE=`echo $1`
TARGET=`echo $1 |  tr abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ`

#echo ${TARGET}

PS_compile_apps=N; export PS_compile_apps
PS_compile_cust=N; export PS_compile_cust
if [ "${TARGET}" = "" ]; then
    if [ "${PS_APP_HOME}" = "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_APP_HOME}" != "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_HOME}" != "${PS_HOME}" ]; then
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_APP_HOME}" != "${PS_APP_HOME}" ]; then
        PS_compile_cust=Y
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
    fi    
else
    case "${TARGET}" in
    "PS_HOME")
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
        ;;
    "PS_APP_HOME")
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_HOME")
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_APP_HOME")
        PS_compile_apps=Y
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
        ;;
    *)    
        echo "Wrong usage of the program"
        PS_Usage || return $?
        ;;
    esac
fi

#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################
echo
echo "$0 : ** PS_HOME          = ${PS_HOME} **"
echo "$0 : ** PS_APP_HOME      = ${PS_APP_HOME} **"
echo "$0 : ** PS_CUST_HOME     = ${PS_CUST_HOME} **"
echo "$0 : ** PS_CUST_APP_HOME = ${PS_CUST_APP_HOME} **"
echo
echo "$0 : ** PS_SRC_HOME      = ${PS_SRC_HOME} **"
echo
#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################

echo "    "
echo "$0 : INAS 2016-2017 Unicode conversion routine beginning on `date`..."
echo "    "


#######################################################################################
# Create Work Area folders and set appropriate folder permissions
#######################################################################################

echo "    "
echo "$0 : Creating Work Area 1 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk16 ]
 then
      mkdir inaswk16
      chmod a+rwx inaswk16
fi 

echo "     "
echo "$0 : Creating Work Area 2 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk2 ]
 then
      mkdir inaswk2
      chmod a+rwx inaswk2 
fi


#######################################################################################
echo "     "
echo "$0 : Creating Unicode COBOL Conversion Output Area..."
cd $PS_SRC_HOME
cd src
if [  ! -x cblunicode ]
 then
      mkdir cblunicode
      chmod a+rwx cblunicode
fi
#######################################################################################


#######################################################################################
# Copy INAS Objects to Work Area #1
#######################################################################################

echo "     "
echo "$0 : Copying INAS 2016-2017 COBOL files to Work Area 1..."

# 2016 INAS Programs 

cp $PS_SRC_HOME/src/cbl/FMCALC16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/FMRJCT16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/FMSNT16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/FMTWEK16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IMCALC16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IMMAPI16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IMMAPO16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IMMSGE16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IMPLUS16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IMTWEK16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/INAS2016.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/INCOMP16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/INFUNC16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/ININAR16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/INLCL16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/INMIGR16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/INTAX16.cbl $PS_SRC_HOME/inaswk16

# 2016 INAS Copybooks 

cp $PS_SRC_HOME/src/cbl/FMR16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/FMREXT16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/FEDWRK16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/FMCNST16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/FUNCWA16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/GLOBAL16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IMCNST16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/INAR16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/PLUSWA16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IMR16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IMREXT16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/PROWRK16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/TAXPRM16.cbl $PS_SRC_HOME/inaswk16
cp $PS_SRC_HOME/src/cbl/IWKGLB16.cbl $PS_SRC_HOME/inaswk16


echo "     "
echo "$0 : Renaming INAS COBOL files in Work Area 1 to PS Standard..."

cd $PS_SRC_HOME
cd inaswk16

#######################################################################################
# Rename all INAS Objects in Work Area #1 to conform to the PeopleSoft naming standard 
#######################################################################################

mv FMCALC16.cbl INP16001.cbl
mv FMRJCT16.cbl INP16002.cbl
mv FMSNT16.cbl  INP16003.cbl
mv FMTWEK16.cbl INP16004.cbl
mv IMCALC16.cbl INP16005.cbl
mv IMMAPI16.cbl INP16006.cbl
mv IMMAPO16.cbl INP16007.cbl
mv IMMSGE16.cbl INP16008.cbl
mv IMPLUS16.cbl INP16009.cbl
mv IMTWEK16.cbl INP16010.cbl
mv INAS2016.cbl INP16011.cbl
mv INCOMP16.cbl INP16012.cbl
mv INFUNC16.cbl INP16013.cbl
mv ININAR16.cbl INP16014.cbl
mv INLCL16.cbl  INP16015.cbl
mv INMIGR16.cbl INP16016.cbl
mv INTAX16.cbl  INP16017.cbl

mv FMR16.cbl    INC16001.cbl
mv FMREXT16.cbl INC16002.cbl
mv FEDWRK16.cbl INC16004.cbl
mv FMCNST16.cbl INC16005.cbl
mv FUNCWA16.cbl INC16006.cbl
mv GLOBAL16.cbl INC16007.cbl
mv IMCNST16.cbl INC16008.cbl
mv INAR16.cbl   INC16009.cbl
mv PLUSWA16.cbl INC16010.cbl
mv IMR16.cbl    INC16011.cbl
mv IMREXT16.cbl INC16012.cbl
mv PROWRK16.cbl INC16013.cbl
mv TAXPRM16.cbl INC16014.cbl
mv IWKGLB16.cbl INC16015.cbl


#######################################################################################
# Run PeopleSoft COBOL Unicode Conversion program against INAS modules in Work Area #1.
# Converted INAS modules will be written to Work Area #2. 
#######################################################################################

echo "     "
echo "$0 : Converting all INAS 2016-2017 COBOL files in Work Area 1 to Unicode..."

#cd $PS_SRC_HOME/bin

$PS_HOME/bin/pscblucvrt -s:$PS_SRC_HOME/inaswk16 -t:$PS_SRC_HOME/inaswk2 -rd:$PS_SRC_HOME/inaswk2


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error.log ]
then
     mv $PS_SRC_HOME/inaswk2/cblcvrt_error.log $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1617.log
fi

#######################################################################################
# If INAS Unicode conversion is not successful, display Warning message and terminate
# processing.  If INAS Unicode conversion is successful, rename converted files back to
# original file names, and copy renamed files to Unicode COBOL source code folder. 
#######################################################################################


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1617.log ]
then
    echo "     "
    echo "$0 : Warning: Not all INAS 2016-2017 COBOL files were converted for Unicode successfully"
    echo "$0 : Warning: See $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1617.log for messages"
    echo "     "
else

mv $PS_SRC_HOME/inaswk2/cblcvrt_summary.log $PS_SRC_HOME/inaswk2/cblcvrt_summary_inas1617.log
mv $PS_SRC_HOME/inaswk2/convert_bindsetup.log $PS_SRC_HOME/inaswk2/convert_bindsetup_inas1617.log
mv $PS_SRC_HOME/inaswk2/convert_date_exception.log $PS_SRC_HOME/inaswk2/convert_date_exception_inas1617.log
mv $PS_SRC_HOME/inaswk2/convert_exception.log $PS_SRC_HOME/inaswk2/convert_exception_inas1617.log

echo "     "
echo "$0 : All INAS COBOL files converted for Unicode successfully and written to Work Area 2.. "
echo "     "
echo "$0 : Renaming INAS 2016-2017 COBOL files back to original file names..."

cd $PS_SRC_HOME
cd inaswk2

# Rename all INAS Objects back to original filenames 

mv INP16001.cbl FMCALC16.cbl
mv INP16002.cbl FMRJCT16.cbl 
mv INP16003.cbl FMSNT16.cbl  
mv INP16004.cbl FMTWEK16.cbl 
mv INP16005.cbl IMCALC16.cbl 
mv INP16006.cbl IMMAPI16.cbl 
mv INP16007.cbl IMMAPO16.cbl 
mv INP16008.cbl IMMSGE16.cbl 
mv INP16009.cbl IMPLUS16.cbl 
mv INP16010.cbl IMTWEK16.cbl 
mv INP16011.cbl INAS2016.cbl 
mv INP16012.cbl INCOMP16.cbl 
mv INP16013.cbl INFUNC16.cbl 
mv INP16014.cbl ININAR16.cbl 
mv INP16015.cbl INLCL16.cbl  
mv INP16016.cbl INMIGR16.cbl 
mv INP16017.cbl INTAX16.cbl  

mv INC16001.cbl FMR16.cbl    
mv INC16002.cbl FMREXT16.cbl 
mv INC16004.cbl FEDWRK16.cbl 
mv INC16005.cbl FMCNST16.cbl 
mv INC16006.cbl FUNCWA16.cbl 
mv INC16007.cbl GLOBAL16.cbl 
mv INC16008.cbl IMCNST16.cbl 
mv INC16009.cbl INAR16.cbl   
mv INC16010.cbl PLUSWA16.cbl 
mv INC16011.cbl IMR16.cbl    
mv INC16012.cbl IMREXT16.cbl 
mv INC16013.cbl PROWRK16.cbl 
mv INC16014.cbl TAXPRM16.cbl
mv INC16015.cbl IWKGLB16.cbl


# Copy converted INAS Objects from Work Area #2 to Unicode Source area 

echo "     "
echo "$0 : Copying Converted INAS 2016-2017 COBOL files to COBOL Unicode Source area..."

cp FMCALC16.cbl $PS_SRC_HOME/src/cblunicode
cp FMRJCT16.cbl $PS_SRC_HOME/src/cblunicode
cp FMSNT16.cbl $PS_SRC_HOME/src/cblunicode
cp FMTWEK16.cbl $PS_SRC_HOME/src/cblunicode
cp IMCALC16.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPI16.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPO16.cbl $PS_SRC_HOME/src/cblunicode
cp IMMSGE16.cbl $PS_SRC_HOME/src/cblunicode
cp IMPLUS16.cbl $PS_SRC_HOME/src/cblunicode
cp IMTWEK16.cbl $PS_SRC_HOME/src/cblunicode
cp INAS2016.cbl $PS_SRC_HOME/src/cblunicode
cp INCOMP16.cbl $PS_SRC_HOME/src/cblunicode
cp INFUNC16.cbl $PS_SRC_HOME/src/cblunicode
cp ININAR16.cbl $PS_SRC_HOME/src/cblunicode
cp INLCL16.cbl $PS_SRC_HOME/src/cblunicode
cp INMIGR16.cbl $PS_SRC_HOME/src/cblunicode
cp INTAX16.cbl $PS_SRC_HOME/src/cblunicode

cp FMR16.cbl $PS_SRC_HOME/src/cblunicode
cp FMREXT16.cbl $PS_SRC_HOME/src/cblunicode
cp FEDWRK16.cbl $PS_SRC_HOME/src/cblunicode
cp FMCNST16.cbl $PS_SRC_HOME/src/cblunicode
cp FUNCWA16.cbl $PS_SRC_HOME/src/cblunicode
cp GLOBAL16.cbl $PS_SRC_HOME/src/cblunicode
cp IMCNST16.cbl $PS_SRC_HOME/src/cblunicode
cp INAR16.cbl $PS_SRC_HOME/src/cblunicode
cp PLUSWA16.cbl $PS_SRC_HOME/src/cblunicode
cp IMR16.cbl $PS_SRC_HOME/src/cblunicode
cp IMREXT16.cbl $PS_SRC_HOME/src/cblunicode
cp PROWRK16.cbl $PS_SRC_HOME/src/cblunicode
cp TAXPRM16.cbl $PS_SRC_HOME/src/cblunicode
cp IWKGLB16.cbl $PS_SRC_HOME/src/cblunicode

echo "     "
echo "$0 : Converted INAS 2016-2017 COBOL files successfully copied to COBOL Unicode Source area..."


# To facilitate Batch INAS Compile, copy batch compile input file to Unicode Source area 

if [ -r $PS_SRC_HOME/src/cbl/INASBL16.cbl ]
  then
       cp $PS_SRC_HOME/src/cbl/INASBL16.cbl $PS_SRC_HOME/src/cblunicode
       chmod a+rwx $PS_SRC_HOME/src/cblunicode/INASBL16.cbl
       echo "     "
       echo "$0 : Batch compile input driver file staged to COBOL Unicode Source area."
fi


echo "     "
echo "$0 : All INAS 2016-2017 COBOL files successfully converted and staged."
echo "     "
echo "     "
echo "$0 : INAS 2016-2017 Unicode conversion routine ending on `date`..."
echo "     "

fi
