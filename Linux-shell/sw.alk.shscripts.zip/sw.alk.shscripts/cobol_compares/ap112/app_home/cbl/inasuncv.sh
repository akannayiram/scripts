#!/bin/sh
#
# inasuncv.sh
#

PS_SRC_HOME=${PS_HOME}
if [ "${PS_compile_apps}" = "Y" ]; then
    PS_SRC_HOME=${PS_APP_HOME}
    if [ "${PS_compile_cust}" = "Y" ]; then
        if [ ! -x $PS_CUST_APP_HOME/temp ]
        then
            mkdir $PS_CUST_APP_HOME/temp
        fi
        rm -rf $PS_CUST_APP_HOME/temp/*
        PS_SRC_HOME=${PS_CUST_APP_HOME}
    fi
elif [ "${PS_compile_cust}" = "Y" ]; then
    if [ ! -x $PS_CUST_HOME/temp ]
    then
        mkdir $PS_CUST_HOME/temp
    fi
    rm -rf $PS_CUST_HOME/temp/*
    PS_SRC_HOME=${PS_CUST_HOME}
fi


echo "    "
echo "$0 : INAS Unicode conversion routine beginning on `date`..."
echo "    "


#######################################################################################
# Create Work Area folders and set appropriate folder permissions
#######################################################################################

echo "$0 : =========================================== "
echo "$0 : **** PS_SRC_HOME = $PS_SRC_HOME ***** "
echo "$0 : =========================================== "

#PS_SRC_HOME=${PS_SRC_HOME}

echo "$0 : Creating Work Area 1 folder..."
cd ${PS_SRC_HOME}
if [ ! -e inaswk1 ]
 then
      mkdir inaswk1
      chmod a+x ${PS_SRC_HOME}/inaswk1
fi 

echo "     "
echo "$0 : Creating Work Area 3 folder..."
cd ${PS_SRC_HOME}
if [ ! -e inaswk3 ]
 then
      mkdir inaswk3
      chmod a+x ${PS_SRC_HOME}/inaswk3 
fi


#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################
#echo "     "
#echo " > Creating Unicode Conversion Output Area..."
#cd ${PS_SRC_HOME}
#cd src
#if [  ! -x cblunicode ]
# then
#      mkdir cblunicode
#      chmod a+rwx cblunicode
#fi
#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################


#######################################################################################
# Copy INAS Objects to Work Area #1
#######################################################################################

echo "$0 :     "
echo "$0 : Copying all COBOL files to Work Area 1..."

cp ${PS_SRC_HOME}/src/cbl/*.cbl ${PS_SRC_HOME}/inaswk1


echo "$0 :     "
echo "$0 : Renaming INAS COBOL files in Work Area 1 to PS Standard..."

cd ${PS_SRC_HOME}
cd inaswk1


#######################################################################################
# Rename all INAS Objects in Work Area #1 to conform to the PeopleSoft naming standard 
#######################################################################################


mv FMCALC10.cbl INP10001.cbl
mv FMRJCT10.cbl INP10002.cbl
mv FMSNT10.cbl  INP10003.cbl
mv FMTWEK10.cbl INP10004.cbl
mv IMCALC10.cbl INP10005.cbl
mv IMMAPI10.cbl INP10006.cbl
mv IMMAPO10.cbl INP10007.cbl
mv IMMSGE10.cbl INP10008.cbl
mv IMPLUS10.cbl INP10009.cbl
mv IMTWEK10.cbl INP10010.cbl
mv INAS2010.cbl INP10011.cbl
mv INCOMP10.cbl INP10012.cbl
mv INFUNC10.cbl INP10013.cbl
mv ININAR10.cbl INP10014.cbl
mv INLCL10.cbl  INP10015.cbl
mv INMIGR10.cbl INP10016.cbl
mv INTAX10.cbl  INP10017.cbl

mv FED10.cbl    INC10001.cbl
mv FEDEXT10.cbl INC10002.cbl
mv FEDORI10.cbl INC10003.cbl
mv FEDWRK10.cbl INC10004.cbl
mv FMCNST10.cbl INC10005.cbl
mv FUNCWA10.cbl INC10006.cbl
mv GLOBAL10.cbl INC10007.cbl
mv IMCNST10.cbl INC10008.cbl
mv INAR10.cbl   INC10009.cbl
mv PLUSWA10.cbl INC10010.cbl
mv IMR10.cbl    INC10011.cbl
mv IMREXT10.cbl INC10012.cbl
mv PROWRK10.cbl INC10013.cbl
mv TAXPRM10.cbl INC10014.cbl
mv IWKGLB10.cbl INC10015.cbl

mv FMCALC11.cbl INP11001.cbl
mv FMRJCT11.cbl INP11002.cbl
mv FMSNT11.cbl  INP11003.cbl
mv FMTWEK11.cbl INP11004.cbl
mv IMCALC11.cbl INP11005.cbl
mv IMMAPI11.cbl INP11006.cbl
mv IMMAPO11.cbl INP11007.cbl
mv IMMSGE11.cbl INP11008.cbl
mv IMPLUS11.cbl INP11009.cbl
mv IMTWEK11.cbl INP11010.cbl
mv INAS2011.cbl INP11011.cbl
mv INCOMP11.cbl INP11012.cbl
mv INFUNC11.cbl INP11013.cbl
mv ININAR11.cbl INP11014.cbl
mv INLCL11.cbl  INP11015.cbl
mv INMIGR11.cbl INP11016.cbl
mv INTAX11.cbl  INP11017.cbl

mv FED11.cbl    INC11001.cbl
mv FEDEXT11.cbl INC11002.cbl
mv FEDORI11.cbl INC11003.cbl
mv FEDWRK11.cbl INC11004.cbl
mv FMCNST11.cbl INC11005.cbl
mv FUNCWA11.cbl INC11006.cbl
mv GLOBAL11.cbl INC11007.cbl
mv IMCNST11.cbl INC11008.cbl
mv INAR11.cbl   INC11009.cbl
mv PLUSWA11.cbl INC11010.cbl
mv IMR11.cbl    INC11011.cbl
mv IMREXT11.cbl INC11012.cbl
mv PROWRK11.cbl INC11013.cbl
mv TAXPRM11.cbl INC11014.cbl
mv IWKGLB11.cbl INC11015.cbl

mv FMCALC12.cbl INP12001.cbl
mv FMRJCT12.cbl INP12002.cbl
mv FMSNT12.cbl  INP12003.cbl
mv FMTWEK12.cbl INP12004.cbl
mv IMCALC12.cbl INP12005.cbl
mv IMMAPI12.cbl INP12006.cbl
mv IMMAPO12.cbl INP12007.cbl
mv IMMSGE12.cbl INP12008.cbl
mv IMPLUS12.cbl INP12009.cbl
mv IMTWEK12.cbl INP12010.cbl
mv INAS2012.cbl INP12011.cbl
mv INCOMP12.cbl INP12012.cbl
mv INFUNC12.cbl INP12013.cbl
mv ININAR12.cbl INP12014.cbl
mv INLCL12.cbl  INP12015.cbl
mv INMIGR12.cbl INP12016.cbl
mv INTAX12.cbl  INP12017.cbl

mv FMR12.cbl    INC12001.cbl
mv FMREXT12.cbl INC12002.cbl
mv FEDWRK12.cbl INC12004.cbl
mv FMCNST12.cbl INC12005.cbl
mv FUNCWA12.cbl INC12006.cbl
mv GLOBAL12.cbl INC12007.cbl
mv IMCNST12.cbl INC12008.cbl
mv INAR12.cbl   INC12009.cbl
mv PLUSWA12.cbl INC12010.cbl
mv IMR12.cbl    INC12011.cbl
mv IMREXT12.cbl INC12012.cbl
mv PROWRK12.cbl INC12013.cbl
mv TAXPRM12.cbl INC12014.cbl
mv IWKGLB12.cbl INC12015.cbl

mv FMCALC13.cbl INP13001.cbl
mv FMRJCT13.cbl INP13002.cbl
mv FMSNT13.cbl  INP13003.cbl
mv FMTWEK13.cbl INP13004.cbl
mv IMCALC13.cbl INP13005.cbl
mv IMMAPI13.cbl INP13006.cbl
mv IMMAPO13.cbl INP13007.cbl
mv IMMSGE13.cbl INP13008.cbl
mv IMPLUS13.cbl INP13009.cbl
mv IMTWEK13.cbl INP13010.cbl
mv INAS2013.cbl INP13011.cbl
mv INCOMP13.cbl INP13012.cbl
mv INFUNC13.cbl INP13013.cbl
mv ININAR13.cbl INP13014.cbl
mv INLCL13.cbl  INP13015.cbl
mv INMIGR13.cbl INP13016.cbl
mv INTAX13.cbl  INP13017.cbl

mv FMR13.cbl    INC13001.cbl
mv FMREXT13.cbl INC13002.cbl
mv FEDWRK13.cbl INC13004.cbl
mv FMCNST13.cbl INC13005.cbl
mv FUNCWA13.cbl INC13006.cbl
mv GLOBAL13.cbl INC13007.cbl
mv IMCNST13.cbl INC13008.cbl
mv INAR13.cbl   INC13009.cbl
mv PLUSWA13.cbl INC13010.cbl
mv IMR13.cbl    INC13011.cbl
mv IMREXT13.cbl INC13012.cbl
mv PROWRK13.cbl INC13013.cbl
mv TAXPRM13.cbl INC13014.cbl
mv IWKGLB13.cbl INC13015.cbl

mv FMCALC14.cbl INP14001.cbl
mv FMRJCT14.cbl INP14002.cbl
mv FMSNT14.cbl  INP14003.cbl
mv FMTWEK14.cbl INP14004.cbl
mv IMCALC14.cbl INP14005.cbl
mv IMMAPI14.cbl INP14006.cbl
mv IMMAPO14.cbl INP14007.cbl
mv IMMSGE14.cbl INP14008.cbl
mv IMPLUS14.cbl INP14009.cbl
mv IMTWEK14.cbl INP14010.cbl
mv INAS2014.cbl INP14011.cbl
mv INCOMP14.cbl INP14012.cbl
mv INFUNC14.cbl INP14013.cbl
mv ININAR14.cbl INP14014.cbl
mv INLCL14.cbl  INP14015.cbl
mv INMIGR14.cbl INP14016.cbl
mv INTAX14.cbl  INP14017.cbl

mv FMR14.cbl    INC14001.cbl
mv FMREXT14.cbl INC14002.cbl
mv FEDWRK14.cbl INC14004.cbl
mv FMCNST14.cbl INC14005.cbl
mv FUNCWA14.cbl INC14006.cbl
mv GLOBAL14.cbl INC14007.cbl
mv IMCNST14.cbl INC14008.cbl
mv INAR14.cbl   INC14009.cbl
mv PLUSWA14.cbl INC14010.cbl
mv IMR14.cbl    INC14011.cbl
mv IMREXT14.cbl INC14012.cbl
mv PROWRK14.cbl INC14013.cbl
mv TAXPRM14.cbl INC14014.cbl
mv IWKGLB14.cbl INC14015.cbl

mv FMCALC15.cbl INP15001.cbl
mv FMRJCT15.cbl INP15002.cbl
mv FMSNT15.cbl  INP15003.cbl
mv FMTWEK15.cbl INP15004.cbl
mv IMCALC15.cbl INP15005.cbl
mv IMMAPI15.cbl INP15006.cbl
mv IMMAPO15.cbl INP15007.cbl
mv IMMSGE15.cbl INP15008.cbl
mv IMPLUS15.cbl INP15009.cbl
mv IMTWEK15.cbl INP15010.cbl
mv INAS2015.cbl INP15011.cbl
mv INCOMP15.cbl INP15012.cbl
mv INFUNC15.cbl INP15013.cbl
mv ININAR15.cbl INP15014.cbl
mv INLCL15.cbl  INP15015.cbl
mv INMIGR15.cbl INP15016.cbl
mv INTAX15.cbl  INP15017.cbl

mv FMR15.cbl    INC15001.cbl
mv FMREXT15.cbl INC15002.cbl
mv FEDWRK15.cbl INC15004.cbl
mv FMCNST15.cbl INC15005.cbl
mv FUNCWA15.cbl INC15006.cbl
mv GLOBAL15.cbl INC15007.cbl
mv IMCNST15.cbl INC15008.cbl
mv INAR15.cbl   INC15009.cbl
mv PLUSWA15.cbl INC15010.cbl
mv IMR15.cbl    INC15011.cbl
mv IMREXT15.cbl INC15012.cbl
mv PROWRK15.cbl INC15013.cbl
mv TAXPRM15.cbl INC15014.cbl
mv IWKGLB15.cbl INC15015.cbl

mv FMCALC16.cbl INP16001.cbl
mv FMRJCT16.cbl INP16002.cbl
mv FMSNT16.cbl  INP16003.cbl
mv FMTWEK16.cbl INP16004.cbl
mv IMCALC16.cbl INP16005.cbl
mv IMMAPI16.cbl INP16006.cbl
mv IMMAPO16.cbl INP16007.cbl
mv IMMSGE16.cbl INP16008.cbl
mv IMPLUS16.cbl INP16009.cbl
mv IMTWEK16.cbl INP16010.cbl
mv INAS2016.cbl INP16011.cbl
mv INCOMP16.cbl INP16012.cbl
mv INFUNC16.cbl INP16013.cbl
mv ININAR16.cbl INP16014.cbl
mv INLCL16.cbl  INP16015.cbl
mv INMIGR16.cbl INP16016.cbl
mv INTAX16.cbl  INP16017.cbl

mv FMR16.cbl    INC16001.cbl
mv FMREXT16.cbl INC16002.cbl
mv FEDWRK16.cbl INC16004.cbl
mv FMCNST16.cbl INC16005.cbl
mv FUNCWA16.cbl INC16006.cbl
mv GLOBAL16.cbl INC16007.cbl
mv IMCNST16.cbl INC16008.cbl
mv INAR16.cbl   INC16009.cbl
mv PLUSWA16.cbl INC16010.cbl
mv IMR16.cbl    INC16011.cbl
mv IMREXT16.cbl INC16012.cbl
mv PROWRK16.cbl INC16013.cbl
mv TAXPRM16.cbl INC16014.cbl
mv IWKGLB16.cbl INC16015.cbl

mv FMCALC17.cbl INP17001.cbl
mv FMRJCT17.cbl INP17002.cbl
mv FMSNT17.cbl  INP17003.cbl
mv FMTWEK17.cbl INP17004.cbl
mv IMCALC17.cbl INP17005.cbl
mv IMMAPI17.cbl INP17006.cbl
mv IMMAPO17.cbl INP17007.cbl
mv IMMSGE17.cbl INP17008.cbl
mv IMPLUS17.cbl INP17009.cbl
mv IMTWEK17.cbl INP17010.cbl
mv INAS2017.cbl INP17011.cbl
mv INCOMP17.cbl INP17012.cbl
mv INFUNC17.cbl INP17013.cbl
mv ININAR17.cbl INP17014.cbl
mv INLCL17.cbl  INP17015.cbl
mv INMIGR17.cbl INP17016.cbl
mv INTAX17.cbl  INP17017.cbl

mv FMR17.cbl    INC17001.cbl
mv FMREXT17.cbl INC17002.cbl
mv FEDWRK17.cbl INC17004.cbl
mv FMCNST17.cbl INC17005.cbl
mv FUNCWA17.cbl INC17006.cbl
mv GLOBAL17.cbl INC17007.cbl
mv IMCNST17.cbl INC17008.cbl
mv INAR17.cbl   INC17009.cbl
mv PLUSWA17.cbl INC17010.cbl
mv IMR17.cbl    INC17011.cbl
mv IMREXT17.cbl INC17012.cbl
mv PROWRK17.cbl INC17013.cbl
mv TAXPRM17.cbl INC17014.cbl
mv IWKGLB17.cbl INC17015.cbl

cd 
cd 
