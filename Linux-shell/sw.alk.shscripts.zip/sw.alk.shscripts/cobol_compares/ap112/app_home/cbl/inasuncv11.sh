#!/bin/sh
#
# inasuncv.mak
#


TARGET_SAVE=`echo $1`
TARGET=`echo $1 |  tr abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ`

#echo ${TARGET}

PS_compile_apps=N; export PS_compile_apps
PS_compile_cust=N; export PS_compile_cust
if [ "${TARGET}" = "" ]; then
    if [ "${PS_APP_HOME}" = "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_APP_HOME}" != "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_HOME}" != "${PS_HOME}" ]; then
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_APP_HOME}" != "${PS_APP_HOME}" ]; then
        PS_compile_cust=Y
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
    fi    
else
    case "${TARGET}" in
    "PS_HOME")
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
        ;;
    "PS_APP_HOME")
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_HOME")
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_APP_HOME")
        PS_compile_apps=Y
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
        ;;
    *)    
        echo "Wrong usage of the program"
        PS_Usage || return $?
        ;;
    esac
fi

#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################
echo
echo "$0 : ** PS_HOME          = ${PS_HOME} **"
echo "$0 : ** PS_APP_HOME      = ${PS_APP_HOME} **"
echo "$0 : ** PS_CUST_HOME     = ${PS_CUST_HOME} **"
echo "$0 : ** PS_CUST_APP_HOME = ${PS_CUST_APP_HOME} **"
echo
echo "$0 : ** PS_SRC_HOME      = ${PS_SRC_HOME} **"
echo
#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################

echo "    "
echo "$0 : INAS 2011-2012 Unicode conversion routine beginning on `date`..."
echo "    "


#######################################################################################
# Create Work Area folders and set appropriate folder permissions
#######################################################################################

echo "    "
echo "$0 : Creating Work Area 1 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk11 ]
 then
      mkdir inaswk11
      chmod a+rwx inaswk11
fi 

echo "     "
echo "$0 : Creating Work Area 2 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk2 ]
 then
      mkdir inaswk2
      chmod a+rwx inaswk2 
fi


#######################################################################################
echo "     "
echo "$0 : Creating Unicode COBOL Conversion Output Area..."
cd $PS_SRC_HOME
cd src
if [  ! -x cblunicode ]
 then
      mkdir cblunicode
      chmod a+rwx cblunicode
fi
#######################################################################################


#######################################################################################
# Copy INAS Objects to Work Area #1
#######################################################################################

echo "     "
echo "$0 : Copying INAS 2011-2012 COBOL files to Work Area 1..."

# 2011 INAS Programs 

cp $PS_SRC_HOME/src/cbl/FMCALC11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/FMRJCT11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/FMSNT11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/FMTWEK11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IMCALC11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IMMAPI11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IMMAPO11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IMMSGE11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IMPLUS11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IMTWEK11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/INAS2011.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/INCOMP11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/INFUNC11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/ININAR11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/INLCL11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/INMIGR11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/INTAX11.cbl $PS_SRC_HOME/inaswk11

# 2011 INAS Copybooks 

cp $PS_SRC_HOME/src/cbl/FED11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/FEDEXT11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/FEDORI11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/FEDWRK11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/FMCNST11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/FUNCWA11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/GLOBAL11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IMCNST11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/INAR11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/PLUSWA11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IMR11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IMREXT11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/PROWRK11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/TAXPRM11.cbl $PS_SRC_HOME/inaswk11
cp $PS_SRC_HOME/src/cbl/IWKGLB11.cbl $PS_SRC_HOME/inaswk11


echo "     "
echo "$0 : Renaming INAS COBOL files in Work Area 1 to PS Standard..."

cd $PS_SRC_HOME
cd inaswk11

#######################################################################################
# Rename all INAS Objects in Work Area #1 to conform to the PeopleSoft naming standard 
#######################################################################################

mv FMCALC11.cbl INP11001.cbl
mv FMRJCT11.cbl INP11002.cbl
mv FMSNT11.cbl  INP11003.cbl
mv FMTWEK11.cbl INP11004.cbl
mv IMCALC11.cbl INP11005.cbl
mv IMMAPI11.cbl INP11006.cbl
mv IMMAPO11.cbl INP11007.cbl
mv IMMSGE11.cbl INP11008.cbl
mv IMPLUS11.cbl INP11009.cbl
mv IMTWEK11.cbl INP11010.cbl
mv INAS2011.cbl INP11011.cbl
mv INCOMP11.cbl INP11012.cbl
mv INFUNC11.cbl INP11013.cbl
mv ININAR11.cbl INP11014.cbl
mv INLCL11.cbl  INP11015.cbl
mv INMIGR11.cbl INP11016.cbl
mv INTAX11.cbl  INP11017.cbl

mv FED11.cbl    INC11001.cbl
mv FEDEXT11.cbl INC11002.cbl
mv FEDORI11.cbl INC11003.cbl
mv FEDWRK11.cbl INC11004.cbl
mv FMCNST11.cbl INC11005.cbl
mv FUNCWA11.cbl INC11006.cbl
mv GLOBAL11.cbl INC11007.cbl
mv IMCNST11.cbl INC11008.cbl
mv INAR11.cbl   INC11009.cbl
mv PLUSWA11.cbl INC11010.cbl
mv IMR11.cbl    INC11011.cbl
mv IMREXT11.cbl INC11012.cbl
mv PROWRK11.cbl INC11013.cbl
mv TAXPRM11.cbl INC11014.cbl
mv IWKGLB11.cbl INC11015.cbl


#######################################################################################
# Run PeopleSoft COBOL Unicode Conversion program against INAS modules in Work Area #1.
# Converted INAS modules will be written to Work Area #2. 
#######################################################################################

echo "     "
echo "$0 : Converting all INAS 2011-2012 COBOL files in Work Area 1 to Unicode..."

#cd $PS_SRC_HOME/bin

$PS_HOME/bin/pscblucvrt -s:$PS_SRC_HOME/inaswk11 -t:$PS_SRC_HOME/inaswk2 -rd:$PS_SRC_HOME/inaswk2


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error.log ]
then
     mv $PS_SRC_HOME/inaswk2/cblcvrt_error.log $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1112.log
fi

#######################################################################################
# If INAS Unicode conversion is not successful, display Warning message and terminate
# processing.  If INAS Unicode conversion is successful, rename converted files back to
# original file names, and copy renamed files to Unicode COBOL source code folder. 
#######################################################################################


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1112.log ]
then
    echo "     "
    echo "$0 : Warning: Not all INAS 2011-2012 COBOL files were converted for Unicode successfully"
    echo "$0 : Warning: See $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1112.log for messages"
    echo "     "
else

mv $PS_SRC_HOME/inaswk2/cblcvrt_summary.log $PS_SRC_HOME/inaswk2/cblcvrt_summary_inas1112.log
mv $PS_SRC_HOME/inaswk2/convert_bindsetup.log $PS_SRC_HOME/inaswk2/convert_bindsetup_inas1112.log
mv $PS_SRC_HOME/inaswk2/convert_date_exception.log $PS_SRC_HOME/inaswk2/convert_date_exception_inas1112.log
mv $PS_SRC_HOME/inaswk2/convert_exception.log $PS_SRC_HOME/inaswk2/convert_exception_inas1112.log

echo "     "
echo "$0 : All INAS COBOL files converted for Unicode successfully and written to Work Area 2.. "
echo "     "
echo "$0 : Renaming INAS 2011-2012 COBOL files back to original file names..."

cd $PS_SRC_HOME
cd inaswk2

# Rename all INAS Objects back to original filenames 

mv INP11001.cbl FMCALC11.cbl
mv INP11002.cbl FMRJCT11.cbl 
mv INP11003.cbl FMSNT11.cbl  
mv INP11004.cbl FMTWEK11.cbl 
mv INP11005.cbl IMCALC11.cbl 
mv INP11006.cbl IMMAPI11.cbl 
mv INP11007.cbl IMMAPO11.cbl 
mv INP11008.cbl IMMSGE11.cbl 
mv INP11009.cbl IMPLUS11.cbl 
mv INP11010.cbl IMTWEK11.cbl 
mv INP11011.cbl INAS2011.cbl 
mv INP11012.cbl INCOMP11.cbl 
mv INP11013.cbl INFUNC11.cbl 
mv INP11014.cbl ININAR11.cbl 
mv INP11015.cbl INLCL11.cbl  
mv INP11016.cbl INMIGR11.cbl 
mv INP11017.cbl INTAX11.cbl  

mv INC11001.cbl FED11.cbl    
mv INC11002.cbl FEDEXT11.cbl
mv INC11003.cbl FEDORI11.cbl  
mv INC11004.cbl FEDWRK11.cbl 
mv INC11005.cbl FMCNST11.cbl 
mv INC11006.cbl FUNCWA11.cbl 
mv INC11007.cbl GLOBAL11.cbl 
mv INC11008.cbl IMCNST11.cbl 
mv INC11009.cbl INAR11.cbl   
mv INC11010.cbl PLUSWA11.cbl 
mv INC11011.cbl IMR11.cbl    
mv INC11012.cbl IMREXT11.cbl 
mv INC11013.cbl PROWRK11.cbl 
mv INC11014.cbl TAXPRM11.cbl
mv INC11015.cbl IWKGLB11.cbl


# Copy converted INAS Objects from Work Area #2 to Unicode Source area 

echo "     "
echo "$0 : Copying Converted INAS 2011-2012 COBOL files to COBOL Unicode Source area..."

cp FMCALC11.cbl $PS_SRC_HOME/src/cblunicode
cp FMRJCT11.cbl $PS_SRC_HOME/src/cblunicode
cp FMSNT11.cbl $PS_SRC_HOME/src/cblunicode
cp FMTWEK11.cbl $PS_SRC_HOME/src/cblunicode
cp IMCALC11.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPI11.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPO11.cbl $PS_SRC_HOME/src/cblunicode
cp IMMSGE11.cbl $PS_SRC_HOME/src/cblunicode
cp IMPLUS11.cbl $PS_SRC_HOME/src/cblunicode
cp IMTWEK11.cbl $PS_SRC_HOME/src/cblunicode
cp INAS2011.cbl $PS_SRC_HOME/src/cblunicode
cp INCOMP11.cbl $PS_SRC_HOME/src/cblunicode
cp INFUNC11.cbl $PS_SRC_HOME/src/cblunicode
cp ININAR11.cbl $PS_SRC_HOME/src/cblunicode
cp INLCL11.cbl $PS_SRC_HOME/src/cblunicode
cp INMIGR11.cbl $PS_SRC_HOME/src/cblunicode
cp INTAX11.cbl $PS_SRC_HOME/src/cblunicode

cp FED11.cbl $PS_SRC_HOME/src/cblunicode
cp FEDEXT11.cbl $PS_SRC_HOME/src/cblunicode
cp FEDORI11.cbl $PS_SRC_HOME/src/cblunicode
cp FEDWRK11.cbl $PS_SRC_HOME/src/cblunicode
cp FMCNST11.cbl $PS_SRC_HOME/src/cblunicode
cp FUNCWA11.cbl $PS_SRC_HOME/src/cblunicode
cp GLOBAL11.cbl $PS_SRC_HOME/src/cblunicode
cp IMCNST11.cbl $PS_SRC_HOME/src/cblunicode
cp INAR11.cbl $PS_SRC_HOME/src/cblunicode
cp PLUSWA11.cbl $PS_SRC_HOME/src/cblunicode
cp IMR11.cbl $PS_SRC_HOME/src/cblunicode
cp IMREXT11.cbl $PS_SRC_HOME/src/cblunicode
cp PROWRK11.cbl $PS_SRC_HOME/src/cblunicode
cp TAXPRM11.cbl $PS_SRC_HOME/src/cblunicode
cp IWKGLB11.cbl $PS_SRC_HOME/src/cblunicode

echo "     "
echo "$0 : Converted INAS 2011-2012 COBOL files successfully copied to COBOL Unicode Source area..."


# To facilitate Batch INAS Compile, copy batch compile input file to Unicode Source area 

if [ -r $PS_SRC_HOME/src/cbl/INASBL11.cbl ]
  then
       cp $PS_SRC_HOME/src/cbl/INASBL11.cbl $PS_SRC_HOME/src/cblunicode
       chmod a+rwx $PS_SRC_HOME/src/cblunicode/INASBL11.cbl
       echo "     "
       echo "$0 : Batch compile input driver file staged to COBOL Unicode Source area."
fi


echo "     "
echo "$0 : All INAS 2011-2012 COBOL files successfully converted and staged."
echo "     "
echo "     "
echo "$0 : INAS 2011-2012 Unicode conversion routine ending on `date`..."
echo "     "

fi
