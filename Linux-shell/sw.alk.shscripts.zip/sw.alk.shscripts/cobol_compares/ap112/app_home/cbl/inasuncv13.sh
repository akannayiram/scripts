#!/bin/sh
#
# inasuncv.mak
#


TARGET_SAVE=`echo $1`
TARGET=`echo $1 |  tr abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ`

#echo ${TARGET}

PS_compile_apps=N; export PS_compile_apps
PS_compile_cust=N; export PS_compile_cust
if [ "${TARGET}" = "" ]; then
    if [ "${PS_APP_HOME}" = "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_APP_HOME}" != "${PS_HOME}" ]; then
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_HOME}" != "${PS_HOME}" ]; then
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
    fi
    if [ "${PS_CUST_APP_HOME}" != "${PS_APP_HOME}" ]; then
        PS_compile_cust=Y
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
    fi    
else
    case "${TARGET}" in
    "PS_HOME")
        PS_SRC_HOME=${PS_HOME}; export PS_SRC_HOME
        ;;
    "PS_APP_HOME")
        PS_compile_apps=Y
        PS_SRC_HOME=${PS_APP_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_HOME")
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_HOME}; export PS_SRC_HOME
        ;;
    "PS_CUST_APP_HOME")
        PS_compile_apps=Y
        PS_compile_cust=Y
        PS_SRC_HOME=${PS_CUST_APP_HOME}; export PS_SRC_HOME
        ;;
    *)    
        echo "Wrong usage of the program"
        PS_Usage || return $?
        ;;
    esac
fi

#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################
echo
echo "$0 : ** PS_HOME          = ${PS_HOME} **"
echo "$0 : ** PS_APP_HOME      = ${PS_APP_HOME} **"
echo "$0 : ** PS_CUST_HOME     = ${PS_CUST_HOME} **"
echo "$0 : ** PS_CUST_APP_HOME = ${PS_CUST_APP_HOME} **"
echo
echo "$0 : ** PS_SRC_HOME      = ${PS_SRC_HOME} **"
echo
#######################################################################################
# USE FOR TESTING ONLY - COMMENT OUT THIS SECTION IN PRODUCTION
#######################################################################################

echo "    "
echo "$0 : INAS 2013-2014 Unicode conversion routine beginning on `date`..."
echo "    "


#######################################################################################
# Create Work Area folders and set appropriate folder permissions
#######################################################################################

echo "    "
echo "$0 : Creating Work Area 1 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk13 ]
 then
      mkdir inaswk13
      chmod a+rwx inaswk13
fi 

echo "     "
echo "$0 : Creating Work Area 2 folder..."

cd $PS_SRC_HOME
if [ ! -x inaswk2 ]
 then
      mkdir inaswk2
      chmod a+rwx inaswk2 
fi


#######################################################################################
echo "     "
echo "$0 : Creating Unicode COBOL Conversion Output Area..."
cd $PS_SRC_HOME
cd src
if [  ! -x cblunicode ]
 then
      mkdir cblunicode
      chmod a+rwx cblunicode
fi
#######################################################################################


#######################################################################################
# Copy INAS Objects to Work Area #1
#######################################################################################

echo "     "
echo "$0 : Copying INAS 2013-2014 COBOL files to Work Area 1..."

# 2013 INAS Programs 

cp $PS_SRC_HOME/src/cbl/FMCALC13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/FMRJCT13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/FMSNT13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/FMTWEK13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IMCALC13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IMMAPI13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IMMAPO13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IMMSGE13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IMPLUS13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IMTWEK13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/INAS2013.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/INCOMP13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/INFUNC13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/ININAR13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/INLCL13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/INMIGR13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/INTAX13.cbl $PS_SRC_HOME/inaswk13

# 2013 INAS Copybooks 

cp $PS_SRC_HOME/src/cbl/FMR13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/FMREXT13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/FEDWRK13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/FMCNST13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/FUNCWA13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/GLOBAL13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IMCNST13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/INAR13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/PLUSWA13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IMR13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IMREXT13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/PROWRK13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/TAXPRM13.cbl $PS_SRC_HOME/inaswk13
cp $PS_SRC_HOME/src/cbl/IWKGLB13.cbl $PS_SRC_HOME/inaswk13


echo "     "
echo "$0 : Renaming INAS COBOL files in Work Area 1 to PS Standard..."

cd $PS_SRC_HOME
cd inaswk13

#######################################################################################
# Rename all INAS Objects in Work Area #1 to conform to the PeopleSoft naming standard 
#######################################################################################

mv FMCALC13.cbl INP13001.cbl
mv FMRJCT13.cbl INP13002.cbl
mv FMSNT13.cbl  INP13003.cbl
mv FMTWEK13.cbl INP13004.cbl
mv IMCALC13.cbl INP13005.cbl
mv IMMAPI13.cbl INP13006.cbl
mv IMMAPO13.cbl INP13007.cbl
mv IMMSGE13.cbl INP13008.cbl
mv IMPLUS13.cbl INP13009.cbl
mv IMTWEK13.cbl INP13010.cbl
mv INAS2013.cbl INP13011.cbl
mv INCOMP13.cbl INP13012.cbl
mv INFUNC13.cbl INP13013.cbl
mv ININAR13.cbl INP13014.cbl
mv INLCL13.cbl  INP13015.cbl
mv INMIGR13.cbl INP13016.cbl
mv INTAX13.cbl  INP13017.cbl

mv FMR13.cbl    INC13001.cbl
mv FMREXT13.cbl INC13002.cbl
mv FEDWRK13.cbl INC13004.cbl
mv FMCNST13.cbl INC13005.cbl
mv FUNCWA13.cbl INC13006.cbl
mv GLOBAL13.cbl INC13007.cbl
mv IMCNST13.cbl INC13008.cbl
mv INAR13.cbl   INC13009.cbl
mv PLUSWA13.cbl INC13010.cbl
mv IMR13.cbl    INC13011.cbl
mv IMREXT13.cbl INC13012.cbl
mv PROWRK13.cbl INC13013.cbl
mv TAXPRM13.cbl INC13014.cbl
mv IWKGLB13.cbl INC13015.cbl


#######################################################################################
# Run PeopleSoft COBOL Unicode Conversion program against INAS modules in Work Area #1.
# Converted INAS modules will be written to Work Area #2. 
#######################################################################################

echo "     "
echo "$0 : Converting all INAS 2013-2014 COBOL files in Work Area 1 to Unicode..."

#cd $PS_SRC_HOME/bin

$PS_HOME/bin/pscblucvrt -s:$PS_SRC_HOME/inaswk13 -t:$PS_SRC_HOME/inaswk2 -rd:$PS_SRC_HOME/inaswk2


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error.log ]
then
     mv $PS_SRC_HOME/inaswk2/cblcvrt_error.log $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1314.log
fi

#######################################################################################
# If INAS Unicode conversion is not successful, display Warning message and terminate
# processing.  If INAS Unicode conversion is successful, rename converted files back to
# original file names, and copy renamed files to Unicode COBOL source code folder. 
#######################################################################################


if [ -w $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1314.log ]
then
    echo "     "
    echo "$0 : Warning: Not all INAS 2013-2014 COBOL files were converted for Unicode successfully"
    echo "$0 : Warning: See $PS_SRC_HOME/inaswk2/cblcvrt_error_inas1314.log for messages"
    echo "     "
else

mv $PS_SRC_HOME/inaswk2/cblcvrt_summary.log $PS_SRC_HOME/inaswk2/cblcvrt_summary_inas1314.log
mv $PS_SRC_HOME/inaswk2/convert_bindsetup.log $PS_SRC_HOME/inaswk2/convert_bindsetup_inas1314.log
mv $PS_SRC_HOME/inaswk2/convert_date_exception.log $PS_SRC_HOME/inaswk2/convert_date_exception_inas1314.log
mv $PS_SRC_HOME/inaswk2/convert_exception.log $PS_SRC_HOME/inaswk2/convert_exception_inas1314.log

echo "     "
echo "$0 : All INAS COBOL files converted for Unicode successfully and written to Work Area 2.. "
echo "     "
echo "$0 : Renaming INAS 2013-2014 COBOL files back to original file names..."

cd $PS_SRC_HOME
cd inaswk2

# Rename all INAS Objects back to original filenames 

mv INP13001.cbl FMCALC13.cbl
mv INP13002.cbl FMRJCT13.cbl 
mv INP13003.cbl FMSNT13.cbl  
mv INP13004.cbl FMTWEK13.cbl 
mv INP13005.cbl IMCALC13.cbl 
mv INP13006.cbl IMMAPI13.cbl 
mv INP13007.cbl IMMAPO13.cbl 
mv INP13008.cbl IMMSGE13.cbl 
mv INP13009.cbl IMPLUS13.cbl 
mv INP13010.cbl IMTWEK13.cbl 
mv INP13011.cbl INAS2013.cbl 
mv INP13012.cbl INCOMP13.cbl 
mv INP13013.cbl INFUNC13.cbl 
mv INP13014.cbl ININAR13.cbl 
mv INP13015.cbl INLCL13.cbl  
mv INP13016.cbl INMIGR13.cbl 
mv INP13017.cbl INTAX13.cbl  

mv INC13001.cbl FMR13.cbl    
mv INC13002.cbl FMREXT13.cbl 
mv INC13004.cbl FEDWRK13.cbl 
mv INC13005.cbl FMCNST13.cbl 
mv INC13006.cbl FUNCWA13.cbl 
mv INC13007.cbl GLOBAL13.cbl 
mv INC13008.cbl IMCNST13.cbl 
mv INC13009.cbl INAR13.cbl   
mv INC13010.cbl PLUSWA13.cbl 
mv INC13011.cbl IMR13.cbl    
mv INC13012.cbl IMREXT13.cbl 
mv INC13013.cbl PROWRK13.cbl 
mv INC13014.cbl TAXPRM13.cbl
mv INC13015.cbl IWKGLB13.cbl


# Copy converted INAS Objects from Work Area #2 to Unicode Source area 

echo "     "
echo "$0 : Copying Converted INAS 2013-2014 COBOL files to COBOL Unicode Source area..."

cp FMCALC13.cbl $PS_SRC_HOME/src/cblunicode
cp FMRJCT13.cbl $PS_SRC_HOME/src/cblunicode
cp FMSNT13.cbl $PS_SRC_HOME/src/cblunicode
cp FMTWEK13.cbl $PS_SRC_HOME/src/cblunicode
cp IMCALC13.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPI13.cbl $PS_SRC_HOME/src/cblunicode
cp IMMAPO13.cbl $PS_SRC_HOME/src/cblunicode
cp IMMSGE13.cbl $PS_SRC_HOME/src/cblunicode
cp IMPLUS13.cbl $PS_SRC_HOME/src/cblunicode
cp IMTWEK13.cbl $PS_SRC_HOME/src/cblunicode
cp INAS2013.cbl $PS_SRC_HOME/src/cblunicode
cp INCOMP13.cbl $PS_SRC_HOME/src/cblunicode
cp INFUNC13.cbl $PS_SRC_HOME/src/cblunicode
cp ININAR13.cbl $PS_SRC_HOME/src/cblunicode
cp INLCL13.cbl $PS_SRC_HOME/src/cblunicode
cp INMIGR13.cbl $PS_SRC_HOME/src/cblunicode
cp INTAX13.cbl $PS_SRC_HOME/src/cblunicode

cp FMR13.cbl $PS_SRC_HOME/src/cblunicode
cp FMREXT13.cbl $PS_SRC_HOME/src/cblunicode
cp FEDWRK13.cbl $PS_SRC_HOME/src/cblunicode
cp FMCNST13.cbl $PS_SRC_HOME/src/cblunicode
cp FUNCWA13.cbl $PS_SRC_HOME/src/cblunicode
cp GLOBAL13.cbl $PS_SRC_HOME/src/cblunicode
cp IMCNST13.cbl $PS_SRC_HOME/src/cblunicode
cp INAR13.cbl $PS_SRC_HOME/src/cblunicode
cp PLUSWA13.cbl $PS_SRC_HOME/src/cblunicode
cp IMR13.cbl $PS_SRC_HOME/src/cblunicode
cp IMREXT13.cbl $PS_SRC_HOME/src/cblunicode
cp PROWRK13.cbl $PS_SRC_HOME/src/cblunicode
cp TAXPRM13.cbl $PS_SRC_HOME/src/cblunicode
cp IWKGLB13.cbl $PS_SRC_HOME/src/cblunicode

echo "     "
echo "$0 : Converted INAS 2013-2014 COBOL files successfully copied to COBOL Unicode Source area..."


# To facilitate Batch INAS Compile, copy batch compile input file to Unicode Source area 

if [ -r $PS_SRC_HOME/src/cbl/INASBL13.cbl ]
  then
       cp $PS_SRC_HOME/src/cbl/INASBL13.cbl $PS_SRC_HOME/src/cblunicode
       chmod a+rwx $PS_SRC_HOME/src/cblunicode/INASBL13.cbl
       echo "     "
       echo "$0 : Batch compile input driver file staged to COBOL Unicode Source area."
fi


echo "     "
echo "$0 : All INAS 2013-2014 COBOL files successfully converted and staged."
echo "     "
echo "     "
echo "$0 : INAS 2013-2014 Unicode conversion routine ending on `date`..."
echo "     "

fi
