#!/bin/bash
dir1=ux102/cust_home/cblbin
dir2=ap112/cust_home/cblbin

cd $dir1
for i in $(ls *.gnt)
do 
	echo "diff -s <(xxd ${dir1}/$i) <(xxd ${dir2}/$i)"

done

cd /software/akannayiram/cobol_compares
