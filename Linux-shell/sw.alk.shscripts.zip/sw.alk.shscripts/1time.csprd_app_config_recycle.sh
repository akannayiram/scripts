#!/bin/bash
echo " "
date
echo "Server Status"
echo "=========================="
psadmin -c sstatus -d CNYCSPR1
echo " "
date
echo "Server Stop"
echo "=========================="
psadmin -c stop -d CNYCSPR1
echo " "
date
echo "Cache Purge"
echo "=========================="
psadmin -c purge -d CNYCSPR1 -noarch
echo " "
date
echo "Configure "
echo "=========================="
#psadmin -c configure -d CNYCSPR1 -cfg_from_file /appl/psft/cfg/cnycsprd/appserv/CNYCSPR1/psappsrv.cfg
psadmin -c configure -d CNYCSPR1 
echo " "
date
echo "Server Start"
echo "=========================="
psadmin -c start -d CNYCSPR1

# Saving these lines for easy copy and paste
# /software/akannayiram/1time.csprd_app_config_recycle.sh | tee -a /tmp/$HOSTNAME.$USER.csprd_app_reconfig.$(date '+%Y%m%d_%H%M%S').log 

