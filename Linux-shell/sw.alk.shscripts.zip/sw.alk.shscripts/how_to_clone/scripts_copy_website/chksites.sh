logdir=/software/akannayiram/how_to_clone/scripts_copy_website/logs
logfile=$logdir/piasites.np.${HOSTNAME}.${LOGNAME}.3-5-2025.txt
echo "************************************"   >> $logfile
echo "$HOSTNAME  User: $LOGNAME"   >> $logfile
echo "************************************"   >> $logfile
echo "CONFIG"   >> $logfile
#find . -path "*/PORTAL.war/*/configuration.properties" -type f |grep -E "dem|ug1|ug2|sit|dm2|erec"
#find . -path "*/PORTAL.war/*/configuration.properties" -type f |grep -E "dm2|rpu" | sed -e "s/^/ZZ/"   >> $logfile
find $HOME -path "*/PORTAL.war/*/configuration.properties" -type f |grep -E "dm2|rpu"  >> $logfile
echo "SITE/CACHE"   >> $logfile
#find . -path "*/PORTAL.war/[cde]*/cache*" -type d |grep -E "dem|ug1|ug2|sit|dm2|erec"
#find . -path "*/PORTAL.war/[cde]*/cache*" -type d |grep -E "dm2|rpu" | sed -e "s/^/ZZ/"   >> $logfile
find $HOME -path "*/PORTAL.war/[cde]*/cache*" -type d |grep -E "dm2|rpu"   >> $logfile
echo "************************************"
