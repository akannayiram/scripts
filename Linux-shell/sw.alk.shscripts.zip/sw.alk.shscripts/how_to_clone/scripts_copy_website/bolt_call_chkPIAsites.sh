#!/bin/bash

build_host_file ()
{
  cat > $tmphost <<!EOF
cs92npwl050
cs92npwl051
fs92npwl050
fs92npwl051
hc92npwl050
hc92npwl051
ih92npwl050
ih92npwl051
!EOF
}


tmphost=/tmp/alk.hosts.$$.tmp;rm -f $tmphost;touch $tmphost

build_host_file

scriptsdir=/software/akannayiram/how_to_clone/scripts_copy_website
scriptnm=chkPIAcache_92np86014.sh

bolt command run ${scriptsdir}/${scriptnm} -t @"$tmphost" --tty --no-host-key-check
