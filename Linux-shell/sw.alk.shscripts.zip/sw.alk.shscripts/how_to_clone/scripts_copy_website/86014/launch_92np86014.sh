#!/bin/bash

scriptdir=/software/akannayiram/how_to_clone/scripts_copy_website/86014

logdir=/software/akannayiram/worktemp/202502logs/86014

${scriptdir}/gather_92np86014.sh | tee -a ${logdir}/${HOSTNAME}.86014.psserver.$(date '+%Y%m%d_%H%M%S').log
