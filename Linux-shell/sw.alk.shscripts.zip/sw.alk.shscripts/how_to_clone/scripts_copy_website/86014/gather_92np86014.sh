#!/bin/bash
if [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on NP Web servers"
   exit
fi

hst=${HOSTNAME%%.*}
#tmpfile=/tmp/alk.${hst}.tmpfile
tmpfile=/tmp/alk/alk.tmp

scriptdir=/software/akannayiram/how_to_clone/scripts_copy_website/86014

#echo "###############################"
dttm=$(date '+%Y-%m-%d %H:%M:%S')
echo "BEGIN: $dttm   Host: ${HOSTNAME}"
echo "*******************************"
for i in `grep cnyd /etc/hosts |grep -v "#"|grep 86014|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c ${scriptdir}/web_get_psserver_entry_86014.sh  
done

dttm=$(date '+%Y-%m-%d %H:%M:%S')
echo "END: $dttm   Host: ${HOSTNAME}"
echo " "
echo " "
cat $tmpfile
