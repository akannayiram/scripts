#!/bin/bash
# Execute against 8.60.19
tgtsite=cnycsdm2
srcsite=cnycssit
find . -path "*/PORTAL.war/${srcsite}" -type d
find . -path "*/psftdocs/${srcsite}" -type d
find . -path "*/PORTAL.war/*/psftdocs/${srcsite}/configuration.properties" -type f
srcsitedir=$(find . -path "*/PORTAL.war/${srcsite}" -type d|head -1)
srcconfigdir=$(find . -path "*/psftdocs/${srcsite}" -type d|head -1)
tgtsitebase=$(dirname $srcsitedir)
tgtconfigbase=$(dirname $srcconfigdir)
echo "cp -pr $srcsitedir ${tgtsitebase}/${tgtsite}"
echo "cp -pr $srcconfigdir ${tgtconfigbase}/${tgtsite}"
