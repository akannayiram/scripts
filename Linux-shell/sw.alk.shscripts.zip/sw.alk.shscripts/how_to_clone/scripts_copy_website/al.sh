#!/bin/bash
str="s1,s2"
IFS=","
for v in ${str}
do
  echo $v
done
