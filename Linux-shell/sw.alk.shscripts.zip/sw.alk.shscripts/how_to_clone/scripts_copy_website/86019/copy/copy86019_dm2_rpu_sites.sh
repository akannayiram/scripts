#!/bin/bash
# Execute against 8.60.19
pillar=${HOSTNAME:0:2}

[[ ${LOGNAME} =~ cny.*z ]] && { echo "Skipping ${LOGNAME}" ; echo "*******************************" ; exit; }
[[ ${LOGNAME} =~ cny.*a ]] && { srcsite=cny${pillar}sit ; tgtsites="cny${pillar}dm2,cny${pillar}rpu" ;  } || { srcsite=cny${pillar}ug2 ; tgtsites="cny${pillar}dm2,cny${pillar}rpu" ;  }
[[ "${pillar}" == "ih" ]] && { tgtsites="cny${pillar}dm2" ; }
if [[ "${pillar}" == "hc" ]] ; then
   if [[ ${LOGNAME} =~ cny.*y ]] ; then
      tgtsites="cny${pillar}dm2,cny${pillar}rpu" 
   else
      tgtsites="cny${pillar}dm2,cny${pillar}rpu" 
#      tgtsites="cny${pillar}dm2,cny${pillar}rpu,erecruit"
   fi
fi

echo "Src: $srcsite"
echo "Tgt: $tgtsites"

echo "${LOGNAME}@${HOSTNAME}: Src Site: ${srcsite}   Tgt Sites: ${tgtsites} "
#find . -path "*/PORTAL.war/${srcsite}" -type d
#find . -path "*/psftdocs/${srcsite}" -type d
#find . -path "*/PORTAL.war/*/psftdocs/${srcsite}/configuration.properties" -type f
srcsitedir=$(find . -path "*/PORTAL.war/${srcsite}" -type d|head -1)
srcconfigdir=$(find . -path "*/psftdocs/${srcsite}" -type d|head -1)

[[ ! -d $srcsitedir ]] && { echo "ERROR! ${LOGNAME}: Missing ${srcsitedir} Aborting..." ; echo "*******************************" ; exit; } || { echo "FOUND! Source: ${srcsitedir}" ; }
[[ ! -d $srcconfigdir ]] && { echo "ERROR! ${LOGNAME}: Missing ${srcconfigdir} Aborting..." ; echo "*******************************" ; exit; } || { echo "FOUND! Source: ${srcconfigdir}" ; }

tgtsitebase=$(dirname $srcsitedir)
tgtconfigbase=$(dirname $srcconfigdir)

IFS=","
for tgtsite in ${tgtsites}
do
  echo "cp -pr $srcsitedir ${tgtsitebase}/${tgtsite}"
  cp -pr $srcsitedir ${tgtsitebase}/${tgtsite}
  echo "cp -pr $srcconfigdir ${tgtconfigbase}/${tgtsite}"
  cp -pr $srcconfigdir ${tgtconfigbase}/${tgtsite}
  grep "$srcsite" ${tgtsitebase}/${tgtsite}/signon.html
  sed -e "s/$srcsite/$tgtsite/" ${tgtsitebase}/${tgtsite}/signon.html

  [[ -d "${tgtsitebase}/${tgtsite}" ]] && ls -ld "${tgtsitebase}/${tgtsite}"
  [[ -d "${tgtconfigbase}/${tgtsite}" ]] && ls -ld "${tgtconfigbase}/${tgtsite}"
  cfg="$tgtconfigbase/${tgtsite}/configuration.properties"

  if [[ -f $cfg ]] ; then
      ls  -lh $cfg
#     grep "^psserver" $cfg 
#     sed -e "s/^psserver.*$/$pssrv" $cfg 
     grep -E "^psserver|^WebProfile" $cfg 
  else
     echo "ERROR! ${LOGNAME}: Missing ${cfg} Aborting..."
     echo "*******************************"
     exit
  fi 

done

exit

 

