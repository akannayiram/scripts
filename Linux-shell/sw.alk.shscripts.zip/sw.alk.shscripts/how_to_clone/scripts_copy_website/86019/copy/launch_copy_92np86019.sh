#!/bin/bash

scriptdir=/software/akannayiram/how_to_clone/scripts_copy_website/86019/copy

logdir=/software/akannayiram/worktemp/202502logs/86019

${scriptdir}/copy_92np86019.sh | tee -a ${logdir}/${HOSTNAME}.86019.psserver.$(date '+%Y%m%d_%H%M%S').log
