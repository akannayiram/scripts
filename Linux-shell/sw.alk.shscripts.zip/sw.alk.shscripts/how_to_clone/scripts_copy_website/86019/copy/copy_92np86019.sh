#!/bin/bash
if [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on NP Web servers"
   exit
fi

scriptdir=/software/akannayiram/how_to_clone/scripts_copy_website/86019/copy


#echo "###############################"
dttm=$(date '+%Y-%m-%d %H:%M:%S')
echo "BEGIN: $dttm   Host: ${HOSTNAME}"
echo "*******************************"
for i in `grep cnyd /etc/hosts |grep -v "#"|grep 86019|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c ${scriptdir}/copy86019_dm2_rpu_sites.sh
done

dttm=$(date '+%Y-%m-%d %H:%M:%S')
echo "END: $dttm   Host: ${HOSTNAME}"
