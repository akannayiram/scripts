#!/bin/bash
# Execute against 8.60.19
# change psserver entry

[[ ${LOGNAME} =~ cny.*z ]] && { echo "Skipping ${LOGNAME}" ; echo "*******************************" ; exit; }
pillar=${HOSTNAME:0:2}
#tgtsites="cnycsdm2,cnycsrpu"
tgtsites="cny${pillar}ug2,cny${pillar}rpu,cny${pillar}sit,erecruit"
# psserver entry from 8.60.19
#pssrv="psserver=
IFS=","
for tgtsite in ${tgtsites}
do
  [[ "${tgtsite}" == "erecruit" && "${HOSTNAME}" != "hc92npwl050" ]] && { continue; } 

  cfg=$(find . -path "*/PORTAL.war/*/psftdocs/${tgtsite}/configuration.properties" -type f)

  if [[ -f $cfg ]] ; then
     #echo "$tgtsite exists on ${HOSTNAME} for ${LOGNAME} and the psserver/WebProfile entries:"
     #echo "$tgtsite exists on ${HOSTNAME} for ${LOGNAME}"
     echo "Site $tgtsite exists for ${LOGNAME}@${HOSTNAME}"
     pssrv=$(grep "^psserver" $cfg)
     grep -E "^psserver|^WebProfile" $cfg 
  else
    [[ ! "$pillar" == "ih" ]] && echo "ERROR! $tgtsite does not exist on ${HOSTNAME} for ${LOGNAME}"
  fi 
echo "*******************************"
done
echo "###############################"
#echo "*******************************"
