#!/bin/bash
if [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on NP Web servers"
   exit
fi

tmpfile=/tmp/alk/alk.tmp

scriptdir=/software/akannayiram/how_to_clone/scripts_copy_website/86019/gather

#echo "###############################"
dttm=$(date '+%Y-%m-%d %H:%M:%S')
echo "BEGIN: $dttm   Host: ${HOSTNAME}"
echo "*******************************"
for i in `grep cnyd /etc/hosts |grep -v "#"|grep 86019|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c ${scriptdir}/web_get_psserver_entry_86019.sh  
done

dttm=$(date '+%Y-%m-%d %H:%M:%S')
echo "END: $dttm   Host: ${HOSTNAME}"
echo " "
echo " "
cat $tmpfile
