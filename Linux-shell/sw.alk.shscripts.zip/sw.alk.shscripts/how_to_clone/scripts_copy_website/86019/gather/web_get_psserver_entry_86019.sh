#!/bin/bash
# Execute against 8.60.19
# check psserver entry

hst=${HOSTNAME%%.*}
#tmpfile=/tmp/alk.${hst}.tmpfile;rm -f /tmp/alk.${hst}.tmpfile
tmpfile=/tmp/alk/alk.tmp

[[ ${LOGNAME} =~ cny.*z ]] && { echo "Skipping ${LOGNAME}" ; echo "*******************************" ; exit; }
pillar=${HOSTNAME:0:2}
#tgtsites="cnycsdm2,cnycsrpu"
tgtsites="cny${pillar}dm2,cny${pillar}rpu,erecruit"
IFS=","
for tgtsite in ${tgtsites}
do
  # For IH, only dm2
  [[ "$pillar" == "ih" && ! "${tgtsite}" =~ dm2 ]] && { continue; }  
  # For sit, only 'a' user
  #[[ "${tgtsite}" =~ sit && ! ${LOGNAME} =~ cny.*a ]] && { continue; }
  # erecruit on hc050 only
  [[ "${tgtsite}" == "erecruit" && "${HOSTNAME}" != "hc92npwl050" ]] && { continue; } 

  cfg=$(find . -path "*/PORTAL.war/*/psftdocs/${tgtsite}/configuration.properties" -type f)

  if [[ -f $cfg ]] ; then
     #echo "$tgtsite exists on ${HOSTNAME} for ${LOGNAME} and the psserver/WebProfile entries:"
     #echo "$tgtsite exists on ${HOSTNAME} for ${LOGNAME}"
     echo "Site $tgtsite exists for ${LOGNAME}@${HOSTNAME}"
     pssrv=$(grep "^psserver" $cfg)
     grep -E "^psserver|^WebProfile" $cfg 
     echo " "
   #  echo "grep -E \"^psserver|^WebProfile\" $cfg " | tee -a $tmpfile
   #  echo "Command for ${LOGNAME}  ${tgtsite} :"
   #  echo " "
   #  echo "sed -i -e \"s/^psserver.\*\$/$pssrv/\" $cfg" | tee -a $tmpfile
   #  echo "grep -E \"^psserver|^WebProfile\" $cfg " | tee -a $tmpfile
     echo " "
  else
     #[[ ! "$pillar" == "ih" ]] && echo "ERROR! $tgtsite does not exist on ${HOSTNAME} for ${LOGNAME}"
     echo "ERROR! $tgtsite does not exist on ${HOSTNAME} for ${LOGNAME}"
  fi 
  
# ***********************************
# cs, fs, hc 
# a user: dm2, rpu  src: sit
# i user: dm2, rpu  src: ug2
# y user: dm2, rpu   Total: 18 
# hc:
# a user: erecruit  src: erecruitsit
# i user: erecruit   Total:  2  src: erecruitsit
# 
# ih 
# a,i, y: dm2:       Total:  3
# ************************************

  if [[ "${tgtsite}" == "erecruit" ]] ; then
     srcsite="erecruitsit"
  elif [[ "${LOGNAME}" =~ cny.*a ]] ; then 
          srcsite="cny${pillar}sit"
  else 
       srcsite="cny${pillar}ug2"
  fi

  echo "${LOGNAME}: src: $srcsite  tgt: $tgtsite" 
  
  htmldoc=$(find . -path "*/PORTAL.war/${tgtsite}/signon.html" -type f)
  if [[ -f $htmldoc ]] ; then
     # 'a' user: sit to 
     echo " "  | tee -a $tmpfile
     echo " "  | tee -a $tmpfile
     echo "signon.html Command for ${LOGNAME} src: $srcsite  tgt:  ${tgtsite} :"  | tee -a $tmpfile
     echo " "  | tee -a $tmpfile
     grep "cmd=login" $htmldoc  | tee -a $tmpfile
     echo " "  | tee -a $tmpfile
     echo " "  | tee -a $tmpfile
     echo "grep \"cmd=login\" $htmldoc"  | tee -a $tmpfile
     echo "sed -i -e \"/cmd=login/s/${srcsite}/${tgtsite}/\" $htmldoc"  | tee -a $tmpfile
     echo "grep \"cmd=login\" $htmldoc"  | tee -a $tmpfile
  else
     echo "ERROR! $tgtsite does not contain signon.html on ${HOSTNAME} for ${LOGNAME}"
  fi

echo "*******************************"
done
echo "###############################"
#echo "*******************************"
