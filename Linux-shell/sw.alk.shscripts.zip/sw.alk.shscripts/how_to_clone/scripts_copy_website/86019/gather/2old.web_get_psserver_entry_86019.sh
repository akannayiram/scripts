#!/bin/bash
# Execute against 8.60.19
# check psserver entry
# ***********************************
# cs, fs, hc 
# a user: dm2, rpu
# i user: dm2, rpu 
# y user: dm2, rpu   Total: 18 
# hc:
# a user: erecruit 
# i user: erecruit   Total:  2 
# 
# ih 
# a,i, y: dm2:       Total:  3
# ************************************


[[ ${LOGNAME} =~ cny.*z ]] && { echo "Skipping ${LOGNAME}" ; echo "*******************************" ; exit; }
pillar=${HOSTNAME:0:2}
#tgtsites="cnycsdm2,cnycsrpu"
tgtsites="cny${pillar}dm2,cny${pillar}rpu,erecruit"
IFS=","
for tgtsite in ${tgtsites}
do
  # For IH, only dm2
  [[ "$pillar" == "ih" && ! "${tgtsite}" =~ dm2 ]] && { continue; }  
  # For sit, only 'a' user
  #[[ "${tgtsite}" =~ sit && ! ${LOGNAME} =~ cny.*a ]] && { continue; }
  # erecruit on hc050 only
  [[ "${tgtsite}" == "erecruit" && "${HOSTNAME}" != "hc92npwl050" ]] && { continue; } 

  cfg=$(find . -path "*/PORTAL.war/*/psftdocs/${tgtsite}/configuration.properties" -type f)

  if [[ -f $cfg ]] ; then
     #echo "$tgtsite exists on ${HOSTNAME} for ${LOGNAME} and the psserver/WebProfile entries:"
     #echo "$tgtsite exists on ${HOSTNAME} for ${LOGNAME}"
     echo "Site $tgtsite exists for ${LOGNAME}@${HOSTNAME}"
     pssrv=$(grep "^psserver" $cfg)
     grep -E "^psserver|^WebProfile" $cfg 
  else
    [[ ! "$pillar" == "ih" ]] && echo "ERROR! $tgtsite does not exist on ${HOSTNAME} for ${LOGNAME}"
  fi 
echo "*******************************"
done
echo "###############################"
#echo "*******************************"
