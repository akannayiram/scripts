#!/bin/bash
# Execute against 8.60.19
# change psserver entry

tgtsite=cnycsdm2
# psserver entry from 8.60.14
pssrv="psserver=
cfg=$(find . -path "*/PORTAL.war/*/psftdocs/${tgtsite}/configuration.properties" -type f)

if [[ -f $cfg ]] ; then
   grep "^psserver" $cfg 
   sed -e "s/^psserver.*$/$pssrv" $cfg 
   grep -E "^psserver|^WebProfile" $cfg 
fi 

