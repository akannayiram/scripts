#!/bin/bash
# ######################################
# Comapre psprcs.cfg between PRD and DR
#    Al Kannayiram
#    August 2024
# #######################################
set -x
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/cs92prux101.CNYCSPR1.cnycsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/cs92drux201.CNYCSPR1.cnycsprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/cs92prux101.CNYCSPR1.cnycsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/cs92drux201.CNYCSPR1.cnycsprd.psprcs_cfg.txt
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/cs92prux101.CNYCSPR2.cnycsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/cs92drux201.CNYCSPR2.cnycsprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/cs92prux101.CNYCSPR2.cnycsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/cs92drux201.CNYCSPR2.cnycsprd.psprcs_cfg.txt
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/cs92prux102.CNYCSPR1.cnycsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/cs92drux202.CNYCSPR1.cnycsprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/cs92prux102.CNYCSPR1.cnycsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/cs92drux202.CNYCSPR1.cnycsprd.psprcs_cfg.txt
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/cs92prux102.CNYCSPR2.cnycsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/cs92drux202.CNYCSPR2.cnycsprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/cs92prux102.CNYCSPR2.cnycsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/cs92drux202.CNYCSPR2.cnycsprd.psprcs_cfg.txt
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/fs92prux101.CNYFSPRD.cnyfsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/fs92drux201.CNYFSPRD.cnyfsprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/fs92prux101.CNYFSPRD.cnyfsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/fs92drux201.CNYFSPRD.cnyfsprd.psprcs_cfg.txt
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/fs92prux102.CNYFSPRD.cnyfsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/fs92drux202.CNYFSPRD.cnyfsprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/fs92prux102.CNYFSPRD.cnyfsprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/fs92drux202.CNYFSPRD.cnyfsprd.psprcs_cfg.txt
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/hc92prux101.CNYHCPRD.cnyhcprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/hc92drux201.CNYHCPRD.cnyhcprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/hc92prux101.CNYHCPRD.cnyhcprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/hc92drux201.CNYHCPRD.cnyhcprd.psprcs_cfg.txt
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/hc92prux102.CNYHCPRD.cnyhcprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/hc92drux202.CNYHCPRD.cnyhcprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/hc92prux102.CNYHCPRD.cnyhcprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/hc92drux202.CNYHCPRD.cnyhcprd.psprcs_cfg.txt
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/ihprux101.CNYIHPRD.cnyihprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/ihdrux201.CNYIHPRD.cnyihprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/ihprux101.CNYIHPRD.cnyihprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/ihdrux201.CNYIHPRD.cnyihprd.psprcs_cfg.txt
echo "diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/ihprux102.CNYIHPRD.cnyihprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/ihdrux202.CNYIHPRD.cnyihprd.psprcs_cfg.txt"
diff -w -s  /software/akannayiram/dr_prep2024/prd/prcs/ihprux102.CNYIHPRD.cnyihprd.psprcs_cfg.txt  /software/akannayiram/dr_prep2024/dr/prcs/ihdrux202.CNYIHPRD.cnyihprd.psprcs_cfg.txt
