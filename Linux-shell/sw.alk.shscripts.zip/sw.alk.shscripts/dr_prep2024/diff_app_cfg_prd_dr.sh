#!/bin/bash
# ######################################
# Comapre psappsrv.cfg between PRD and DR
#    Al Kannayiram
#    August 2024
# #######################################
set -x
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap101.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap201.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap101.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap201.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap102.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap202.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap102.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap202.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap103.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap203.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap103.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap203.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap104.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap204.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap104.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap204.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap105.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap205.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap105.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap205.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap106.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap206.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap106.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap206.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap107.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap207.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap107.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap207.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap108.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap208.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap108.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap208.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap109.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap209.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap109.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap209.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap110.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap210.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap110.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap210.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap111.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap211.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap111.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap211.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap112.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap212.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap112.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap212.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap113.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap213.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap113.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap213.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap114.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap214.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap114.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap214.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap115.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap215.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap115.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap215.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap116.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap216.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap116.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap216.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap117.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap217.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap117.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap217.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap118.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap218.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap118.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap218.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap119.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap219.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap119.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap219.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap120.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap220.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap120.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap220.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap121.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap221.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap121.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap221.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap122.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap222.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap122.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap222.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap123.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap223.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap123.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap223.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap124.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap224.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap124.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap224.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap125.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap225.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap125.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap225.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap126.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap226.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap126.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap226.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap127.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap227.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap127.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap227.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap128.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap228.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap128.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap228.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap129.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap229.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap129.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap229.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap130.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap230.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap130.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap230.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap131.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap231.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap131.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap231.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap132.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap232.CNYCSPR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap132.CNYCSPR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap232.CNYCSPR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap133.CNYCSIM1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap233.CNYCSIM1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap133.CNYCSIM1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap233.CNYCSIM1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap134.CNYCSAM1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap234.CNYCSAM1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap134.CNYCSAM1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap234.CNYCSAM1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap135.CNYCSSL1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap235.CNYCSSL1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap135.CNYCSSL1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap235.CNYCSSL1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap136.CNYCSSL2.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap236.CNYCSSL2.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap136.CNYCSSL2.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap236.CNYCSSL2.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap137.CNYCSSL3.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap237.CNYCSSL3.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap137.CNYCSSL3.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap237.CNYCSSL3.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap138.CNYCSCM1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap238.CNYCSCM1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap138.CNYCSCM1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap238.CNYCSCM1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap138.CNYCSRR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap238.CNYCSRR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap138.CNYCSRR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap238.CNYCSRR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap139.CNYCSCM1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap239.CNYCSCM1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap139.CNYCSCM1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap239.CNYCSCM1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap139.CNYCSRR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap239.CNYCSRR1.cnycsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/cs92prap139.CNYCSRR1.cnycsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/cs92drap239.CNYCSRR1.cnycsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap101.CNYFSPR1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap201.CNYFSPR1.cnyfsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap101.CNYFSPR1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap201.CNYFSPR1.cnyfsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap102.CNYFSPR1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap202.CNYFSPR1.cnyfsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap102.CNYFSPR1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap202.CNYFSPR1.cnyfsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap103.CNYFSAM1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap203.CNYFSAM1.cnyfsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap103.CNYFSAM1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap203.CNYFSAM1.cnyfsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap104.CNYFSIM1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap204.CNYFSIM1.cnyfsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap104.CNYFSIM1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap204.CNYFSIM1.cnyfsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap104.CNYFSSL1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap204.CNYFSSL1.cnyfsprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/fs92prap104.CNYFSSL1.cnyfsprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/fs92drap204.CNYFSSL1.cnyfsprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap101.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap201.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap101.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap201.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap102.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap202.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap102.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap202.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap103.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap203.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap103.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap203.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap104.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap204.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap104.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap204.CNYHCPR1.cnyhcprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap105.CNYHCAM1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap205.CNYHCAM1.cnyhcprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap105.CNYHCAM1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap205.CNYHCAM1.cnyhcprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap106.CNYHCIM1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap206.CNYHCIM1.cnyhcprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap106.CNYHCIM1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap206.CNYHCIM1.cnyhcprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap106.CNYHCSL1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap206.CNYHCSL1.cnyhcprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap106.CNYHCSL1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap206.CNYHCSL1.cnyhcprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap107.CNYHCCM1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap207.CNYHCCM1.cnyhcprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/hc92prap107.CNYHCCM1.cnyhcprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/hc92drap207.CNYHCCM1.cnyhcprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap101.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap201.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap101.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap201.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap102.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap202.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap102.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap202.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap103.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap203.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap103.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap203.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap104.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap204.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap104.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap204.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap105.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap205.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap105.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap205.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap106.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap206.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap106.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap206.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap107.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap207.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap107.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap207.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap108.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap208.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap108.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap208.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap109.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap209.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap109.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap209.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap110.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap210.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap110.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap210.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap111.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap211.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap111.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap211.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap112.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap212.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap112.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap212.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap113.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap213.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap113.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap213.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap114.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap214.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap114.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap214.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap115.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap215.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap115.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap215.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap116.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap216.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap116.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap216.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap117.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap217.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap117.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap217.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap118.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap218.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap118.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap218.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap119.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap219.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap119.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap219.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap120.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap220.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap120.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap220.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap121.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap221.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap121.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap221.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap122.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap222.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap122.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap222.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap123.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap223.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap123.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap223.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap124.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap224.CNYIHPR1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap124.CNYIHPR1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap224.CNYIHPR1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap125.CNYIHAM1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap225.CNYIHAM1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap125.CNYIHAM1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap225.CNYIHAM1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap126.CNYIHIM1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap226.CNYIHIM1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap126.CNYIHIM1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap226.CNYIHIM1.cnyihprd.psappsrv_cfg.txt
echo "diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap126.CNYIHSL1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap226.CNYIHSL1.cnyihprd.psappsrv_cfg.txt"
diff -w -s    /software/akannayiram/dr_prep2024/prd/app/ihprap126.CNYIHSL1.cnyihprd.psappsrv_cfg.txt    /software/akannayiram/dr_prep2024/dr/app/ihdrap226.CNYIHSL1.cnyihprd.psappsrv_cfg.txt
