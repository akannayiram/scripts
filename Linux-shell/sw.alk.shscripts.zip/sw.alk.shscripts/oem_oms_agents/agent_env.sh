#!/bin/bash
# Al Kannayiram Sept 2024
# Source as oracle

export AGENT_BASE=/appl/oracle/product/agent13c
export AGENT_HOME=$AGENT_BASE/agent_13.5.0.0.0
export AGENT_INST=$AGENT_BASE/agent_inst

export PATH=$PATH:$AGENT_HOME/bin
