#!/bin/bash
if [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on NP Web servers"
   exit
fi
#for i in `grep cnyd /etc/hosts |grep -v "#"|grep 858|awk  '{print $2}'`
#do
#sudo su - $i -c /appl/oracle/weblogic/$i/webserv/peoplesoft/bin/startPIA.sh  ; echo "on" `cat /etc/hosts |grep $i`
#done

#for i in `grep cnyd /etc/hosts |grep -v "#"|grep 86019|awk  '{print $2}'`
for i in `grep cnyd /etc/hosts |grep -v "#"|grep 86019|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c /appl/psft/pia/$i/webserv/peoplesoft/bin/startPIA.sh  ; echo "on" `cat /etc/hosts |grep $i`
done

