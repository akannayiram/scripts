#!/bin/bash
[[ ! $USER == "oracle" ]] && { echo "Execute with oracle"; exit 1; }

scriptloc=/software/akannayiram/202205_patches/bin
scriptnm=tux.sh
${scriptloc}/${scriptnm}  2>&1 | tee -a ${HOSTNAME}.${USER}.$(date '+%Y%m%d').${scriptnm}.log 
