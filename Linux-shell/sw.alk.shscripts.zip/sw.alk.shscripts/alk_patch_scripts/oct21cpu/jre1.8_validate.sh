# JRE Validation (App, Prcs)
# JRE - /software/patches/2021-11-maint/jre/
echo "#############JRE: Contents of /software/patches/2021-11-maint/jre/jre1.8.0_311/"
ls -ld /software/patches/2021-11-maint/jre/jre1.8.0_311
echo "#############JRE: Contents of /appl/oracle/jre/"
ls -l /appl/oracle/jre/
cd /appl/oracle/jre
echo "#############JRE: symlink of jre1.8_64bit"
ls -l jre1.8_64bit
