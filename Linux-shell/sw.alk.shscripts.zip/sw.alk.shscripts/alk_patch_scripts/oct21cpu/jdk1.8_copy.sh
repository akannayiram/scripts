# JDK Copy (Web)
# JDK - /software/patches/2021-11-maint/jdk/
ls -ld /software/patches/2021-11-maint/jdk/jdk1.8.0_311
ls -l /appl/oracle/jdk
cd /appl/oracle/jdk
cp -rap /software/patches/2021-11-maint/jdk/jdk1.8.0_311 /appl/oracle/jdk/
rm /appl/oracle/jdk/jdk1.8_64bit
ln -s /appl/oracle/jdk/jdk1.8.0_311 /appl/oracle/jdk/jdk1.8_64bit	
ls -l
