# JRE Copy (App, Prcs)
# JRE - /software/patches/2021-11-maint/jre/
ls -ld /software/patches/2021-11-maint/jre/jre1.8.0_311
ls -l /appl/oracle/jre
cd /appl/oracle/jre
cp -rap /software/patches/2021-11-maint/jre/jre1.8.0_311 /appl/oracle/jre/
rm /appl/oracle/jre/jre1.8_64bit
ln -s jre1.8.0_311 jre1.8_64bit
ls -l 
