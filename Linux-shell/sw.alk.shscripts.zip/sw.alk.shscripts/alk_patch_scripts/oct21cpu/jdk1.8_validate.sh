# JDK Validation (Web)
# JDK - /software/patches/2021-11-maint/jdk/
echo "#############JDK: Contents of /software/patches/2021-11-maint/jdk/jdk1.8.0_311/"
ls -ld /software/patches/2021-11-maint/jdk/jdk1.8.0_311
echo "#############JDK: Contents of /appl/oracle/jdk/"
ls -l /appl/oracle/jdk/
cd /appl/oracle/jdk
echo "#############JDK: symlink of jdk1.8_64bit"
ls -l jdk1.8_64bit
