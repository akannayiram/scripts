#!/bin/bash
# #############################
#  Al Kannayiram Oct 2023
#   - To confirm that PS_HOME/jre is soft linked to /appl/oracle/jre/jre1.8_64bit
# ########################

# Functions
get_linkloc_jrever ()
{
   linkloc=$(stat -c%N $PS_HOME/jre)
   finallinkloc=$(readlink -f $PS_HOME/jre)
   jrever=$($PS_HOME/jre/bin/java -version 2>&1|grep version)
   echo "[$hst] [$LOGNAME] [$jrever] [$linkloc] [Final: $finallinkloc]"

}

# print current dir and list jre dir/archive 
echo "--------------------"
echo "List at start"
date; pwd ; ls -ld jre*

hst=$(echo $HOSTNAME|awk -F"." '{print $1}')


# if PS_HOME not set, exit
[[ -z $PS_HOME ]] && { echo "ERROR! PS_HOME not set. Check the user login [$LOGNAME] on [$hst]. Exiting...."; exit } 

jrelink="/appl/oracle/jre/jre1.8_64bit"

# Exit if /appl/oracle/jre/jre1.8_64bit symlink not exists 
[[ ! -d $jrelink ]] && [[ ! -L $jrelink ]]  && [[ ! -e $jrelink ]] && { echo "ERROR! jre symlink [$jrelink] does not exist on [$hst]. Exiting..."; exit; }

cd $PS_HOME 

# Validate PS_HOME owner (use $PS_HOME/appserv to get owner)
# Exit if $PS_HOME/appserv dir does not exist 
[[ ! -d $PS_HOME/appserv ]] && { echo "ERROR! [$PS_HOME/appserv] dir does not exist. Check login user [$LOGNAME] on [$hst]. Exiting..."; exit; }
# Get the owner
own=$(ls -ld $PS_HOME/appserv|awk '{print $3}')
[[ "$own" != "$LOGNAME" ]] && { echo "ERROR! Execute as owner [$own]. Logged in as [$LOGNAME] on [$hst]. Exiting..."; exit; }

# Check if $PS_HOME/jre is a valid symlink
# If yes, then print java version and exit
if [[ -L $PS_HOME/jre ]] && [[ -d $PS_HOME/jre ]] && [[ -e $PS_HOME/jre ]] ; then
   # "readlink -f" prints the canonicalized version of a symlink (i.e. recursive)
   get_linkloc_jrever
   exit 
fi

# if jre dir does not exist, create a symlink and exit
if [[ ! -d jre ]] ; then
   ln -s $jrelink jre
   get_linkloc_jrever
   exit
fi

# jre.tar.gz already exists, rename it
[[ -f jre.tar.gz ]] && mv jre.tar.gz renamed.$(date '+%Y%m%d_%H%M%S').jre.tar.gz


# Create archive and list
[[ -d jre ]] && tar -zcf jre.tar.gz jre  
echo "--------------------"
echo "List after creating the archive"
ls -ld jre* 

# if archive exists, delete the dir 
[[ -f jre.tar.gz ]] && rm -rf jre 
# list again
echo "--------------------"
echo "List after deleting the jre dir"
ls -ld jre* 

# Create symlink
ln -s $jrelink jre
get_linkloc_jrever


