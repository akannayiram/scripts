#!/bin/bash
# #############################
#  Al Kannayiram Oct 2023
#   - To confirm that PS_HOME/jre is soft linked to /appl/oracle/jre/jre1.8_64bit
# ########################

# DRY RUN WITHOUT MAKING ANY CHANGES
#set -x

# Functions
get_linkloc ()
{
   linkloc=$(stat -c%N $PS_HOME/jre)
   [[ "$ISVALIDLINK" == "Y" ]] && finallinkloc=$(readlink -f $PS_HOME/jre)

}

get_jrever ()
{
   jrever=$($PS_HOME/jre/bin/java -version 2>&1|grep version)

}

logmsg ()
{
   [[ "$ISPSHOMEJRE" == "N" ]] && pshomejre="MISSING"
   [[ "$ISJREDIR" == "Y" ]] && pshomejre="DIR"
   [[ "$ISSYMLINK" == "Y" ]] && pshomejre="SYMLINK"
   [[ "$ISVALIDLINK" == "Y" ]] && pshomejre="VALID SYMLINK"
   msg="[$hst] [$LOGNAME] [PS_HOME/jre]: [$pshomejre] [$jrever] [Symlink]: $linkloc  [Final]: $finallinkloc"
   echo $msg

}

# print current dir and list jre dir/archive 
echo "--------------------"
date

hst=$(echo $HOSTNAME|awk -F"." '{print $1}')

# if PS_HOME not set, exit
[[ -z $PS_HOME ]] && { echo "ERROR! PS_HOME not set. Check the user login [$LOGNAME] on [$hst]. Exiting...."; exit; } 

# Intialize
ISPSHOMEJRE=N
ISJREDIR=N
ISJRESYMLINK=N
ISVALIDLINK=N

cd $PS_HOME 
echo "[$hst] Current directory: $(pwd)"
echo "List at start"
ls -ld jre*

# Validate PS_HOME owner (use $PS_HOME/appserv to get owner)
# Exit if $PS_HOME/appserv dir does not exist 
[[ ! -d $PS_HOME/appserv ]] && { echo "ERROR! [$PS_HOME/appserv] dir does not exist. Check login user [$LOGNAME] on [$hst]. Exiting..."; exit; }
# Get the owner
own=$(ls -ld $PS_HOME/appserv|awk '{print $3}')
[[ "$own" != "$LOGNAME" ]] && { echo "ERROR! Execute as owner [$own]. Logged in as [$LOGNAME] on [$hst]. Exiting..."; exit; }


# Check if $PS_HOME/jre exists
if [[ -d $PS_HOME/jre ]] ; then
   ISPSHOMEJRE=Y
   # Check if $PS_HOME/jre is a symlink
   if [[ -L $PS_HOME/jre ]] ; then
      ISJRESYMLINK=Y
      if [[ -e $PS_HOME/jre ]] ; then
         ISVALIDLINK=Y
         get_linkloc
         get_jrever
      fi
   else
      ISJREDIR=Y
      get_jrever
   fi
fi

logmsg

# jre.tar.gz already exists, rename it
#[[ -f jre.tar.gz ]] && mv jre.tar.gz renamed.$(date '+%Y%m%d_%H%M%S').jre.tar.gz
# TEST CODE
[[ -f jre.tar.gz ]] && echo "TEST CODE: jre.tar.gz exists"

echo "--------------------"

