#!/bin/bash
cd $PS_HOME 

# print current dir and jre dir/archive 
echo "--------------------"
echo "List at start"
date; pwd ; ls -ld jre*

# jre.tar.gz already exists and jre dir does not exist, display no issue and exit 
[[ -f jre.tar.gz ]] && [[ ! -d jre ]] && { echo "NO ISSUE! jre.tar.gz exists and jre does not exist."; exit; }

# jre.tar.gz already exists, display an error and exit 
[[ -f jre.tar.gz ]] && { echo "ERROR! jre.tar.gz already exists. Rename and try. Exiting..."; exit; }

# Exit if jre dir does not exist 
[[ ! -d jre ]] && { echo "WARNING! jre dir deoes not exist. No work. Exiting..."; exit; }

# Exit if /appl/oracle/jre/jre1.8_64bit symlink not exists 
[[ ! -d /appl/oracle/jre/jre1.8_64bit ]] && { echo "WARNING! jre dir deoes not exist. No work. Exiting..."; exit; }

# To check the owner 
own=$(ls -ld jre|awk '{print $3}')
[[ "$own" != "$LOGNAME" ]] && { echo "ERROR! Execute as jre owner [$own]. Exiting..."; exit; }

# Create archive and list
[[ -d jre ]] && tar -zcf jre.tar.gz jre  
echo "--------------------"
echo "List after creating the archive"
ls -ld jre* 

# if archive exists, delete the dir 
[[ -f jre.tar.gz ]] && rm -rf jre 
# list again
echo "--------------------"
echo "List after deleting the jre dir"
ls -ld jre* 

# Create symlink
ln -s /appl/oracle/jre/jre1.8_64bit jre

# Test jre
jre/bin/java -version

