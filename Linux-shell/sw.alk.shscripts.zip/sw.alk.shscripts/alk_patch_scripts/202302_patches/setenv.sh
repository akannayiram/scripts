export PATCH_MEDIA_DIR=/software/patches/2023-02-maint
export JDK_DIR=$PATCH_MEDIA_DIR/JDK_1.8.0_361_LNX/jdk1.8.0_361
export JRE_DIR=$PATCH_MEDIA_DIR/JRE_1.8.0_361_LNX/jre1.8.0_361
export PATCH_SCRIPT_HOME=/software/akannayiram/alk_patch_scripts/202302_patches
