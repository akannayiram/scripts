#!/bin/bash
[[ ! $USER == "oracle" ]] && { echo "Execute with oracle"; exit 1; }

. ./setenv.sh
scriptloc=$PATCH_SCRIPT_HOME/bin
scriptnm=jre361copy.sh
${scriptloc}/${scriptnm}  2>&1 | tee -a ${HOSTNAME}.${USER}.$(date '+%Y%m%d').${scriptnm}.log 
