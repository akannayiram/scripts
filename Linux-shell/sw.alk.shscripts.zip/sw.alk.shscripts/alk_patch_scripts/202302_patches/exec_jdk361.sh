#!/bin/bash
[[ ! $USER == "oracle" ]] && { echo "Execute with oracle"; exit 1; }

. ./setenv.sh
scriptloc=$PATCH_SCRIPT_HOME/bin
scriptnm=jdk361copy.sh
${scriptloc}/${scriptnm}  2>&1 | tee -a /tmp/${HOSTNAME}.${USER}.$(date '+%Y%m%d').${scriptnm}.log 
