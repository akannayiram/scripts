echo "Hostname: [$HOSTNAME]   User: [$LOGNAME]   Date/time: [$(date)]"
echo "pwd: $(pwd)   [$PS_HOME/setup/PsCA/archives/Linux]"
ls -ld $HOME/setup/PsCA/archives/Linux
