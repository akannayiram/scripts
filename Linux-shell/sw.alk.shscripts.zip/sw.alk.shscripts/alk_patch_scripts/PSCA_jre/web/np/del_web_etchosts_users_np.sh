#!/bin/bash
if [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on NP Web servers"
   exit
fi
for i in `grep cnyd /etc/hosts |grep -v "#"|grep 858|awk  '{print $2}'`
do
sudo su - $i -c /software/akannayiram/alk_patch_scripts/PSCA_jre/web/del_psca_web_linux_targz.sh   ; echo "on" `cat /etc/hosts |grep $i`
done
