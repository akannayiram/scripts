#!/bin/bash
# Al Kannayiram  9/25/2023
# tar-gzip of Linux dir with in "../setup/PsCA/.."
# This was flagged by Security Scan 
#

echo "Starting $0 Host: [$HOSTNAME] Logname: [$LOGNAME]"
date
pscapath="*/PsCA/archives/Linux"
# Check if  "*/PsCA/archives/Linux" exists
[[ $(find $PS_HOME -path "$pscapath"|wc -l) -eq 0 ]] && { echo "[$pscapath] not found. Exiting..."; exit; }

# Loop thru: if 'old_setup' folder exists, then count will be two
for pdir in $(find $PS_HOME -path "*/PsCA/archives/Linux" -exec dirname {} \;)
do
  echo "Parent dir: [$pdir]"
  echo "Make parent dir as current directory"
  cd $pdir
  echo "Current dir: $(pwd)"
  ls -ldh Linux*
  # Confirm that Linux dir exists and it is owned by current user
  [[ ! -d Linux ]] && [[ ! -x Linux ]] && { echo "Linux directory not accessible within [$pdir].  Exiting..."; exit; }
  [[ $(ls -ldh Linux|awk '{print $3}') != "$LOGNAME" ]] && { echo "$LOGNAME is not the owner of [$pdir]. Exiting..."; exit; }
  #tar -zcf Linux.tar.gz Linux
  # Confirm that Linux.tar.gz exists
  [[ -f Linux.tar.gz ]] && rm -rf Linux
  echo "Linux directory removed"
  date
  ls -ldh Linux*
done

