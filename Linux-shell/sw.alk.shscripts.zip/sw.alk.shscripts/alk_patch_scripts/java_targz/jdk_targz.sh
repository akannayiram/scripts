#!/bin/bash
javadir=jdk1.8.0_371
[[ ! "$LOGNAME" == "oracle" ]] && { echo "ERROR! login user msut be oracle. Exiting...."; exit ; }
ls -lh /appl/oracle/jdk
cd /appl/oracle/jdk
[[ ! -d "$javadir" ]] &&  { echo "ERROR! [$javadir] is missing. Exiting...."; exit ; }
[[ ! -x "$javadir" ]] &&  { echo "ERROR! [$javadir] is not accessible. Exiting...."; exit ; }
date
tar -zcf ${javadir}.tar.gz $javadir
ls -lh *gz
ls -lh /appl/oracle/jdk
