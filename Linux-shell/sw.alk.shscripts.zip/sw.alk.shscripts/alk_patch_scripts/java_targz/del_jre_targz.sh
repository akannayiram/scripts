#!/bin/bash
javadir=jre1.8.0_371
[[ ! "$LOGNAME" == "oracle" ]] && { echo "ERROR! login user msut be oracle. Exiting...."; exit ; }
cd /appl/oracle/jre
ls -lh
[[ ! -d "$javadir" ]] &&  { echo "ERROR! [$javadir] is missing. Exiting...."; exit ; }
[[ ! -x "$javadir" ]] &&  { echo "ERROR! [$javadir] is not accessible. Exiting...."; exit ; }
[[ ! -f "${javadir}.tar.gz" ]] &&  { echo "ERROR! [${javadir}.tar.gz] is missing. Exiting...."; exit ; }
date
rm -rf ${javadir}
ls -lh 
