#!/bin/bash
set -x
export ORACLE_HOME=/appl/oracle/product/19/client
logdir=/software/akannayiram/alk_patch_scripts/ora19c_client_patch/opatchlogs/np-logs
dttm=$(date '+%Y%m%d_%H%M%S')
stdoutlog=${logdir}/${HOSTNAME}.${LOGNAME}.dryrun_opatch_symlinks.${dttm}.stdout.log
stderrlog=${logdir}/${HOSTNAME}.${LOGNAME}.dryrun_opatch_symlinks.${dttm}.stderr.log
echo $ORACLE_HOME;echo $logdir;echo $dttm;echo $stdoutlog; echo $stderrlog
/software/akannayiram/alk_patch_scripts/ora19c_client_patch/ora19c_opatch_fix_dryrun.sh > $stdoutlog 2> $stderrlog

