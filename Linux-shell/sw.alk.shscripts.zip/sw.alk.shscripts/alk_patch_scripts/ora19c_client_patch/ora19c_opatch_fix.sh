#!/bin/bash
# ############################
#  Al Kannayiram Oct 2023
# ############################
# Fix $ORACLE_HOME/OPatch
# ###########################
set -x
# Functions
#get_linkloc_OPatchver ()
#{
#   if [[ -d OPatch ]] ; then	
#   linkloc=$(stat -c%N $ORACLE_HOME/OPatch)
#   finallinkloc=$(readlink -f $ORACLE_HOME/OPatch)
#   OPatchver=$($ORACLE_HOME/OPatch/opatch version 2>&1|grep Version)
#   fi
#   echo "[$hst] [$LOGNAME]: [orahomeOPatch]: [$orahomeOPatch] version: [$OPatchver] Symlink: [$linkloc] Final: [$finallinkloc] [OPatch.tar.gz?: $OPatchtargzexists]"

#}

get_linkloc ()
{
   if [[ -d OPatch ]] ; then	
   linkloc=$(stat -c%N $ORACLE_HOME/OPatch)
   finallinkloc=$(readlink -f $ORACLE_HOME/OPatch)
   fi

}

status_msg ()
{
   echo "[$hst] [$LOGNAME]: [orahomeOPatch]: [$orahomeOPatch] version: [$OPatchver] Symlink: [$linkloc] Final: [$finallinkloc] [OPatch.tar.gz?: $OPatchtargzexists]"

}

create_symlink ()
{
   ln -s $OPatch_symlink_target OPatch
   msg="Symlink was created"
   logmsg
}

get_OPatch_version ()
{
   #OPatchver=$($ORACLE_HOME/OPatch/opatch version 2>&1|grep Version)
   OPatchver=$($ORACLE_HOME/OPatch/opatch version |grep Version)
   #msg="[Orahome: $ORACLE_HOME] OPatch version: [$OPatchver]"
   #logmsg
}

logmsg ()
{
  echo "[$hst] [$LOGNAME]: $msg"
}


create_tar_gz ()
{
  inpdir=$1
  # OPatch.tar.gz already exists, rename it
  [[ -f ${inpdir}.tar.gz ]] && mv ${inpdir}.tar.gz renamed.$(date '+%Y%m%d_%H%M%S').${inpdir}.tar.gz

  tar -zcf ${inpdir}.tar.gz $inpdir 
  echo "[$hst] [$LOGNAME]: tar-gzip [$inpdir] was completed"
}

delete_OPatch_dir()
{
   [[ -f OPatch.tar.gz ]] && rm -rf OPatch
   msg="OPatch dir was deleted"
   logmsg

}

hst=$(echo $HOSTNAME|awk -F"." '{print $1}')
OPatch_symlink_target=/psft/oraclient-common/opatch-patch/OPatch

echo "[$hst] [$LOGNAME]: $(date)"
echo "[$hst] [$LOGNAME]: Starting [$0]"
# Exit if the login user is not oracle 
###[[ "$LOGNAME" != "oracle" ]] && { echo "[$hst] [$LOGNAME]: ERROR! [$LOGNAME] is not allowed. Use [oracle] to execute"; exit; }

# Exit if ORACLE_HOME is not set
[[ -z "$ORACLE_HOME" ]] && { echo "[$hst] [$LOGNAME]: ERROR! ORACLE_HOME is not set. Exiting..."; exit; }
[[ ! -d "$ORACLE_HOME" ]] && { echo "[$hst] [$LOGNAME]: ERROR! [$ORACLE_HOME] does not exist. Exiting..."; exit; }

cd $ORACLE_HOME
echo "[$hst] [$LOGNAME]: Current dir: $(pwd)"
echo "[$hst] [$LOGNAME]: Before: List OPatch dir"
ls -lhd OPatch* 

OPatchver=""; linkloc=""; finallinkloc=""; orahomeOPatch="";OPatchtargzexists="N"
if [[ -d OPatch ]] ; then
   if [[ -L OPatch ]] ; then
      if [[ -e OPatch ]] ; then 
	 # Valid symlink
	 msg="Status: Valid OPatch symlink exists already. No change done"
	 logmsg
	 orahomeOPatch="VALID SYMLINK"
         # check OPatch.tar.gz already exists
         [[ -f OPatch.tar.gz ]] && OPatchtargzexists=Y
	 get_linkloc
         get_OPatch_version
         status_msg
       else  # invalid symlink
         # check OPatch.tar.gz already exists
         [[ -f OPatch.tar.gz ]] && OPatchtargzexists=Y
         rm -f OPatch
	 create_symlink
	 msg="Status: Invalid OPatch symlink removed. Correct symlink created."
	 logmsg
	 orahomeOPatch="INVALID SYMLINK"
	 get_linkloc
	 get_OPatch_version
         status_msg
       fi
   else  # Dir and not a symlink
    # check OPatch.tar.gz already exists
    [[ -f OPatch.tar.gz ]] && OPatchtargzexists=Y
    create_tar_gz OPatch
    delete_OPatch_dir
    create_symlink
    orahomeOPatch="DIR"
    get_linkloc
    get_OPatch_version
    status_msg
   fi
else   # missing OPatch dir
  # check OPatch.tar.gz already exists
  [[ -f OPatch.tar.gz ]] && OPatchtargzexists=Y
  create_symlink
  msg="Status: OPatch dir did not exist. Symlink created. "
  logmsg
  orahomeOPatch="MISSING OPatch DIR"
  get_linkloc
  get_OPatch_version
  status_msg
fi

echo "[$hst] [$LOGNAME]: After: List OPatch dir"
ls -lhd OPatch*
