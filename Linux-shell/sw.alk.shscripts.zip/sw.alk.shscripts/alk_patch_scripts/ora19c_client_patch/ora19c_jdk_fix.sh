#!/bin/bash
# ############################
#  Al Kannayiram Oct 2023
# ############################
# Fix $ORACLE_HOME/jdk
# ###########################
set -x
# Functions
get_linkloc_jdkver ()
{
   if [[ -d jdk ]] ; then	
   linkloc=$(stat -c%N $ORACLE_HOME/jdk)
   finallinkloc=$(readlink -f $ORACLE_HOME/jdk)
   jdkver=$($ORACLE_HOME/jdk/bin/java -version 2>&1|grep version)
   fi
   echo "[$hst] [$LOGNAME]: [orahomejdk]: [$orahomejdk] version: [$jdkver] Symlink: [$linkloc] Final: [$finallinkloc] [jdk.tar.gz?: $jdktargzexists]"

}

get_linkloc ()
{
   if [[ -d jdk ]] ; then	
   linkloc=$(stat -c%N $ORACLE_HOME/jdk)
   finallinkloc=$(readlink -f $ORACLE_HOME/jdk)
   fi

}

status_msg ()
{
   echo "[$hst] [$LOGNAME]: [orahomejdk]: [$orahomejdk] version: [$jdkver] Symlink: [$linkloc] Final: [$finallinkloc] [jdk.tar.gz?: $jdktargzexists]"

}

create_symlink ()
{
   ln -s $jdk_symlink_target jdk
   msg="Symlink was created"
   logmsg
}

get_jdk_version ()
{
   jdkver=$($ORACLE_HOME/jdk/bin/java -version 2>&1|grep version)
#   msg="jdk version: [$jdkver]"
#   logmsg
}

logmsg ()
{
  echo "[$hst] [$LOGNAME]: $msg"
}


create_tar_gz ()
{
  inpdir=$1
  # jdk.tar.gz already exists, rename it
  [[ -f ${inpdir}.tar.gz ]] && mv ${inpdir}.tar.gz renamed.$(date '+%Y%m%d_%H%M%S').${inpdir}.tar.gz

  tar -zcf ${inpdir}.tar.gz $inpdir 
  echo "[$hst] [$LOGNAME]: tar-gzip [$inpdir] was completed"
}

delete_jdk_dir()
{
   [[ -f jdk.tar.gz ]] && rm -rf jdk
   msg="jdk dir was deleted"
   logmsg

}

hst=$(echo $HOSTNAME|awk -F"." '{print $1}')
jdk_symlink_target=/psft/oraclient-common/jdk/jdk1.8_64bit

echo "[$hst] [$LOGNAME]: $(date)"
echo "[$hst] [$LOGNAME]: Starting [$0]"
# Exit if the login user is not oracle 
[[ "$LOGNAME" != "oracle" ]] && { echo "[$hst] [$LOGNAME]: ERROR! [$LOGNAME] is not allowed. Use [oracle] to execute"; exit; }

# Exit if ORACLE_HOME is not set
[[ -z "$ORACLE_HOME" ]] && { echo "[$hst] [$LOGNAME]: ERROR! ORACLE_HOME is not set. Exiting..."; exit; }
[[ ! -d "$ORACLE_HOME" ]] && { echo "[$hst] [$LOGNAME]: ERROR! [$ORACLE_HOME] does not exist. Exiting..."; exit; }

cd $ORACLE_HOME
echo "[$hst] [$LOGNAME]: Current dir: $(pwd)"
echo "[$hst] [$LOGNAME]: Before: List jdk dir"
ls -lhd jdk* 

jdkver=""; linkloc=""; finallinkloc=""; orahomejdk="";jdktargzexists="N"
if [[ -d jdk ]] ; then
   if [[ -L jdk ]] ; then
      if [[ -e jdk ]] ; then 
	 # Valid symlink
	 msg="Status: Valid jdk symlink exists already. No change done"
	 logmsg
	 orahomejdk="VALID SYMLINK"
         # check jdk.tar.gz already exists
         [[ -f jdk.tar.gz ]] && jdktargzexists=Y
	 get_linkloc
         get_jdk_version
         status_msg
       else  # invalid symlink
         # check jdk.tar.gz already exists
         [[ -f jdk.tar.gz ]] && jdktargzexists=Y
         # rm -f jdk
	 create_symlink
	 msg="Status: Invalid jdk symlink removed. Correct symlink created."
	 logmsg
	 orahomejdk="INVALID SYMLINK"
	 get_linkloc
	 # get_jdk_version
         status_msg
       fi
   else  # Dir and not a symlink
    # check jdk.tar.gz already exists
    [[ -f jdk.tar.gz ]] && jdktargzexists=Y
    create_tar_gz jdk
    delete_jdk_dir
    create_symlink
    orahomejdk="DIR"
    get_linkloc
    get_jdk_version
    status_msg
   fi
else   # missing jdk dir
  # check jdk.tar.gz already exists
  [[ -f jdk.tar.gz ]] && jdktargzexists=Y
  create_symlink
  msg="Status: jdk dir did not exist. Symlink created. "
  logmsg
  orahomejdk="MISSING JDK DIR"
  get_linkloc
  get_jdk_version
  status_msg
fi

echo "[$hst] [$LOGNAME]: After: List jdk dir"
ls -lhd jdk*
