#!/bin/bash
chkdir ()
{
  inpdir=$1
  [[ ! -d $inpdir ]] && echo "WARNING: [$inpdir] dir does not exist" && return 
  [[ $(ls -l $inpdir|awk '{print $3}') != "$LOGNAME" ]] && { echo "ERROR. $LOGNAME is not owner of [$inpdir].  Exiting..."; sameowner=N; } && return 
 # echo "tar-gzip [$inpdir]"
  tar -zcf ${inpdir}.tar.gz $inpdir 
  echo "tar-gzip [$inpdir] completed"

}

date

# Exit if the login user is not oracle 
[[ "$LOGNAME" != "oracle" ]] && { echo "ERROR! [$LOGNAME] is not allowed. Use [oracle] to execute"; exit; }

# Exit if ORACLE_HOME is not set
[[ -z "$ORACLE_HOME" != "oracle" ]] && { echo "ERROR! [$LOGNAME] is not allowed. Use [oracle] to execute"; exit; }

echo "Starting [$0]  Host: [$HOSTNAME]  Logname: [$LOGNAME]"
cd $ORACLE_HOME
#jdkexists=Y
#opatchexists=Y
#direxists=Y

echo "Current dir: $(pwd)"
echo "Before: List jdk OPatch dir"
ls -lhd jdk* OPatch*
#[[ ! -d jdk ]] && { echo "WARNING: jdk dir does not exist"; ((jdkexists=N); }
#[[ ! -d OPatch ]] && { echo "WARNING: OPatch dir does not exist"; ((opatchexists=N); }

sameowner=Y
chkdir jdk 
[[ $sameowner == "N" ]] && error "ERROR! [jdk] dir is owned by $LOGNAME"

sameowner=Y
chkdir OPatch 
[[ $sameowner == "N" ]] && error "ERROR! [jdk] dir is owned by $LOGNAME"

echo "After: List jdk OPatch dir"
ls -lhd jdk* OPatch*
