#!/bin/bash
chkdir ()
{
  inpdir=$1
  [[ ! -d $inpdir ]] && echo "WARNING: [$inpdir] dir does not exist" && return 
  [[ $(ls -l $inpdir|awk '{print $3}') != "$LOGNAME" ]] && { echo "ERROR. $LOGNAME is not owner of [$inpdir].  Exiting..."; sameowner=N; } && return 
 # echo "tar-gzip [$inpdir]"
  tar -zcf ${inpdir}.tar.gz $inpdir 
  echo "tar-gzip [$inpdir] completed"

}

create_symlink ()
{
	ln -s $jdk_symlink_target jdk
}

get_jdk_version ()
{
 jdkver=$($ORACLE_HOME/jdk/bin/java -version|grep version)
}

logmsg ()
{
  echo "[$hst] [$LOGNAME]: $msg"
}


create_tar_gz ()
{
  inpdir=$1
  tar -zcf ${inpdir}.tar.gz $inpdir 
  echo "[$hst] [$LOGNAME]: tar-gzip [$inpdir] completed"
}

delete_jdk_dir()
{
  [[ -f jdk.tar.gz ]] && rm -rf jdk

}

date

jdk_symlink_target=/psft/oraclient-common/jdk/jdk1.8_64bit

# Exit if the login user is not oracle 
[[ "$LOGNAME" != "oracle" ]] && { echo "[$hst] [$LOGNAME]: ERROR! [$LOGNAME] is not allowed. Use [oracle] to execute"; exit; }

# Exit if ORACLE_HOME is not set
[[ -z "$ORACLE_HOME" != "oracle" ]] && { echo "[$hst] [$LOGNAME]: ERROR! [$LOGNAME] is not allowed. Use [oracle] to execute"; exit; }

echo "Starting [$0]  Host: [$HOSTNAME]  Logname: [$LOGNAME]"
cd $ORACLE_HOME
echo "[$hst] [$LOGNAME]: Current dir: $(pwd)"
echo "[$hst] [$LOGNAME]: Before: List jdk dir"
ls -lhd jdk* 

if [[ -d jdk ]] ; then
   if [[ -L jdk ]] ; then
      if [[ -e jdk ]] ; then 
	 # Valid symlink
         get_jdk_version
	 msg="Status: Valid jdk symlink exists already. No change done"
	 logmsg
       else  # invalid symlink
         rm -f jdk
	 create_symlink
	 get_jdk_version
	 msg="Status: Invalid jdk symlink removed. Correct symlink created."

       fi
   else  # Dir and not a symlink
    create_tar_gz
    delete_jdk_dir
    create_symlink
   fi
else   # missing jdk dir
  create_symlink
  msg="Staus: jdk dir didn't exist. Symlink created. "
  logmsg
fi

echo "[$hst] [$LOGNAME]: "After: List jdk dir"
ls -lhd jdk*
