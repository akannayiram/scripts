#!/bin/bash
[[ ! "$LOGNAME" == "oracle" ]] && { echo "ERROR! $LOGNAME is not allowed. Execute as oracle."; exit; }
export ORACLE_HOME=/appl/oracle/product/19/client
logdir=/software/akannayiram/alk_patch_scripts/ora19c_client_patch/prd-logs
dttm=$(date '+%Y%m%d_%H%M%S')
stdoutlog=${logdir}/${HOSTNAME}.${LOGNAME}.dryrun_oraclient_jdk_symlinks.$dttm.stdout.log
stderrlog=${logdir}/${HOSTNAME}.${LOGNAME}.dryrun_oraclient_jdk_symlinks.$dttm.stderr.log
echo $ORACLE_HOME;echo $logdir;echo $dttm;echo $stdoutlog; echo $stderrlog
/software/akannayiram/alk_patch_scripts/ora19c_client_patch/ora19c_jdk_fix_dryrun.sh > $stdoutlog 2> $stderrlog

