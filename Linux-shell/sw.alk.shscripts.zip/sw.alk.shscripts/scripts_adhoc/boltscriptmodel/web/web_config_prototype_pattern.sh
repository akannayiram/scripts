#!/bin/bash
# 2bolt_template_for_running_against_web_domains.sh 

# #############################################################
# BOLT TEMPLATE FOR RUNNING AGAINST WEB DOMAINS
# 
# 1) bolt command is simple.
#      bolt command run $scriptfile -t@"$hstfile" --tty --no-host-key-check
# 
#     NOTE: Script must be accessible from web hosts. (e.g. /software/akannayiram) 
# 
# 2) Second script is also a pattern. No changes except for the final script 
#    that's called in the second script.
#        - In this pattern, we against the /etc/hosts, 
#          and identifies the user name. (grep cny860xx)
#        - remove the CR (sed -e "s/\r//" )
#        -  A 'for-loop': sudo to the username and execute the script. 
#              sudo su - $username -c "$scriptname"
# 	   
# 3) Third script is different depending on the requirement.
#    E.g. checking psserver entry, trying to check cache folder etc.
#    
# *******************
# SEE BELOW FOR EAXMPLES OF THOSE THREE SCRIPTS   
# *******************
# 
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# akannayiram@workbench $ cat bolt_call_chkPIAsites.sh 

build_host_file ()
{
  cat > $tmphost <<!EOF
cs92npwl050
cs92npwl051
fs92npwl050
fs92npwl051
hc92npwl050
hc92npwl051
ih92npwl050
ih92npwl051
!EOF
}

build_script_gather_weblogins ()
{

  cat > $scriptfile1 <<!EOF
#!/bin/bash
if [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on NP Web servers"
   exit
fi
for i in \`grep cnyd /etc/hosts |grep -v "#"|grep 86014|awk  '{print $2}'|sed -e "s/\r//"\`
do
sudo su - \$i -c "${scriptfile2}" 
done

!EOF

}

build_action_script ()
{

  cat > $scriptfile2 <<!EOF
#!/bin/bash
logdir=/software/akannayiram/how_to_clone/scripts_copy_website/logs
logfile=\$logdir/piasites.np.\${HOSTNAME}.\${LOGNAME}.3-5-2025.txt
echo "************************************"   >> \$logfile
echo "\$HOSTNAME  User: \$LOGNAME"   >> \$logfile
echo "************************************"   >> \$logfile
echo "CONFIG"   >> \$logfile
#find . -path "*/PORTAL.war/*/configuration.properties" -type f |grep -E "dem|ug1|ug2|sit|dm2|erec"
#find . -path "*/PORTAL.war/*/configuration.properties" -type f |grep -E "dm2|rpu" | sed -e "s/^/ZZ/"   >> \$logfile
find \$HOME -path "*/PORTAL.war/*/configuration.properties" -type f |grep -E "dm2|rpu"  >> \$logfile
echo "SITE/CACHE"   >> \$logfile
#find . -path "*/PORTAL.war/[cde]*/cache*" -type d |grep -E "dem|ug1|ug2|sit|dm2|erec"
#find . -path "*/PORTAL.war/[cde]*/cache*" -type d |grep -E "dm2|rpu" | sed -e "s/^/ZZ/"   >> \$logfile
find \$HOME -path "*/PORTAL.war/[cde]*/cache*" -type d |grep -E "dm2|rpu"   >> \$logfile
echo "************************************"
!EOF

}


#tmphost=/tmp/alk.hosts.$$.tmp;rm -f $tmphost;touch $tmphost


#build_host_file

scriptsdir=/software/akannayiram/scripts_adhoc/boltscriptmodel/web
scriptnm1=chkPIA_gather_weblogins.sh
scriptfile1=${scriptsdir}/${scriptnm1}


scriptnm2=chkPIA_action_script.sh
scriptfile2=${scriptsdir}/${scriptnm2}

build_script_gather_weblogins


build_action_script


#bolt command run ${scriptsdir}/${scriptnm} -t @"$tmphost" --tty --no-host-key-check

#[15:32:35] /software/akannayiram/scripts_adhoc/boltscriptmodel/web
