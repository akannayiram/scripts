#!/bin/bash
# bolt_template_for_running_against_web_domains.sh 

# #############################################################
# BOLT TEMPLATE FOR RUNNING AGAINST WEB DOMAINS
# 
# 1) bolt command is simple.
# 
# bolt command run $scriptfile -t@"$hstfile" --tty --no-host-key-check
# 
#      $script must be accessible from web hosts. 
# 	 Typically /software mount. No issues.
# 
# 2) Second script is also a pattern. No changes except for the final script 
#    that's called in the second script.
#    
#    In this pattern, we against the /etc/hosts, and identifies the user name.
#    - grep -v # (exclude comments)
#    - grep cny860xx or cny861xx 
#    - awk the second field 
#    - remove the carriage return (Someone must transferred the hosts from windows in the default mode)
#      sed -e "s/\r//" 
# 
#    We do a for-loop against the above (/etc/hosts et. al.)	and then 
#    sudo to the username and execute the script. 
#        sudo su - $username -c "$scriptname"
# 	   
# 3) Third script is different every time depending on the requirement.
#    E.g. checking psserver entry, trying to check cache folder etc.
#    
# *******************
# SEE BELOW FOR EAXMPLES OF THOSE THREE SCRIPTS   
# *******************
# 
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# *******************
# F I R S T    S C R I P T
#$ cat bolt_call_chkPIAsites.sh 

build_host_file ()
{
  cat > $tmphost <<!EOF
cs92npwl050
cs92npwl051
fs92npwl050
fs92npwl051
hc92npwl050
hc92npwl051
ih92npwl050
ih92npwl051
!EOF
}



tmphost=/tmp/alk.hosts.$$.tmp;rm -f $tmphost;touch $tmphost

build_host_file

scriptsdir=/software/akannayiram/how_to_clone/scripts_copy_website
scriptnm=chkPIAcache_92np86014.sh

bolt command run ${scriptsdir}/${scriptnm} -t @"$tmphost" --tty --no-host-key-check

# [21:57:48] /software/akannayiram/how_to_clone/scripts_copy_website
# 
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# *******************
# S E C O N D    S C R I P T
# *******************
$ cat chkPIAcache_92np86014.sh
#!/bin/bash
if [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on NP Web servers"
   exit
fi
scriptsdir=/software/akannayiram/how_to_clone/scripts_copy_website
scriptnm=chksites.sh

for i in `grep cnyd /etc/hosts |grep -v "#"|grep 86014|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c "${scriptsdir}/${scriptnm}" 
done

# [22:00:07] /software/akannayiram/how_to_clone/scripts_copy_website
# 
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# *******************
# T H I R D    S C R I P T
# *******************
 $ cat chksites.sh
logdir=/software/akannayiram/how_to_clone/scripts_copy_website/logs
logfile=$logdir/piasites.np.${HOSTNAME}.${LOGNAME}.3-5-2025.txt
echo "************************************"   >> $logfile
echo "$HOSTNAME  User: $LOGNAME"   >> $logfile
echo "************************************"   >> $logfile
echo "CONFIG"   >> $logfile
#find . -path "*/PORTAL.war/*/configuration.properties" -type f |grep -E "dem|ug1|ug2|sit|dm2|erec"
#find . -path "*/PORTAL.war/*/configuration.properties" -type f |grep -E "dm2|rpu" | sed -e "s/^/ZZ/"   >> $logfile
find $HOME -path "*/PORTAL.war/*/configuration.properties" -type f |grep -E "dm2|rpu"  >> $logfile
echo "SITE/CACHE"   >> $logfile
#find . -path "*/PORTAL.war/[cde]*/cache*" -type d |grep -E "dem|ug1|ug2|sit|dm2|erec"
#find . -path "*/PORTAL.war/[cde]*/cache*" -type d |grep -E "dm2|rpu" | sed -e "s/^/ZZ/"   >> $logfile
find $HOME -path "*/PORTAL.war/[cde]*/cache*" -type d |grep -E "dm2|rpu"   >> $logfile
echo "************************************"

# [22:11:32] /software/akannayiram/how_to_clone/scripts_copy_website
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# 

