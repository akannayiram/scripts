#!/bin/bash
# ######################################
# To copy psappsrv.cfg from PROD hosts
#   - Al Kannayiram
#     July 2024
# #######################################
# Find the app domain directory
set -x
tagetdir=/software/akannayiram/dr_prep2024/prd/app
hostnm=$(echo $HOSTNAME|cut -d"." -f1)
for domdir in `find $PS_CFG_HOME/appserv -name "CNY*" -type d`
do
  dom=$(basename $domdir)
  #echo "domdir: [$domdir] dom: [$dom]"
  #psappsrvpath=`find $domdir -maxdepth 1 -name psappsrv.cfg`
  psappsrvpath=$domdir/psappsrv.cfg
  #echo "psappsrvpath: [$psappsrvpath]"
  echo "domdir: [$domdir] dom: [$dom] psappsrv.cfg: [$psappsrvpath]"
#  psappsrvfile=$(basename $psappsrvpath)
  if [[ -f $psappsrvpath ]] ; then
     cp $psappsrvpath $tagetdir/${hostnm}.${dom}.${USER}.psappsrv_cfg.txt
  else
     echo "ERROR ERROR [$psappsrvpath] is wrong. check the script"
  fi
done

