#!/bin/bash
# #############################################
#  Bolt - Execute to copy CFG from PROD/DR 
#    Al Kannayiram
#    July 2024
# #############################################
set -x
# -------------------------------------------------------------
# Pass two paramaters:
#   1: File containing hosts by pillar 
#       (Must use the same Unix login; hence by the pillar)
#   2: Pillar Linux Login
# -------------------------------------------------------------

[[ $# -ne 2 ]] && { echo "ERROR! ERROR!! 2 parameters are required!; exit 1; }
[[ ! -f $1 && ! -r $1 ]] && { echo "ERROR! ERROR!! Problem with the Input file [$1]. Please check!; exit 1; }
inphostsfile=$1
usr=$2
copyscript=/software/akannayiram/dr_prep2024/bin/prd_copy_appcfg.sh
date
bolt command run "sudo su - $usr -c $copyscript" -t @"$inphostsfile" --no-host-key-check --connect-timeout 60 --tty
echo " "
