#!/bin/bash
logdir=/software/akannayiram/scripts_adhoc/1timewebpsserver/logs
logfile=$logdir/piasites.prd.${HOSTNAME}.${LOGNAME}.$(date '+%Y%m%d').txt
echo "************************************"   >> $logfile
echo "$HOSTNAME  User: $LOGNAME"   >> $logfile
echo "************************************"   >> $logfile

while read -r line       >> $logfile
do       >> $logfile
#   echo "Processing: [$line]"  >> $logfile
   d=$(dirname $line)       >> $logfile
   leaf=$(basename $d)       >> $logfile
#   echo "Site: [$leaf]"  >> $logfile
   pssrv=$(grep "^psserver" $line)  >> $logfile
   echo "$HOSTNAME - [$LOGNAME] [$leaf] $pssrv "   >> $logfile
   
done < <(find $HOME -path "*/PORTAL.war/*/configuration.properties" -type f)   >> $logfile
echo "************************************"   >> $logfile
