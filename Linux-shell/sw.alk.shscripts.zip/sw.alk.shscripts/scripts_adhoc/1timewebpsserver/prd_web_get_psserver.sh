#!/bin/bash

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Al Kannayiram March 2025
#    Ger psserver server entries 
# *******************
# prd_web_get_psserver.sh
# 
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set -x

build_host_file ()
{

  for ((a=101;a<=104;a++)) do echo "cs92prwl$a" >> $tmphost ; done

}


# for NP
# for i in \`grep cnyp /etc/hosts |grep -v "#"|grep 86014|awk  '{print $2}'|sed -e "s/\r//"\`


build_script_gather_weblogins ()
{

  cat > $scr1 <<!EOF
#!/bin/bash
if [[ ! \$HOSTNAME =~ prwl ]] ; then
   echo "Wrong host. Run on PRD Web servers"
   exit
fi
for i in \`grep cnyp /etc/hosts |grep -v "#"|grep 860|awk  '{print \$2}'|sed -e "s/\r//"\`
do
sudo su - \$i -c "${scr2}" 
done

!EOF

}

build_action_script ()
{

  cat > $scr2 <<!EOF
#!/bin/bash
logdir=${basedir}/logs
logfile=\$logdir/piasites.prd.\${HOSTNAME}.\${LOGNAME}.\$(date '+%Y%m%d').txt
echo "************************************"   >> \$logfile
echo "\$HOSTNAME  User: \$LOGNAME"   >> \$logfile
echo "************************************"   >> \$logfile

while read -r line       >> \$logfile
do       >> \$logfile
#   echo "Processing: [\$line]"  >> \$logfile
   d=\$(dirname \$line)       >> \$logfile
   leaf=\$(basename \$d)       >> \$logfile
#   echo "Site: [\$leaf]"  >> \$logfile
   pssrv=\$(grep "^psserver" \$line)  >> \$logfile
   echo "\$HOSTNAME - [\$LOGNAME] [\$leaf] \$pssrv "   >> \$logfile
   
done < <(find \$HOME -path "*/PORTAL.war/*/configuration.properties" -type f)   >> \$logfile
echo "************************************"   >> \$logfile
!EOF

}

#echo "CONFIG"   >> \$logfile
#find \$HOME -path "*/PORTAL.war/*/configuration.properties" -type f -exec grep "^psserver" {} \\;  >> \$logfile

#build_host_file

# ---------------------
#   MAIN
# ---------------------

# Initialize
basedir=/software/akannayiram/scripts_adhoc/1timewebpsserver
scr1=${basedir}/weblogins.sh;rm -f $scr1
scr2=${basedir}/ext_psserver.sh;rm -f $scr2

tmphost=${basedir}/alk_prd_web_hosts.tmp;rm -f $tmphost
build_host_file

build_script_gather_weblogins


build_action_script

chmod 555 $scr1 $scr2

#bolt command run ${scr1} -t @"$tmphost" --tty --no-host-key-check

# Location: /software/akannayiram/scripts_adhoc/1timewebpsserver/
# END (al kannayiram)
