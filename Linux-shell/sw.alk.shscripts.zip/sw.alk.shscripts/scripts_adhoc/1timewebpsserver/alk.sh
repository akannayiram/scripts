#!/bin/bash
if [[ ! $HOSTNAME =~ prwl ]] ; then
   echo "Wrong host. Run on PRD Web servers"
   exit
fi
for i in `grep cnyp /etc/hosts |grep -v "#"|grep 860|awk  '{print $2}'|sed -e "s/\r//"`
do
#sudo su - $i -c "/software/akannayiram/scripts_adhoc/1timewebpsserver/ext_psserver.sh" 
  echo $i
done

