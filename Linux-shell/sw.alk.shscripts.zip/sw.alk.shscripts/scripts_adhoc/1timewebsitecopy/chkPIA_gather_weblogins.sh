#!/bin/bash
if [[ ! workbench =~ npwl ]] ; then
   echo "Wrong host. Run on NP Web servers"
   exit
fi
for i in `grep cnyd /etc/hosts |grep -v "#"|grep 86014|awk  '{print }'|sed -e "s/\r//"`
do
sudo su - $i -c "/software/akannayiram/scripts_adhoc/boltscriptmodel/web/chkPIA_action_script.sh" 
done

