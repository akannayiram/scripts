#!/bin/bash
# ######################################
# psappsrv.cfg on PROD hosts
#   - Al Kannayiram
#     March 2025
# #######################################
# Find the app domain directory
set -x
#tagetdir=/software/akannayiram/scripts_adhoc/1timeappcfg/logs
tagetdir=/tmp
hostnm=$(echo $HOSTNAME|cut -d"." -f1)
for domdir in `find $PS_CFG_HOME/appserv -name "CNY*" -type d`
do
  dom=$(basename $domdir)
  #echo "domdir: [$domdir] dom: [$dom]"
  #psappsrvpath=`find $domdir -maxdepth 1 -name psappsrv.cfg`
  psappsrvpath=$domdir/psappsrv.cfg
  #echo "psappsrvpath: [$psappsrvpath]"
  echo "domdir: [$domdir] dom: [$dom] psappsrv.cfg: [$psappsrvpath]"
#  psappsrvfile=$(basename $psappsrvpath)
  if [[ -f $psappsrvpath ]] ; then
#     tgtfile=$tagetdir/${hostnm}.${dom}.${USER}.psappsrv_cfg.txt
     tgtfile=$tagetdir/psappsrv.cfg
#     cp -p $psappsrvpath ${psappsrvpath}.alk.bkup
     cp $psappsrvpath $tgtfile
     sed -i -e "s/Min Instances=12/Min Instances=10/" $tgtfile
     sed -i -e "s/Max Instances=12/Max Instances=10/" $tgtfile
     echo "***************************"
     diff $psappsrvpath $tgtfile
     echo "***************************"
  else
     echo "ERROR ERROR [$psappsrvpath] is wrong. check the script"
  fi
done

