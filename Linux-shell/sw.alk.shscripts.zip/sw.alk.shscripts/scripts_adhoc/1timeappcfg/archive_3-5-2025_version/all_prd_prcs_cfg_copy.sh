#!/bin/bash
# ###################################################
#  PRD CS PRCS DOMAINS
#
#
#
# ###################################################

# CS Prcs domains: Two domains on each of the three hosts 
# Two bolt commands are executed: one for each domain
HOSTGRP=/tmp/csprdprcshst$$.txt
rm -f $HOSTGRP
cat > $HOSTGRP << !EOF
cs92prux101
cs92prux102
!EOF

/software/akannayiram/dr_prep2024/bin/prd_bolt_cmd_copy_prd_prcscfg.sh $HOSTGRP cnycsprd|tee -a tee_CS_bolt_cmd_copy_prd_prcscfg_$(date '+%Y%m%d_%H%M%S').log

# ###################################################
#  PRD IH PRCS DOMAINS
#
#
#
# ###################################################

HOSTGRP=/tmp/ihprdprcshst$$.txt
rm -f $HOSTGRP
cat > $HOSTGRP << !EOF
ihprux101
ihprux102
!EOF
/software/akannayiram/dr_prep2024/bin/prd_bolt_cmd_copy_prd_prcscfg.sh $HOSTGRP cnyihprd|tee -a tee_IH_bolt_cmd_copy_prd_prcscfg_$(date '+%Y%m%d_%H%M%S').log

# ###################################################
#  PRD HC PRCS DOMAINS
#
#
#
# ###################################################

HOSTGRP=/tmp/hcprdprcshst$$.txt
rm -f $HOSTGRP
cat > $HOSTGRP << !EOF
hc92prux101
hc92prux102
!EOF

/software/akannayiram/dr_prep2024/bin/prd_bolt_cmd_copy_prd_prcscfg.sh $HOSTGRP cnyhcprd|tee -a tee_HC_bolt_cmd_copy_prd_prcscfg_$(date '+%Y%m%d_%H%M%S').log


# ###################################################
#  PRD FS PRCS DOMAINS
#
#
#
# ###################################################

HOSTGRP=/tmp/fsprdprcshst$$.txt
rm -f $HOSTGRP
cat > $HOSTGRP << !EOF
fs92prux101
fs92prux102
!EOF

/software/akannayiram/dr_prep2024/bin/prd_bolt_cmd_copy_prd_prcscfg.sh $HOSTGRP cnyfsprd|tee -a tee_FS_bolt_cmd_copy_prd_prcscfg_$(date '+%Y%m%d_%H%M%S').log


