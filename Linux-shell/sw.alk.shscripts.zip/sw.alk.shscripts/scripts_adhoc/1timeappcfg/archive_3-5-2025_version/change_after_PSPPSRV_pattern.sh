#!/bin/bash

# How to change min and max of only the PSAPPSRV 
#
# printf '%s\n' '/1//4/s//8/' x | ex file.txt
# 
# ex is capable of combining multiple addresses. 
# So /1/ means "Go to" (or refer to) "the next line matching regex 1." i
# Then /4/ goes from that line to the next line matching 4. 
# And s//8/ has the usual meaning; as in Sed, a blank regex passed 
# to the s command means "reuse last regex used" which in this case is 4.
# 
# To print the modified file but not save the changes, use the following command instead:
# 
# printf '%s\n' '/1//4/s//8/' %p | ex file.txt
# 
# x means to save changes and exit, and %p means "print whole file." 
# (% is a synonym for 1,$, which is an address range from the first line to the last line.)

inp=al.cfg

printf '%s\n' '/\[PSAPPSRV\]//Min Instances/s/10/8/' x | ex $inp
printf '%s\n' '/\[PSAPPSRV\]//Max Instances/s/10/8/' x | ex $inp
