#!/bin/bash
# ###################################################
#  PRD CS APP DOMAINS
#
#
#
# ###################################################

# CS App domains
HOSTGRP=/tmp/csprdapphst$$.txt
rm -f $HOSTGRP
cat > $HOSTGRP << !EOF
cs92prap101
cs92prap102
cs92prap103
cs92prap104
cs92prap105
cs92prap106
cs92prap107
cs92prap108
cs92prap109
cs92prap110
cs92prap111
cs92prap112
cs92prap113
cs92prap114
cs92prap115
cs92prap116
cs92prap117
cs92prap118
cs92prap119
cs92prap120
cs92prap121
cs92prap122
cs92prap123
cs92prap124
cs92prap125
cs92prap126
cs92prap127
cs92prap128
cs92prap129
cs92prap130
cs92prap131
cs92prap132
!EOF

# # CS
# ./csprd_app_psadmin_cmd.sh start | tee -a tee_csprd_app_psadmin_cmd_$(date '+%Y%m%d_%H%M%S').log
scriptdir=/software/akannayiram/scripts_adhoc/1timeappcfg

${scriptdir}/prd_bolt_cmd_appcfg.sh $HOSTGRP cnycsprd|tee -a tee_CS_bolt_cmd_prd_appcfg_$(date '+%Y%m%d_%H%M%S').log

