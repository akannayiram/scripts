#!/bin/bash
# ######################################
# psappsrv.cfg on PROD hosts
#   - Al Kannayiram
#     March 2025
# 
#  PRD CS APP DOMAINS
#    Reconfig App domains
#
# ###################################################

set -x

build_copy_script ()
{

  cat > $copyscript <<!EOF
#!/bin/bash
#tgtdir=/software/akannayiram/scripts_adhoc/1timeappcfg/logs
tgtdir=/tmp
hostnm=\$(echo \$HOSTNAME|cut -d"." -f1)
for domdir in \`find \$PS_CFG_HOME/appserv -name "CNY*" -type d\`
do
  dom=\$(basename \$domdir)
  psappsrvpath=\$domdir/psappsrv.cfg
#  echo "domdir: [\$domdir] dom: [\$dom] psappsrv.cfg: [\$psappsrvpath]"
  echo "HOST: [\$hostnm]  psappsrv.cfg: [\$psappsrvpath]"
  if [[ -f \$psappsrvpath ]] ; then
#     tgtfile=\$tgtdir/\${hostnm}.\${dom}.\${USER}.psappsrv_cfg.txt
     tgtfile=\$tgtdir/psappsrv.cfg ; rm -f \$tgtfile
     rm -f \${psappsrvpath}.alk.bkup ; cp -p \$psappsrvpath \${psappsrvpath}.alk.bkup
     cp \$psappsrvpath \$tgtfile
     sed -i -e "s/Min Instances=12/Min Instances=10/" \$tgtfile
     sed -i -e "s/Max Instances=12/Max Instances=10/" \$tgtfile
     echo "Z***************************"
     diff \$psappsrvpath \$tgtfile
     echo "Z***************************"
  else
     echo "ERROR ERROR [\$psappsrvpath] is wrong. check the script"
  fi
done
!EOF
}



# CS App domains
HOSTGRP=./csprfapphst.txt
rm -f $HOSTGRP
for ((a=301; a<333; a++)) do echo "csspfap$a" >> $HOSTGRP ; done;

scriptdir=/software/akannayiram/scripts_adhoc/1timeappcfg/perf_appcfg_reconfig

usr=cnycsprf
copyscript=${scriptdir}/cs_prf_appcfg_auto_gen.sh ; rm -f $copyscript

build_copy_script
chmod 755 $copyscript

date
bolt command run "sudo su - $usr -c $copyscript" -t @"$HOSTGRP" --no-host-key-check --connect-timeout 60 --tty |tee -a tee_cs_prf_appcfg_$(date '+%Y%m%d_%H%M%S').log

echo " "
