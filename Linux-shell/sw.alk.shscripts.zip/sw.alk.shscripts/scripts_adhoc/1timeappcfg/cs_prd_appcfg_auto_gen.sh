#!/bin/bash
#tgtdir=/software/akannayiram/scripts_adhoc/1timeappcfg/logs
tgtdir=/tmp
hostnm=$(echo $HOSTNAME|cut -d"." -f1)
for domdir in `find $PS_CFG_HOME/appserv -name "CNY*" -type d`
do
  dom=$(basename $domdir)
  psappsrvpath=$domdir/psappsrv.cfg
  echo "domdir: [$domdir] dom: [$dom] psappsrv.cfg: [$psappsrvpath]"
  if [[ -f $psappsrvpath ]] ; then
#     tgtfile=$tgtdir/${hostnm}.${dom}.${USER}.psappsrv_cfg.txt
     tgtfile=$tgtdir/psappsrv.cfg ; rm -f $tgtfile
     rm -f ${psappsrvpath}.alk.bkup ; cp -p $psappsrvpath ${psappsrvpath}.alk.bkup
     cp $psappsrvpath $tgtfile
     sed -i -e "s/Min Instances=12/Min Instances=10/" $tgtfile
     sed -i -e "s/Max Instances=12/Max Instances=10/" $tgtfile
     echo "***************************"
     diff $psappsrvpath $tgtfile
     echo "***************************"
  else
     echo "ERROR ERROR [$psappsrvpath] is wrong. check the script"
  fi
done
