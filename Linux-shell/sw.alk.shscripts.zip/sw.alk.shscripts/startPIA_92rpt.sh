#!/bin/bash
if [[ ! $HOSTNAME =~ rpwl ]] ; then
   echo "Wrong host. Run on PRD Web servers"
   exit
fi
for i in `grep cnyr /etc/hosts |grep 858|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c /appl/oracle/weblogic/$i/webserv/peoplesoft/bin/startPIA.sh  ; echo "on" `cat /etc/hosts |grep $i`
done
