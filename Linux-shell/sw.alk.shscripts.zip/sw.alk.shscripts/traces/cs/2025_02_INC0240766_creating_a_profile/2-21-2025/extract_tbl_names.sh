#!/bin/bash
[[ ! -r $1 ]] && { echo "ERROR. Input file not found"; exit; }
inp=$1
cat $1|cut -c55-|grep " Stmt="|sed -e "s/^.* Stmt=//"|sed -e "s#^INSERT INTO ##I"|sed -e "s/^UPDATE //I"|sed -e "s#^.*FROM##I"|sed -e "s/WHERE.*$//I"|sed -e "s/ORDER BY.*$//I"|tr , \\n|tr [a-z] [A-Z]|sed -e "s/^ *[P]/P/"|grep -i PS|awk '{print $1}'|sort -u
#> ${1}.stmts_binds.txt

