[[ ! -r $1 ]] && { echo "ERROR. Input file not found"; exit; }
inp=$1

# Stmt= timings
#cat $1|grep " Stmt="|awk '{print $5}'|grep "^[0-9]"|sort -n -r|uniq -c|nl
#cat $1|grep " Stmt="|awk '{print $5}'|grep "^[0-9]"|sort -n -r|nl

# EXE Dur timings
#cat $1|grep " EXE" $1 |grep " Cur#"|awk '{print $8}'|grep "^Dur"|tr '=' ' '|sort -k2 -n -r|uniq -c|nl
cat $1|grep " EXE" $1 |grep " Cur#"|awk '{print $8}'|grep "^Dur"|tr '=' ' '|sort -k2 -n -r|nl

