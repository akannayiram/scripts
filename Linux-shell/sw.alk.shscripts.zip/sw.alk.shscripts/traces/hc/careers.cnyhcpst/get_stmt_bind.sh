[[ ! -r $1 ]] && { echo "Input file not found. Exiting..."; exit; }
# Egrep with "-n" to get the line number and then delete all chars leading up to Stmt= and Bind-
# Notice the leading space before Stmt and Bind
# Also notice that, 'Stmt=' is removed whereas 'Bind-' is kept
egrep -n " Stmt=| Bind-" $1|sed -e "s/:.* Stmt=/: /"|sed -e "s#:.* Bind-#: Bind-#" > ${1}.stmt.bind.txt
