#!/bin/bash
# ##################################################
# Get the top 10 Memory hog processes and 
# then find any PSAPPSRV processes among them.
# If found, get the PID and "i num"  for PSAPPSRV.
#    Note: 
#       Use the "i num" in tmadmin command line 
#       to recycle PSAPPSRV.
# History:
# Who                When      Why and What
# -----------------  --------- ------------------------
# Al Kannayiram      6/18/2021 Initial creation
#
# ##################################################

echo "---------FREE MEMORY---------------"
free -m

echo " "
echo "---------PERCENTAGE USAGE---------- "
mempct=`free -m|grep "^Mem:"|awk '{print $3*100/$2}'`
swppct=`free -m|grep "^Swap:"|awk '{print $3*100/$2}'`
echo "Memory %Used: $mempct     Swap %Used: $swppct"
echo " "

# Delete the tmp files created previously by this program
#find /tmp -user $USER -type f -name "tmadmin*.txt" -exec rm -f {} \; 2>/dev/null
# Temp file to save shutdown/boot command
TMPFILE=/tmp/tmadmin$$.txt

echo -e "Memory \t\t Login     \t PID      \t psappsrv \t inst \t Domain"
echo -e "------ \t\t --------- \t -------- \t -------- \t ---- \t --------"
#ps -eo pid,rss,comm|sort -k 2,2 -nr|head -10|grep PSAPPSRV|while read line
ps -eo pid,rss,comm|grep PSAPPSRV|sort -k 2,2 -nr|head -10|grep PSAPPSRV|while read line
do
pidnum=`echo $line|awk '{print $1}'`
mem=`echo $line|awk '{print $2}'`
#
# ================================================================
# The objective to remove unwated text from grep output.
# Sample grep output and parsed/edited text are given below.
# Series of sed commands with regex are used to remove unneeded text
# Sample grep output:
#      cnyepdm2  66914      1  0 13:15 ?        00:00:09 \
#      PSAPPSRV -C dom=CNYEPDM2_202833 -g 99 -i 3 -u prtnpap001.cf.cuny.edu \
#      -U /appl/psft/dm2/ep900/appserv/CNYEPDM2/LOGS/TUXLOG -m 0 -R 26636 \
#      -o ./LOGS/stdout -e ./LOGS/stderr -- -D CNYEPDM2 -S PSAPPSRV
# Edited output:
#      cnyepdm2  66914 PSAPPSRV -i 3 CNYEPDM2
# ================================================================
edited=`ps -aef|grep $pidnum|grep -v grep|sed -e "s/     1.*PSAPPSRV -C.* -i /PSAPPSRV -i /"|sed -e "s? -u .*/appserv/? ?"|sed -e "s#/LOGS.*# #"`
unixuser=`echo $edited|awk '{print $1}'`
pid=`echo $edited|awk '{print $2}'`
appsrv=`echo $edited|awk '{print $3}'`
instnum=`echo $edited|awk '{print $4 " " $5}'`
domain=`echo $edited|awk '{print $6}'`
echo -e "$mem \t $unixuser \t $pid    \t $appsrv \t $instnum \t $domain"
# Output shutdown/boot command to a tmp file
# Exclude psveritypipeexec
if [[ $appsrv = "PSAPPSRV" ]] ; then
   echo "shutdown $instnum -g APPSRV" >> $TMPFILE
   echo "boot $instnum -g APPSRV" >> $TMPFILE
fi
done | sort -nr -k 1,1
echo " "
echo "---List tmadmin shutdown/boot commands---"
cat $TMPFILE
rm -f $TMPFILE
