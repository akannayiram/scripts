#!/bin/bash
echo " "
date
echo "Server Status"
echo "=========================="
psadmin -c sstatus -d CNYCSPR1
echo " "
date
echo "Server Stop"
echo "=========================="
psadmin -c stop -d CNYCSPR1
echo " "
date
echo "Cache Purge"
echo "=========================="
psadmin -c purge -d CNYCSPR1 -noarch
echo " "
echo "Reconfigure"
echo "=========================="
psadmin -c configure -d CNYCSPR1
echo " "
date
echo "Server Start"
echo "=========================="
psadmin -c start -d CNYCSPR1

# Saving these lines for easy copy and paste
# /software/akannayiram/csprd_app_config_recycle.sh | tee -a /tmp/$HOSTNAME.$USER.csprd_app_config_recycle.$(date '+%Y%m%d_%H%M%S').log 
# cat /software/akannayiram/csprd_app_recycle.sh | sed -e "s/PR1/AM1/"
# cat /software/akannayiram/csprd_app_recycle.sh | sed -e "s/PR1/IM1/"

