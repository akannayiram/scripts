inp=$1
# make a backup first
cp -p $inp $inp.bkup.b4.smtp
echo SMTPSourceMachine: Before the change
grep "^SMTPSourceMachine" $inp 
host=`echo $HOSTNAME|cut -d"." -f1`
sed -i "/^SMTPSourceMachine/s/SMTPSourceMachine=.*$/SMTPSourceMachine=$host/" $inp
echo SMTPSourceMachine: After the change
grep "^SMTPSourceMachine" $inp 

