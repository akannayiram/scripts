#!/bin/bash
#set -x
# IH NP PRCS servers ih92npux050 and ih92npux051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi

bolt command run "sudo su - cnyihdm2 -c \"psadmin -p $actn -d CNYIHDM2\"" -t ih92npux050 --tty
bolt command run "sudo su - cnyihug2 -c \"psadmin -p $actn -d CNYIHUG2\"" -t ih92npux050 --tty
#bolt command run "sudo su - cnyihug1 -c \"psadmin -p $actn -d CNYIHUG1\"" -t ih92npux050 --tty

