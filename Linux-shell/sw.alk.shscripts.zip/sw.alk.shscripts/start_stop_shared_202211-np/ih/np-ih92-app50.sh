#!/bin/bash
#set -x
# IH NP App servers ih92npap050 and ih92npap051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi

bolt command run "sudo su - cnyihdm2 -c \"psadmin -c $actn -d CNYIHDM2\"" -t ih92npap050 --tty
bolt command run "sudo su - cnyihug1 -c \"psadmin -c $actn -d CNYIHUG1\"" -t ih92npap050 --tty
bolt command run "sudo su - cnyihug2 -c \"psadmin -c $actn -d CNYIHUG2\"" -t ih92npap050 --tty

