#!/bin/bash
#set -x
# FS NP PRCS servers fs92npux050 and fs92npux051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi
bolt command run "sudo su - cnyfsde2 -c \"psadmin -p $actn -d CNYFSDE2\"" -t fs92npux051 --tty
bolt command run "sudo su - cnyfspdv -c \"psadmin -p $actn -d CNYFSPDV\"" -t fs92npux051 --tty
bolt command run "sudo su - cnyfspst -c \"psadmin -p $actn -d CNYFSPST\"" -t fs92npux051 --tty
bolt command run "sudo su - cnyfsdev -c \"psadmin -p $actn -d CNYFSDEV\"" -t fs92npux051 --tty
bolt command run "sudo su - cnyfsdem -c \"psadmin -p $actn -d CNYFSDEM\"" -t fs92npux051 --tty
bolt command run "sudo su - cnyfsdmo -c \"psadmin -p $actn -d CNYFSDMO\"" -t fs92npux051 --tty

