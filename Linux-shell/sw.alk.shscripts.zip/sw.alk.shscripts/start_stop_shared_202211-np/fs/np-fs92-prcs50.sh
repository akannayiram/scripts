#!/bin/bash
#set -x
# FS NP PRCS servers fs92npux050 and fs92npux051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi
bolt command run "sudo su - cnyfsug2 -c \"psadmin -p $actn -d CNYFSUG2\"" -t fs92npux050 --tty
bolt command run "sudo su - cnyfsug1 -c \"psadmin -p $actn -d CNYFSUG1\"" -t fs92npux050 --tty
bolt command run "sudo su - cnyfsdm2 -c \"psadmin -p $actn -d CNYFSDM2\"" -t fs92npux050 --tty
bolt command run "sudo su - cnyfsrpu -c \"psadmin -p $actn -d CNYFSRPU\"" -t fs92npux050 --tty

