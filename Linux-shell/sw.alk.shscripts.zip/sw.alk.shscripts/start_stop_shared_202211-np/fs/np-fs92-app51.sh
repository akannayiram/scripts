#!/bin/bash
#set -x
# FS NP App servers fs92npap050 and fs92npap051:
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi
bolt command run "sudo su - cnyfsdem -c \"psadmin -c $actn -d CNYFSDEM\"" -t fs92npap051 --tty
bolt command run "sudo su - cnyfsdmo -c \"psadmin -c $actn -d CNYFSDMO\"" -t fs92npap051 --tty
bolt command run "sudo su - cnyfsdev -c \"psadmin -c $actn -d CNYFSDEV\"" -t fs92npap051 --tty
bolt command run "sudo su - cnyfsde2 -c \"psadmin -c $actn -d CNYFSDE2\"" -t fs92npap051 --tty
bolt command run "sudo su - cnyfspst -c \"psadmin -c $actn -d CNYFSPST\"" -t fs92npap051 --tty
bolt command run "sudo su - cnyfspdv -c \"psadmin -c $actn -d CNYFSPDV\"" -t fs92npap051 --tty

