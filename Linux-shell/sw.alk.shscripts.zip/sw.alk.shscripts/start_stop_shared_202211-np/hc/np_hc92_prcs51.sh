#!/bin/bash
# ======================================
#    H C   9.2   P R C S   S E R V E R S
# ======================================
set -x
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi


bolt command run "sudo su - cnyhcde2 -c \"psadmin -p $actn -d CNYHCDE2\"" -t hc92npux051 --tty
bolt command run "sudo su - cnyhcpst -c \"psadmin -p $actn -d CNYHCPST\"" -t hc92npux051 --tty
bolt command run "sudo su - cnyhcpdv -c \"psadmin -p $actn -d CNYHCPDV\"" -t hc92npux051 --tty
bolt command run "sudo su - cnyhcdev -c \"psadmin -p $actn -d CNYHCDEV\"" -t hc92npux051 --tty
bolt command run "sudo su - cnyhcdem -c \"psadmin -p $actn -d CNYHCDEM\"" -t hc92npux051 --tty
bolt command run "sudo su - cnyhcdmo -c \"psadmin -p $actn -d CNYHCDMO\"" -t hc92npux051 --tty

