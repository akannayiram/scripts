#!/bin/bash
# ======================================
#    C S   9.2   A P P   S E R V E R S
# ======================================
#set -x
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi
date
echo "sudo su - cnycsrpu -c \"psadmin -c $actn -d CNYCSRPU\"" 
bolt command run "sudo su - cnycsrpu -c \"psadmin -c $actn -d CNYCSRPU\"" -t cs92npap050 --tty
date
echo "sudo su - cnycsdm2 -c \"psadmin -c $actn -d CNYCSDM2\"" 
bolt command run "sudo su - cnycsdm2 -c \"psadmin -c $actn -d CNYCSDM2\"" -t cs92npap050 --tty
date
echo "sudo su - cnycsug2 -c \"psadmin -c $actn -d CNYCSUG2\"" 
bolt command run "sudo su - cnycsug2 -c \"psadmin -c $actn -d CNYCSUG2\"" -t cs92npap050 --tty
date
echo "sudo su - cnycsad2 -c \"psadmin -c $actn -d CNYCSAD2\"" 
bolt command run "sudo su - cnycsad2 -c \"psadmin -c $actn -d CNYCSAD2\"" -t cs92npap050 --tty
date
echo "sudo su - cnycsad1 -c \"psadmin -c $actn -d CNYCSAD1\"" 
bolt command run "sudo su - cnycsad1 -c \"psadmin -c $actn -d CNYCSAD1\"" -t cs92npap050 --tty
date
echo "sudo su - cnycsug1 -c \"psadmin -c $actn -d CNYCSUG1\"" 
bolt command run "sudo su - cnycsug1 -c \"psadmin -c $actn -d CNYCSUG1\"" -t cs92npap050 --tty

