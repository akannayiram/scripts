#!/bin/bash
# ======================================
#    C S   9.2   P R C S   S E R V E R S
# ======================================
set -x
[[ $# -ne 1 ]] && { echo "Input param is required (sstatus, start, stop). Exiting...."; exit; }
if [[ "$1" == "sstatus" ||  "$1" == "status" || "$1" == "start" ||  "$1" == "stop" ]] ; then
   actn=$1
   [[ "$actn" == "status" ]] && actn="sstatus"
   echo "Input param is [$actn]"
else
   echo "ERROR! Input param must be one of  (sstatus, start, stop). Exiting...."
   exit
fi

bolt command run "sudo su - cnycspst -c \"psadmin -p $actn -d CNYCSPST\"" -t cs92npux051 --tty
bolt command run "sudo su - cnycsdev -c \"psadmin -p $actn -d CNYCSDEV\"" -t cs92npux051 --tty
bolt command run "sudo su - cnycsde2 -c \"psadmin -p $actn -d CNYCSDE2\"" -t cs92npux051 --tty
bolt command run "sudo su - cnycscu5 -c \"psadmin -p $actn -d CNYCSCU5\"" -t cs92npux051 --tty
bolt command run "sudo su - cnycsdem -c \"psadmin -p $actn -d CNYCSDEM\"" -t cs92npux051 --tty
bolt command run "sudo su - cnycsdmo -c \"psadmin -p $actn -d CNYCSDMO\"" -t cs92npux051 --tty
bolt command run "sudo su - cnycspdv -c \"psadmin -p $actn -d CNYCSPDV\"" -t cs92npux051 --tty
bolt command run "sudo su - cnycs005 -c \"psadmin -p $actn -d CNYCS005\"" -t cs92npux051 --tty

