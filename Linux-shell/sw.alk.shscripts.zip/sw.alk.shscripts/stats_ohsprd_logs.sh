#!/bin/bash
# ##################################
# stats_ohsprd_logs.sh
# Al Kannayiram: Stats from OHS logs
#   
#   Modify the search string "searchstring"
#   It's hardcoded currently; 
#   I'll remove hardcoding soon and 
#   modify it to accept as an input parm.
#    Format of the "searchstring":
#       dd/mmm/yyyy:HH24:<Minutes Regex>
#
#   N O T E :
#    OHS log filenames are NOT configured the same 
#    across NP, PRF, PRD tiers.
#    In a way, filenames are hardcoded.
#    Hece, this script is for P R O D U C T I O N only
# ##################################
#set -x
extract_from_log () {

echo " "
if [[ -r $1 ]] ; then 
	logf=$(basename $1)
	echo "Processing log file: [$logf]"
	#grep "$searchstring"  $1|awk '{print $5}'|grep "^\["|sed -e "s/^\[//"|awk -F":" '{print $1 ":" $2 ":" $3}'|sort|uniq -c|awk '{print $2 "\t" $1}'
	grep "$searchstring"  $1|awk '{print $5}'|grep "^\["|sed -e "s/^\[//"|awk -F":" '{print $1 ":" $2 ":" $3}'|sort|uniq -c|awk '{print $2 "\t" $1}'|sed -e "s/$yyyy:/$yyyy /"
else
	echo "ERROR! Missing [$1]"
fi	
echo " "

}

# CONSTANT
yyyy=$(date '+%Y')
# An example search string. Date is full. Time: 20 hours, 
#   Minutes: First digit is 0 to 2, the second digit is 0 to 9.
#   So, minutes from 00 to 29.
searchstring="31/Mar/2023:20:[0-2][0-9]:"    

if [[ $HOSTNAME =~ ohs92prd ]] ; then

logfile=cs_access.log && extract_from_log ${PROXY_LOGS}/${logfile}
logfile=ih_access.log && extract_from_log ${PROXY_LOGS}/${logfile}
logfile=fin_access.log && extract_from_log ${PROXY_LOGS}/${logfile}
logfile=hcm_access.log && extract_from_log ${PROXY_LOGS}/${logfile}

fi

if [[ $HOSTNAME =~ ohs92prf ]] ; then

logfile=cs_prf_log && extract_from_log ${PROXY_LOGS}/${logfile}
logfile=ih_prf_log && extract_from_log ${PROXY_LOGS}/${logfile}
logfile=fin_prf_log && extract_from_log ${PROXY_LOGS}/${logfile}
logfile=hcm_prf_log && extract_from_log ${PROXY_LOGS}/${logfile}

fi
