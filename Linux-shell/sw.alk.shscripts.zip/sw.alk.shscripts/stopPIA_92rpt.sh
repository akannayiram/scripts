#!/bin/bash -x
if [[ ! $HOSTNAME =~ rpwl ]] ; then
   echo "Wrong host. Run on RPT Web servers"
   exit
fi
for i in `grep cnyr /etc/hosts |grep -E "858|860"|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c $PS_CFG_HOME/$i/webserv/peoplesoft/bin/stopPIA.sh  ; echo "on" `cat /etc/hosts |grep $i`
done
