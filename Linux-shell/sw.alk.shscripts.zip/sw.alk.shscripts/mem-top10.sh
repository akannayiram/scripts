echo "PID    Memory  Process"
echo "------ ------- ------------"
ps -eo pid,rss,comm|sort -k 2,2 -nr|head -10

#ps -eo rss,comm|sort -k 1,1 -nr|head -10
