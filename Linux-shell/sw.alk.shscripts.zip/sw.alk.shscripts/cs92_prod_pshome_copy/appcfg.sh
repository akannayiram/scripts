#!/bin/bash -x
# Find the app domain directory 
logfile=/software/akannayiram/cs92_prod_pshome_copy/${HOSTNAME}.${USER}.psappsrv_cfg.txt
for domdir in `find $HOME -name "CNYCS*" -type d`
do 
  psappsrv=`find $domdir -maxdepth 1 -name psappsrv.cfg`
  echo $psappsrv >> $logfile
  egrep "^DBName=|^SMTPServer=|^SMTPServer1=" $psappsrv >> $logfile
done
