#!/bin/bash
# enumerate the log files
TMP=/tmp/alk$$.tmp
for inp in `ls cs92prap*txt`
do
 echo "${HOSTNAME}: Input File: [$inp]"
 cnt=`grep Copied $inp|wc -l`
 if [[ "$cnt" -eq "0" ]] ; then 
    echo "${HOSTNAME}: [ERROR} Didn't find the Copied line. Skipping [$inp]....."
 else
    rm -f $TMP
    grep Copied $inp > $TMP
    psadmin_config=${inp}.psadmin
    while read -r copiedlines
    do
      echo "${HOSTNAME}: Copied Line: [$copiedlines]"
      appdom=`echo $copiedlines|grep Copied|awk '{print $2}'|sed -e "s#.*appserv/##"|sed -e "s#/psappsrv.cfg]##"`
      echo "${HOSTNAME}: App Domain Name: [$appdom]"
      echo "${HOSTNAME}: psadmin -c configure -d $appdom"
      echo "psadmin -c configure -d $appdom" > -l /software/akannayiram/cs92_prod_pshome_copy/sedlogs/${HOSTNAME}.cnycsprd.psappsrv_cfg.txt.psadmin
     cat /software/akannayiram/cs92_prod_pshome_copy/sedlogs/${HOSTNAME}.cnycsprd.psappsrv_cfg.txt.psadmin
  #   $psadmin_config
    done < $TMP
 fi
done
rm -f $TMP
