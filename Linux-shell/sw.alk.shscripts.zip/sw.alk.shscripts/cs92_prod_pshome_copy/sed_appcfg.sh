#!/bin/bash -x
# Find the app domain directory 
logfile=/software/akannayiram/cs92_prod_pshome_copy/sedlogs/${HOSTNAME}.${USER}.psappsrv_cfg.txt
for domdir in `find $HOME -name "CNYCS*" -type d`
do 
  psappsrv=`find $domdir -maxdepth 1 -name psappsrv.cfg`
  bkupfile=${psappsrv}.bkup.2-9-2022
  cp -p $psappsrv $bkupfile
  echo "Copied [$psappsrv] to [$bkupfile]" >> $logfile
  echo "Before making the change" >> $logfile
  egrep "^DBName=|^SMTPServer=|^SMTPServer1=" $psappsrv >> $logfile
  sed -i -e "s/DBName=CNYCSPR2/DBName=CNYCSPR1/" $psappsrv
  echo "After making the change" >> $logfile
  egrep "^DBName=|^SMTPServer=|^SMTPServer1=" $psappsrv >> $logfile
done
