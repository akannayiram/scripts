#!/bin/bash
# Find the app domain directory 
dttm=`date '+%Y-%m-%d %H:%M:%S'`
logfile=/software/akannayiram/cs92_prod_pshome_copy/${HOSTNAME}.${USER}.pstuxcfg_list.txt
for domdir in `find $HOME -name "CNYCS*" -type d`
do 
  pstuxcfg=`find $domdir -maxdepth 1 -name PSTUXCFG -type f -exec ls -l {} \;`
  echo "[$dttm]:: $HOSTNAME [$pstuxcfg]"
  echo "[$dttm]:: $HOSTNAME [$pstuxcfg]" >> $logfile
done
