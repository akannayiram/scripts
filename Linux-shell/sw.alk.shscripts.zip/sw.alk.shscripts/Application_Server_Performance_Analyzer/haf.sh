#!/bin/bash
set -x
export JAVA_HOME=/appl/psft/pt86014/pt/ps_home8.60.14/jre
cd /software/akannayiram/Application_Server_Performance_Analyzer/HAF
export PSDB=CNYFSPDV
export APPDOM=CNYFSPDV
export PSDB_HOST=$(tnsping $PSDB|grep -i host|sed  's/.*HOST[^=]*\([^)]*\).*/\1/i'|sed 's/=//'|sed s'/ //')
export PSFT_USER=SYSADM
#export PSFT_PASSWORD=Database password
read -p "Enter sysadm pw: " PSFT_PASSWORD
# export PSFT_CONNECTION=jdbc:oracle:thin:@FINnpDB002.Cf.CUNY.Edu:3200/CNYFSPDV
#export PSFT_CONNECTION=jdbc:oracle:thin:@${PSDB_HOST}:3200/${PSDB}
export PSFT_CONNECTION=jdbc:oracle:thin:${PSFT_USER}/${PSFT_PASSWORD}@${PSDB_HOST}:3200/${PSDB}


# bash ./run_analyzer.sh -Danalyzer="resource/Tools_AS_Perf_Unix_analyzer.xml" -Dp_PS_CFG_HOME=PS_CFG_HOME -Dp_AppServerDomain=
bash ./run_analyzer.sh -Danalyzer="resource/Tools_AS_Perf_Unix_analyzer.xml" -Dp_PS_CFG_HOME=$PS_CFG_HOME -Dp_AppServerDomain=$APPDOM

