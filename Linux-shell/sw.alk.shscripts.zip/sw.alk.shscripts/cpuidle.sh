#!/bin/bash
hst=$(hostname|cut -d"." -f1)
# Lowest 3 CPU Idle Percentage
while true 
do
echo " "
date
#grep Cpu /tmp/*92rp*top.hdr*|cut -d"," -f4|awk '{print $1}'|sort -n|head -3
#grep Cpu /tmp/${hst}*top.hdr*|cut -d"," -f4|awk '{print $1}'|sort -n|head -3
egrep "^top|Cpu" /tmp/${hst}*top.hdr*|paste -d "|" - -|cut -d"," -f1,9|awk '{print $7 " " $3}'|sort -n -k1|head -3
sleep 15 
done 
