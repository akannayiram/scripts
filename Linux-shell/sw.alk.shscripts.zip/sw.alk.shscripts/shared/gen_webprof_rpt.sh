#!/bin/bash
# --------------------------
# ######################################
#  Generate Webprofile listing for a stack
#  al kannayiram - 10/17/2024
# 
#  Invoke with a 3-char Stack Identifier such as DM2, PST
# ######################################

build_env_list () {

for i in $stacklist
do
  for j in CNYCS CNYIH CNYHC CNYFS
  do
    env="$j$i"
    [[ "$env" == "CNYHCDM2" ]] && env=CNYHCUG3
    [[ "$env" == "CNYFSDM2" ]] && env=CNYFSUG3
    envlist="$envlist $env"
  done
done


}

# Exit if no Input argument
[[ $# -lt 1 ]] && { echo "ERROR! Invoke with Stack Id parameter"; exit 1; }

stacklist="$1"
envlist=""
build_env_list
echo "$envlist"
for env in $envlist
do
  echo "Processing $env"
  sqlplus /@"$env" @/software/akannayiram/shared/SQLs_validate_webprofiles_html.sql
  mv webprofile_config_values_report.html ${env}_webprofile_config_values_report.html
done
