#Set PATH type environment settings
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib:/lib64:/usr/lib64; export LD_LIBRARY_PATH
PATH=$PATH:/usr/lib:/lib64:/usr/lib64;export PATH
#Set Application specific environments
if [ -d /appl/oracle/product/19/client ] 
        then
        ORACLE_BASE=/appl/oracle; export ORACLE_BASE
        ORACLE_HOME=$ORACLE_BASE/product/19/client; export ORACLE_HOME
        PATH=$ORACLE_HOME/bin:$PATH; export PATH
        TNS_ADMIN=/psft/env; export TNS_ADMIN
        LD_LIBRARY_PATH=$ORACLE_HOME/lib:$LD_LIBRARY_PATH; export LD_LIBRARY_PATH
fi

