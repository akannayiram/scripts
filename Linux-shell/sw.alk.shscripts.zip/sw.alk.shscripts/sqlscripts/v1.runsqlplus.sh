#!/bin/bash
# Check input param
#set -x
[[ $# -ne 2 ]] && { echo "ERROR! ERROR! Input param is requried. Exiting....."; exit 1; }
sqlscript=$1
inpdb=$2
date

# tmp file
tmpdb=/tmp/${inpdb}.tmp.$$
rm -f $tmpdb
cat $inpdb|grep -v "^#" > $tmpdb
#cat $inpdb | while read line
while read -r line
do
  # Get usr creds
  db=$(echo $line|awk '{print $1}')
  pw=$(echo $line|awk '{print $2}')
  usr=$(echo $line|awk '{print $3}')
  echo "db: [$db]  pw: [$pw]  usr: [$usr]"
sqlplus -s ${usr}/${pw}@${db} @${sqlscript}
done < $tmpdb
rm -f $tmpdb
date
