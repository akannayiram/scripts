#!/bin/bash
# Check input param
#set -x
[[ $# -ne 2 ]] && { echo "ERROR! ERROR! Input param is requried. Exiting....."; exit 1; }
sqlscript=$1
inpdb=$2
echo "[Begin]: $(date) Script: [$sqlscript]  DB List: [$inpdb]"

#cat $inpdb | while read line
while read -r line
do
  # Skip if commented out
  [[ $(echo $line|cut -c1) == "#" ]] && { echo "Skipping [$line]"; continue; }
  # Get usr creds
  db=$(echo $line|awk '{print $1}')
  pw=$(echo $line|awk '{print $2}')
  usr=$(echo $line|awk '{print $3}')
#  echo "db: [$db]  pw: [$pw]  usr: [$usr]"
  echo "###############################################################"
  echo "Connecting to $db as $usr"
sqlplus -s ${usr}/${pw}@${db} @${sqlscript}
done < $inpdb
echo "[End]: $(date) Script: [$sqlscript]  DB List: [$inpdb]"
