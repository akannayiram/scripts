#echo [$HOSTNAME] $(ls -lh /software/reg29/appserv/classes/com.peoplesoft.cs.sa.jar)
#echo [$HOSTNAME] $(ls -lh /appl/psft/prd/cs920/appserv/classes/com.peoplesoft.cs.sa.jar)
#echo [$HOSTNAME] $(ls -lh /software/reg29/class/com.peoplesoft.cs.sa.jar)
#echo [$HOSTNAME] $(ls -lh /appl/psft/prd/cs920/class/com.peoplesoft.cs.sa.jar)
# Compute checksum and then compare 
srcappjar=/software/reg29/appserv/classes/com.peoplesoft.cs.sa.jar
srcclassjar=/software/reg29/class/com.peoplesoft.cs.sa.jar
tgtappjar=/appl/psft/prd/cs920/appserv/classes/com.peoplesoft.cs.sa.jar
tgtclassjar=/appl/psft/prd/cs920/class/com.peoplesoft.cs.sa.jar
srcappjarsum=$(md5sum $srcappjar|awk '{print $1}')
tgtappjarsum=$(md5sum $tgtappjar|awk '{print $1}')
srcclassjarsum=$(md5sum $srcclassjar|awk '{print $1}')
tgtclassjarsum=$(md5sum $tgtclassjar|awk '{print $1}')
echo "[$HOSTNAME] srcappjarsum: [$srcappjarsum] srcclassjarsum: [$srcclassjarsum]"
echo "[$HOSTNAME] tgtappjarsum: [$tgtappjarsum] tgtclassjarsum: [$tgtclassjarsum]"
#echo "1. $?"
[[ "$srcappjarsum" == "$tgtappjarsum" ]] && [[ "$srcclassjarsum" == "$tgtclassjarsum" ]] && { echo "SAME SAME"; }
#echo "2. $?"
[[  "$srcappjarsum" != "$tgtappjarsum" ]] && { echo "ERROR! Check appserv/classes"; }
#echo "3. $?" When the first AND fails, return code seems to be 1
[[  "$srcclassjarsum" != "$tgtclassjarsum" ]] && { echo "ERROR! Check class/"; }
#echo "4. $?"
echo "Done"   # just so that Bolt does not get 'return code of 1' and gets 'exit code of zero'
