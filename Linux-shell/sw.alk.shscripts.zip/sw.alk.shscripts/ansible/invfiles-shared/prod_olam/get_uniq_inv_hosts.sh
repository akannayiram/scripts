#!/bin/bash

ansible-inventory -i ./CurrentAnsibleHosts.txt all --graph|grep "\-\-"|grep -v "@"|sed -e "s/^.*--//"|tr [A-Z] [a-z]|sort -u >  uniq_CurrentAnsibleHosts.txt
