#!/bin/bash
# ########################################
#  Al Kannayiram August 2024
#  Build a validation script with group names 
#  extracted from /etc/anible/hosts
#
grep "\[" /etc/ansible/hosts|grep -v "#"|grep -E "app|prcs|web|_rb|_ca|srch|_ohs"|sed -e "s/\[//"|sed -e "s/\]//"|sed -e "s/:children//"|while read -r line;do echo "ansible-inventory -i /etc/ansible/hosts --graph $line";done > validate_ansible_groups2.sh
