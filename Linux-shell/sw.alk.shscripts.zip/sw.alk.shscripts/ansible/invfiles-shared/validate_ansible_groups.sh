#!/bin/bash
# ########################################
#  Al Kannayiram August 2024
#  Build this validation script programatically validation script 
#  by extracting groups names from /etc/anible/hosts
#
# [akannayiram@cnypram001 ~]$ grep "\[" /etc/ansible/hosts|grep -v "#"|grep -E "app|prcs|web"|sed -e "s/\[//"|sed -e "s/\]//"|sed -e "s/:children//"|while read -r line;do echo "ansible-inventory -i /etc/ansible/hosts --graph $line";done > validate_ansible_groups.sh
# [akannayiram@cnypram001 ~]$ date
# Wed Aug  7 16:51:57 EDT 2024
set -x
ansible-inventory -i /etc/ansible/hosts --graph prd_cs_app
ansible-inventory -i /etc/ansible/hosts --graph prd_cs_prcs
ansible-inventory -i /etc/ansible/hosts --graph prd_ih_app
ansible-inventory -i /etc/ansible/hosts --graph prd_ih_prcs
ansible-inventory -i /etc/ansible/hosts --graph prd_hc_app
ansible-inventory -i /etc/ansible/hosts --graph prd_hc_prcs
ansible-inventory -i /etc/ansible/hosts --graph prd_fs_app
ansible-inventory -i /etc/ansible/hosts --graph prd_fs_prcs
ansible-inventory -i /etc/ansible/hosts --graph prd_cs_appprcs
ansible-inventory -i /etc/ansible/hosts --graph prd_ih_appprcs
ansible-inventory -i /etc/ansible/hosts --graph prd_hc_appprcs
ansible-inventory -i /etc/ansible/hosts --graph prd_fs_appprcs
ansible-inventory -i /etc/ansible/hosts --graph prd_all_app
ansible-inventory -i /etc/ansible/hosts --graph prd_all_prcs
ansible-inventory -i /etc/ansible/hosts --graph prd_all_appprcs
ansible-inventory -i /etc/ansible/hosts --graph rptprd_cs_app
ansible-inventory -i /etc/ansible/hosts --graph rptprd_cs_prcs
ansible-inventory -i /etc/ansible/hosts --graph rptprd_hc_app
ansible-inventory -i /etc/ansible/hosts --graph rptprd_hc_prcs
ansible-inventory -i /etc/ansible/hosts --graph rptprd_fs_app
ansible-inventory -i /etc/ansible/hosts --graph rptprd_fs_prcs
ansible-inventory -i /etc/ansible/hosts --graph rptprd_all_appprcs
ansible-inventory -i /etc/ansible/hosts --graph prd2rpt_all_appprcs
ansible-inventory -i /etc/ansible/hosts --graph prd_cs_web
ansible-inventory -i /etc/ansible/hosts --graph prd_ih_web
ansible-inventory -i /etc/ansible/hosts --graph prd_hc_web
ansible-inventory -i /etc/ansible/hosts --graph prd_fs_web
ansible-inventory -i /etc/ansible/hosts --graph prd_all_web
ansible-inventory -i /etc/ansible/hosts --graph rptprd_cs_web
ansible-inventory -i /etc/ansible/hosts --graph rptprd_hc_web
ansible-inventory -i /etc/ansible/hosts --graph rptprd_fs_web
ansible-inventory -i /etc/ansible/hosts --graph rptprd_all_web
ansible-inventory -i /etc/ansible/hosts --graph prd2rpt_all_web
ansible-inventory -i /etc/ansible/hosts --graph prd_ca
ansible-inventory -i /etc/ansible/hosts --graph prd_ohs
ansible-inventory -i /etc/ansible/hosts --graph prd_rb
ansible-inventory -i /etc/ansible/hosts --graph prd_srch
