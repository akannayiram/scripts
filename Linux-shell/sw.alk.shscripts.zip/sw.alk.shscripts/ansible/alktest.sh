#!/bin/bash
echo "Ansible test connection to [$HOSTNAME] as [$LOGNAME] at $(date)"
