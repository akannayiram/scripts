# Execute from within nonprod/apux, perf/apuc, prod/apux directory
ln -s /home/akannayiram/common/ansible.cfg ansible.cfg
ln -s /home/akannayiram/common/apux_play.yml play.yml
ln -s /home/akannayiram/common/apux_tasks.yml tasks.yml

ln -s /home/akannayiram/common/gethosts.sh gethosts.sh
