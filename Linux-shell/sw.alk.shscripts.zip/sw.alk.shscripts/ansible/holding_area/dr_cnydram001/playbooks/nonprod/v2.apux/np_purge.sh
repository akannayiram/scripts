#!/bin/bash
# *****************
#  N O N - P R O D
#
#   P U R G E    C A C H E
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=purge
#limit_hosts=npprcs
limit_hosts=ih92npux051

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

./np_exec_play.sh $actn $limit_hosts | tee -a $teelog
