#!/bin/bash
# *****************
#  N O N - P R O D
#
#   S T A T U S    C H E C K
# *****************
set -x
actn=status
#limit_hosts=npprcs
#limit_hosts=test
limit_hosts=fs92npux052
./np_exec_play.sh $actn $limit_hosts
