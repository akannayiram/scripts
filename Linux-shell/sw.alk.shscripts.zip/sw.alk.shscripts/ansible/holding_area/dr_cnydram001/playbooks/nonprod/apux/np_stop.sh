#!/bin/bash
# *****************
#  N O N - P R O D
#
#   S T O P    D O M A I N S
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=stop
#limit_hosts=npprcs
#limit_hosts=ih92npux051
limit_hosts=npcsappprcs
#limit_hosts=npihappprcs
#limit_hosts=npfsappprcs
#limit_hosts=nphcappprcs

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

./np_exec_play.sh $actn $limit_hosts | tee -a $teelog

# Parse the log file
./apux_parse_logs.sh "$teelog"
echo "Log: $teelog"
