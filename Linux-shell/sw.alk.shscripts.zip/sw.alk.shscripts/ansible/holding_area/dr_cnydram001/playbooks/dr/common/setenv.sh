export ANSIBLE_BECOME_EXE='/usr/bin/sudo su - '
export ANSIBLE_CONFIG=./ansible.cfg
