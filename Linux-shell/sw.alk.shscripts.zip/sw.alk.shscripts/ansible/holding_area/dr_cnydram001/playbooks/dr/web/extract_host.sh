#!/bin/bash
pattern1="TASK \[set_fact\]"
pattern2="TASK \[Shell task"
awk "/$pattern1/{flag=1;next}/$pattern2/{flag=0}flag" $1|grep "^ok"|tr "[]" " "|awk '{print $2}'|sort
awk "/$pattern1/{flag=1;next}/$pattern2/{flag=0}flag" $1|grep "^ok"|wc -l
