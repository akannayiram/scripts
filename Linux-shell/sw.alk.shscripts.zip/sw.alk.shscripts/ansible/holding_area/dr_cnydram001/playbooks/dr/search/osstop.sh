#!/bin/bash
# *****************
#  P R O D
#
#   S T  O P   S E A R C H   D O M A I N S
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=stop
limit_hosts=all

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

sttm="BEGIN: Playbook: [osstop.yml] Action: [$actn]: $(date)"
echo $sttm
ansible-playbook osstop.yml | tee -a $teelog
echo $sttm
echo "END:   Playbook: [osstop.yml] Action: [$actn]: $(date)"
echo "Log: $teelog"
