#!/bin/bash
echo "Running on [$HOSTNAME] as [$LOGNAME]"
pwd
./start_Clean_Address.sh
