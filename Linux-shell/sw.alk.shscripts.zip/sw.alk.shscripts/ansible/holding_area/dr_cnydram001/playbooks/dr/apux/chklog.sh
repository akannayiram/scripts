#!/bin/bash
# Check the log
logfile=$1

#grep STDOUT $logfile|sed -e "s/^.* on //"|awk '{print $1}'|sort -u
#grep STDERR $logfile|sort

# Prd App BBL: 81 Rpt App BBL: 3 
# Prd Prcs BBL: 10 Rpt Prcs BBL: 3
# Total: 97
echo "*** Expected BBL Count: 97 ***"
bblcnt=$(grep BBL $logfile|wc -l)
echo "BBL Count: [$bblcnt]"
stdoutcnt=$(grep STDOUT $logfile|wc -l)
echo "STDOUT Count: [$stdoutcnt]"
stderrcnt=$(grep STDERR $logfile|wc -l)
echo "STDERR Count: [$stderrcnt]"

# Ansible play status
# Check if any failed
failedcnt=$(grep "ok=" $logfile|grep -v "failed=0"|wc -l)
echo "Failed Count: [$failedcnt]"
