#!/bin/bash
# *****************
#  P E R F O R M A N C E
#
#    Usage: Pass two input parameters
#       1) Action (start, stop, purge or sstatus)
#       2) Host or Host group (limit_hosts)
# *****************
#set -x

# Constants
ENVTYPE=dr
SAFETYSW="_${ENVTYPE}_allow_shutdown"
# ***

[[ $# -ne 2 ]] && { echo "ERROR! Two input parameters are required for [$0]. Aborting..."; exit; }

actn=$1
[[ "$actn" == "status" ]] && actn=sstatus
[[ "$actn" != "sstatus" && "$actn" != "start" && "$actn" != "stop" && "$actn" != "purge" ]] && { echo "ERROR! [$actn] is invalid input parameter". Aborting...; exit; }


# For stop and purge, 'touch' to create an 'allow' file
#  (To project against inadvertent execution of shutdown/purge)
if [[ "$actn" == "stop" || "$actn" == "purge" ]] ; then
   [[ ! -f $SAFETYSW ]] && { echo "ERROR! [$SAFETYSW] is missing. Create [$SAFETYSW] and try again. Aborting..."; exit; }
  # stat -c (to use FORMATs and output in same order) %w: File birth time; %F: File type 
  cdate=$(stat -c "%w %F" ${SAFETYSW}|awk '{print $1}')
  curdate=$(date '+%Y-%m-%d')
  [[ "$cdate" != "$curdate" ]] && { echo "ERROR! [$SAFETYSW] is stale. Re-create [$SAFETYSW] and try again. Aborting..."; exit; }
fi

# Limit the number of hosts
limit_hosts=$2
[[ "$limit_hosts" != "all" && ! "$limit_hosts" =~ dr && ! "$limit_hosts" =~ rpt ]] && { echo "ERROR! [$limit_hosts] is invalid host or host group. Please check and try again. Aborting...."; exit; }


sttm="BEGIN: Playbook: [play.yml] Action: [$actn]: $(date)"
echo $sttm
ansible-playbook play.yml --limit "$limit_hosts" -e actn="$actn"

# echo remove _allow_shutdown file
rm -f $SAFETYSW

echo $sttm
echo "END: Playbook: [play.yml] Action: [$actn]: $(date)"
