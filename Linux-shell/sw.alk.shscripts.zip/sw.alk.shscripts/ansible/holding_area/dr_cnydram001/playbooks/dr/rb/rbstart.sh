#!/bin/bash
echo "Running on [$HOSTNAME] as [$LOGNAME]"
cd RoboRegistrar
pwd
./startRobo.sh
