ln -s ../common/ansible.cfg ansible.cfg
#ln -s ../common/appprcs_play.yml appprcs_play.yml
#ln -s ../common/appprcs_tasks.yml appprcs_tasks.yml
ln -s ../common/play.yml play.yml
ln -s ../common/tasks.yml tasks.yml
