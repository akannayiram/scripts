#!/bin/bash
# *****************
#  P R O D
#
#   S T O P   W E B   D O M A I N S
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=stop
limit_hosts=web

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

sttm="BEGIN: Playbook: [play.yml] Action: [$actn]: $(date)"
echo $sttm
ansible-playbook play.yml --limit "$limit_hosts" -e actn="$actn" | tee -a $teelog
echo $sttm
echo "END:   Playbook: [play.yml] Action: [$actn]: $(date)"
echo "Log: $teelog"
