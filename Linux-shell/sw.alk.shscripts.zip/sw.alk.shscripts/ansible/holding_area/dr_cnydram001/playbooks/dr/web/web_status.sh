#!/bin/bash
# *****************
#  D R
#
#   S T A T U S   W E B   D O M A I N S
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=status
limit_hosts=web

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

sttm="BEGIN: Playbook: [play.yml] Action: [$actn]: $(date)"
echo $sttm
ansible-playbook play.yml --limit "$limit_hosts" -e actn="$actn" | tee -a $teelog

# Parse the log file
./web_parse_logs.sh "$teelog"

echo $sttm
echo "END:   Playbook: [play.yml] Action: [$actn]: $(date)"
echo "Log: $teelog"
