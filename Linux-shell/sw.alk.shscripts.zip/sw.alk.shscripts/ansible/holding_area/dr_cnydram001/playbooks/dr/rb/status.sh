#!/bin/bash
echo "Running on [$HOSTNAME] as [$LOGNAME]"
cd RoboRegistrar
pwd
ls -lh ./PSTransPlugIn.class
