#!/bin/bash
# *****************
#  P E R F O R M A N C E
#
#   P U R G E    C A C H E
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=purge
#limit_hosts=drfsprcs
limit_hosts=drappprcs

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

./dr_exec_play.sh $actn $limit_hosts | tee -a $teelog

# Parse the log file
./apux_parse_logs.sh "$teelog"
echo "Log: $teelog"
