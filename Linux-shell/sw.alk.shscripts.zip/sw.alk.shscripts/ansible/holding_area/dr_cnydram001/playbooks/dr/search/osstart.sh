#!/bin/bash
# *****************
#  P R O D
#
#   S T A R T   S E A R C H   D O M A I N S
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=start
limit_hosts=all

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

sttm="BEGIN: Playbook: [osstart.yml] Action: [$actn]: $(date)"
echo $sttm
ansible-playbook osstart.yml | tee -a $teelog
echo $sttm
echo "END:   Playbook: [osstart.yml] Action: [$actn]: $(date)"
echo "Log: $teelog"
