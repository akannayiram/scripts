#!/bin/bash
echo "Running on [$HOSTNAME] as [$LOGNAME]"
cd bin
pwd
ls -lh ./clnaddrd_CNYCSPRD_TAF1.ini
