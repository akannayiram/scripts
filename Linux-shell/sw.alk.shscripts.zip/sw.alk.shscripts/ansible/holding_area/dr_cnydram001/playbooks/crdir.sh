#base=nonprod
#base=perf
base=prod
mkdir -p ${base}/common
mkdir -p ${base}/apux/inventory
mkdir -p ${base}/web/inventory
mkdir -p ${base}/ohs/inventory
mkdir -p ${base}/search/inventory
mkdir -p ${base}/ca/inventory
mkdir -p ${base}/rb/inventory
