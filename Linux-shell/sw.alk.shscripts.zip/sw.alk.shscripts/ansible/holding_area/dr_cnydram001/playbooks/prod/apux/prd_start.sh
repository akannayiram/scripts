#!/bin/bash
# *****************
#  P E R F O R M A N C E
#
#   S T A R T    D O M A I N S
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=start
#limit_hosts=prdihappprcs
#limit_hosts=prdappprcs
limit_hosts=prd2rptappprcs

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

./prd_exec_play.sh $actn $limit_hosts | tee -a $teelog
echo "Log: $teelog"
