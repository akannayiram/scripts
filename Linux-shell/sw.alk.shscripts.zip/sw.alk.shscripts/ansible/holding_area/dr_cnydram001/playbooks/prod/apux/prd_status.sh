#!/bin/bash
# *****************
#  P E R F O R M A N C E
#
#   S T A T U S    C H E C K
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=sstatus
#limit_hosts=prdappprcs
limit_hosts=prd2rptappprcs

#limit_hosts=finpfux301

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

./prd_exec_play.sh $actn $limit_hosts | tee -a $teelog
echo "Log: $teelog"
