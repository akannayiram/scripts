#!/bin/bash
# *****************
#  P E R F O R M A N C E
#
#   S T O P    D O M A I N S
# *****************
#set -x
LOGDIR=logs
[[ ! -d "$LOGDIR" ]] && mkdir -p $LOGDIR

actn=stop
limit_hosts=prfappprcs
#limit_hosts=finpfux301
#limit_hosts=prffsprcs
#limit_hosts=prfihappprcs

teelog=${LOGDIR}/${HOSTNAME}.${LOGNAME}.${limit_hosts}.${actn}.$(date '+%Y%m%d_%H%M%S').log

./prf_exec_play.sh $actn $limit_hosts | tee -a $teelog

# Parse the log file
./apux_parse_logs.sh "$teelog"
echo "Log: $teelog"
