#!/bin/bash
scp -pr cnynpam001:$HOME/playbooks np_cnynpam001/
scp -pr cnynpam001:$HOME/common np_cnynpam001/
