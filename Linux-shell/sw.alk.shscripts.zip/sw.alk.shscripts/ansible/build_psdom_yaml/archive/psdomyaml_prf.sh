#!/bin/bash
# ########################################
# To build PS domains in a format
#    that can be fed to Ansible playbooks
#    Format is yaml with dictionary objects
# #########################################
#  Al Kannayiram   Feb 2024
###########################################

out_yamlfile ()
{

  outfile=${outdir}/${hst}.yaml
  rm -f $outfile
#  echo "---" > $outfile
  echo "domains:" >> $outfile

}

app_hosts ()
{

  out_yamlfile

  apptmp=/tmp/apptmp$$.tmp
  rm -f $apptmp
  ps -eo comm,pid,user|grep BBL|grep -v grep > $apptmp
  while read -r line
  do
    usr=$(echo $line|awk '{print $3}')
    pidnum=$(echo $line|awk '{print $2}')
    dom=$(ps -aef |grep "$usr"|grep "$pidnum"|grep BBL|grep -v grep|awk '{print $18 }'|awk  -F"/"  '{print $7 " " $8}'|sed -e "s/ LOGS//"|sed -e "s/prcs //")
    #   - { "usr":"cnyihdm3", "dom":"CNYIHDM3", "domtype":"app" }
    echo  "  - { \"usr\":\"$usr\", \"dom\":\"$dom\", \"domtype\":\"app\" }" >> $outfile

  done < $apptmp
  rm -f $apptmp
  echo "Output file: $outfile"

}

prcs_hosts ()
{

  out_yamlfile

  prcstmp=/tmp/prcstmp$$.tmp
  rm -f $prcstmp
  ps -eo comm,pid,user|grep BBL|grep -v grep > $prcstmp
  while read -r line
  do
    usr=$(echo $line|awk '{print $3}')
    pidnum=$(echo $line|awk '{print $2}')
    dom=$(ps -aef |grep "$usr"|grep "$pidnum"|grep BBL|grep -v grep|awk '{print $18 }'|awk  -F"/"  '{print $7 " " $8}'|sed -e "s/ LOGS//"|sed -e "s/prcs //")
    #   - { "usr":"cnyihdm3", "dom":"CNYIHDM3", "domtype":"prcs" }
    echo  "  - { \"usr\":\"$usr\", \"dom\":\"$dom\", \"domtype\":\"prcs\" }"  >> $outfile

  done < $prcstmp
  rm -f $prcstmp
  echo "Output file: $outfile"

}

[[ -Z "$1" ]] && { echo "ERROR!! Input argument (np, prf, prd, or dr) is required. Aborting..."; exit; }
[[ ! "$1" == "np" && ! "$1" == "prf" && ! "$1" == "prd" && ! "$1" == "dr" && ]] && "ERROR!! Invalid input. Valid args: (np, prf, prd, or dr). Aborting..."; exit; }
tier=$1
#outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars
#outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_prf
outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_${tier}
mkdir -p $outdir

echo "Start: $(date)"
# Get hostname without domain suffix
hst=$(echo $HOSTNAME|awk -F"." '{print $1}')

# When run on PRCS hosts
[[ "$HOSTNAME" =~ npux && "$tier" == "np" ]]  && prcs_hosts
[[ "$HOSTNAME" =~ pfux && "$tier" == "prf" ]] && prcs_hosts
[[ "$HOSTNAME" =~ prux && "$tier" == "prd" ]] && prcs_hosts
[[ "$HOSTNAME" =~ rpux && "$tier" == "prd" ]] && prcs_hosts
[[ "$HOSTNAME" =~ drux && "$tier" == "dr" ]]  && prcs_hosts


# When run on APP hosts
[[ "$HOSTNAME" =~ npap && "$tier" == "np" ]]  && app_hosts
[[ "$HOSTNAME" =~ pfap && "$tier" == "prf" ]] && app_hosts
[[ "$HOSTNAME" =~ prap && "$tier" == "prd" ]] && app_hosts
[[ "$HOSTNAME" =~ rpap && "$tier" == "prd" ]] && app_hosts
[[ "$HOSTNAME" =~ drap && "$tier" == "dr" ]]  && app_hosts


