#!/bin/bash
# ########################################
# To build PS domains in a format
#    that can be fed to Ansible playbooks
#    Format is yaml with dictionary objects
# #########################################
#  Al Kannayiram   Feb 2024
###########################################

out_yamlfile ()
{

  outfile=${outdir}/${hst}.yaml
  rm -f $outfile
#  echo "---" > $outfile
  echo "domains:" >> $outfile

}

app_hosts ()
{

  out_yamlfile

  apptmp=/tmp/apptmp$$.tmp
  rm -f $apptmp
  ps -eo comm,pid,user|grep BBL|grep -v grep > $apptmp
  while read -r line
  do
    usr=$(echo $line|awk '{print $3}')
    pidnum=$(echo $line|awk '{print $2}')
    dom=$(ps -aef |grep "$usr"|grep "$pidnum"|grep BBL|grep -v grep|awk '{print $18 }'|awk  -F"/"  '{print $7 " " $8}'|sed -e "s/ LOGS//"|sed -e "s/prcs //")
    #   - { "usr":"cnyihdm3", "dom":"CNYIHDM3", "domtype":"app" }
    echo  "  - { \"usr\":\"$usr\", \"dom\":\"$dom\", \"domtype\":\"app\" }" >> $outfile

  done < $apptmp
  rm -f $apptmp
  echo "Output file: $outfile"

}

prcs_hosts ()
{

  out_yamlfile

  prcstmp=/tmp/prcstmp$$.tmp
  rm -f $prcstmp
  ps -eo comm,pid,user|grep BBL|grep -v grep > $prcstmp
  while read -r line
  do
    usr=$(echo $line|awk '{print $3}')
    pidnum=$(echo $line|awk '{print $2}')
    dom=$(ps -aef |grep "$usr"|grep "$pidnum"|grep BBL|grep -v grep|awk '{print $18 }'|awk  -F"/"  '{print $7 " " $8}'|sed -e "s/ LOGS//"|sed -e "s/prcs //")
    #   - { "usr":"cnyihdm3", "dom":"CNYIHDM3", "domtype":"prcs" }
    echo  "  - { \"usr\":\"$usr\", \"dom\":\"$dom\", \"domtype\":\"prcs\" }"  >> $outfile

  done < $prcstmp
  rm -f $prcstmp
  echo "Output file: $outfile"

}

#outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars
#outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_prf
outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_prd

echo "Start: $(date)"
# Get hostname without domain suffix
hst=$(echo $HOSTNAME|awk -F"." '{print $1}')

# When run on PRCS hosts
#[[ "$HOSTNAME" =~ npux ]] && prcs_hosts
#[[ "$HOSTNAME" =~ pfux ]] && prcs_hosts
[[ "$HOSTNAME" =~ prux || "$HOSTNAME" =~ rpux ]] && prcs_hosts


# When run on APP hosts
#[[ "$HOSTNAME" =~ npap ]] && app_hosts
#[[ "$HOSTNAME" =~ pfap ]] && app_hosts
[[ "$HOSTNAME" =~ prap || "$HOSTNAME" =~ rpap ]] && app_hosts


