#!/bin/bash
# ########################################
# To build PS domains in a format
#    that can be fed to Ansible playbooks
#    Format is yaml with dictionary objects
# #########################################
#  Al Kannayiram   Feb 2024
###########################################

out_yamlfile ()
{
#  echo "In out_yamlfile"

  [[ ! -d "$outdir" ]] && mkdir -p $outdir
  outfile=${outdir}/${hst}.yaml
  rm -f $outfile
#  echo "---" > $outfile
  echo "domains:" > $outfile

}

app_hosts ()
{
#  echo "In app_hosts"

  out_yamlfile

  apptmp=/tmp/apptmp$$.tmp
  rm -f $apptmp
  ps -eo comm,pid,user|grep BBL|grep -v grep|sort -k3,3 > $apptmp
  while read -r line
  do
    usr=$(echo $line|awk '{print $3}')
    pidnum=$(echo $line|awk '{print $2}')
    dom=$(ps -aef |grep "$usr"|grep "$pidnum"|grep BBL|grep -v grep|awk '{print $18 }'|awk  -F"/"  '{print $7 " " $8}'|sed -e "s/ LOGS//"|sed -e "s/prcs //")
    #   - { "usr":"cnyihdm3", "dom":"CNYIHDM3", "domtype":"app" }
    # echo  "  - { \"usr\":\"$usr\", \"dom\":\"$dom\", \"domtype\":\"app\" }" >> $outfile
    echo  "  - { \"usr\":\"$usr\", \"dom\":\"$dom\", \"domtype\":\"app\", \"domopt\":\"-c\" }" >> $outfile

  done < $apptmp
  rm -f $apptmp
  echo "Output file: $outfile"

}

prcs_hosts ()
{

#  echo "In prcs_hosts"
  out_yamlfile

  prcstmp=/tmp/prcstmp$$.tmp
  rm -f $prcstmp
  ps -eo comm,pid,user|grep BBL|grep -v grep|sort -k3,3 > $prcstmp
  while read -r line
  do
    usr=$(echo $line|awk '{print $3}')
    pidnum=$(echo $line|awk '{print $2}')
    dom=$(ps -aef |grep "$usr"|grep "$pidnum"|grep BBL|grep -v grep|awk '{print $18 }'|awk  -F"/"  '{print $7 " " $8}'|sed -e "s/ LOGS//"|sed -e "s/prcs //")
    #   - { "usr":"cnyihdm3", "dom":"CNYIHDM3", "domtype":"prcs" }
    # echo  "  - { \"usr\":\"$usr\", \"dom\":\"$dom\", \"domtype\":\"prcs\" }"  >> $outfile
    echo  "  - { \"usr\":\"$usr\", \"dom\":\"$dom\", \"domtype\":\"prcs\", \"domopt\":\"-p\" }"  >> $outfile

  done < $prcstmp
  rm -f $prcstmp
  echo "Output file: $outfile"

}

echo "Start: $(date)"
# Get hostname without domain suffix
hst=$(echo $HOSTNAME|awk -F"." '{print $1}')

# When run on PRCS hosts
[[ "$HOSTNAME" =~ npux ]] && { outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_np; prcs_hosts; exit; }
# Adding RTR_PRF hosts
#[[ "$HOSTNAME" =~ pfux ]] && { outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_prf; prcs_hosts; exit; }
[[ "$HOSTNAME" =~ pfux || "$HOSTNAME" =~ pfrux ]] && { outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_prf; prcs_hosts; exit; }
# Adding RPT_PRD hosts
[[ "$HOSTNAME" =~ prux || "$HOSTNAME" =~ rpux ]] && { outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_prd; prcs_hosts; exit; }


# When run on APP hosts
[[ "$HOSTNAME" =~ npap ]] && { outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_np; app_hosts; exit; }
# Adding RTR_PRF hosts
#[[ "$HOSTNAME" =~ pfap ]] && { outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_prf; app_hosts; exit; }
[[ "$HOSTNAME" =~ pfap || "$HOSTNAME" =~ pfrap ]] && { outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_prf; app_hosts; exit; }
# Adding RPT_PRD hosts
[[ "$HOSTNAME" =~ prap || "$HOSTNAME" =~ rpap ]] && { outdir=/software/akannayiram/ansible/build_psdom_yaml/host_vars_prd; app_hosts; exit; }

echo "End: $(date)"

