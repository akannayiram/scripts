#!/bin/bash
# #################################
#     Al Kannayiram
#     5/30/2024
# 
# 
# #################################

# 
[[ ! -f "$1" ]] && { echo "ERROR...Input file [$1] is missing. Aborting...."; exit; }
[[ ! -r "$1" ]] && { echo "ERROR...Cannot read input file [$1]. Aborting...."; exit; }

inpfile="$1"

# Extracted log entries
EXTLOGFILE=/tmp/alk.parsed.log.$$.tmp; rm -f $EXTLOGFILE

# Error file
ERRFILE=/tmp/alk.parsed.log.$$.tmp; rm -f $ERRFILE


grep -E -n "ERROR|BBL|MONITOR|processes" $inpfile > $EXTLOGFILE


# Initialize
stdoutfound=N; bblfound=N; montrfound=N;

while read -r line
do
# when stdoutfound=N, if not STDOUT, skip
  if [[ $stdoutfound == "N"  && ! $line =~ .*STDOUT.* ]] ; then 
     echo "ERROR..Expected STDOUT, but not found. Skipping ["$line"]...."
     echo "$line" >> $ERRFILE
     continue
  fi



done < $EXTLOGFILE


