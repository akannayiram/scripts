#!/bin/bash
inet_cnt=$(ip addr|grep secondary|awk '{print $2}'|cut -d"/" -f1|wc -l)
if [[ "$inet_cnt" -gt 0 ]] ; then
   srchstr=""
   for i in $(ip addr|grep secondary|awk '{print $2}'|cut -d"/" -f1)
   do
      #[[ ! -z $srchstr ]] && srchstr="${srchstr}|$i"
      #[[  -z $srchstr ]] && srchstr="$i"
      [[ ! -z $srchstr ]] && srchstr="${srchstr}|$i" || srchstr="$i"
   done
grep cny /etc/hosts |grep -v '#'|grep -E "$srchstr"|awk  '{print $2}'
fi
