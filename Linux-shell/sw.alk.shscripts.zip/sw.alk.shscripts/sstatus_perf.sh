#!/bin/bash
if [[ ! $HOSTNAME =~ pfap ]] || [[ ! $HOSTNAME =~ 3[012][0-9] ]] ; then
   echo "Wrong host. Run on PERF App servers"
   exit
fi
if [[ ! $USER =~ prf ]] || [[ ! $USER =~ cny ]] ; then
   echo "Wrong User $USER. Run using service account"
   exit
fi
if [[ $# -eq 0  ]] ; then
   echo "ERROR! Input Domain is requried"
   exit
fi
echo "PSADMIN: Server Status"
while true
do
psadmin -c sstatus -d $1
date
sleep 30
done
