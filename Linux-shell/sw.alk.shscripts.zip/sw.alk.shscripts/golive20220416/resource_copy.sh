#!/bin/bash -x
dt=$(date '+%Y%m%d')
cd $HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/cnyfsprd
pwd 
echo "Check if any cu* files exist"
ls -l cu* 
find . -name "cu*" -type f -exec tar -cvf /software/akannayiram/golive20220416/${HOSTNAME}.${USER}.${dt}.bkup.tar {} \;
cp -p /software/Custom/web/cnyfsprd/psftdocs/* .
# List the copied cu* files
ls -l cu*
cd webprof 
echo "Files in webprof"
ls -l 
rm -f * 
ls -l 
cd $HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war 
cp -p /software/Custom/web/cnyfsprd/favicon.ico .
echo "After copying favicon.ico"
ls -l $HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/*ico 
cd $HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/cnyfsprd 
ls -l cu_signin.css 
rm -f cu_signin.css 
cp -p /software/Custom/web/cnyfsprd/site/cu_signin.css .
echo "After copying cu_signin.css"
ls -l HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/cnyfsprd/cu_signin.css
cd $HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/cnyfsprd/images
ls -l cu_logo_cunyfirst_color.svg
rm -f cu_logo_cunyfirst_color.svg
cp -p /software/Custom/web/cnyfsprd/site/images/cu_logo_cunyfirst_color.svg .
echo "After copying cu_logo_cunyfirst_color.svg.css"
ls -l $HOME/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/cnyfsprd/images/cu_logo_cunyfirst_color.svg

