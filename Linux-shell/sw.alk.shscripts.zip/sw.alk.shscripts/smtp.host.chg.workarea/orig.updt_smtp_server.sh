#!/bin/bash -x

dttm=$(date '+%Y-%m-%d_%H%M%S')
for dom in $(find $HOME -name CNY* -type d)
do 
  echo $dom
  file=$dom/psappsrv.cfg
  [[ -f $file ]] && cp -p $file ${file}.b4.smtpchg.${dttm} && sed -i -e "/^SMTPServer/s/=.*$/=pgwnp.cuny.edu/" $file
  file=$dom/psprcs.cfg
  [[ -f $file ]] && cp -p $file ${file}.b4.smtpchg.${dttm} && sed -i -e "/^SMTPServer/s/=.*$/=pgwnp.cuny.edu/" $file
done
