#!/bin/bash -x
#sudo su - $usr -c "find $homedir/appserv/prcs -mindepth 1 -maxdepth 1 -name CNY* -type d"
#sudo su - $1 -c 'for domain in $(find /appl/psft/prd -type d -name CNY* -exec basename {} \;); do echo "Domain: $domain"; echo; psadmin -c kill -d $domain; done'

dtttm=$(date '+%Y-%m-%d_%H%M%S')
for dom in $(find $HOME -name CNY* -type d)
do 
  echo $dom
  found=n
  [[ -f $dom/psappsrv.cfg ]] && file=$dom/psappsrv.cfg && found=y
  [[ -f $dom/psprcs.cfg ]] && file=$dom/psprcs.cfg && found=y
  # Make a backup before the change
  cp -p $file ${file}.b4.smtpchg.${dttm}
#  sed -i -e "/^SMTPServer=/s/^.*$/SMTPServer=pgwnp.cuny.edu/" $file
#  sed -i -e "/^SMTPServer1=/s/^.*$/SMTPServer=pgwnp.cuny.edu/" $file
  sed -i -e "/^SMTPServer/s/=.*$/=pgwnp.cuny.edu/" $file
done
