#!/bin/bash -x
if [[ ! $HOSTNAME =~ npwl ]] ; then
   echo "Wrong host. Run on NP Web servers"
   exit
fi
#for i in `grep cnyd /etc/hosts |grep -v "#"|grep 858|awk  '{print $2}'`
for i in `grep cnyd /etc/hosts |grep -v "#"|grep 858|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c /appl/oracle/weblogic/$i/webserv/peoplesoft/bin/stopPIA.sh  ; echo "on" `cat /etc/hosts |grep $i`
done

