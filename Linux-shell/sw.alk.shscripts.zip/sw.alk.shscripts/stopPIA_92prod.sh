#!/bin/bash
#if [[ ! $HOSTNAME =~ prwl ]] ; then
if [[ ! $HOSTNAME =~ prwl && ! $HOSTNAME =~ rpwl ]] ; then
   echo "Wrong host. Run on PRD Web servers"
   exit
fi
for i in `grep cnyp /etc/hosts |grep -v "#"|grep -E "858|860"|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c /appl/oracle/weblogic/$i/webserv/peoplesoft/bin/stopPIA.sh  ; echo "on" `cat /etc/hosts |grep $i`
done
