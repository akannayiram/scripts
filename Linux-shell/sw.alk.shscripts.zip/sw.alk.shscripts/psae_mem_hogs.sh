#!/bin/bash
# ##################################################
# List the psae Memory  Usage
# History:
# Who                When      Why and What
# -----------------  --------- ------------------------
# Al Kannayiram      6/18/2021 Initial creation
#
# ##################################################

processstring=psae
echo "---------FREE MEMORY---------------"
free -m

echo " "
echo "---------PERCENTAGE USAGE---------- "
mempct=`free -m|grep "^Mem:"|awk '{print $3*100/$2}'`
swppct=`free -m|grep "^Swap:"|awk '{print $3*100/$2}'`
echo "Memory %Used: $mempct     Swap %Used: $swppct"
echo " "


#echo -e "Memory \t Login     \t PID      \t psappsrv \t inst \t Domain"
#echo -e "------ \t --------- \t -------- \t -------- \t ---- \t --------"
echo -e "Memory \t Login     \t PID      \t Process    "
echo -e "------ \t --------- \t -------- \t -----------"
#ps -eo pid,rss,comm|sort -k 2,2 -nr|head -10|grep $processstring|while read line
ps -eo pid,rss,comm,user|grep $processstring|sort -k 2,2 -nr|while read line
do
pidnum=`echo $line|awk '{print $1}'`
mem=`echo $line|awk '{print $2}'`
psname=`echo $line|awk '{print $3}'`
unixuser=`echo $line|awk '{print $4}'`
#
# ================================================================
# The objective to remove unwated text from grep output.
# Sample grep output and parsed/edited text are given below.
# Series of sed commands with regex are used to remove unneeded text
#echo -e "$mem \t $unixuser \t $pidnum \t $psname"
[[ "$psname" = "psae" ]] && echo -e "$mem \t $unixuser \t $pidnum \t $psname"
done | sort -nr -k 1,1
echo " "
