#!/bin/bash
echo " "
date
echo "Server Status"
echo "=========================="
psadmin -c sstatus -d CNYFSPR1
echo " "
date
echo "Server Stop"
echo "=========================="
psadmin -c stop -d CNYFSPR1
echo " "
date
echo "Cache Purge"
echo "=========================="
psadmin -c purge -d CNYFSPR1 -noarch
echo " "
date
echo "Server Start"
echo "=========================="
psadmin -c start -d CNYFSPR1

# Saving these lines for easy copy and paste
# /software/akannayiram/fsprd_app_recycle.sh | tee -a /tmp/$HOSTNAME.$USER.fsprd_app_recycle.$(date '+%Y%m%d_%H%M%S').log 
# cat /software/akannayiram/fsprd_app_recycle.sh | sed -e "s/PR1/AM1/"
# cat /software/akannayiram/fsprd_app_recycle.sh | sed -e "s/PR1/IM1/"

