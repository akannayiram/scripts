#!/bin/bash
#
#	Setup_Developer_NonProd_LOG_Access.sh
#
#	By Mark Daneman
#	Created: 08-DEC-2022
#	Updated: 12-DEC-2022
#
#	REQ0028371 / RITM0029787 / SCTASK0033215 / INTERNAL - Setup Developer LOG and CUSTOM access
#
#	Grant Developers add/change/delete access to LOGS and CUSTOM directories using Linux FACLs via Windows AD groups
#		PS_HOME=/appl/psft/ad1/cs920
#			PS_HOME/custom
#			PS_HOME/appserv/CNYCSAD1/LOGS
#			PS_HOME/appserv/prcs/CNYCSAD1/LOGS
#
#	PS_HOME for each app and psunx server will be exported via NFS to SFTP server cnysftpxdev92.cf.cuny.edu (ft92npux050)
#	Developers will login to SFTP server and access the LOG and CUSTOM directories mounted at
#		/sftp/servers/<servername>
#		i.e.
#			/sftp/servers/cs92npap050/ad1/cs920/custom
#			/sftp/servers/cs92npap050/ad1/cs920/appserv/CNYCSAD1/LOGS
#			/sftp/servers/cs92npux050/ad1/cs920/custom
#			/sftp/servers/cs92npux050/ad1/cs920/appserv/prcs/CNYCSAD1/LOGS
#
#	Access will be in non-prod by pillar: CS, FS, HC, and IH
#		Access will be further defined by AD group with non-prod DM2 and PST as a separate group
#		No access will be granted to
#			RPT - Reporting
#			PR2 - Performance
#			PRD - Production
#			DR - Disaster Recovery
#
#	Windows AD groups and users setup on dccf01.cf.cuny.edu
#		pshome_cs - Grants developers add/delete/change access to non-prod LOG and CUSTOM directories except for DM2 and PST
#		pshome_fs - Grants developers add/delete/change access to non-prod LOG and CUSTOM directories except for DM2 and PST
#		pshome_hc - Grants developers add/delete/change access to non-prod LOG and CUSTOM directories except for DM2 and PST
#		pshome_ih - Grants developers add/delete/change access to non-prod LOG and CUSTOM directories except for DM2 and PST
#		pshome_cs_dm2_pst - Grants developers add/delete/change access to LOG and CUSTOM directories for DM2 and PST
#		pshome_fs_dm2_pst - Grants developers add/delete/change access to LOG and CUSTOM directories for DM2 and PST
#		pshome_hc_dm2_pst - Grants developers add/delete/change access to LOG and CUSTOM directories for DM2 and PST
#		pshome_ih_dm2_pst - Grants developers add/delete/change access to LOG and CUSTOM directories for DM2 and PST
#
#	Script files
#		1 - Setup_Developer_NonProd_LOG_Access.sh - Setup FACLs and NFS exports on non-prod AA92npap05N servers
#		2 - Setup_Developer_SFTP_Server_mounts.sh - Setup NFS mounts on cnysftpxdev92.cf.cuny.edu (ft92npux050)
#		3 - Add_Developer_SFTP_Access.ps1 - Add developers to Windows AD roles on dccf01.cf.cuny.edu
#		Tools
#		T - List_Developer_NonProd_LOG_CUSTOM_Directories.sh - List log and custom directories on cnysftpxdev92
#		T - Dismount_Developer_SFTP_Server_mounts.sh - Dismount NFS mounts on cnysftpxdev92.cf.cuny.edu (ft92npux050)
#
echo -e "\nGrant Developers add/change/delete access to LOGS and CUSTOM directories"
echo -e "    and the developer AD group needed to update them\n"

#	
#	Only run this script on these non-prod servers
#
SERVERLIST="cs92npap050, cs92npap051, cs92npux050, cs92npux051,\
 fs92npap050, fs92npap051, fs92npux050, fs92npux051,\
 hc92npap050, hc92npap051, hc92npux050, hc92npux051,\
 ih92npap050, ih92npap051, ih92npux050, ih92npux051,"

if [[ "$SERVERLIST" != *"${HOSTNAME%%.*},"* ]]
then
	echo "ERROR: This script should not be run on ${HOSTNAME%%.*}"
	exit
fi

UHOST=${HOSTNAME^^}
LHOST=${HOSTNAME,,}

#
#	Parameter 1 can be used to update a single instance on the server, i.e. ad1
#
if [ "$1" != "" ]
then
    SDOMAIN=${1,,}
        if [ ${#SDOMAIN} -ne 3 ] || [ ! -d "/appl/psft/$SDOMAIN" ]
        then
            echo "ERROR: Invalid instance $SDOMAIN"
            exit
        fi
        #
        #	Make sure user is the owner of the instance
        #
        if [ $USER != "cny${LHOST:0:2}$SDOMAIN" ]
        then
            echo "ERROR: Instance $SDOMAIN cannot be updated by $USER"
            exit
        fi
else
        if [ $USER != "root" ]
        then
            echo "ERROR: Only root can update all instances"
            echo "	To update a single instance, login as the correct user and specify the instance, i.e."
            echo "	su - cnyhcad2"
            echo "	bash /psft/team_server/Setup_Developer_NonProd_LOG_Access.sh ad2"
            exit
        fi
fi

#
#	For a single instance, skip root setup
#
if [ "$SDOMAIN" = "" ]
then
    #
    #	Remove circular symbolic link
    #
    if [ -d "/appl/psft/psft" ]
    then
        echo "Remove circular symbolic link /appl/psft/psft"
        rm -f /appl/psft/psft
    fi
    
    #
    #	Find LOG and custom directories
    #	and set desired developer FACLs
    #
    
    #	Remove default FACLs from top level directories
    echo "Remove FACLs on /appl"
    setfacl --remove-default --no-mask /appl
    setfacl --remove-default --no-mask /appl/psft
    #	Remove all existng FACLs top level directories
    echo "Remove FACLs on /appl/psft"
    setfacl --remove-all --no-mask /appl
    setfacl --remove-all --no-mask /appl/psft

    #
    #	Set permissions
    #
    echo "Set permissions on /appl and /appl/psft"
    chmod 775 /appl
    chmod 775 /appl/psft

fi

#
#	Verify groups exist
#
GRPNONPRD="pshome_${LHOST:0:2}"
GRPDM2PST="pshome_${LHOST:0:2}_dm2_pst"

if [ "`getent group $GRPNONPRD`" = "" ]
then
    echo "ERROR: AD Group $GRPNONPRD does not exist!"
    echo ""
    echo "Try restarting and clearing sssd AD/LDAP service and cache"
    echo "service sssd stop ; rm -rf /var/lib/sss/db/* ; service sssd start"
    echo ""
    exit
fi

if [ "`getent group $GRPDM2PST`" = "" ]
then
    echo "ERROR: AD Group $GRPDM2PST does not exist!"
    echo ""
    echo "Try restarting and clearing sssd AD/LDAP service and cache"
    echo "service sssd stop ; rm -rf /var/lib/sss/db/* ; service sssd start"
    echo ""
    exit
fi

for DIR in `find /appl/psft/ -mindepth 1 -maxdepth 1 -type d`
do

    #
    #   Skip /appl/psft/psft
    #
    if [ "$DIR" = "/appl/psft/psft" ]
    then
       echo -e "\nSkip Link: $DIR"
       continue
    fi

    #
    #	For single instance, skip all others
    #
    if [ "$SDOMAIN" != "" ]
    then
        if [ "$DIR" != "/appl/psft/$SDOMAIN" ]
        then
            continue
        fi
    fi
               
    UDIR=${DIR^^}
    PDOMAIN=${UDIR: -3}
    CUSTDIR="$DIR/${LHOST:0:2}920/custom"
    APPLOGDIR="$DIR/${LHOST:0:2}920/appserv/CNY${UHOST:0:2}$PDOMAIN/LOGS"
    PRCSLOGDIR="$DIR/${LHOST:0:2}920/appserv/prcs/CNY${UHOST:0:2}$PDOMAIN/LOGS"
        
    GRPNONPRD="pshome_${LHOST:0:2}"
    GRPDM2PST="pshome_${LHOST:0:2}_dm2_pst"

    #
    #   Remove any existing FACLs
    #	And update permissions
    #
    if [ -d "$DIR" ]
    then
         echo -e "\nRemove FACLs on $DIR"
         #	Remove default FACLs
         setfacl --recursive --remove-default --no-mask $DIR
         #	Remove all existng FACLs
         setfacl --recursive --remove-all --no-mask $DIR
         
         #	Set permissions
         echo -e "Update permissions on $DIR and $DIR/*920"
         chmod 775 $DIR
         chmod 775 $DIR/*920

    fi  

    #
    #   Do not grant access to 
    #       RPT - Reporting
    #       PR2 - Performance
    #       PRD - Production
    #   Skip to next directory
    #
    if [ "$PDOMAIN" = "RPT" ] || [ "$PDOMAIN" = "PR2" ] || [ "$PDOMAIN" = "PRD" ]
    then
        echo "  Skip RPT/PR2/PRD: $DIR"
        continue
    fi  

    #
    #   DM2 and PST have special group access
    #        
    if [ "$PDOMAIN" = "DM2" ] || [ "$PDOMAIN" = "PST" ]
    then
        DEVGRP=$GRPDM2PST
    else
        DEVGRP=$GRPNONPRD
    fi  
        
    echo -e "  Developer Groups: $DEVGRP"

    UFLAG="false"
    
    #
    #	For pshome FACLs to work, group access must be Write
    #	Using --modify mask::rwx which is the same as chmod 775
    #
        
    if [ -d "$CUSTDIR" ]
    then
         echo "  Set FACLs for $CUSTDIR"
         UFLAG="true"
         #	Set default FACLs on directories for all files created in the future
         setfacl --recursive --default --modify group:$DEVGRP:rwx --modify mask::rwx $CUSTDIR
         #	Set FACLs on existing directories and files
         setfacl --recursive --modify group:$DEVGRP:rwx --modify mask::rwx $CUSTDIR
    fi  
    if [ -d "$APPLOGDIR" ]
    then
         echo "  Set FACLs for $APPLOGDIR"
         UFLAG="true"
         #	Set default FACLs on directories for all files created in the future
         setfacl --recursive --default --modify group:$DEVGRP:rwx --modify mask::rwx $APPLOGDIR
         #	Set FACLs on existing directories and files
         setfacl --recursive --modify group:$DEVGRP:rwx --modify mask::rwx $APPLOGDIR
    fi  
    if [ -d "$PRCSLOGDIR" ]
    then
         UFLAG="true"
         echo "  Set FACLs for $PRCSLOGDIR"
         #	Set default FACLs on directories for all files created in the future
         setfacl --recursive --default --modify group:$DEVGRP:rwx --modify mask::rwx $PRCSLOGDIR
         #	Set FACLs on existing directories and files
         setfacl --recursive --modify group:$DEVGRP:rwx --modify mask::rwx $PRCSLOGDIR
    fi

    if [ "$UFLAG" = "false" ]
    then
         echo "  No LOG or CUSTOM directories found"
    fi  

done

#
#	For a single instance, skip root setup
#
if [ "$SDOMAIN" = "" ]
then
    #
    #	Update /etc/exports
    #
    echo -e "\nAdding the following to /etc/exports"
    echo "    #       Developer LOGS and custom access - RITM0029787"
    echo -e "    /appl/psft   cnysftpxdev92.cf.cuny.edu(rw,sync)"
    
    sed -i '/RITM0029787\|cnysftpxdev92/d' /etc/exports
    echo "#       Developer LOGS and custom access - RITM0029787" >> /etc/exports
    echo -e "/appl/psft   cnysftpxdev92.cf.cuny.edu(rw,sync)"  >> /etc/exports
    
    #
    #	Update exports and check it is exported
    #
    echo -e "\nRunning exportfs -ra\n  and showmount -e 127.0.0.1"
    exportfs -ra
    showmount -e 127.0.0.1
    
    #
    #	To fix error: clnt_create: RPC: Program not registered
    #
    echo -e "\nIf there is an error on the export, run the following"
    echo "    systemctl status nfs-server.service"
    echo "    systemctl enable nfs-server.service"
    echo "    systemctl start nfs-server.service"
fi

#
#
#
echo -e "\nCOMPLETED: Setup_Developer_NonProd_LOG_Access.sh\n"

