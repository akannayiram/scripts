hosts=/home/akannayiram/servers/92dr/dr_app_cs92_servers.txt
outdir=/software/akannayiram/jdk.jre.patchlogs/dr202402/jre
dt=$(date '+%Y%m%d')

while read line
do
#  bolt command run "echo $HOSTNAME; ls -l /tmp/${HOSTNAME}*${dt}*log; 
   echo "scp -p /tmp/{line}*${dt}*log $outdir/"
done < $hosts
