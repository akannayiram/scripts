echo "Before"
ls -ld jre*
mv jre jre.b4.symlink
ln -s /appl/oracle/jre/jre1.8_64bit/ jre
echo "After creating symlink"
ls -ld jre*
