echo ""
echo "=========================================================="
echo "BEGIN Hostname: $HOSTNAME"   Login: $USER
echo "=========================================================="
echo "Executing [find /appl/oracle -name log4j*.jar -exec ls -l {} \;]"
find /appl/oracle -name log4j*.jar -exec ls -l {} \;
echo "Removing JndiLookup.class"
find /appl/oracle -name log4j*.jar -exec zip -q -d {} org/apache/logging/log4j/core/lookup/JndiLookup.class \;
echo "Checking if JndiLookup.class exists"
find /appl/oracle -name log4j*.jar -exec zip -q -d {} org/apache/logging/log4j/core/lookup/JndiLookup.class \;
echo "=========================================================="
echo "END Hostname: $HOSTNAME"   Login: $USER
echo "=========================================================="
echo ""
