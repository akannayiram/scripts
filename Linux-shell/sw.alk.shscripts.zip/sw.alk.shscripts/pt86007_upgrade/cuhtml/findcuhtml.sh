#!/bin/bash
find . -name "cu_cookiesrequired.html" -type f
find . -name "cu_exception.html" -type f
find . -name "cu_expire.html" -type f
find . -name "cu_expire_oam.html" -type f
find . -name "cu_signin.html" -type f
find . -name "cu_signintrace.html" -type f
find . -name "cu_signout.html" -type f
find . -name "cu_signout_oam.html" -type f
