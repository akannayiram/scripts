#!/bin/bash
cp -p cnyfspst/cu_cookiesrequired.html cnyfspdv/
cp -p cnyfspst/cu_exception.html cnyfspdv/
cp -p cnyfspst/cu_expire.html cnyfspdv/
cp -p cnyfspst/cu_signin.html cnyfspdv/
cp -p cnyfspst/cu_signintrace.html cnyfspdv/
cp -p cnyfspst/cu_signout.html cnyfspdv/
#cp -p cnyfspst/cu_signout_oam.html cnyfspdv/
#cp -p cnyfspst/cu_expire_oam.html cnyfspdv/
