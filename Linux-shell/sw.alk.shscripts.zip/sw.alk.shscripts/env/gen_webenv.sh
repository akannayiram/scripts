#!/bin/bash
#set -x
TMP=$HOSTNAME.web.cmds
rm -f $TMP
for usr in `grep cny /etc/hosts |grep 858|awk  '{print $2}'`
do
  echo "User: $usr"
cat >> $TMP <<EOF
echo "================================="
echo "   user: $usr"
echo "================================="
sudo su - $usr -c 'grep "JAVA_OPTIONS_LINUX=" /appl/oracle/weblogic/$usr/webserv/peoplesoft/bin/setEnv.sh|grep -v "#"'
SITES=\$(sudo su - $usr -c 'ls -d /appl/oracle/weblogic/$usr/webserv/peoplesoft/applications/peoplesoft/PORTAL.war/WEB-INF/psftdocs/*')
for i in \`echo "\$SITES"\`
do
 basename \$i
done
EOF

done
. ./$TMP
ps ax o user:16,pid,pcpu,pmem,vsz,rss,stat,start_time,time,cmd|grep java|grep -v grep
