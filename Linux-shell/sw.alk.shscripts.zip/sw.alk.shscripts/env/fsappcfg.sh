CFG=fs.psappsrv.cfg.files
rm -f $CFG 
cat > $CFG <<EOF
/appl/psft/ug2/fs920/appserv/CNYFSUG2/psappsrv.cfg
/appl/psft/ug1/fs920/appserv/CNYFSUG1/psappsrv.cfg
/appl/psft/rpu/fs920/appserv/CNYFSRPU/psappsrv.cfg
/appl/psft/dm2/fs920/appserv/CNYFSDM2/psappsrv.cfg
EOF
   #GREPSTR="^Min\sI|^Domain\sI|^\[PSAPPSRV|^\[PSQRYSRV|^\[PSBRKHND_dflt"
   GREPSTR="^\[Work|^\[JOLT|^Domain\sI|^\[PSAPPSRV|^\[PSQRYSRV|^\[PSBRKHND_dflt"

while read -r APPCFG
do
  echo " "
  echo " "
  echo "Starting $APPCFG"
  echo " "
  #egrep -n -A 2 -B 3 "$GREPSTR" $APPCFG 2>&1
  egrep -n -A 10 "$GREPSTR" $APPCFG 2>&1|grep -v ";"
done  < $CFG
