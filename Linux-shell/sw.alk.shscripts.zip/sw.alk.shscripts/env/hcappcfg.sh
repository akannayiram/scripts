CFG=hc.psappsrv.cfg.files
rm -f $CFG 
cat > $CFG <<EOF
/appl/psft/ug2/hc920/appserv/CNYHCUG2/psappsrv.cfg
/appl/psft/ug1/hc920/appserv/CNYHCUG1/psappsrv.cfg
/appl/psft/rpu/hc920/appserv/CNYHCRPU/psappsrv.cfg
/appl/psft/dm2/hc920/appserv/CNYHCDM2/psappsrv.cfg
EOF
   #GREPSTR="^Min\sI|^Domain\sI|^\[PSAPPSRV|^\[PSQRYSRV|^\[PSBRKHND_dflt"
   GREPSTR="^\[Work|^\[JOLT|^Domain\sI|^\[PSAPPSRV|^\[PSQRYSRV|^\[PSBRKHND_dflt"

while read -r APPCFG
do
  echo " "
  echo " "
  echo "Starting $APPCFG"
  echo " "
  #egrep -n -A 2 -B 3 "$GREPSTR" $APPCFG 2>&1
  egrep -n -A 10 "$GREPSTR" $APPCFG 2>&1|grep -v ";"
done  < $CFG
