# find domain cfg files
APPCFG=psappsrv.cfg
#find /appl/psft -name $APPCFG -type f 2>&1|grep -v denied|grep -v Archive
find /appl/psft -name $APPCFG -type f |grep -v denied|grep -v Archive
PRCSCFG=psprcs.cfg
#find /appl/psft -name $PRCSCFG -type f 2>&1|grep -v denied|grep -v Archive
find /appl/psft -name $PRCSCFG -type f |grep -v denied|grep -v Archive
