#!/bin/bash
#set -x
for usr in `grep cny /etc/hosts |grep 858|awk  '{print $2}'`
do
  echo "User: $usr"
  CFG=/appl/oracle/weblogic/$usr/webserv/peoplesoft/PORTAL.war/WEB-INF/psftdocs/configuration.properties
  sudo su $usr -c grep "^psserver" $CFG 
done

