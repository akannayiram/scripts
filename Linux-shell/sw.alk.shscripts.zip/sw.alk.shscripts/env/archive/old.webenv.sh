#!/bin/bash
#set -x
for usr in `grep cny /etc/hosts |grep 858|awk  '{print $2}'`
do
  echo "User: $usr"
  #sudo su - $usr -c /appl/oracle/weblogic/$usr/webserv/peoplesoft/bin/startPIA.sh  ; echo "on" `cat /etc/hosts |grep $usr`
  ps -aef|grep java|grep $usr|grep -v grep
  grep OPTION /appl/oracle/weblogic/$usr/webserv/peoplesoft/bin/setEnv.sh
  ls -l /appl/oracle/weblogic/$usr/webserv/peoplesoft/PORTAL.war/WEB-INF/psftdocs
done

