#!/bin/bash

function build_app_domains_hosted
{
cat > $TMPFILE <<EOF
cnyfsug1:CNYFSUG1
cnyfsrpu:CNYFSRPU
cnyfsug2:CNYFSUG2
cnyfsdm2:CNYFSDM2
EOF

}

if [[ ! $HOSTNAME =~ npap || ! $HOSTNAME =~ fs92 ]] ; then
   echo "Wrong host. Run on NP App servers"
   exit
fi

TMPFILE=/tmp/appdomains$$.txt

build_app_domains_hosted


while read -r line
do
 usr=`echo $line|cut -d":" -f1`
 dom=`echo $line|cut -d":" -f2`
 echo "Processing User: $usr  Domain: $dom  (Input line: $line)"
sudo su - $usr -c "psadmin -c stop -d $dom"
done < $TMPFILE

rm -f $TMPFILE
