#!/bin/bash

function build_app_domains_hosted
{
cat > $TMPFILE <<EOF
cnyhcrpu:CNYHCRPU
cnyhcug1:CNYHCUG1
cnyhcug2:CNYHCUG2
EOF
#cnyhcdm2:CNYHCDM2

}

if [[ $# -eq 0 ]] ; then
   echo "Missing parameter. Valid params: start, stop, status"
   exit
fi
if [[ "$1" = "start" ||  "$1" = "stop" ||  "$1" = "status" ]] ; then
   :
else
   echo "Wrong parameter. Valid params: start, stop, status"
   exit
fi

if [[ "$1" = "status" ]] ; then
   action="sstatus"
else
   action=$1
fi

if [[ ! $HOSTNAME =~ npap || ! $HOSTNAME =~ hc92 ]] ; then
   echo "Wrong host. Run on NP App servers"
   exit
fi

TMPFILE=/tmp/appdomains$$.txt

build_app_domains_hosted


while read -r line
do
 usr=`echo $line|cut -d":" -f1`
 dom=`echo $line|cut -d":" -f2`
 echo "Processing User: $usr  Domain: $dom  (Input line: $line)"
sudo su - $usr -c "psadmin -c $action -d $dom"
done < $TMPFILE

rm -f $TMPFILE
