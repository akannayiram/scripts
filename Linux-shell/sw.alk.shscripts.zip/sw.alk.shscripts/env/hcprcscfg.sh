CFG=hc.psprcs.cfg.files
rm -f $CFG 
cat > $CFG <<EOF
/appl/psft/ug2/hc920/appserv/prcs/CNYHCUG2/psprcs.cfg
/appl/psft/ug1/hc920/appserv/prcs/CNYHCUG1/psprcs.cfg
/appl/psft/rpu/hc920/appserv/prcs/CNYHCRPU/psprcs.cfg
/appl/psft/dm2/hc920/appserv/prcs/CNYHCDM2/psprcs.cfg
EOF
   #GREPSTR="^Min\sI|^Domain\sI|^\[PSAPPSRV|^\[PSQRYSRV|^\[PSBRKHND_dflt"
   #GREPSTR="^\[Work|^\[JOLT|^Domain\sI|^\[PSAPPSRV|^\[PSQRYSRV|^\[PSBRKHND_dflt"
   GREPSTR="^DBName|^PrcsServerName"

while read -r APPCFG
do
  echo " "
  echo " "
  echo "Starting $APPCFG"
  echo " "
  #egrep -n -A 2 -B 3 "$GREPSTR" $APPCFG 2>&1
  egrep -n  "$GREPSTR" $APPCFG 2>&1|grep -v ";"
done  < $CFG
