#!/bin/bash
if [[ ! $HOSTNAME =~ pfwl ]] || [[ ! $HOSTNAME =~ 3[012][0-9] ]] ; then
   echo "Wrong host. Run on PERF Web servers"
   exit
fi
#if [[ ! $USER =~ prf ]] || [[ ! $USER =~ cny ]] ; then
#   echo "Wrong User $USER. Run using service account"
if [[ $USER =~ 85 ]] && [[ $USER =~ cny ]] ; then
   echo "Wrong User $USER. Run using your login and not service account"
   exit
fi
if [[ ! $HOSTNAME =~ ihpfwl ]] ; then
   echo "Wrong host. Run on PERF IH Web servers"
   exit
fi
echo "configurtion.properties: pssever parameter"
for i in `grep cnyp /etc/hosts |grep 858|awk  '{print $2}'`
do
sudo su - $i -c "find /appl/oracle/weblogic/$i -name configuration.properties -type f|xargs grep "^psserver""
done
