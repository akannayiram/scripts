#!/bin/bash
# ############################
# 
# check psserver entry in Web config
# 
# Al Kannayiram  March 2025
# 
# ############################
#set -x
hst=${HOSTNAME%%.*}
#pillar=${HOSTNAME:0:2}
#tmpfile=/tmp/alk.${hst}.tmpfile;rm -f /tmp/alk.${hst}.tmpfile
#echo $tmpfile
#tmpfile=/tmp/alk/alk.tmp

[[ ${LOGNAME} =~ cny.*z ]] && { echo "Skipping ${LOGNAME}" ; echo "*******************************" ; exit; }

while read -r cfgfile 
do

  if [[ -f $cfgfile ]] ; then
     # extract site name 
     sitenm=$(echo $cfgfile|sed -e "s#^.*psftdocs/##"|sed -e "s#/configuration.properties##")
#     echo "${LOGNAME}@${hst} Site: ${sitenm}"
#     echo "Config: $cfgfile on ${LOGNAME}@${hst}"
#     grep "^psserver" $cfgfile
     pssrv=$(grep "^psserver" $cfgfile)
#     echo "${LOGNAME}@${hst} [${sitenm}]: $pssrv"
     echo "${hst}: [${LOGNAME}] [${sitenm}]: $pssrv"
#     echo " "
#     echo " "
#     echo " "  | tee -a $tmpfile
#     echo " "  | tee -a $tmpfile
  else
     echo "ERROR! $cfgfile does not exist on ${HOSTNAME} for ${LOGNAME}"
  fi 
  
#echo "*******************************"
done < <(find . -path */psftdocs/cny*/configuration.properties -type f -print ) 
#echo "###############################"
echo "*******************************"
