#!/bin/bash
#if [[ ! $HOSTNAME =~ prwl  || ! "$HOSTNAME" =~ *10[1-9] ]] ; then
#   echo "Wrong host. Run on PROD Web servers"
if [[ ! $HOSTNAME =~ [np|pf|pr]wl ]] ; then
   echo "Wrong host. Run on PROD Web servers"
   exit
fi

hst="${HOSTNAME%%.*}"
mkdir -p /tmp/alk;tmpfile=/tmp/alk/alk.${hst}.tmp;rm -f $tmpfile
touch $tmpfile;chmod 666 $tmpfile

scriptdir=/software/akannayiram/psadm_1time_scripts_fixes/get_psserver_prd_202503

#echo "###############################"
dttm=$(date '+%Y-%m-%d %H:%M:%S')  
echo "*******************************"   | tee -a $tmpfile
echo "BEGIN: $dttm   Host: ${hst}"       | tee -a $tmpfile
echo "*******************************"   | tee -a $tmpfile
#for i in `grep cnyd /etc/hosts |grep -v "#"|grep 86019|awk  '{print $2}'|sed -e "s/\r//"`
for i in `grep cnyd /etc/hosts |grep -v "#"|grep 8601|awk  '{print $2}'|sed -e "s/\r//"`
do
sudo su - $i -c ${scriptdir}/web_grep_psserver.sh
done | tee -a $tmpfile

dttm=$(date '+%Y-%m-%d %H:%M:%S')
echo "END: $dttm   Host: ${HOSTNAME}"   | tee -a $tmpfile
echo "*******************************"   | tee -a $tmpfile
echo " "   | tee -a $tmpfile
#cat $tmpfile
echo "Log: $tmpfile"
