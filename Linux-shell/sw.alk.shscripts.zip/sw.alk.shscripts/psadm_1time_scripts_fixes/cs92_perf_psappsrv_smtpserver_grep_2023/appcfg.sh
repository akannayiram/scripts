#!/bin/bash -x
# Find the app domain directory 
if [[ ! $HOSTNAME =~ csspfap3 ]] || [[ ! $HOSTNAME =~ 3[0123][0-9] ]] ; then
   echo "Wrong host. Run on PERF App servers"
   exit
fi

hostnm=`echo $HOSTNAME|cut -d"." -f1`
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $hostnm    User: $USER "
echo "=========================================================="
date

dttm=`date '+%Y-%m-%d %H:%M:%S'`
dttmtxt=`date '+%Y-%m-%d_%H%M%S'`
LOGDIR=/software/akannayiram/cs92_perf_psappsrv_smtp_trace/perfsedlogs
logfile=$LOGDIR/${HOSTNAME}.${USER}.psappsrv_cfg.${dttmtxt}.txt
for domdir in `find $HOME -name "CNYCS*" -type d`
do 
  psappsrv=`find $domdir -maxdepth 1 -name psappsrv.cfg`
  echo "[$dttm]:: Before making the change" >> $logfile
  echo "[$dttm]:: $HOSTNAME [$psappsrv]" >> $logfile
  egrep "^DBName=|^SMTPTrace=" $psappsrv >> $logfile
  #sed -i -e "s/^SMTPTrace=0/SMTPTrace=1/" $psappsrv
  #echo "[$dttm]:: After making the change" >> $logfile
  #egrep "^DBName=|^SMTPTrace=" $psappsrv >> $logfile
  
done

echo ""
echo "=========================================================="
echo "END Hostname: $hostnm    User: $USER "
echo "=========================================================="
echo ""

