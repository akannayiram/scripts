#!/bin/bash
# Find the app domain directory 
if [[ ! $HOSTNAME =~ csspfap3 ]] || [[ ! $HOSTNAME =~ 3[012][0-9] ]] ; then
   echo "Wrong host. Run on PERF App servers"
   exit
fi

dttm=`date '+%Y-%m-%d %H:%M:%S'`
LOGDIR=/software/akannayiram/cs92_perf_psappsrv_smtp_trace/perfsedlogs
logfile=$LOGDIR/${HOSTNAME}.${USER}.pstuxcfg_list.txt
for domdir in `find $HOME -name "CNYCS*" -type d`
do 
  pstuxcfg=`find $domdir -maxdepth 1 -name PSTUXCFG -type f -exec ls -l {} \;`
  echo "[$dttm]:: $HOSTNAME [$pstuxcfg]"
  echo "[$dttm]:: $HOSTNAME [$pstuxcfg]" >> $logfile
done
