#!/bin/bash -x
# Find the app domain directory 
if [[ ! $HOSTNAME =~ csspfap3 ]] || [[ ! $HOSTNAME =~ 3[012][0-9] ]] ; then
   echo "Wrong host. Run on PERF App servers"
   exit
fi

hostnm=`echo $HOSTNAME|cut -d"." -f1`
echo ""
echo "=========================================================="
echo "BEGIN Hostname: $hostnm    User: $USER "
echo "=========================================================="
date

dttm=`date '+%Y-%m-%d %H:%M:%S'`
dt=`date '+%Y-%m-%d'`
LOGDIR=/software/akannayiram/cs92_perf_psappsrv_smtp_trace/perfsedlogs
logfile=$LOGDIR/${HOSTNAME}.${USER}.psappsrv_cfg.txt
for domdir in `find $HOME -name "CNYCS*" -type d`
do 
  psappsrv=`find $domdir -maxdepth 1 -name psappsrv.cfg`
  bkupfile=${psappsrv}.bkup.$dt
  cp -p $psappsrv $bkupfile
  echo "[$dttm]:: Copied [$psappsrv] to [$bkupfile]" >> $logfile
  echo "[$dttm]:: Before making the change" >> $logfile
  egrep "^DBName=|^SMTPServer=|^SMTPServer1=" $psappsrv >> $logfile
  sed -i -e "s/DBName=CNYCSPR2/DBName=CNYCSPR1/" $psappsrv
  echo "[$dttm]:: After making the change" >> $logfile
  egrep "^DBName=|^SMTPServer=|^SMTPServer1=" $psappsrv >> $logfile
done

echo ""
echo "=========================================================="
echo "END Hostname: $hostnm    User: $USER "
echo "=========================================================="
echo ""

