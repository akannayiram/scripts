#!/bin/bash
[[ -z $1 ]] && { echo "Pass env abbreviation"; exit; }
envn=$1
tmpdir=/tmp/old.poi.${envn}
mkdir $tmpdir
echo "====================="
echo "Before moving: $tmpdir"
date
ls -lh $tmpdir/

echo "====================="
echo "Before: Contents of $PS_HOME/class"
pwd
cd $PS_HOME/class
ls -lh
mv commons-collections4-4.1.jar $tmpdir/
mv poi-3.17.jar $tmpdir/
mv poi-excelant-3.17.jar $tmpdir/
mv poi-ooxml-3.17.jar $tmpdir/
mv poi-ooxml-schemas-3.17.jar $tmpdir/
mv xalan_2_7_0.jar $tmpdir/
mv xmlbeans-2.6.0.jar $tmpdir/
echo "====================="
echo "After moving: $tmpdir"
ls -lh $tmpdir/

echo "====================="
echo "After: Contents of $PS_HOME/class"
ls -lh
