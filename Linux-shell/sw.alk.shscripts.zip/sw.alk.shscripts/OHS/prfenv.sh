#!/bin/bash
# ########################################
# al kannayiram, feb 2025
#    Handy env variables and aliases
# ########################################
# P E R F 
# ########################################
# 

# These environmental variables are already predefined and sourced/exported
# DOMAIN_HOME
# PROXY_LOGS
# INSTANCE
# PROXY_INSTANCE
# 
# Foe example, on prf04:
# DOMAIN_HOME=/appl/oracle/middleware/user_projects/domains/ohs2
# PROXY_LOGS=/appl/oracle/middleware/user_projects/domains/ohs2/servers/ohs1/logs
# INSTANCE=ohs1
# PROXY_INSTANCE=/appl/oracle/middleware/user_projects/domains/ohs2/config/fmwconfig/components/OHS/instances/ohs1
# 


# Config files are stored in: $PROXY_INSTANCE/moduleconf

# For ohs92prf01, ohs92prf02, ohs92prf03
# (except for ohs92prf04)
DOMAIN_HOME=/appl/oracle/middleware/user_projects/domains/ohs12214_domain















