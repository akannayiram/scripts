#!/bin/bash 
if [[ ! $HOSTNAME =~ pfwl ]] ; then
   echo "Wrong host. Run on PERF Web servers"
   exit
fi
TMP=/tmp/alk$$.pids
rm -f $TMP
ps -ae -o comm,pid,user|grep cnyp|grep 858|grep java|grep -v grep|sort -k 3,3 > $TMP
while read i
do
echo "Processing $i"
usr=`echo $i|awk '{print $3}'`
pid=`echo $i|awk '{print $2}'`
echo "Usr: [$usr]  pid: [$pid]"
sudo su - $usr -c  "kill -9 $pid"
done < $TMP
