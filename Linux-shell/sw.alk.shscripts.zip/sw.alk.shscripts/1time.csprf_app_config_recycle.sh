#!/bin/bash
echo " "
date
echo "Server Status"
echo "=========================="
psadmin -c sstatus -d CNYCSPR1
echo " "
date
echo "Server Stop"
echo "=========================="
psadmin -c stop -d CNYCSPR1
echo " "
date
echo "Cache Purge"
echo "=========================="
psadmin -c purge -d CNYCSPR1 -noarch
echo " "
date
echo "Configure "
echo "=========================="
#psadmin -c configure -d CNYCSPR1 -cfg_from_file /appl/psft/cfg/cnycsprf/appserv/CNYCSPR1/psappsrv.cfg
psadmin -c configure -d CNYCSPR1 
echo " "
date
echo "Server Start"
echo "=========================="
psadmin -c start -d CNYCSPR1

# Saving these lines for easy copy and paste
# export mydir=/software/akannayiram/scripts_adhoc/1timeappcfg/perf_appcfg_reconfig
# export logdir=$mydir/prflogs
# ${mydir}/1time.csprf_app_config_recycle.sh | tee -a ${logdir}/${HOSTNAME}.$(logname).${LOGNAME}.csprf_app_reconfig.$(date '+%Y%m%d_%H%M%S').log 

