ls -ld /appl/psft/cny/prd/bpl/datafiles/interfaces/CS/interfacein/i1445_ELM_User_Sync
ls -ld /appl/psft/cny/prd/bpl/datafiles/interfaces/CS/interfacein/i1445_ELM_User_Sync/data
ls -ld /appl/psft/cny/prd/bpl/datafiles/interfaces/CS/interfacein/i1445_ELM_User_Sync/archive
ls -ld /appl/psft/cny/prd/bpl/datafiles/interfaces/CS/interfacein/i1445_ELM_User_Sync/error
ls -ld /appl/psft/cny/prd/bpl/datafiles/interfaces/CS/interfaceout/i1445_ELM_Sec_File
ls -ld /appl/psft/cny/prd/bpl/datafiles/interfaces/CS/interfaceout/i1445_ELM_Sec_File/data
ls -ld /appl/psft/cny/prd/bpl/datafiles/interfaces/CS/interfaceout/i1445_ELM_Sec_File/archive
ls -ld /appl/psft/cny/prd/bpl/datafiles/interfaces/CS/interfaceout/i1445_ELM_Sec_File/error
