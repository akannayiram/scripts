# CSS PeopleSoft Signon
#bolt script run status_web_global.sh -t cssnpwl001 --no-host-key-check --connect-timeout 600  --tty

crm=/appl/scripts/ams/PERF/pf-crm-wl-servers
css=/appl/scripts/ams/PERF/pf-css-wl-servers
ep=/appl/scripts/ams/PERF/pf-epp-wl-servers
fin=/appl/scripts/ams/PERF/pf-fin-wl-servers
hcm=/appl/scripts/ams/PERF/pf-hcm-wl-servers

bolt script run status_web_global.sh -t @$crm --no-host-key-check --connect-timeout 600  --tty
bolt script run status_web_global.sh -t @$css --no-host-key-check --connect-timeout 600  --tty
bolt script run status_web_global.sh -t @$ep --no-host-key-check --connect-timeout 600  --tty
bolt script run status_web_global.sh -t @$fin --no-host-key-check --connect-timeout 600  --tty
bolt script run status_web_global.sh -t @$hcm --no-host-key-check --connect-timeout 600  --tty
