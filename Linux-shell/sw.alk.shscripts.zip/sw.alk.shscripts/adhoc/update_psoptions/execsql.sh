#!/bin/bash

for i in `cat env.txt`
do
 echo "$i"
 sqlplus /@"$i" @updt.sql > "$i".log 2>&1
done
