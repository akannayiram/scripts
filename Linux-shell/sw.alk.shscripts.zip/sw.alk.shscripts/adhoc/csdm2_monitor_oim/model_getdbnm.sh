#!/bin/bash 

# ################################################
# To execute SQL commands on workbench
# sqlplus options:
#   -L  Attempts to log on just once, 
#       instead of reprompting on error.
#   -S  Silent mode which suppresses 
#       the display of the sqlplus banner, 
#       prompts, and echoing of commands.
# 
# al kannayiram Nov 2024
# 
# ################################################

#DB=CNYCSDM2
DB=$1
OUT=/tmp/alk.tmp.$$; rm -f $OUT

sqlplus -S -L /@CNYCSDM2 <<!EOF > $OUT
set head off feed off
select * from ps.psdbowner;
exit;
!EOF
cat $OUT

#sqlcmd="$(sqlplus -S -L /@CNYCSDM2 <<!EOF
sqlcmd="$(sqlplus -S -L /@\"${DB}\" <<!EOF
set head off feed off
select count(*) from ps.psdbowner;
exit;
!EOF
)"
cnt=$(echo "$sqlcmd")
echo $cnt
