#!/bin/bash 

# ################################################
# To execute SQL commands on workbench
# sqlplus options:
#   -L  Attempts to log on just once, 
#       instead of reprompting on error.
#   -S  Silent mode which suppresses 
#       the display of the sqlplus banner, 
#       prompts, and echoing of commands.
# 
# al kannayiram Nov 2024
# 
# ################################################

#DB=CNYCSDM2
CONN="sysadm/nSzgY3Yx@//oradb-prod-SCAN.Cf.CUNY.Edu:3200/CNYCSPRD_HUD"
OUT=CSPRD_log_oim_node_checks.txt
echo "######################" >> $OUT
date >> $OUT

#sqlcmd="$(sqlplus -S -L /@\"${DB}\" <<!EOF
sqlcmd="$(sqlplus -S -L ${CONN} <<!EOF
set head off feed off
select count(MSGNODENAME) from PSNODESDOWN;
exit;
!EOF
)"
cnt=$(echo "$sqlcmd"|sed -e "/^$/d"|awk '{print $1}')
#echo "Count of Nodes down: $cnt" >> $OUT
echo "Count of problem OIM Service Ops: $cnt" >> $OUT
tail -3 $OUT
