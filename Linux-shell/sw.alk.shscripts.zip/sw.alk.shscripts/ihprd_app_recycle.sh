#!/bin/bash
echo " "
date
echo "Server Status"
echo "=========================="
psadmin -c sstatus -d CNYIHPR1
echo " "
date
echo "Server Stop"
echo "=========================="
psadmin -c stop -d CNYIHPR1
echo " "
date
echo "Cache Purge"
echo "=========================="
psadmin -c purge -d CNYIHPR1 -noarch
echo " "
date
echo "Server Start"
echo "=========================="
psadmin -c start -d CNYIHPR1

# Saving these lines for easy copy and paste
# /software/akannayiram/ihprd_app_recycle.sh | tee -a /tmp/$HOSTNAME.$USER.ihprd_app_recycle.$(date '+%Y%m%d_%H%M%S').log 
# cat /software/akannayiram/ihprd_app_recycle.sh | sed -e "s/PR1/AM1/"
# cat /software/akannayiram/ihprd_app_recycle.sh | sed -e "s/PR1/IM1/"
